import * as i0 from '@angular/core';
import { input, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RadioButton, RadioGroup } from '@ngstarter/components/radio';
import { Error, Hint } from '@ngstarter/components/form-field';

class RadioGroupField {
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    getErrorMessage() {
        const errors = this.control().errors;
        if (!errors) {
            return '';
        }
        const errorKey = Object.keys(errors)[0];
        const validator = this.config().validators?.find((v) => v.type === errorKey);
        return validator?.message || 'Invalid value';
    }
    get options() {
        return this.config().payload?.['options'] || [];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: RadioGroupField, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: RadioGroupField, isStandalone: true, selector: "ngs-radio-group-field", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, exportAs: ["ngsRadioGroupField"], ngImport: i0, template: "@if (control() && config()) {\n  <div class=\"radio-group-container\">\n    @if (config().label) {\n      <div class=\"radio-group-label\">{{ config().label }}</div>\n    }\n    <ngs-radio-group\n      [formControl]=\"control()\"\n      [class.inline]=\"config().inline\">\n      @for (option of options; track option.value) {\n        <ngs-radio-button [value]=\"option.value\">{{ option.label }}</ngs-radio-button>\n      }\n    </ngs-radio-group>\n    @if (config().hint && (control().valid || control().invalid && !control().touched)) {\n      <ngs-hint>{{ config().hint }}</ngs-hint>\n    }\n    @if (control().invalid && control().touched) {\n      <ngs-error>{{ getErrorMessage() }}</ngs-error>\n    }\n  </div>\n}\n", styles: [":host{display:block;margin-bottom:calc(var(--spacing, .25rem) * 6)}:host .radio-group-label{display:block;color:var(--ngs-form-field-outlined-label-text-color);font-size:calc(var(--ngs-form-field-outlined-label-text-size) * .75)}:host ngs-radio-group{display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 1)}:host ngs-radio-group.inline{flex-direction:row;flex-wrap:wrap;align-items:center;gap:calc(var(--spacing, .25rem) * 4)}:host ngs-hint{display:block;font-size:var(--ngs-form-field-subscript-text-size, .75rem)}:host ngs-error{display:block;font-size:var(--ngs-form-field-subscript-text-size, .75rem);letter-spacing:var(--ngs-form-field-subscript-text-tracking, normal);font-weight:var(--ngs-form-field-subscript-text-weight, 400)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: RadioButton, selector: "ngs-radio-button", inputs: ["id", "value", "name", "checked", "disabled"], outputs: ["checkedChange", "change"] }, { kind: "component", type: RadioGroup, selector: "ngs-radio-group", inputs: ["disabled", "name", "value"], outputs: ["disabledChange", "valueChange", "change"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: Error, selector: "ngs-error" }, { kind: "component", type: Hint, selector: "ngs-hint", inputs: ["align"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: RadioGroupField, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-radio-group-field', exportAs: 'ngsRadioGroupField', imports: [
                        RadioButton,
                        RadioGroup,
                        ReactiveFormsModule,
                        Error,
                        Hint,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (control() && config()) {\n  <div class=\"radio-group-container\">\n    @if (config().label) {\n      <div class=\"radio-group-label\">{{ config().label }}</div>\n    }\n    <ngs-radio-group\n      [formControl]=\"control()\"\n      [class.inline]=\"config().inline\">\n      @for (option of options; track option.value) {\n        <ngs-radio-button [value]=\"option.value\">{{ option.label }}</ngs-radio-button>\n      }\n    </ngs-radio-group>\n    @if (config().hint && (control().valid || control().invalid && !control().touched)) {\n      <ngs-hint>{{ config().hint }}</ngs-hint>\n    }\n    @if (control().invalid && control().touched) {\n      <ngs-error>{{ getErrorMessage() }}</ngs-error>\n    }\n  </div>\n}\n", styles: [":host{display:block;margin-bottom:calc(var(--spacing, .25rem) * 6)}:host .radio-group-label{display:block;color:var(--ngs-form-field-outlined-label-text-color);font-size:calc(var(--ngs-form-field-outlined-label-text-size) * .75)}:host ngs-radio-group{display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 1)}:host ngs-radio-group.inline{flex-direction:row;flex-wrap:wrap;align-items:center;gap:calc(var(--spacing, .25rem) * 4)}:host ngs-hint{display:block;font-size:var(--ngs-form-field-subscript-text-size, .75rem)}:host ngs-error{display:block;font-size:var(--ngs-form-field-subscript-text-size, .75rem);letter-spacing:var(--ngs-form-field-subscript-text-tracking, normal);font-weight:var(--ngs-form-field-subscript-text-weight, 400)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }] } });

export { RadioGroupField };
//# sourceMappingURL=ngstarter-components-form-renderer-radio-group-field-BWoY3Eog.mjs.map
