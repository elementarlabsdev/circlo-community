import * as i0 from '@angular/core';
import { inject, ChangeDetectorRef, input, booleanAttribute, model, output, ChangeDetectionStrategy, Component, contentChildren } from '@angular/core';
import { toObservable, outputToObservable } from '@angular/core/rxjs-interop';
import { Subject, startWith, switchMap, of, merge, takeUntil } from 'rxjs';

let nextId = 0;
class ExpansionPanel {
    _cdr = inject(ChangeDetectorRef);
    accordion = inject(Accordion, { optional: true });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    expanded = model(false, ...(ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []));
    hideToggle = input(false, { ...(ngDevMode ? { debugName: "hideToggle" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    opened = output();
    closed = output();
    expandedChange = output();
    id = `ngs-expansion-panel-${nextId++}`;
    headerId = `ngs-expansion-panel-header-${nextId++}`;
    toggle() {
        if (this.expanded()) {
            this.close();
        }
        else {
            this.open();
        }
    }
    open() {
        if (!this.expanded()) {
            this.expanded.set(true);
            this.opened.emit();
            this._emitExpansionChange();
        }
    }
    close() {
        if (this.expanded()) {
            this.expanded.set(false);
            this.closed.emit();
            this._emitExpansionChange();
        }
    }
    _emitExpansionChange() {
        this.expandedChange.emit(this.expanded());
        this._cdr.markForCheck();
    }
    _getHideToggle() {
        return this.hideToggle() || (this.accordion?.hideToggle() ?? false);
    }
    _getExpandedState() {
        return this.expanded() ? 'expanded' : 'collapsed';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: ExpansionPanel, isStandalone: true, selector: "ngs-expansion-panel", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, expanded: { classPropertyName: "expanded", publicName: "expanded", isSignal: true, isRequired: false, transformFunction: null }, hideToggle: { classPropertyName: "hideToggle", publicName: "hideToggle", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { expanded: "expandedChange", opened: "opened", closed: "closed", expandedChange: "expandedChange" }, host: { properties: { "class.ngs-expanded": "expanded()", "class.ngs-expansion-panel-disabled": "disabled()", "attr.id": "id" }, classAttribute: "ngs-expansion-panel" }, exportAs: ["ngsExpansionPanel"], ngImport: i0, template: "<ng-content select=\"ngs-expansion-panel-header\"/>\n<div class=\"ngs-expansion-panel-content\"\n     role=\"region\"\n     [class.ngs-expanded]=\"expanded()\"\n     [attr.id]=\"id\"\n     [attr.aria-labelledby]=\"headerId\"\n     [attr.aria-hidden]=\"!expanded()\"\n     (click)=\"$event.stopPropagation()\">\n  <div class=\"ngs-expansion-panel-body\">\n    <ng-content/>\n  </div>\n  <ng-content select=\"ngs-action-row\"/>\n</div>\n", styles: [":host{--ngs-expansion-panel-background: var(--color-surface);--ngs-expansion-panel-color: var(--color-on-surface);--ngs-expansion-panel-divider-color: var(--color-subtle);--ngs-expansion-panel-disabled-color: var(--color-neutral-300);--ngs-expansion-panel-header-height: calc(var(--spacing, .25rem) * 14);--ngs-expansion-panel-header-expanded-height: calc(var(--spacing, .25rem) * 16);--ngs-expansion-panel-content-padding: 3px 24px 16px 24px;--ngs-expansion-panel-radius: .75rem;--ngs-expansion-panel-description-color: var(--color-on-surface-variant);margin-bottom:-1px}:host:first-of-type{border-top-left-radius:var(--ngs-expansion-panel-radius);border-top-right-radius:var(--ngs-expansion-panel-radius)}:host:last-of-type{border-bottom-left-radius:var(--ngs-expansion-panel-radius);border-bottom-right-radius:var(--ngs-expansion-panel-radius)}:host.ngs-expanded{border-top:1px solid var(--ngs-expansion-panel-divider-color, rgba(0, 0, 0, .12));border-bottom:1px solid var(--ngs-expansion-panel-divider-color, rgba(0, 0, 0, .12));border-radius:var(--ngs-expansion-panel-radius)}:host.ngs-expanded+ngs-expansion-panel{border-top-left-radius:var(--ngs-expansion-panel-radius);border-top-right-radius:var(--ngs-expansion-panel-radius)}:host{display:block;background:var(--ngs-expansion-panel-background);color:var(--ngs-expansion-panel-color);border:1px solid var(--ngs-expansion-panel-divider-color);overflow:hidden}:host.ngs-expanded{margin:16px 0}:host.ngs-expanded:first-of-type{margin-top:0}:host.ngs-expanded:last-of-type{margin-bottom:0}:host.ngs-expansion-panel-disabled{--ngs-expansion-panel-description-color: var(--ngs-expansion-panel-disabled-color);color:var(--ngs-expansion-panel-disabled-color);pointer-events:none}:host .ngs-expansion-panel-content{display:grid;grid-template-rows:0fr;transition:grid-template-rows 225ms cubic-bezier(.4,0,.2,1);visibility:hidden;overflow:hidden;height:0}:host.ngs-expanded :host .ngs-expansion-panel-content{grid-template-rows:1fr;visibility:visible}:host .ngs-expansion-panel-content.ngs-expanded{grid-template-rows:1fr;visibility:visible;height:auto}:host .ngs-expansion-panel-content>div{overflow:hidden;min-height:0}:host .ngs-expansion-panel-body{padding:var(--ngs-expansion-panel-content-padding)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanel, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-expansion-panel', exportAs: 'ngsExpansionPanel', standalone: true, host: {
                        'class': 'ngs-expansion-panel',
                        '[class.ngs-expanded]': 'expanded()',
                        '[class.ngs-expansion-panel-disabled]': 'disabled()',
                        '[attr.id]': 'id',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content select=\"ngs-expansion-panel-header\"/>\n<div class=\"ngs-expansion-panel-content\"\n     role=\"region\"\n     [class.ngs-expanded]=\"expanded()\"\n     [attr.id]=\"id\"\n     [attr.aria-labelledby]=\"headerId\"\n     [attr.aria-hidden]=\"!expanded()\"\n     (click)=\"$event.stopPropagation()\">\n  <div class=\"ngs-expansion-panel-body\">\n    <ng-content/>\n  </div>\n  <ng-content select=\"ngs-action-row\"/>\n</div>\n", styles: [":host{--ngs-expansion-panel-background: var(--color-surface);--ngs-expansion-panel-color: var(--color-on-surface);--ngs-expansion-panel-divider-color: var(--color-subtle);--ngs-expansion-panel-disabled-color: var(--color-neutral-300);--ngs-expansion-panel-header-height: calc(var(--spacing, .25rem) * 14);--ngs-expansion-panel-header-expanded-height: calc(var(--spacing, .25rem) * 16);--ngs-expansion-panel-content-padding: 3px 24px 16px 24px;--ngs-expansion-panel-radius: .75rem;--ngs-expansion-panel-description-color: var(--color-on-surface-variant);margin-bottom:-1px}:host:first-of-type{border-top-left-radius:var(--ngs-expansion-panel-radius);border-top-right-radius:var(--ngs-expansion-panel-radius)}:host:last-of-type{border-bottom-left-radius:var(--ngs-expansion-panel-radius);border-bottom-right-radius:var(--ngs-expansion-panel-radius)}:host.ngs-expanded{border-top:1px solid var(--ngs-expansion-panel-divider-color, rgba(0, 0, 0, .12));border-bottom:1px solid var(--ngs-expansion-panel-divider-color, rgba(0, 0, 0, .12));border-radius:var(--ngs-expansion-panel-radius)}:host.ngs-expanded+ngs-expansion-panel{border-top-left-radius:var(--ngs-expansion-panel-radius);border-top-right-radius:var(--ngs-expansion-panel-radius)}:host{display:block;background:var(--ngs-expansion-panel-background);color:var(--ngs-expansion-panel-color);border:1px solid var(--ngs-expansion-panel-divider-color);overflow:hidden}:host.ngs-expanded{margin:16px 0}:host.ngs-expanded:first-of-type{margin-top:0}:host.ngs-expanded:last-of-type{margin-bottom:0}:host.ngs-expansion-panel-disabled{--ngs-expansion-panel-description-color: var(--ngs-expansion-panel-disabled-color);color:var(--ngs-expansion-panel-disabled-color);pointer-events:none}:host .ngs-expansion-panel-content{display:grid;grid-template-rows:0fr;transition:grid-template-rows 225ms cubic-bezier(.4,0,.2,1);visibility:hidden;overflow:hidden;height:0}:host.ngs-expanded :host .ngs-expansion-panel-content{grid-template-rows:1fr;visibility:visible}:host .ngs-expansion-panel-content.ngs-expanded{grid-template-rows:1fr;visibility:visible;height:auto}:host .ngs-expansion-panel-content>div{overflow:hidden;min-height:0}:host .ngs-expansion-panel-body{padding:var(--ngs-expansion-panel-content-padding)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], expanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "expanded", required: false }] }, { type: i0.Output, args: ["expandedChange"] }], hideToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideToggle", required: false }] }], opened: [{ type: i0.Output, args: ["opened"] }], closed: [{ type: i0.Output, args: ["closed"] }], expandedChange: [{ type: i0.Output, args: ["expandedChange"] }] } });

class Accordion {
    _destroyed = new Subject();
    _cdr = inject(ChangeDetectorRef);
    /** Whether the accordion should allow multiple expanded panels at a time. */
    multi = input(false, { ...(ngDevMode ? { debugName: "multi" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether the expansion indicator should be hidden. */
    hideToggle = input(false, { ...(ngDevMode ? { debugName: "hideToggle" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _panels = contentChildren(ExpansionPanel, { ...(ngDevMode ? { debugName: "_panels" } : /* istanbul ignore next */ {}), descendants: true });
    _panels$ = toObservable(this._panels);
    ngAfterContentInit() {
        this._panels$.pipe(startWith(this._panels()), switchMap(panels => {
            if (panels.length === 0) {
                return of(null);
            }
            return merge(...panels.map(panel => outputToObservable(panel.expandedChange).pipe(switchMap(expanded => {
                if (expanded && !this.multi()) {
                    this._closeAllExcept(panel);
                }
                this._cdr.markForCheck();
                return of(null);
            }))));
        }), takeUntil(this._destroyed)).subscribe();
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
    }
    openAll() {
        if (this.multi()) {
            this._panels().forEach(p => p.open());
            this._cdr.markForCheck();
        }
    }
    closeAll() {
        this._panels().forEach(p => p.close());
        this._cdr.markForCheck();
    }
    _closeAllExcept(panel) {
        this._panels().forEach(p => {
            if (p !== panel) {
                p.close();
            }
        });
        this._cdr.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Accordion, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: Accordion, isStandalone: true, selector: "ngs-accordion", inputs: { multi: { classPropertyName: "multi", publicName: "multi", isSignal: true, isRequired: false, transformFunction: null }, hideToggle: { classPropertyName: "hideToggle", publicName: "hideToggle", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ngs-accordion-multi": "multi()" }, classAttribute: "ngs-accordion not-prose" }, queries: [{ propertyName: "_panels", predicate: ExpansionPanel, descendants: true, isSignal: true }], exportAs: ["ngsAccordion"], ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Accordion, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-accordion', exportAs: 'ngsAccordion', standalone: true, host: {
                        'class': 'ngs-accordion not-prose',
                        '[class.ngs-accordion-multi]': 'multi()',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { multi: [{ type: i0.Input, args: [{ isSignal: true, alias: "multi", required: false }] }], hideToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideToggle", required: false }] }], _panels: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ExpansionPanel), { ...{ descendants: true }, isSignal: true }] }] } });

class ExpansionPanelHeader {
    panel = inject(ExpansionPanel);
    _cdr = inject(ChangeDetectorRef);
    hideToggle = input(false, { ...(ngDevMode ? { debugName: "hideToggle" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _toggle() {
        if (!this.panel.disabled()) {
            this.panel.toggle();
            this._cdr.markForCheck();
            if (this.panel.accordion) {
                this.panel.accordion._cdr.markForCheck();
            }
        }
    }
    _getExpandedState() {
        return this.panel._getExpandedState();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanelHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: ExpansionPanelHeader, isStandalone: true, selector: "ngs-expansion-panel-header", inputs: { hideToggle: { classPropertyName: "hideToggle", publicName: "hideToggle", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "button" }, listeners: { "click": "_toggle()", "keydown.enter": "_toggle()", "keydown.space": "_toggle()" }, properties: { "attr.id": "panel.headerId", "attr.tabindex": "panel.disabled() ? -1 : 0", "attr.aria-controls": "panel.id", "attr.aria-expanded": "panel.expanded()", "attr.aria-disabled": "panel.disabled()", "class.ngs-expanded": "panel.expanded()" }, classAttribute: "ngs-expansion-panel-header" }, ngImport: i0, template: "<span class=\"ngs-expansion-panel-header-content\">\n  <ng-content select=\"ngs-panel-title\" />\n  <ng-content select=\"ngs-panel-description\" />\n  <ng-content />\n</span>\n\n@if (!hideToggle() && !panel._getHideToggle()) {\n  <span class=\"ngs-expansion-indicator\">\n    <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -960 960 960\" aria-hidden=\"true\" focusable=\"false\">\n      <path d=\"M480-345 240-585l36-36 204 204 204-204 36 36-240 240Z\"></path>\n    </svg>\n  </span>\n} @else {\n  <span class=\"ngs-expansion-indicator-placeholder\"></span>\n}\n", styles: [":host{display:flex;flex-direction:row;align-items:center;padding:0 24px;border-radius:inherit;transition:height 225ms cubic-bezier(.4,0,.2,1);height:var(--ngs-expansion-panel-header-height, 48px);cursor:pointer;outline:none}:host:hover{background:#0000000a}:host.ngs-expanded{height:var(--ngs-expansion-panel-header-expanded-height, 64px)}:host.ngs-expanded .ngs-expansion-indicator{transform:rotate(180deg)}:host[aria-disabled=true]{cursor:default;background:inherit}:host .ngs-expansion-panel-header-content{display:flex;flex:1;flex-direction:row;align-items:center;overflow:hidden}:host .ngs-expansion-indicator-placeholder{margin-left:0;width:24px;height:24px;display:flex;align-items:center;justify-content:center;flex:none}:host .ngs-expansion-indicator{width:24px;height:24px;transition:transform 225ms cubic-bezier(.4,0,.2,1);position:relative;right:-8px;flex:none}:host .ngs-expansion-indicator svg{fill:currentColor;width:100%;height:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanelHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-expansion-panel-header', standalone: true, host: {
                        'class': 'ngs-expansion-panel-header',
                        'role': 'button',
                        '[attr.id]': 'panel.headerId',
                        '[attr.tabindex]': 'panel.disabled() ? -1 : 0',
                        '[attr.aria-controls]': 'panel.id',
                        '[attr.aria-expanded]': 'panel.expanded()',
                        '[attr.aria-disabled]': 'panel.disabled()',
                        '[class.ngs-expanded]': 'panel.expanded()',
                        '(click)': '_toggle()',
                        '(keydown.enter)': '_toggle()',
                        '(keydown.space)': '_toggle()',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"ngs-expansion-panel-header-content\">\n  <ng-content select=\"ngs-panel-title\" />\n  <ng-content select=\"ngs-panel-description\" />\n  <ng-content />\n</span>\n\n@if (!hideToggle() && !panel._getHideToggle()) {\n  <span class=\"ngs-expansion-indicator\">\n    <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 -960 960 960\" aria-hidden=\"true\" focusable=\"false\">\n      <path d=\"M480-345 240-585l36-36 204 204 204-204 36 36-240 240Z\"></path>\n    </svg>\n  </span>\n} @else {\n  <span class=\"ngs-expansion-indicator-placeholder\"></span>\n}\n", styles: [":host{display:flex;flex-direction:row;align-items:center;padding:0 24px;border-radius:inherit;transition:height 225ms cubic-bezier(.4,0,.2,1);height:var(--ngs-expansion-panel-header-height, 48px);cursor:pointer;outline:none}:host:hover{background:#0000000a}:host.ngs-expanded{height:var(--ngs-expansion-panel-header-expanded-height, 64px)}:host.ngs-expanded .ngs-expansion-indicator{transform:rotate(180deg)}:host[aria-disabled=true]{cursor:default;background:inherit}:host .ngs-expansion-panel-header-content{display:flex;flex:1;flex-direction:row;align-items:center;overflow:hidden}:host .ngs-expansion-indicator-placeholder{margin-left:0;width:24px;height:24px;display:flex;align-items:center;justify-content:center;flex:none}:host .ngs-expansion-indicator{width:24px;height:24px;transition:transform 225ms cubic-bezier(.4,0,.2,1);position:relative;right:-8px;flex:none}:host .ngs-expansion-indicator svg{fill:currentColor;width:100%;height:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { hideToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideToggle", required: false }] }] } });

class ExpansionPanelTitle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanelTitle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: ExpansionPanelTitle, isStandalone: true, selector: "ngs-expansion-panel-title", host: { classAttribute: "ngs-expansion-panel-title" }, exportAs: ["ngsExpansionPanelTitle"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;margin-right:16px;flex-basis:0;flex-grow:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanelTitle, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-expansion-panel-title', exportAs: 'ngsExpansionPanelTitle', host: {
                        'class': 'ngs-expansion-panel-title'
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{display:flex;margin-right:16px;flex-basis:0;flex-grow:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class ExpansionPanelDescription {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanelDescription, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: ExpansionPanelDescription, isStandalone: true, selector: "ngs-expansion-panel-description", host: { classAttribute: "ngs-expansion-panel-description" }, exportAs: ["ngsExpansionPanelDescription"], ngImport: i0, template: "<ng-content />\n", styles: [":host{display:flex;color:var(--ngs-expansion-panel-description-color);align-items:center;justify-content:space-between;flex-basis:0;flex-grow:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ExpansionPanelDescription, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-expansion-panel-description', exportAs: 'ngsExpansionPanelDescription', host: {
                        'class': 'ngs-expansion-panel-description'
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: [":host{display:flex;color:var(--ngs-expansion-panel-description-color);align-items:center;justify-content:space-between;flex-basis:0;flex-grow:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class ActionRow {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ActionRow, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: ActionRow, isStandalone: true, selector: "ngs-action-row", host: { classAttribute: "ngs-action-row" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:flex;flex-direction:row;justify-content:flex-end;padding:calc(var(--spacing, .25rem) * 3);border-top:1px solid var(--ngs-expansion-panel-divider-color, rgba(0, 0, 0, .12));gap:calc(var(--spacing, .25rem) * 3)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ActionRow, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-action-row', standalone: true, imports: [], host: {
                        'class': 'ngs-action-row'
                    }, template: "<ng-content />\n", styles: [":host{display:flex;flex-direction:row;justify-content:flex-end;padding:calc(var(--spacing, .25rem) * 3);border-top:1px solid var(--ngs-expansion-panel-divider-color, rgba(0, 0, 0, .12));gap:calc(var(--spacing, .25rem) * 3)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Accordion, ActionRow, ExpansionPanel, ExpansionPanelDescription, ExpansionPanelHeader, ExpansionPanelTitle };
//# sourceMappingURL=ngstarter-components-expansion.mjs.map
