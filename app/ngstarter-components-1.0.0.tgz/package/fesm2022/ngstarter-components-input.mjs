import * as i0 from '@angular/core';
import { inject, ElementRef, signal, DestroyRef, input, booleanAttribute, computed, effect, forwardRef, Directive } from '@angular/core';
import { NgControl, NgForm, FormGroupDirective } from '@angular/forms';
import { FormFieldControl } from '@ngstarter/components/form-field';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ErrorStateMatcher, AUTOFOCUSABLE } from '@ngstarter/components/core';

class Input {
    elementRef = inject(ElementRef);
    ngControl = inject(NgControl, { optional: true, self: true });
    stateChanges = signal(undefined, ...(ngDevMode ? [{ debugName: "stateChanges" }] : /* istanbul ignore next */ []));
    _destroyRef = inject(DestroyRef);
    _defaultErrorStateMatcher = inject(ErrorStateMatcher);
    _parentForm = inject(NgForm, { optional: true });
    _parentFormGroup = inject(FormGroupDirective, { optional: true });
    _id = input(`ngs-input-${nextUniqueId++}`, { ...(ngDevMode ? { debugName: "_id" } : /* istanbul ignore next */ {}), alias: 'id' });
    get id() { return this._id(); }
    _placeholder = input('', { ...(ngDevMode ? { debugName: "_placeholder" } : /* istanbul ignore next */ {}), alias: 'placeholder' });
    get placeholder() { return this._placeholder(); }
    _required = input(false, { ...(ngDevMode ? { debugName: "_required" } : /* istanbul ignore next */ {}), transform: booleanAttribute, alias: 'required' });
    get required() { return this._required(); }
    _disabled = input(false, { ...(ngDevMode ? { debugName: "_disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute, alias: 'disabled' });
    get disabled() { return this._disabled(); }
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    errorStateMatcher = input(...(ngDevMode ? [undefined, { debugName: "errorStateMatcher" }] : /* istanbul ignore next */ []));
    _value = signal('', ...(ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []));
    get value() {
        return this._value();
    }
    set value(value) {
        this._value.set(value);
        this.elementRef.nativeElement.value = value;
    }
    focusedValue = false;
    _focused = signal(false, ...(ngDevMode ? [{ debugName: "_focused" }] : /* istanbul ignore next */ []));
    get focused() { return this._focused(); }
    errorStateValue = false;
    _errorState = signal(false, ...(ngDevMode ? [{ debugName: "_errorState" }] : /* istanbul ignore next */ []));
    get errorState() { return this._errorState(); }
    isRequired = computed(() => {
        if (this._required()) {
            return true;
        }
        const control = this.ngControl?.control;
        if (control && control.validator) {
            const validator = control.validator({});
            if (validator && validator['required']) {
                return true;
            }
        }
        return false;
    }, ...(ngDevMode ? [{ debugName: "isRequired" }] : /* istanbul ignore next */ []));
    emptyValue = true;
    _empty = computed(() => !this._value(), ...(ngDevMode ? [{ debugName: "_empty" }] : /* istanbul ignore next */ []));
    get empty() { return this._empty(); }
    shouldLabelFloatValue = false;
    _shouldLabelFloat = computed(() => {
        return !!this._value() || this._focused();
    }, ...(ngDevMode ? [{ debugName: "_shouldLabelFloat" }] : /* istanbul ignore next */ []));
    get shouldLabelFloat() { return this._shouldLabelFloat(); }
    constructor() {
        effect(() => {
            this.focusedValue = this._focused();
            this.errorStateValue = this._errorState();
            this.emptyValue = this._empty();
            this.shouldLabelFloatValue = this._shouldLabelFloat();
        });
    }
    ngOnInit() {
        this._value.set(this.elementRef.nativeElement.value);
        this.ngControl?.statusChanges?.pipe(takeUntilDestroyed(this._destroyRef)).subscribe(() => {
            this.updateErrorState();
        });
    }
    ngDoCheck() {
        if (this._value() !== this.elementRef.nativeElement.value) {
            this._value.set(this.elementRef.nativeElement.value);
        }
        this.updateErrorState();
    }
    updateErrorState() {
        const oldState = this._errorState();
        const parent = this._parentFormGroup || this._parentForm;
        const matcher = this.errorStateMatcher() || this._defaultErrorStateMatcher;
        const control = this.ngControl ? this.ngControl.control : null;
        const newState = matcher.isErrorState(control, parent);
        if (newState !== oldState) {
            this._errorState.set(newState);
        }
    }
    onFocus() {
        this._focused.set(true);
    }
    onBlur() {
        this._focused.set(false);
        this.updateErrorState();
    }
    onInput(event) {
        this._value.set(event.target.value);
    }
    focus() {
        this.elementRef.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Input, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: Input, isStandalone: true, selector: "input[ngsInput], textarea[ngsInput]", inputs: { _id: { classPropertyName: "_id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, _placeholder: { classPropertyName: "_placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, _required: { classPropertyName: "_required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, _disabled: { classPropertyName: "_disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, errorStateMatcher: { classPropertyName: "errorStateMatcher", publicName: "errorStateMatcher", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "focus": "onFocus()", "blur": "onBlur()", "input": "onInput($event)" }, properties: { "attr.id": "id", "attr.placeholder": "placeholder", "disabled": "disabled", "required": "required", "attr.readonly": "readonly() || null", "class.ngs-input-floating": "shouldLabelFloat" }, classAttribute: "ngs-input" }, providers: [
            {
                provide: FormFieldControl,
                useExisting: forwardRef(() => Input)
            },
            {
                provide: AUTOFOCUSABLE,
                useExisting: forwardRef(() => Input)
            }
        ], exportAs: ["ngsInput"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Input, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[ngsInput], textarea[ngsInput]',
                    exportAs: 'ngsInput',
                    host: {
                        'class': 'ngs-input',
                        '[attr.id]': 'id',
                        '[attr.placeholder]': 'placeholder',
                        '[disabled]': 'disabled',
                        '[required]': 'required',
                        '[attr.readonly]': 'readonly() || null',
                        '[class.ngs-input-floating]': 'shouldLabelFloat',
                        '(focus)': 'onFocus()',
                        '(blur)': 'onBlur()',
                        '(input)': 'onInput($event)',
                    },
                    providers: [
                        {
                            provide: FormFieldControl,
                            useExisting: forwardRef(() => Input)
                        },
                        {
                            provide: AUTOFOCUSABLE,
                            useExisting: forwardRef(() => Input)
                        }
                    ]
                }]
        }], ctorParameters: () => [], propDecorators: { _id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], _placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], _required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], _disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], errorStateMatcher: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorStateMatcher", required: false }] }] } });
let nextUniqueId = 0;

/**
 * Generated bundle index. Do not edit.
 */

export { Input };
//# sourceMappingURL=ngstarter-components-input.mjs.map
