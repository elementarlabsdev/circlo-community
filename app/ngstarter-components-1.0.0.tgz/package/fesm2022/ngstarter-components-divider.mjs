import * as i0 from '@angular/core';
import { Component, input, booleanAttribute } from '@angular/core';

class TextDivider {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextDivider, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TextDivider, isStandalone: true, selector: "ngs-text-divider", host: { classAttribute: "ngs-text-divider" }, exportAs: ["ngsTextDivider"], ngImport: i0, template: "<div class=\"line-start\"></div>\n<div class=\"text\">\n  <ng-content/>\n</div>\n<div class=\"line-end\"></div>\n", styles: [":host{display:flex;width:100%;align-items:center;gap:calc(var(--spacing, .25rem) * 4);flex-wrap:nowrap}:host .text{white-space:nowrap}:host .line-start{position:relative;flex-grow:1}:host .line-start:before{content:\"\";position:absolute;height:1px;background:var(--color-border);top:50%;width:100%}:host .line-end{position:relative;flex-grow:1}:host .line-end:before{content:\"\";position:absolute;height:1px;background:var(--color-border);top:50%;width:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextDivider, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-divider', exportAs: 'ngsTextDivider', host: {
                        'class': 'ngs-text-divider',
                    }, template: "<div class=\"line-start\"></div>\n<div class=\"text\">\n  <ng-content/>\n</div>\n<div class=\"line-end\"></div>\n", styles: [":host{display:flex;width:100%;align-items:center;gap:calc(var(--spacing, .25rem) * 4);flex-wrap:nowrap}:host .text{white-space:nowrap}:host .line-start{position:relative;flex-grow:1}:host .line-start:before{content:\"\";position:absolute;height:1px;background:var(--color-border);top:50%;width:100%}:host .line-end{position:relative;flex-grow:1}:host .line-end:before{content:\"\";position:absolute;height:1px;background:var(--color-border);top:50%;width:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class Divider {
    /** Whether the divider is vertically aligned. */
    vertical = input(false, { ...(ngDevMode ? { debugName: "vertical" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether the divider is an inset divider. */
    inset = input(false, { ...(ngDevMode ? { debugName: "inset" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fixedHeight = input(false, { ...(ngDevMode ? { debugName: "fixedHeight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Divider, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: Divider, isStandalone: true, selector: "ngs-divider", inputs: { vertical: { classPropertyName: "vertical", publicName: "vertical", isSignal: true, isRequired: false, transformFunction: null }, inset: { classPropertyName: "inset", publicName: "inset", isSignal: true, isRequired: false, transformFunction: null }, fixedHeight: { classPropertyName: "fixedHeight", publicName: "fixedHeight", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "separator" }, properties: { "attr.aria-orientation": "vertical() ? \"vertical\" : \"horizontal\"", "class.ngs-divider-vertical": "vertical()", "class.ngs-divider-horizontal": "!vertical()", "class.ngs-divider-inset": "inset()", "class.is-fixed-height": "fixedHeight()" }, classAttribute: "ngs-divider" }, exportAs: ["ngsDivider"], ngImport: i0, template: '', isInline: true, styles: [":host{--ngs-divider-vertical-fixed-height: calc(var(--spacing, .25rem) * 5);display:block;border-top-style:solid;border-top-color:var(--color-border);flex:none}:host.ngs-divider-horizontal{border-top-width:1px}:host.ngs-divider-horizontal.ngs-divider-inset{margin-left:80px}[dir=rtl] :host.ngs-divider-horizontal.ngs-divider-inset{margin-left:0;margin-right:80px}:host.ngs-divider-vertical{display:inline-block;border-top-width:0;border-right-style:solid;border-right-color:var(--color-border);border-right-width:1px;vertical-align:middle;height:100%}:host.ngs-divider-vertical.ngs-divider-inset{margin-top:8px;margin-bottom:8px}:host.ngs-divider-vertical.is-fixed-height:not([class*=h-]){height:var(--ngs-divider-vertical-fixed-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Divider, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-divider', exportAs: 'ngsDivider', template: '', host: {
                        'role': 'separator',
                        'class': 'ngs-divider',
                        '[attr.aria-orientation]': 'vertical() ? "vertical" : "horizontal"',
                        '[class.ngs-divider-vertical]': 'vertical()',
                        '[class.ngs-divider-horizontal]': '!vertical()',
                        '[class.ngs-divider-inset]': 'inset()',
                        '[class.is-fixed-height]': 'fixedHeight()',
                    }, styles: [":host{--ngs-divider-vertical-fixed-height: calc(var(--spacing, .25rem) * 5);display:block;border-top-style:solid;border-top-color:var(--color-border);flex:none}:host.ngs-divider-horizontal{border-top-width:1px}:host.ngs-divider-horizontal.ngs-divider-inset{margin-left:80px}[dir=rtl] :host.ngs-divider-horizontal.ngs-divider-inset{margin-left:0;margin-right:80px}:host.ngs-divider-vertical{display:inline-block;border-top-width:0;border-right-style:solid;border-right-color:var(--color-border);border-right-width:1px;vertical-align:middle;height:100%}:host.ngs-divider-vertical.ngs-divider-inset{margin-top:8px;margin-bottom:8px}:host.ngs-divider-vertical.is-fixed-height:not([class*=h-]){height:var(--ngs-divider-vertical-fixed-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { vertical: [{ type: i0.Input, args: [{ isSignal: true, alias: "vertical", required: false }] }], inset: [{ type: i0.Input, args: [{ isSignal: true, alias: "inset", required: false }] }], fixedHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "fixedHeight", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { Divider, TextDivider };
//# sourceMappingURL=ngstarter-components-divider.mjs.map
