import * as i0 from '@angular/core';
import { input, Component } from '@angular/core';
import * as i1 from '@angular/platform-browser';

class TextContent {
    sanitizer;
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    sanitizedHtml = '';
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    ngOnInit() {
        this.sanitizedHtml = this.sanitizer.bypassSecurityTrustHtml(this.config().content?.['htmlContent'] || '');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextContent, deps: [{ token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: TextContent, isStandalone: true, selector: "ngs-text-content", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<div [innerHTML]=\"sanitizedHtml\"></div>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-content', imports: [], template: "<div [innerHTML]=\"sanitizedHtml\"></div>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [{ type: i1.DomSanitizer }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }] } });

export { TextContent };
//# sourceMappingURL=ngstarter-components-form-renderer-text-content-BjzH_M3-.mjs.map
