import * as i0 from '@angular/core';
import { InjectionToken, inject, PLATFORM_ID, DestroyRef, NgZone, ElementRef, signal, computed, afterNextRender, effect, input, booleanAttribute, model, forwardRef, ChangeDetectionStrategy, Component, contentChildren, output, TemplateRef, ViewContainerRef, Directive } from '@angular/core';
import { toObservable, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { BreakpointObserver } from '@angular/cdk/layout';
import { combineLatest, switchMap, of, distinctUntilChanged } from 'rxjs';
import { DOCUMENT } from '@angular/common';

const SIDENAV = new InjectionToken('SIDENAV');

class Sidenav {
    _platformId = inject(PLATFORM_ID);
    _breakpointObserver = inject(BreakpointObserver);
    _destroyRef = inject(DestroyRef);
    _ngZone = inject(NgZone);
    _elementRef = inject(ElementRef);
    isHovered = signal(false, ...(ngDevMode ? [{ debugName: "isHovered" }] : /* istanbul ignore next */ []));
    _isSettled = signal(false, ...(ngDevMode ? [{ debugName: "_isSettled" }] : /* istanbul ignore next */ []));
    _isBreakpointMatched = signal(false, ...(ngDevMode ? [{ debugName: "_isBreakpointMatched" }] : /* istanbul ignore next */ []));
    _previousOpened = null;
    /** Indicates whether the sidenav is in mobile (adaptive) mode. */
    isMobile = computed(() => this.adaptive() && this._isBreakpointMatched(), ...(ngDevMode ? [{ debugName: "isMobile" }] : /* istanbul ignore next */ []));
    effectiveMode = computed(() => {
        if (this.isMobile()) {
            return 'over';
        }
        return this.mode();
    }, ...(ngDevMode ? [{ debugName: "effectiveMode" }] : /* istanbul ignore next */ []));
    constructor() {
        afterNextRender(() => {
            this._ngZone.runOutsideAngular(() => {
                setTimeout(() => {
                    this._isSettled.set(true);
                }, 100);
            });
        });
        combineLatest([
            toObservable(this.adaptive),
            toObservable(this.adaptiveBreakpoint)
        ]).pipe(switchMap(([adaptive, breakpoint]) => {
            if (!adaptive) {
                return of(false);
            }
            return this._breakpointObserver.observe(breakpoint).pipe(switchMap(result => of(result.matches)));
        }), distinctUntilChanged(), takeUntilDestroyed(this._destroyRef)).subscribe((matches) => {
            this._isBreakpointMatched.set(matches);
            if (matches) {
                this._previousOpened = this.opened();
                this.opened.set(false);
            }
            else {
                if (this._previousOpened !== null) {
                    this.opened.set(this._previousOpened);
                    this._previousOpened = null;
                }
            }
        });
        effect(() => {
            const isOpened = this.opened();
            const isMatched = this._isBreakpointMatched();
            if (!isMatched) {
                this._previousOpened = isOpened;
            }
        });
    }
    adaptive = input(true, { ...(ngDevMode ? { debugName: "adaptive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    adaptiveBreakpoint = input('(max-width: 991.98px)', ...(ngDevMode ? [{ debugName: "adaptiveBreakpoint" }] : /* istanbul ignore next */ []));
    opened = model(false, ...(ngDevMode ? [{ debugName: "opened" }] : /* istanbul ignore next */ []));
    fixedWidth = input(null, ...(ngDevMode ? [{ debugName: "fixedWidth" }] : /* istanbul ignore next */ []));
    mode = input('over', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    position = input('start', ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    collapsed = input(false, { ...(ngDevMode ? { debugName: "collapsed" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disableClose = input(false, { ...(ngDevMode ? { debugName: "disableClose" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    open() {
        return this.toggle(true);
    }
    close() {
        return this.toggle(false);
    }
    toggle(isOpen = !this.opened()) {
        this.opened.set(isOpen);
        return Promise.resolve();
    }
    _getWidth() {
        if (this.fixedWidth() !== null && this.fixedWidth() !== undefined) {
            return typeof this.fixedWidth() === 'number' ? this.fixedWidth() : parseInt(this.fixedWidth(), 10);
        }
        if (this._elementRef.nativeElement && this._elementRef.nativeElement.offsetWidth > 0) {
            return this._elementRef.nativeElement.offsetWidth;
        }
        return 280;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Sidenav, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: Sidenav, isStandalone: true, selector: "ngs-sidenav", inputs: { adaptive: { classPropertyName: "adaptive", publicName: "adaptive", isSignal: true, isRequired: false, transformFunction: null }, adaptiveBreakpoint: { classPropertyName: "adaptiveBreakpoint", publicName: "adaptiveBreakpoint", isSignal: true, isRequired: false, transformFunction: null }, opened: { classPropertyName: "opened", publicName: "opened", isSignal: true, isRequired: false, transformFunction: null }, fixedWidth: { classPropertyName: "fixedWidth", publicName: "fixedWidth", isSignal: true, isRequired: false, transformFunction: null }, mode: { classPropertyName: "mode", publicName: "mode", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null }, disableClose: { classPropertyName: "disableClose", publicName: "disableClose", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { opened: "openedChange" }, host: { listeners: { "mouseenter": "isHovered.set(true)", "mouseleave": "isHovered.set(false)" }, properties: { "class.ngs-sidenav-closed": "!opened()", "class.ngs-sidenav-opened": "opened()", "class.ngs-sidenav-push": "effectiveMode() === \"push\"", "class.ngs-sidenav-side": "effectiveMode() === \"side\"", "class.ngs-sidenav-over": "effectiveMode() === \"over\"", "class.ngs-sidenav-end": "position() === \"end\"", "class.is-settled": "_isSettled()", "class.is-collapsed": "collapsed()", "attr.tabindex": "-1" }, classAttribute: "ngs-sidenav" }, providers: [
            {
                provide: SIDENAV,
                useExisting: forwardRef(() => Sidenav),
            }
        ], exportAs: ["ngsSidenav"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{--ngs-sidenav-background-color: var(--color-background);--ngs-sidenav-divider-color: rgba(0, 0, 0, .12);--ngs-sidenav-z-index: 5;--ngs-sidenav-transition-duration: .4s;--ngs-sidenav-transition-timing-function: cubic-bezier(.25, .8, .25, 1);display:block;position:absolute;top:0;bottom:0;z-index:var(--ngs-sidenav-z-index);outline:0;box-sizing:border-box;overflow-y:auto;transform:translate3d(-100%,0,0);width:var(--ngs-sidenav-width);background:var(--ngs-sidenav-background-color)}:host.is-settled{transition:transform var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function)}:host.ngs-sidenav-end{right:0;transform:translate3d(100%,0,0)}:host.ngs-sidenav-opened{transform:translateZ(0)}:host.is-collapsed{width:var(--ngs-sidenav-collapsed-width)}:host:hover{width:var(--ngs-sidenav-width)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Sidenav, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidenav', exportAs: 'ngsSidenav', standalone: true, imports: [], providers: [
                        {
                            provide: SIDENAV,
                            useExisting: forwardRef(() => Sidenav),
                        }
                    ], host: {
                        'class': 'ngs-sidenav',
                        '[class.ngs-sidenav-closed]': '!opened()',
                        '[class.ngs-sidenav-opened]': 'opened()',
                        '[class.ngs-sidenav-push]': 'effectiveMode() === "push"',
                        '[class.ngs-sidenav-side]': 'effectiveMode() === "side"',
                        '[class.ngs-sidenav-over]': 'effectiveMode() === "over"',
                        '[class.ngs-sidenav-end]': 'position() === "end"',
                        '[class.is-settled]': '_isSettled()',
                        '[class.is-collapsed]': 'collapsed()',
                        '[attr.tabindex]': '-1',
                        '(mouseenter)': 'isHovered.set(true)',
                        '(mouseleave)': 'isHovered.set(false)',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{--ngs-sidenav-background-color: var(--color-background);--ngs-sidenav-divider-color: rgba(0, 0, 0, .12);--ngs-sidenav-z-index: 5;--ngs-sidenav-transition-duration: .4s;--ngs-sidenav-transition-timing-function: cubic-bezier(.25, .8, .25, 1);display:block;position:absolute;top:0;bottom:0;z-index:var(--ngs-sidenav-z-index);outline:0;box-sizing:border-box;overflow-y:auto;transform:translate3d(-100%,0,0);width:var(--ngs-sidenav-width);background:var(--ngs-sidenav-background-color)}:host.is-settled{transition:transform var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function)}:host.ngs-sidenav-end{right:0;transform:translate3d(100%,0,0)}:host.ngs-sidenav-opened{transform:translateZ(0)}:host.is-collapsed{width:var(--ngs-sidenav-collapsed-width)}:host:hover{width:var(--ngs-sidenav-width)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { adaptive: [{ type: i0.Input, args: [{ isSignal: true, alias: "adaptive", required: false }] }], adaptiveBreakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "adaptiveBreakpoint", required: false }] }], opened: [{ type: i0.Input, args: [{ isSignal: true, alias: "opened", required: false }] }, { type: i0.Output, args: ["openedChange"] }], fixedWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "fixedWidth", required: false }] }], mode: [{ type: i0.Input, args: [{ isSignal: true, alias: "mode", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }], disableClose: [{ type: i0.Input, args: [{ isSignal: true, alias: "disableClose", required: false }] }] } });

class SidenavContainer {
    _ngZone = inject(NgZone);
    _document = inject(DOCUMENT);
    _platformId = inject(PLATFORM_ID);
    _isSettled = signal(false, ...(ngDevMode ? [{ debugName: "_isSettled" }] : /* istanbul ignore next */ []));
    _sidenavs = contentChildren(Sidenav, { ...(ngDevMode ? { debugName: "_sidenavs" } : /* istanbul ignore next */ {}), descendants: true });
    backdropClick = output();
    hasBackdrop = input(true, { ...(ngDevMode ? { debugName: "hasBackdrop" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoFocus = input(true, ...(ngDevMode ? [{ debugName: "autoFocus" }] : /* istanbul ignore next */ []));
    autosize = input(false, { ...(ngDevMode ? { debugName: "autosize" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    fixedWidth = input(null, ...(ngDevMode ? [{ debugName: "fixedWidth" }] : /* istanbul ignore next */ []));
    constructor() {
        afterNextRender(() => {
            this._ngZone.runOutsideAngular(() => {
                setTimeout(() => {
                    this._isSettled.set(true);
                }, 100);
            });
        });
        effect(() => {
            const sidenavs = this._sidenavs();
            sidenavs.forEach(sidenav => {
                if (sidenav.opened()) {
                    this._focusSidenav(sidenav);
                }
            });
        });
    }
    _focusSidenav(sidenav) {
        const autoFocus = this.autoFocus();
        if (autoFocus === false) {
            return;
        }
        this._ngZone.runOutsideAngular(() => {
            setTimeout(() => {
                const element = sidenav._elementRef.nativeElement;
                if (autoFocus === 'dialog' || autoFocus === true) {
                    element.focus();
                }
                else if (autoFocus === 'first-tabbable') {
                    const firstTabbable = element.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                    firstTabbable?.focus();
                }
                else if (typeof autoFocus === 'string' && autoFocus.length > 0) {
                    const selectedElement = element.querySelector(autoFocus);
                    selectedElement?.focus();
                }
            });
        });
    }
    _isShowingBackdrop() {
        const hasAdaptiveOver = this._sidenavs()?.some(sidenav => sidenav.opened() &&
            sidenav.adaptive() &&
            sidenav._isBreakpointMatched());
        return (this.hasBackdrop() || hasAdaptiveOver) && this._sidenavs()?.some(sidenav => sidenav.opened() && sidenav.effectiveMode() !== 'side');
    }
    _onBackdropClicked() {
        this.backdropClick.emit();
        this._sidenavs().forEach(sidenav => {
            if (sidenav.opened()) {
                if (!sidenav.disableClose()) {
                    sidenav.close();
                }
            }
        });
    }
    _getContentMarginLeft() {
        if (!this.autosize()) {
            const startSidenav = this._sidenavs()?.find(s => s.position() === 'start' && s.opened());
            if (startSidenav) {
                if (this.fixedWidth() !== null && this.fixedWidth() !== undefined) {
                    return `${parseInt(this.fixedWidth(), 10)}px`;
                }
                if (startSidenav.collapsed()) {
                    return 'var(--ngs-sidenav-collapsed-width)';
                }
                if (startSidenav.mode() === 'push' || startSidenav.effectiveMode() === 'side') {
                    return 'var(--ngs-sidenav-width)';
                }
            }
            return '0px';
        }
        // Logic for autosize would typically involve a MutationObserver or ResizeObserver
        // but the current implementation already uses functions in host bindings which are
        // re-evaluated on change detection.
        const startSidenav = this._sidenavs()?.find(s => s.position() === 'start' && s.opened());
        if (startSidenav) {
            if (this.fixedWidth() !== null && this.fixedWidth() !== undefined) {
                return `${parseInt(this.fixedWidth(), 10)}px`;
            }
            if (startSidenav.collapsed()) {
                return 'var(--ngs-sidenav-collapsed-width)';
            }
            if (startSidenav.mode() === 'push' || startSidenav.effectiveMode() === 'side') {
                return 'var(--ngs-sidenav-width)';
            }
        }
        return '0px';
    }
    _getContentMarginRight() {
        if (!this.autosize()) {
            const endSidenav = this._sidenavs()?.find(s => s.position() === 'end' && s.opened());
            if (endSidenav) {
                if (this.fixedWidth() !== null && this.fixedWidth() !== undefined) {
                    return `${parseInt(this.fixedWidth(), 10)}px`;
                }
                if (endSidenav.collapsed()) {
                    return 'var(--ngs-sidenav-collapsed-width)';
                }
                if (endSidenav.mode() === 'push' || endSidenav.effectiveMode() === 'side') {
                    return 'var(--ngs-sidenav-width)';
                }
            }
            return '0px';
        }
        const endSidenav = this._sidenavs()?.find(s => s.position() === 'end' && s.opened());
        if (endSidenav) {
            if (this.fixedWidth() !== null && this.fixedWidth() !== undefined) {
                return `${parseInt(this.fixedWidth(), 10)}px`;
            }
            if (endSidenav.collapsed()) {
                return 'var(--ngs-sidenav-collapsed-width)';
            }
            if (endSidenav.mode() === 'push' || endSidenav.effectiveMode() === 'side') {
                return 'var(--ngs-sidenav-width)';
            }
        }
        return '0px';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavContainer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: SidenavContainer, isStandalone: true, selector: "ngs-sidenav-container", inputs: { hasBackdrop: { classPropertyName: "hasBackdrop", publicName: "hasBackdrop", isSignal: true, isRequired: false, transformFunction: null }, autoFocus: { classPropertyName: "autoFocus", publicName: "autoFocus", isSignal: true, isRequired: false, transformFunction: null }, autosize: { classPropertyName: "autosize", publicName: "autosize", isSignal: true, isRequired: false, transformFunction: null }, fixedWidth: { classPropertyName: "fixedWidth", publicName: "fixedWidth", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { backdropClick: "backdropClick" }, host: { properties: { "class.is-settled": "_isSettled()" }, classAttribute: "ngs-sidenav-container" }, queries: [{ propertyName: "_sidenavs", predicate: Sidenav, descendants: true, isSignal: true }], exportAs: ["ngsSidenavContainer"], ngImport: i0, template: "<div class=\"ngs-sidenav-backdrop\"\n     [class.ngs-sidenav-shown]=\"_isShowingBackdrop()\"\n     (click)=\"_onBackdropClicked()\"></div>\n\n<ng-content select=\"ngs-sidenav\"/>\n<ng-content select=\"ngs-sidenav-content\"/>\n<ng-content />\n", styles: [":host{--ngs-sidenav-backdrop-color: var(--overlay-backdrop-bg);--ngs-sidenav-transition-duration: .4s;--ngs-sidenav-transition-timing-function: cubic-bezier(.25, .8, .25, 1);--ngs-sidenav-width: 280px;--ngs-sidenav-collapsed-width: 74px}:host.is-settled .ngs-sidenav-backdrop{transition:opacity var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function),visibility var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function)}:host{position:relative;z-index:1;box-sizing:border-box;-webkit-overflow-scrolling:touch;display:block;overflow:hidden;width:100%;height:100%}.ngs-sidenav-backdrop{position:absolute;inset:0;display:block;z-index:3;visibility:hidden;background:var(--ngs-sidenav-backdrop-color);opacity:0;pointer-events:none}.ngs-sidenav-backdrop.ngs-sidenav-shown{visibility:visible;opacity:1;pointer-events:auto}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavContainer, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidenav-container', exportAs: 'ngsSidenavContainer', standalone: true, imports: [], host: {
                        'class': 'ngs-sidenav-container',
                        '[class.is-settled]': '_isSettled()',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"ngs-sidenav-backdrop\"\n     [class.ngs-sidenav-shown]=\"_isShowingBackdrop()\"\n     (click)=\"_onBackdropClicked()\"></div>\n\n<ng-content select=\"ngs-sidenav\"/>\n<ng-content select=\"ngs-sidenav-content\"/>\n<ng-content />\n", styles: [":host{--ngs-sidenav-backdrop-color: var(--overlay-backdrop-bg);--ngs-sidenav-transition-duration: .4s;--ngs-sidenav-transition-timing-function: cubic-bezier(.25, .8, .25, 1);--ngs-sidenav-width: 280px;--ngs-sidenav-collapsed-width: 74px}:host.is-settled .ngs-sidenav-backdrop{transition:opacity var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function),visibility var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function)}:host{position:relative;z-index:1;box-sizing:border-box;-webkit-overflow-scrolling:touch;display:block;overflow:hidden;width:100%;height:100%}.ngs-sidenav-backdrop{position:absolute;inset:0;display:block;z-index:3;visibility:hidden;background:var(--ngs-sidenav-backdrop-color);opacity:0;pointer-events:none}.ngs-sidenav-backdrop.ngs-sidenav-shown{visibility:visible;opacity:1;pointer-events:auto}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { _sidenavs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => Sidenav), { ...{ descendants: true }, isSignal: true }] }], backdropClick: [{ type: i0.Output, args: ["backdropClick"] }], hasBackdrop: [{ type: i0.Input, args: [{ isSignal: true, alias: "hasBackdrop", required: false }] }], autoFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoFocus", required: false }] }], autosize: [{ type: i0.Input, args: [{ isSignal: true, alias: "autosize", required: false }] }], fixedWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "fixedWidth", required: false }] }] } });

class SidenavContent {
    _ngZone = inject(NgZone);
    _container = inject(SidenavContainer);
    _isSettled = signal(false, ...(ngDevMode ? [{ debugName: "_isSettled" }] : /* istanbul ignore next */ []));
    constructor() {
        afterNextRender(() => {
            this._ngZone.runOutsideAngular(() => {
                setTimeout(() => {
                    this._isSettled.set(true);
                }, 100);
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidenavContent, isStandalone: true, selector: "ngs-sidenav-content", host: { properties: { "class.is-settled": "_isSettled()", "style.margin-left": "_container._getContentMarginLeft()", "style.margin-right": "_container._getContentMarginRight()" }, classAttribute: "ngs-sidenav-content" }, exportAs: ["ngsSidenavContent"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{position:relative;z-index:1;display:block;height:100%;overflow:auto;--ngs-sidenav-transition-duration: .4s;--ngs-sidenav-transition-timing-function: cubic-bezier(.25, .8, .25, 1)}:host.is-settled{transition:margin-left var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function),margin-right var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidenav-content', exportAs: 'ngsSidenavContent', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-sidenav-content',
                        '[class.is-settled]': '_isSettled()',
                        '[style.margin-left]': '_container._getContentMarginLeft()',
                        '[style.margin-right]': '_container._getContentMarginRight()',
                    }, template: "<ng-content/>\n", styles: [":host{position:relative;z-index:1;display:block;height:100%;overflow:auto;--ngs-sidenav-transition-duration: .4s;--ngs-sidenav-transition-timing-function: cubic-bezier(.25, .8, .25, 1)}:host.is-settled{transition:margin-left var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function),margin-right var(--ngs-sidenav-transition-duration) var(--ngs-sidenav-transition-timing-function)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [] });

class SidenavCollapsed {
    _templateRef = inject(TemplateRef);
    _viewContainerRef = inject(ViewContainerRef);
    _sidenav = inject(SIDENAV);
    constructor() {
        effect(() => {
            const collapsed = this._sidenav.collapsed();
            const hovered = this._sidenav.isHovered();
            if (collapsed && !hovered) {
                if (this._viewContainerRef.length === 0) {
                    this._viewContainerRef.createEmbeddedView(this._templateRef);
                }
            }
            else {
                this._viewContainerRef.clear();
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavCollapsed, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SidenavCollapsed, isStandalone: true, selector: "[ngsSidenavCollapsed]", exportAs: ["ngsSidenavCollapsed"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavCollapsed, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSidenavCollapsed]',
                    exportAs: 'ngsSidenavCollapsed',
                    standalone: true
                }]
        }], ctorParameters: () => [] });

class SidenavExpanded {
    _templateRef = inject(TemplateRef);
    _viewContainerRef = inject(ViewContainerRef);
    _sidenav = inject(SIDENAV);
    constructor() {
        effect(() => {
            const collapsed = this._sidenav.collapsed();
            const hovered = this._sidenav.isHovered();
            if (!collapsed || (collapsed && hovered)) {
                if (this._viewContainerRef.length === 0) {
                    this._viewContainerRef.createEmbeddedView(this._templateRef);
                }
            }
            else {
                this._viewContainerRef.clear();
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavExpanded, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SidenavExpanded, isStandalone: true, selector: "[ngsSidenavExpanded]", exportAs: ["ngsSidenavExpanded"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidenavExpanded, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSidenavExpanded]',
                    exportAs: 'ngsSidenavExpanded',
                    standalone: true
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { Sidenav, SidenavCollapsed, SidenavContainer, SidenavContent, SidenavExpanded };
//# sourceMappingURL=ngstarter-components-sidenav.mjs.map
