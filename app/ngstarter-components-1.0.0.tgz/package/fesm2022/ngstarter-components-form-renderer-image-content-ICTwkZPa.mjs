import * as i0 from '@angular/core';
import { input, ChangeDetectionStrategy, Component } from '@angular/core';

class ImageContent {
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ImageContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: ImageContent, isStandalone: true, selector: "ngs-image-content", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "ngs-image-content" }, exportAs: ["ngsImageContent"], ngImport: i0, template: "@if (config().content; as opts) {\n  <img [src]=\"opts['src']\"\n       [alt]=\"opts['alt'] || ''\"\n       [width]=\"opts['width'] || null\"\n       [height]=\"opts['height'] || null\">\n}\n", styles: [":host{display:flex;align-items:center;justify-content:center}:host img{max-width:100%;height:auto;border-radius:4px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ImageContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-image-content', exportAs: 'ngsImageContent', imports: [], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-image-content',
                    }, template: "@if (config().content; as opts) {\n  <img [src]=\"opts['src']\"\n       [alt]=\"opts['alt'] || ''\"\n       [width]=\"opts['width'] || null\"\n       [height]=\"opts['height'] || null\">\n}\n", styles: [":host{display:flex;align-items:center;justify-content:center}:host img{max-width:100%;height:auto;border-radius:4px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }] } });

export { ImageContent };
//# sourceMappingURL=ngstarter-components-form-renderer-image-content-ICTwkZPa.mjs.map
