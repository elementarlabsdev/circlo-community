class PositionManager {
    _positions = {
        'below-start': {
            originY: 'bottom',
            overlayY: 'top',
            originX: 'start',
            overlayX: 'start',
            panelClass: ['ngs-overlay-below', 'ngs-overlay-below-start']
        },
        'below-center': {
            originY: 'bottom',
            overlayY: 'top',
            originX: 'center',
            overlayX: 'center',
            panelClass: ['ngs-overlay-below', 'ngs-overlay-below-center']
        },
        'below-end': {
            originY: 'bottom',
            overlayY: 'top',
            originX: 'end',
            overlayX: 'end',
            panelClass: ['ngs-overlay-below', 'ngs-overlay-below-end']
        },
        'above-start': {
            originY: 'top',
            overlayY: 'bottom',
            originX: 'start',
            overlayX: 'start',
            panelClass: ['ngs-overlay-above', 'ngs-overlay-above-start']
        },
        'above-center': {
            originY: 'top',
            overlayY: 'bottom',
            originX: 'center',
            overlayX: 'center',
            panelClass: ['ngs-overlay-above', 'ngs-overlay-above-center']
        },
        'above-end': {
            originY: 'top',
            overlayY: 'bottom',
            originX: 'end',
            overlayX: 'end',
            panelClass: ['ngs-overlay-above', 'ngs-overlay-above-end']
        },
        'before-start': {
            originY: 'top',
            overlayY: 'top',
            originX: 'start',
            overlayX: 'end',
            panelClass: ['ngs-overlay-before', 'ngs-overlay-before-start']
        },
        'before-center': {
            originY: 'center',
            overlayY: 'center',
            originX: 'start',
            overlayX: 'end',
            panelClass: ['ngs-overlay-before', 'ngs-overlay-before-center']
        },
        'before-end': {
            originY: 'bottom',
            overlayY: 'bottom',
            originX: 'start',
            overlayX: 'end',
            panelClass: ['ngs-overlay-before', 'ngs-overlay-before-end']
        },
        'after-end': {
            originY: 'bottom',
            overlayY: 'bottom',
            originX: 'end',
            overlayX: 'start',
            panelClass: ['ngs-overlay-after', 'ngs-overlay-after-end']
        },
        'after-center': {
            originY: 'center',
            overlayY: 'center',
            originX: 'end',
            overlayX: 'start',
            panelClass: ['ngs-overlay-after', 'ngs-overlay-after-center']
        },
        'after-start': {
            originY: 'top',
            overlayY: 'top',
            originX: 'end',
            overlayX: 'start',
            panelClass: ['ngs-overlay-after', 'ngs-overlay-after-start']
        }
    };
    _positionPairs = {
        'below-start': 'above-start',
        'below-center': 'above-center',
        'below-end': 'above-end',
        'above-start': 'below-start',
        'above-center': 'below-center',
        'above-end': 'below-end',
        'before-end': 'before-start',
        'before-center': 'after-center',
        'before-start': 'before-end',
        'after-end': 'after-start',
        'after-center': 'before-center',
        'after-start': 'after-end'
    };
    build(position) {
        return [this._positions[position], this._positions[this._positionPairs[position]]];
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { PositionManager };
//# sourceMappingURL=ngstarter-components-overlay.mjs.map
