import * as i0 from '@angular/core';
import { input, signal, Component } from '@angular/core';
import { Divider } from '@ngstarter/components/divider';

class DividerBlockComponent {
    id = input.required(...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    content = input.required(...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    settings = input.required(...(ngDevMode ? [{ debugName: "settings" }] : /* istanbul ignore next */ []));
    index = input.required(...(ngDevMode ? [{ debugName: "index" }] : /* istanbul ignore next */ []));
    initialized = signal(true, ...(ngDevMode ? [{ debugName: "initialized" }] : /* istanbul ignore next */ []));
    getData() {
        return {
            content: null,
            settings: this.settings()
        };
    }
    isEmpty() {
        return true;
    }
    focus() {
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: DividerBlockComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: DividerBlockComponent, isStandalone: true, selector: "ngs-divider-block", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: true, transformFunction: null }, content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: true, transformFunction: null }, settings: { classPropertyName: "settings", publicName: "settings", isSignal: true, isRequired: true, transformFunction: null }, index: { classPropertyName: "index", publicName: "index", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<ngs-divider/>\n", styles: [""], dependencies: [{ kind: "component", type: Divider, selector: "ngs-divider", inputs: ["vertical", "inset", "fixedHeight"], exportAs: ["ngsDivider"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: DividerBlockComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-divider-block', imports: [
                        Divider
                    ], template: "<ngs-divider/>\n" }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: true }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: true }] }], settings: [{ type: i0.Input, args: [{ isSignal: true, alias: "settings", required: true }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "index", required: true }] }] } });

export { DividerBlockComponent };
//# sourceMappingURL=ngstarter-components-content-editor-divider-block.component-q0a_cYJ6.mjs.map
