import * as i0 from '@angular/core';
import { contentChildren, forwardRef, model, input, output, effect, ChangeDetectionStrategy, Component, booleanAttribute, computed, Optional, Inject } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class RadioGroup {
    _radios = contentChildren(forwardRef(() => RadioButton), { ...(ngDevMode ? { debugName: "_radios" } : /* istanbul ignore next */ {}), descendants: true });
    disabled = model(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    name = input(...(ngDevMode ? [undefined, { debugName: "name" }] : /* istanbul ignore next */ []));
    value = model(...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    change = output();
    constructor() {
        effect(() => {
            this._markRadiosForCheck();
        });
        effect(() => {
            this._updateSelectedRadioFromValue();
            this._onChange(this.value());
        });
    }
    _onChange = () => { };
    _onTouched = () => { };
    ngAfterContentInit() {
        this._updateSelectedRadioFromValue();
    }
    writeValue(value) {
        this.value.set(value);
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    _emitChangeEvent(value) {
        this._onChange(value);
        this.change.emit({ source: this, value });
    }
    _updateSelectedRadioFromValue() {
        const _radios = this._radios();
        if (_radios) {
            _radios.forEach(radio => {
                radio.checked.set(this.value() === radio.value());
            });
        }
    }
    _markRadiosForCheck() {
        const _radios = this._radios();
        if (_radios) {
            _radios.forEach(radio => radio._markForCheck());
        }
    }
    _onRadioClick(radio) {
        if (this.disabled() || radio.disabled()) {
            return;
        }
        if (this.value() !== radio.value()) {
            this.value.set(radio.value());
            this._emitChangeEvent(this.value());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: RadioGroup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: RadioGroup, isStandalone: true, selector: "ngs-radio-group", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { disabled: "disabledChange", value: "valueChange", change: "change" }, host: { properties: { "attr.role": "\"radiogroup\"", "attr.aria-disabled": "disabled()" }, classAttribute: "ngs-radio-group" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => RadioGroup),
                multi: true
            }
        ], queries: [{ propertyName: "_radios", predicate: i0.forwardRef(() => RadioButton), descendants: true, isSignal: true }], ngImport: i0, template: "<ng-content />\n", styles: [":host{display:flex;flex-wrap:wrap;gap:1rem}:host[aria-disabled=true]{pointer-events:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: RadioGroup, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-radio-group', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => RadioGroup),
                            multi: true
                        }
                    ], host: {
                        'class': 'ngs-radio-group',
                        '[attr.role]': '"radiogroup"',
                        '[attr.aria-disabled]': 'disabled()',
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: [":host{display:flex;flex-wrap:wrap;gap:1rem}:host[aria-disabled=true]{pointer-events:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { _radios: [{ type: i0.ContentChildren, args: [forwardRef(() => RadioButton), { ...{ descendants: true }, isSignal: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }, { type: i0.Output, args: ["disabledChange"] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], change: [{ type: i0.Output, args: ["change"] }] } });

let nextId = 0;
class RadioButton {
    radioGroup;
    _changeDetectorRef;
    id = input(`ngs-radio-button-${nextId++}`, ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    value = input(...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    name = input(...(ngDevMode ? [undefined, { debugName: "name" }] : /* istanbul ignore next */ []));
    checked = model(false, ...(ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []));
    disabledInput = input(false, { ...(ngDevMode ? { debugName: "disabledInput" } : /* istanbul ignore next */ {}), alias: 'disabled',
        transform: booleanAttribute });
    disabled = computed(() => {
        return this.disabledInput() || (this.radioGroup && this.radioGroup.disabled());
    }, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    change = output();
    constructor(radioGroup, _changeDetectorRef) {
        this.radioGroup = radioGroup;
        this._changeDetectorRef = _changeDetectorRef;
    }
    ngOnInit() {
        if (this.radioGroup && this.radioGroup.value() === this.value()) {
            this.checked.set(true);
        }
    }
    _onInputClick(event) {
        event.stopPropagation();
        if (this.radioGroup) {
            this.radioGroup._onRadioClick(this);
        }
        else {
            this.checked.set(true);
            this.change.emit({ source: this, value: this.value() });
        }
    }
    _markForCheck() {
        this._changeDetectorRef.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: RadioButton, deps: [{ token: forwardRef(() => RadioGroup), optional: true }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: RadioButton, isStandalone: true, selector: "ngs-radio-button", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, disabledInput: { classPropertyName: "disabledInput", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange", change: "change" }, host: { properties: { "class.ngs-radio-button-checked": "checked()", "class.ngs-radio-button-disabled": "disabled()", "attr.id": "id()" }, classAttribute: "ngs-radio-button" }, ngImport: i0, template: "\n<label class=\"ngs-radio-button-label\" [attr.for]=\"id() + '-input'\">\n  <span class=\"ngs-radio-button-container\">\n    <input\n      type=\"radio\"\n      class=\"ngs-radio-button-input\"\n      [id]=\"id() + '-input'\"\n      [name]=\"name() || (radioGroup ? radioGroup.name() : null)\"\n      [checked]=\"checked()\"\n      [disabled]=\"disabled()\"\n      [value]=\"value()\"\n      (click)=\"_onInputClick($event)\"\n    >\n    <span class=\"ngs-radio-button-outer-circle\"></span>\n    <span class=\"ngs-radio-button-inner-circle\"></span>\n  </span>\n  <span class=\"ngs-radio-button-label-content\">\n    <ng-content />\n  </span>\n</label>\n", styles: [":host{--ngs-radio-button-size: 19px;--ngs-radio-button-inner-circle-size: 10px;--ngs-radio-button-border-width: 1px;--ngs-radio-button-unchecked-color: var(--input-border-color);--ngs-radio-button-checked-color: var(--color-primary);--ngs-radio-button-disabled-color: var(--color-on-surface-variant);--ngs-radio-button-label-color: var(--color-on-surface);--ngs-radio-button-disabled-label-color: var(--color-on-surface-variant);--ngs-radio-button-gap: 8px;display:inline-flex;align-items:center;cursor:pointer;-webkit-user-select:none;user-select:none}:host.ngs-radio-button-disabled{cursor:default;pointer-events:none;--ngs-radio-button-unchecked-color: var(--color-on-surface);--ngs-radio-button-checked-color: var(--color-on-surface);--ngs-radio-button-label-color: var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-radio-button-disabled{--ngs-radio-button-unchecked-color: color-mix(in srgb, var(--color-on-surface), transparent 62%)}}@supports (color: color-mix(in lab,red,red)){:host.ngs-radio-button-disabled{--ngs-radio-button-checked-color: color-mix(in srgb, var(--color-on-surface), transparent 62%)}}@supports (color: color-mix(in lab,red,red)){:host.ngs-radio-button-disabled{--ngs-radio-button-label-color: color-mix(in srgb, var(--color-on-surface), transparent 62%)}}:host .ngs-radio-button-label{display:flex;align-items:center;cursor:inherit}:host .ngs-radio-button-container{position:relative;display:flex;align-items:center;justify-content:center;flex-shrink:0;width:var(--ngs-radio-button-size);height:var(--ngs-radio-button-size)}:host .ngs-radio-button-input{position:absolute;inset:0;opacity:0;cursor:inherit;z-index:1;margin:0}:host .ngs-radio-button-outer-circle{position:absolute;inset:0;border-radius:9999px;border-style:solid;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.2s;border-width:var(--ngs-radio-button-border-width);border-color:var(--ngs-radio-button-unchecked-color)}:host .ngs-radio-button-inner-circle{border-radius:9999px;transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.2s;transform:scale(0);width:var(--ngs-radio-button-inner-circle-size);height:var(--ngs-radio-button-inner-circle-size);background:var(--ngs-radio-button-checked-color)}:host.ngs-radio-button-checked .ngs-radio-button-outer-circle{border-color:var(--ngs-radio-button-checked-color)}:host.ngs-radio-button-checked .ngs-radio-button-inner-circle{transform:scale(1)}:host .ngs-radio-button-label-content{transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.2s;padding-left:var(--ngs-radio-button-gap);color:var(--ngs-radio-button-label-color)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: RadioButton, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-radio-button', host: {
                        '[class.ngs-radio-button-checked]': 'checked()',
                        '[class.ngs-radio-button-disabled]': 'disabled()',
                        '[attr.id]': 'id()',
                        'class': 'ngs-radio-button',
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "\n<label class=\"ngs-radio-button-label\" [attr.for]=\"id() + '-input'\">\n  <span class=\"ngs-radio-button-container\">\n    <input\n      type=\"radio\"\n      class=\"ngs-radio-button-input\"\n      [id]=\"id() + '-input'\"\n      [name]=\"name() || (radioGroup ? radioGroup.name() : null)\"\n      [checked]=\"checked()\"\n      [disabled]=\"disabled()\"\n      [value]=\"value()\"\n      (click)=\"_onInputClick($event)\"\n    >\n    <span class=\"ngs-radio-button-outer-circle\"></span>\n    <span class=\"ngs-radio-button-inner-circle\"></span>\n  </span>\n  <span class=\"ngs-radio-button-label-content\">\n    <ng-content />\n  </span>\n</label>\n", styles: [":host{--ngs-radio-button-size: 19px;--ngs-radio-button-inner-circle-size: 10px;--ngs-radio-button-border-width: 1px;--ngs-radio-button-unchecked-color: var(--input-border-color);--ngs-radio-button-checked-color: var(--color-primary);--ngs-radio-button-disabled-color: var(--color-on-surface-variant);--ngs-radio-button-label-color: var(--color-on-surface);--ngs-radio-button-disabled-label-color: var(--color-on-surface-variant);--ngs-radio-button-gap: 8px;display:inline-flex;align-items:center;cursor:pointer;-webkit-user-select:none;user-select:none}:host.ngs-radio-button-disabled{cursor:default;pointer-events:none;--ngs-radio-button-unchecked-color: var(--color-on-surface);--ngs-radio-button-checked-color: var(--color-on-surface);--ngs-radio-button-label-color: var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-radio-button-disabled{--ngs-radio-button-unchecked-color: color-mix(in srgb, var(--color-on-surface), transparent 62%)}}@supports (color: color-mix(in lab,red,red)){:host.ngs-radio-button-disabled{--ngs-radio-button-checked-color: color-mix(in srgb, var(--color-on-surface), transparent 62%)}}@supports (color: color-mix(in lab,red,red)){:host.ngs-radio-button-disabled{--ngs-radio-button-label-color: color-mix(in srgb, var(--color-on-surface), transparent 62%)}}:host .ngs-radio-button-label{display:flex;align-items:center;cursor:inherit}:host .ngs-radio-button-container{position:relative;display:flex;align-items:center;justify-content:center;flex-shrink:0;width:var(--ngs-radio-button-size);height:var(--ngs-radio-button-size)}:host .ngs-radio-button-input{position:absolute;inset:0;opacity:0;cursor:inherit;z-index:1;margin:0}:host .ngs-radio-button-outer-circle{position:absolute;inset:0;border-radius:9999px;border-style:solid;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.2s;border-width:var(--ngs-radio-button-border-width);border-color:var(--ngs-radio-button-unchecked-color)}:host .ngs-radio-button-inner-circle{border-radius:9999px;transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.2s;transform:scale(0);width:var(--ngs-radio-button-inner-circle-size);height:var(--ngs-radio-button-inner-circle-size);background:var(--ngs-radio-button-checked-color)}:host.ngs-radio-button-checked .ngs-radio-button-outer-circle{border-color:var(--ngs-radio-button-checked-color)}:host.ngs-radio-button-checked .ngs-radio-button-inner-circle{transform:scale(1)}:host .ngs-radio-button-label-content{transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.2s;padding-left:var(--ngs-radio-button-gap);color:var(--ngs-radio-button-label-color)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [{ type: RadioGroup, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [forwardRef(() => RadioGroup)]
                }] }, { type: i0.ChangeDetectorRef }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }, { type: i0.Output, args: ["checkedChange"] }], disabledInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], change: [{ type: i0.Output, args: ["change"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { RadioButton, RadioGroup };
//# sourceMappingURL=ngstarter-components-radio.mjs.map
