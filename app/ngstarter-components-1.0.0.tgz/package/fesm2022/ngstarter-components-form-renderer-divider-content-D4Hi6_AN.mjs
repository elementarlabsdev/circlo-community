import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Divider } from '@ngstarter/components/divider';

class DividerContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: DividerContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: DividerContent, isStandalone: true, selector: "ngs-divider-content", exportAs: ["ngsDividerContent"], ngImport: i0, template: "<ngs-divider/>\n", styles: [":host hr{width:100%;border:none;border-top:1px solid var(--color-outline-variant);margin:1rem 0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Divider, selector: "ngs-divider", inputs: ["vertical", "inset", "fixedHeight"], exportAs: ["ngsDivider"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: DividerContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-divider-content', exportAs: 'ngsDividerContent', imports: [
                        Divider
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ngs-divider/>\n", styles: [":host hr{width:100%;border:none;border-top:1px solid var(--color-outline-variant);margin:1rem 0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

export { DividerContent };
//# sourceMappingURL=ngstarter-components-form-renderer-divider-content-D4Hi6_AN.mjs.map
