import * as i0 from '@angular/core';
import { inject, TemplateRef, input, Directive, contentChildren, contentChild, booleanAttribute, Component, ElementRef } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { Skeleton } from '@ngstarter/components/skeleton';

class NotificationDefDirective {
    templateRef = inject(TemplateRef);
    ngsNotificationDef = input.required(...(ngDevMode ? [{ debugName: "ngsNotificationDef" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: NotificationDefDirective, isStandalone: true, selector: "[ngsNotificationDef]", inputs: { ngsNotificationDef: { classPropertyName: "ngsNotificationDef", publicName: "ngsNotificationDef", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsNotificationDef]',
                    standalone: true
                }]
        }], propDecorators: { ngsNotificationDef: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsNotificationDef", required: true }] }] } });

class NotificationControlsDefDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationControlsDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: NotificationControlsDefDirective, isStandalone: true, selector: "[ngsNotificationControlsDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationControlsDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsNotificationControlsDef]',
                    standalone: true
                }]
        }] });

class NotificationList {
    defs = contentChildren(NotificationDefDirective, ...(ngDevMode ? [{ debugName: "defs" }] : /* istanbul ignore next */ []));
    controlsDef = contentChild(NotificationControlsDefDirective, ...(ngDevMode ? [{ debugName: "controlsDef" }] : /* istanbul ignore next */ []));
    notifications = input([], ...(ngDevMode ? [{ debugName: "notifications" }] : /* istanbul ignore next */ []));
    static = input(true, { ...(ngDevMode ? { debugName: "static" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _initialized = false;
    _defsMap = new Map();
    get controlsTpl() {
        return this.controlsDef()?.templateRef;
    }
    ngAfterContentInit() {
        this.defs().forEach((def) => {
            this._defsMap.set(def.ngsNotificationDef(), def.templateRef);
        });
        this._initialized = true;
    }
    getNotificationTemplate(type) {
        if (!this._defsMap.has(type)) {
            throw new Error(`Invalid type "${type}" for notification def`);
        }
        return this._defsMap.get(type);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: NotificationList, isStandalone: true, selector: "ngs-notification-list", inputs: { notifications: { classPropertyName: "notifications", publicName: "notifications", isSignal: true, isRequired: false, transformFunction: null }, static: { classPropertyName: "static", publicName: "static", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-static": "static()" }, classAttribute: "ngs-notification-list" }, queries: [{ propertyName: "defs", predicate: NotificationDefDirective, isSignal: true }, { propertyName: "controlsDef", first: true, predicate: NotificationControlsDefDirective, descendants: true, isSignal: true }], exportAs: ["ngsNotificationList"], ngImport: i0, template: "@if (_initialized) {\n  @for (notification of notifications(); track notification) {\n    <div class=\"notification\">\n      <ng-container [ngTemplateOutlet]=\"getNotificationTemplate(notification.type)\"\n                    [ngTemplateOutletContext]=\"{ $implicit: notification }\" />\n      @if (controlsDef()) {\n        <div class=\"controls\">\n          <ng-container [ngTemplateOutlet]=\"controlsTpl\"\n                        [ngTemplateOutletContext]=\"{ $implicit: notification }\" />\n        </div>\n      }\n    </div>\n  }\n}\n", styles: [":host{--ngs-notification-list-gap: calc(var(--spacing, .25rem) * 6);display:flex;flex-direction:column;gap:var(--ngs-notification-list-gap)}:host .notification{position:relative}:host .controls{position:absolute;inset-inline-end:calc(var(--spacing, .25rem) * 1);top:calc(var(--spacing, .25rem) * 1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationList, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification-list', exportAs: 'ngsNotificationList', imports: [
                        NgTemplateOutlet
                    ], host: {
                        'class': 'ngs-notification-list',
                        '[class.is-static]': 'static()'
                    }, template: "@if (_initialized) {\n  @for (notification of notifications(); track notification) {\n    <div class=\"notification\">\n      <ng-container [ngTemplateOutlet]=\"getNotificationTemplate(notification.type)\"\n                    [ngTemplateOutletContext]=\"{ $implicit: notification }\" />\n      @if (controlsDef()) {\n        <div class=\"controls\">\n          <ng-container [ngTemplateOutlet]=\"controlsTpl\"\n                        [ngTemplateOutletContext]=\"{ $implicit: notification }\" />\n        </div>\n      }\n    </div>\n  }\n}\n", styles: [":host{--ngs-notification-list-gap: calc(var(--spacing, .25rem) * 6);display:flex;flex-direction:column;gap:var(--ngs-notification-list-gap)}:host .notification{position:relative}:host .controls{position:absolute;inset-inline-end:calc(var(--spacing, .25rem) * 1);top:calc(var(--spacing, .25rem) * 1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { defs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => NotificationDefDirective), { isSignal: true }] }], controlsDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => NotificationControlsDefDirective), { isSignal: true }] }], notifications: [{ type: i0.Input, args: [{ isSignal: true, alias: "notifications", required: false }] }], static: [{ type: i0.Input, args: [{ isSignal: true, alias: "static", required: false }] }] } });

class NotificationSkeleton {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationSkeleton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: NotificationSkeleton, isStandalone: true, selector: "ngs-notification-skeleton", host: { classAttribute: "ngs-notification-skeleton" }, exportAs: ["ngsNotificationSkeleton"], ngImport: i0, template: "<div class=\"flex gap-3\">\n  <ngs-skeleton roundedFull class=\"size-11\"/>\n  <div class=\"grow flex flex-col gap-2\">\n    <ngs-skeleton class=\"h-16\"/>\n    <ngs-skeleton class=\"w-20 h-3\"/>\n  </div>\n</div>\n", styles: [":host{display:contents}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Skeleton, selector: "ngs-skeleton", inputs: ["roundedFull"], exportAs: ["ngsSkeleton"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationSkeleton, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification-skeleton', exportAs: 'ngsNotificationSkeleton', imports: [
                        Skeleton
                    ], host: {
                        'class': 'ngs-notification-skeleton',
                    }, template: "<div class=\"flex gap-3\">\n  <ngs-skeleton roundedFull class=\"size-11\"/>\n  <div class=\"grow flex flex-col gap-2\">\n    <ngs-skeleton class=\"h-16\"/>\n    <ngs-skeleton class=\"w-20 h-3\"/>\n  </div>\n</div>\n", styles: [":host{display:contents}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class NotificationTime {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationTime, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: NotificationTime, isStandalone: true, selector: "ngs-notification-time,[ngs-notification-time]", host: { classAttribute: "ngs-notification-time" }, exportAs: ["ngsNotificationTime"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{font-size:.75rem;color:var(--color-on-surface-variant)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationTime, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification-time,[ngs-notification-time]', exportAs: 'ngsNotificationTime', imports: [], host: {
                        'class': 'ngs-notification-time'
                    }, template: "<ng-content/>\n", styles: [":host{font-size:.75rem;color:var(--color-on-surface-variant)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class NotificationActor {
    elementRef = inject(ElementRef);
    get asLink() {
        return this.elementRef.nativeElement.tagName === 'A';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationActor, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: NotificationActor, isStandalone: true, selector: "ngs-notification-actor,[ngs-notification-actor]", host: { properties: { "class.as-link": "asLink" }, classAttribute: "ngs-notification-actor" }, ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:inline-block;font-weight:600;color:var(--color-on-surface);font-size:.875rem}:host.as-link:hover{cursor:pointer;text-decoration:underline}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationActor, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification-actor,[ngs-notification-actor]', imports: [], host: {
                        'class': 'ngs-notification-actor',
                        '[class.as-link]': 'asLink'
                    }, template: "<ng-content/>\n", styles: [":host{display:inline-block;font-weight:600;color:var(--color-on-surface);font-size:.875rem}:host.as-link:hover{cursor:pointer;text-decoration:underline}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class NotificationMessage {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationMessage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: NotificationMessage, isStandalone: true, selector: "ngs-notification-message", host: { classAttribute: "ngs-notification-message" }, exportAs: ["ngsNotificationMessage"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{font-size:.875rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationMessage, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification-message', exportAs: 'ngsNotificationMessage', imports: [], host: {
                        'class': 'ngs-notification-message'
                    }, template: "<ng-content/>\n", styles: [":host{font-size:.875rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class Notification {
    isUnread = input(false, { ...(ngDevMode ? { debugName: "isUnread" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Notification, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: Notification, isStandalone: true, selector: "ngs-notification,[ngs-notification]", inputs: { isUnread: { classPropertyName: "isUnread", publicName: "isUnread", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-unread": "isUnread()" }, classAttribute: "ngs-notification" }, exportAs: ["ngsNotification"], ngImport: i0, template: "<div class=\"avatar\">\n  <ng-content select=\"[ngsNotificationAvatar]\"/>\n</div>\n<div class=\"grow\">\n  <span class=\"message\">\n    <ng-content select=\"ngs-notification-message,[ngs-notification-message]\"/>\n  </span>\n  <div class=\"content\">\n    <ng-content select=\"ngs-notification-content,[ngs-notification-content]\"/>\n  </div>\n  <ng-content select=\"ngs-notification-time,[ngs-notification-time]\"/>\n</div>\n", styles: [":host{--ngs-notification-padding: calc(var(--spacing, .25rem) * 5);--ngs-notification-gap: calc(var(--spacing, .25rem) * 4);--ngs-notification-bg: var(--color-surface-container-low);--ngs-notification-hover-bg: var(--color-surface-container);--ngs-notification-is-unread-bg: var(--color-primary-200);--ngs-notification-is-unread-hover-bg: var(--color-primary-300);display:flex;width:100%;position:relative;border-radius:.75rem;gap:var(--ngs-notification-gap);padding:var(--ngs-notification-padding)}:host .avatar{position:relative}:host .avatar:empty{display:none}:host .actor:empty{display:none}:host .message:empty{display:none}:host-context(ngs-notification-list.is-static){cursor:auto}:host-context(ngs-notification-list){background:var(--ngs-notification-bg);cursor:pointer}:host-context(ngs-notification-list).is-unread{background:var(--ngs-notification-is-unread-bg)}:host-context(ngs-notification-list:not(.is-static)):hover{background:var(--ngs-notification-hover-bg)}:host-context(ngs-notification-list:not(.is-static)).is-unread:hover{background:var(--ngs-notification-is-unread-hover-bg)}:host-context(html.dark){--ngs-notification-is-unread-bg: var(--color-neutral-950);--ngs-notification-is-unread-hover-bg: var(--color-neutral-900)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Notification, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification,[ngs-notification]', exportAs: 'ngsNotification', imports: [], host: {
                        'class': 'ngs-notification',
                        '[class.is-unread]': 'isUnread()'
                    }, template: "<div class=\"avatar\">\n  <ng-content select=\"[ngsNotificationAvatar]\"/>\n</div>\n<div class=\"grow\">\n  <span class=\"message\">\n    <ng-content select=\"ngs-notification-message,[ngs-notification-message]\"/>\n  </span>\n  <div class=\"content\">\n    <ng-content select=\"ngs-notification-content,[ngs-notification-content]\"/>\n  </div>\n  <ng-content select=\"ngs-notification-time,[ngs-notification-time]\"/>\n</div>\n", styles: [":host{--ngs-notification-padding: calc(var(--spacing, .25rem) * 5);--ngs-notification-gap: calc(var(--spacing, .25rem) * 4);--ngs-notification-bg: var(--color-surface-container-low);--ngs-notification-hover-bg: var(--color-surface-container);--ngs-notification-is-unread-bg: var(--color-primary-200);--ngs-notification-is-unread-hover-bg: var(--color-primary-300);display:flex;width:100%;position:relative;border-radius:.75rem;gap:var(--ngs-notification-gap);padding:var(--ngs-notification-padding)}:host .avatar{position:relative}:host .avatar:empty{display:none}:host .actor:empty{display:none}:host .message:empty{display:none}:host-context(ngs-notification-list.is-static){cursor:auto}:host-context(ngs-notification-list){background:var(--ngs-notification-bg);cursor:pointer}:host-context(ngs-notification-list).is-unread{background:var(--ngs-notification-is-unread-bg)}:host-context(ngs-notification-list:not(.is-static)):hover{background:var(--ngs-notification-hover-bg)}:host-context(ngs-notification-list:not(.is-static)).is-unread:hover{background:var(--ngs-notification-is-unread-hover-bg)}:host-context(html.dark){--ngs-notification-is-unread-bg: var(--color-neutral-950);--ngs-notification-is-unread-hover-bg: var(--color-neutral-900)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { isUnread: [{ type: i0.Input, args: [{ isSignal: true, alias: "isUnread", required: false }] }] } });

class NotificationContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: NotificationContent, isStandalone: true, selector: "ngs-notification-content,[ngs-notification-content]", host: { classAttribute: "ngs-notification-content" }, exportAs: ["ngsNotificationContent"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;margin:calc(var(--spacing, .25rem) * 1) 0 calc(var(--spacing, .25rem) * 1) 0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-notification-content,[ngs-notification-content]', exportAs: 'ngsNotificationContent', imports: [], host: {
                        'class': 'ngs-notification-content'
                    }, template: "<ng-content/>\n", styles: [":host{display:block;margin:calc(var(--spacing, .25rem) * 1) 0 calc(var(--spacing, .25rem) * 1) 0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class NotificationPropsDirective {
    isUnread = input(false, { ...(ngDevMode ? { debugName: "isUnread" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationPropsDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: NotificationPropsDirective, isStandalone: true, selector: "[ngsNotificationProps]", inputs: { isUnread: { classPropertyName: "isUnread", publicName: "isUnread", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-unread": "isUnread()" }, classAttribute: "ngs-notification-props" }, exportAs: ["ngsNotificationProps"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationPropsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsNotificationProps]',
                    exportAs: 'ngsNotificationProps',
                    standalone: true,
                    host: {
                        'class': 'ngs-notification-props',
                        '[class.is-unread]': 'isUnread()',
                    }
                }]
        }], propDecorators: { isUnread: [{ type: i0.Input, args: [{ isSignal: true, alias: "isUnread", required: false }] }] } });

class NotificationAvatarDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationAvatarDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: NotificationAvatarDirective, isStandalone: true, selector: "[ngsNotificationAvatar]", host: { classAttribute: "ngs-notification-avatar" }, exportAs: ["ngsNotificationAvatar"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NotificationAvatarDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsNotificationAvatar]',
                    exportAs: 'ngsNotificationAvatar',
                    host: {
                        'class': 'ngs-notification-avatar'
                    }
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Notification, NotificationActor, NotificationAvatarDirective, NotificationContent, NotificationControlsDefDirective, NotificationDefDirective, NotificationList, NotificationMessage, NotificationPropsDirective, NotificationSkeleton, NotificationTime };
//# sourceMappingURL=ngstarter-components-notifications.mjs.map
