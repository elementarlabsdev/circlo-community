import * as i0 from '@angular/core';
import { Component, input, booleanAttribute, Directive } from '@angular/core';
import * as i1 from '@ngstarter/components/core';
import { Ripple } from '@ngstarter/components/core';
import { Divider } from '@ngstarter/components/divider';

class Suggestions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Suggestions, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Suggestions, isStandalone: true, selector: "ngs-suggestions", host: { classAttribute: "ngs-suggestions" }, exportAs: ["ngsSuggestions"], ngImport: i0, template: "<ng-content />\n", styles: [":host{--ngs-suggestions-bg: var(--color-surface-container-lowest);--ngs-suggestion-block-heading-color: var(--color-on-surface);--ngs-suggestion-block-font-size: .75rem;--ngs-suggestion-block-font-weight: 600;--ngs-suggestion-block-content-padding: calc(var(--spacing, .25rem) * 2) 0;--ngs-suggestion-height: calc(var(--spacing, .25rem) * 11);--ngs-suggestion-padding: 0 calc(var(--spacing, .25rem) * 2);--ngs-suggestion-hover-bg: var(--color-surface-container-low);--ngs-suggestion-border-radius: calc(infinity * 1px);display:block;overflow-y:auto;background:var(--ngs-suggestions-bg)}:host-context(html.dark){--ngs-suggestions-bg: var(--color-surface-container-high);--ngs-suggestion-hover-bg: var(--color-surface-bright)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Suggestions, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-suggestions', exportAs: 'ngsSuggestions', imports: [], host: {
                        'class': 'ngs-suggestions'
                    }, template: "<ng-content />\n", styles: [":host{--ngs-suggestions-bg: var(--color-surface-container-lowest);--ngs-suggestion-block-heading-color: var(--color-on-surface);--ngs-suggestion-block-font-size: .75rem;--ngs-suggestion-block-font-weight: 600;--ngs-suggestion-block-content-padding: calc(var(--spacing, .25rem) * 2) 0;--ngs-suggestion-height: calc(var(--spacing, .25rem) * 11);--ngs-suggestion-padding: 0 calc(var(--spacing, .25rem) * 2);--ngs-suggestion-hover-bg: var(--color-surface-container-low);--ngs-suggestion-border-radius: calc(infinity * 1px);display:block;overflow-y:auto;background:var(--ngs-suggestions-bg)}:host-context(html.dark){--ngs-suggestions-bg: var(--color-surface-container-high);--ngs-suggestion-hover-bg: var(--color-surface-bright)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class Suggestion {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Suggestion, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Suggestion, isStandalone: true, selector: "ngs-suggestion,[ngs-suggestion]", exportAs: ["ngsSuggestion"], hostDirectives: [{ directive: i1.Ripple }], ngImport: i0, template: "<div class=\"figure\">\n  <div class=\"icon\">\n    <ng-content select=\"[ngsSuggestionIcon]\"/>\n  </div>\n  <div class=\"thumb\">\n    <ng-content select=\"[ngsSuggestionThumb]\"/>\n  </div>\n</div>\n<div class=\"content\">\n  <ng-content/>\n</div>\n", styles: [":host{display:flex;align-items:center;width:100%;gap:calc(var(--spacing, .25rem) * 2.5);height:var(--ngs-suggestion-height);padding:var(--ngs-suggestion-padding);border-radius:var(--ngs-suggestion-border-radius)}:host:hover{background:var(--ngs-suggestion-hover-bg);cursor:pointer}:host .figure{line-height:0}:host .icon,:host .thumb{line-height:0;display:inline-flex;align-items:center;justify-content:center;--ngs-avatar-size: calc(var(--spacing, .25rem) * 8);border-radius:calc(infinity * 1px)}:host .icon:empty,:host .thumb:empty{display:none}:host .content{display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 2.5);font-size:.875rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Suggestion, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-suggestion,[ngs-suggestion]', exportAs: 'ngsSuggestion', imports: [], hostDirectives: [
                        Ripple
                    ], template: "<div class=\"figure\">\n  <div class=\"icon\">\n    <ng-content select=\"[ngsSuggestionIcon]\"/>\n  </div>\n  <div class=\"thumb\">\n    <ng-content select=\"[ngsSuggestionThumb]\"/>\n  </div>\n</div>\n<div class=\"content\">\n  <ng-content/>\n</div>\n", styles: [":host{display:flex;align-items:center;width:100%;gap:calc(var(--spacing, .25rem) * 2.5);height:var(--ngs-suggestion-height);padding:var(--ngs-suggestion-padding);border-radius:var(--ngs-suggestion-border-radius)}:host:hover{background:var(--ngs-suggestion-hover-bg);cursor:pointer}:host .figure{line-height:0}:host .icon,:host .thumb{line-height:0;display:inline-flex;align-items:center;justify-content:center;--ngs-avatar-size: calc(var(--spacing, .25rem) * 8);border-radius:calc(infinity * 1px)}:host .icon:empty,:host .thumb:empty{display:none}:host .content{display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 2.5);font-size:.875rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SuggestionBlock {
    heading = input(...(ngDevMode ? [undefined, { debugName: "heading" }] : /* istanbul ignore next */ []));
    showDivider = input(false, { ...(ngDevMode ? { debugName: "showDivider" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inline = input(false, { ...(ngDevMode ? { debugName: "inline" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SuggestionBlock, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: SuggestionBlock, isStandalone: true, selector: "ngs-suggestion-block", inputs: { heading: { classPropertyName: "heading", publicName: "heading", isSignal: true, isRequired: false, transformFunction: null }, showDivider: { classPropertyName: "showDivider", publicName: "showDivider", isSignal: true, isRequired: false, transformFunction: null }, inline: { classPropertyName: "inline", publicName: "inline", isSignal: true, isRequired: false, transformFunction: null } }, exportAs: ["ngsSuggestionBlock"], ngImport: i0, template: "@if (showDivider()) {\n  <div class=\"my-4 px-2\">\n    <ngs-divider/>\n  </div>\n}\n\n@if (heading()) {\n  <div class=\"heading\">{{ heading() }}</div>\n}\n\n<div class=\"content\" [class.is-inline]=\"inline()\">\n  <ng-content/>\n</div>\n", styles: [":host{display:block}:host .heading{color:var(--ngs-suggestion-block-heading-color);font-size:var(--ngs-suggestion-block-font-size);font-weight:var(--ngs-suggestion-block-font-weight);padding:var(--ngs-suggestion-padding)}:host .content{padding:var(--ngs-suggestion-block-content-padding)}:host .content.is-inline{display:flex;gap:calc(var(--spacing, .25rem) * 3)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Divider, selector: "ngs-divider", inputs: ["vertical", "inset", "fixedHeight"], exportAs: ["ngsDivider"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SuggestionBlock, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-suggestion-block', exportAs: 'ngsSuggestionBlock', imports: [
                        Divider
                    ], template: "@if (showDivider()) {\n  <div class=\"my-4 px-2\">\n    <ngs-divider/>\n  </div>\n}\n\n@if (heading()) {\n  <div class=\"heading\">{{ heading() }}</div>\n}\n\n<div class=\"content\" [class.is-inline]=\"inline()\">\n  <ng-content/>\n</div>\n", styles: [":host{display:block}:host .heading{color:var(--ngs-suggestion-block-heading-color);font-size:var(--ngs-suggestion-block-font-size);font-weight:var(--ngs-suggestion-block-font-weight);padding:var(--ngs-suggestion-padding)}:host .content{padding:var(--ngs-suggestion-block-content-padding)}:host .content.is-inline{display:flex;gap:calc(var(--spacing, .25rem) * 3)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { heading: [{ type: i0.Input, args: [{ isSignal: true, alias: "heading", required: false }] }], showDivider: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDivider", required: false }] }], inline: [{ type: i0.Input, args: [{ isSignal: true, alias: "inline", required: false }] }] } });

class SuggestionIconDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SuggestionIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SuggestionIconDirective, isStandalone: true, selector: "[ngsSuggestionIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SuggestionIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSuggestionIcon]',
                    standalone: true
                }]
        }] });

class SuggestionThumbDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SuggestionThumbDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SuggestionThumbDirective, isStandalone: true, selector: "[ngsSuggestionThumb]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SuggestionThumbDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSuggestionThumb]',
                    standalone: true
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Suggestion, SuggestionBlock, SuggestionIconDirective, SuggestionThumbDirective, Suggestions };
//# sourceMappingURL=ngstarter-components-suggestions.mjs.map
