import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component } from '@angular/core';

class EmptyState {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyState, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: EmptyState, isStandalone: true, selector: "ngs-empty-state", host: { classAttribute: "ngs-empty-state" }, exportAs: ["ngsEmptyState"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{--ngs-empty-state-padding: 0;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:calc(var(--spacing, .25rem) * 6);padding:var(--ngs-empty-state-padding)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyState, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-empty-state', exportAs: 'ngsEmptyState', host: {
                        'class': 'ngs-empty-state',
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{--ngs-empty-state-padding: 0;width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:calc(var(--spacing, .25rem) * 6);padding:var(--ngs-empty-state-padding)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class EmptyStateImage {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateImage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: EmptyStateImage, isStandalone: true, selector: "ngs-empty-state-image", host: { classAttribute: "ngs-empty-state-image" }, exportAs: ["ngsEmptyStateImage"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;justify-content:center;padding:calc(var(--spacing, .25rem) * 8);width:calc(var(--spacing, .25rem) * 40);height:calc(var(--spacing, .25rem) * 40)}:host ::ng-deep img,:host ::ng-deep svg{max-width:100%;max-height:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateImage, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-empty-state-image', exportAs: 'ngsEmptyStateImage', host: {
                        'class': 'ngs-empty-state-image'
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;justify-content:center;padding:calc(var(--spacing, .25rem) * 8);width:calc(var(--spacing, .25rem) * 40);height:calc(var(--spacing, .25rem) * 40)}:host ::ng-deep img,:host ::ng-deep svg{max-width:100%;max-height:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class EmptyStateIcon {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: EmptyStateIcon, isStandalone: true, selector: "ngs-empty-state-icon", host: { classAttribute: "ngs-empty-state-icon" }, exportAs: ["ngsEmptyStateIcon"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;justify-content:center;padding:calc(var(--spacing, .25rem) * 8);width:calc(var(--spacing, .25rem) * 40);height:calc(var(--spacing, .25rem) * 40);background:var(--color-surface-container);border-radius:calc(infinity * 1px);margin-bottom:calc(var(--spacing, .25rem) * 6)}:host ::ng-deep ngs-icon{--icon-size: calc(var(--spacing, .25rem) * 28)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateIcon, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-empty-state-icon', exportAs: 'ngsEmptyStateIcon', host: {
                        'class': 'ngs-empty-state-icon'
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;justify-content:center;padding:calc(var(--spacing, .25rem) * 8);width:calc(var(--spacing, .25rem) * 40);height:calc(var(--spacing, .25rem) * 40);background:var(--color-surface-container);border-radius:calc(infinity * 1px);margin-bottom:calc(var(--spacing, .25rem) * 6)}:host ::ng-deep ngs-icon{--icon-size: calc(var(--spacing, .25rem) * 28)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class EmptyStateTitle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateTitle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: EmptyStateTitle, isStandalone: true, selector: "ngs-empty-state-title,[ngs-empty-state-title]", host: { classAttribute: "ngs-empty-state-title" }, exportAs: ["ngsEmptyStateTitle"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;font-size:1.5rem;font-weight:700}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateTitle, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-empty-state-title,[ngs-empty-state-title]', exportAs: 'ngsEmptyStateTitle', host: {
                        'class': 'ngs-empty-state-title'
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{display:block;font-size:1.5rem;font-weight:700}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class EmptyStateContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: EmptyStateContent, isStandalone: true, selector: "ngs-empty-state-content", host: { classAttribute: "ngs-empty-state-content" }, exportAs: ["ngsEmptyStateContent"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;font-size:.875rem;color:var(--color-neutral-600)}:host-context(html.dark){color:var(--color-neutral-500)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-empty-state-content', exportAs: 'ngsEmptyStateContent', host: {
                        'class': 'ngs-empty-state-content'
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{display:block;font-size:.875rem;color:var(--color-neutral-600)}:host-context(html.dark){color:var(--color-neutral-500)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class EmptyStateActions {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateActions, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: EmptyStateActions, isStandalone: true, selector: "ngs-empty-state-actions", host: { classAttribute: "ngs-empty-state-actions" }, exportAs: ["ngsEmptyStateActions"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 6);margin-top:calc(var(--spacing, .25rem) * 4)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: EmptyStateActions, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-empty-state-actions', exportAs: 'ngsEmptyStateActions', host: {
                        'class': 'ngs-empty-state-actions'
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 6);margin-top:calc(var(--spacing, .25rem) * 4)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { EmptyState, EmptyStateActions, EmptyStateContent, EmptyStateIcon, EmptyStateImage, EmptyStateTitle };
//# sourceMappingURL=ngstarter-components-empty-state.mjs.map
