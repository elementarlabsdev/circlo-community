import * as i0 from '@angular/core';
import { Component } from '@angular/core';

class ImagePlaceholder {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ImagePlaceholder, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: ImagePlaceholder, isStandalone: true, selector: "ngs-image-placeholder", host: { classAttribute: "ngs-image-placeholder" }, exportAs: ["ngsImagePlaceholder"], ngImport: i0, template: "<svg viewBox=\"0 0 100 100\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" preserveAspectRatio=\"none\">\n  <defs>\n    <clipPath id=\"rectMaskExtraSmall\">\n      <rect x=\"10\" y=\"20\" width=\"80\" height=\"60\" rx=\"6\"/>\n    </clipPath>\n  </defs>\n\n  <rect x=\"10\" y=\"20\" width=\"80\" height=\"60\" rx=\"6\" class=\"placeholder-mountain-bg\"/>\n\n  <g clip-path=\"url(#rectMaskExtraSmall)\">\n    <path d=\"M10 80L40 35L70 80H10Z\" class=\"placeholder-mountain-1\"/>\n    <path d=\"M45 80L67.5 47.5L90 80H45Z\" class=\"placeholder-mountain-2\"/>\n    <circle cx=\"72.5\" cy=\"37.5\" r=\"7.5\" class=\"placeholder-mountain-sun\"/>\n  </g>\n</svg>\n", styles: [":host{display:flex;background:var(--color-surface-container);align-items:center;justify-content:center}:host svg{width:40%;min-width:100px}:host .placeholder-mountain-bg{fill:var(--color-neutral-300)}:host .placeholder-mountain-1{fill:var(--color-neutral-400)}:host .placeholder-mountain-2{fill:var(--color-neutral-100);opacity:.7}:host .placeholder-mountain-sun{fill:var(--color-neutral-100)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ImagePlaceholder, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-image-placeholder', exportAs: 'ngsImagePlaceholder', imports: [], host: {
                        'class': 'ngs-image-placeholder'
                    }, template: "<svg viewBox=\"0 0 100 100\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" preserveAspectRatio=\"none\">\n  <defs>\n    <clipPath id=\"rectMaskExtraSmall\">\n      <rect x=\"10\" y=\"20\" width=\"80\" height=\"60\" rx=\"6\"/>\n    </clipPath>\n  </defs>\n\n  <rect x=\"10\" y=\"20\" width=\"80\" height=\"60\" rx=\"6\" class=\"placeholder-mountain-bg\"/>\n\n  <g clip-path=\"url(#rectMaskExtraSmall)\">\n    <path d=\"M10 80L40 35L70 80H10Z\" class=\"placeholder-mountain-1\"/>\n    <path d=\"M45 80L67.5 47.5L90 80H45Z\" class=\"placeholder-mountain-2\"/>\n    <circle cx=\"72.5\" cy=\"37.5\" r=\"7.5\" class=\"placeholder-mountain-sun\"/>\n  </g>\n</svg>\n", styles: [":host{display:flex;background:var(--color-surface-container);align-items:center;justify-content:center}:host svg{width:40%;min-width:100px}:host .placeholder-mountain-bg{fill:var(--color-neutral-300)}:host .placeholder-mountain-1{fill:var(--color-neutral-400)}:host .placeholder-mountain-2{fill:var(--color-neutral-100);opacity:.7}:host .placeholder-mountain-sun{fill:var(--color-neutral-100)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ImagePlaceholder };
//# sourceMappingURL=ngstarter-components-image-placeholder.mjs.map
