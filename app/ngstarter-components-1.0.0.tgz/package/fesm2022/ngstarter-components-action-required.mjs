import * as i0 from '@angular/core';
import { input, output, Component } from '@angular/core';
import { Icon } from '@ngstarter/components/icon';
import { Button } from '@ngstarter/components/button';

class ActionRequired {
    actionText = input(...(ngDevMode ? [undefined, { debugName: "actionText" }] : /* istanbul ignore next */ []));
    iconName = input(...(ngDevMode ? [undefined, { debugName: "iconName" }] : /* istanbul ignore next */ []));
    description = input.required(...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    buttonText = input.required(...(ngDevMode ? [{ debugName: "buttonText" }] : /* istanbul ignore next */ []));
    buttonClicked = output();
    getIconName(iconName) {
        if (iconName === 'error') {
            return 'fluent:error-circle-24-regular';
        }
        if (iconName === 'warning') {
            return 'fluent:warning-24-regular';
        }
        if (iconName === 'help') {
            return 'fluent:question-circle-24-regular';
        }
        return iconName;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ActionRequired, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: ActionRequired, isStandalone: true, selector: "ngs-action-required", inputs: { actionText: { classPropertyName: "actionText", publicName: "actionText", isSignal: true, isRequired: false, transformFunction: null }, iconName: { classPropertyName: "iconName", publicName: "iconName", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: true, transformFunction: null }, buttonText: { classPropertyName: "buttonText", publicName: "buttonText", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { buttonClicked: "buttonClicked" }, host: { classAttribute: "ngs-action-required" }, exportAs: ["ngsActionRequired"], ngImport: i0, template: "<div class=\"action-text\">\n  <ngs-icon [name]=\"getIconName(iconName() || 'error')\"/>\n  {{ actionText() || 'Action Required' }}\n</div>\n<div class=\"description\">{{ description() }}</div>\n<button ngsButton=\"filled\" class=\"button\" (click)=\"buttonClicked.emit()\">\n  {{ buttonText() }}\n<!--  <ngs-icon name=\"fluent:arrow-right-24-regular\"/>-->\n</button>\n", styles: [":host{--ngs-action-required-bg: linear-gradient(135deg, var(--color-error-container), var(--color-error-container-highest));--ngs-action-action-text-bg: var(--color-surface);--ngs-action-text-color: var(--color-on-error-container);display:flex;width:100%;border-radius:1rem;padding:calc(var(--spacing, .25rem) * 6);gap:calc(var(--spacing, .25rem) * 8);align-items:center;background:var(--ngs-action-required-bg);color:var(--ngs-action-text-color)}:host .action-text{display:flex;border-radius:.75rem;background:var(--ngs-action-action-text-bg);padding:calc(var(--spacing, .25rem) * 2.5) calc(var(--spacing, .25rem) * 3) calc(var(--spacing, .25rem) * 2.5) calc(var(--spacing, .25rem) * 2.5);align-items:center;flex:none;font-size:var(--text-md);gap:calc(var(--spacing, .25rem) * 1.5)}:host .description{flex-grow:1}:host .button{flex:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ActionRequired, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-action-required', exportAs: 'ngsActionRequired', imports: [
                        Icon,
                        Button
                    ], host: {
                        'class': 'ngs-action-required',
                    }, template: "<div class=\"action-text\">\n  <ngs-icon [name]=\"getIconName(iconName() || 'error')\"/>\n  {{ actionText() || 'Action Required' }}\n</div>\n<div class=\"description\">{{ description() }}</div>\n<button ngsButton=\"filled\" class=\"button\" (click)=\"buttonClicked.emit()\">\n  {{ buttonText() }}\n<!--  <ngs-icon name=\"fluent:arrow-right-24-regular\"/>-->\n</button>\n", styles: [":host{--ngs-action-required-bg: linear-gradient(135deg, var(--color-error-container), var(--color-error-container-highest));--ngs-action-action-text-bg: var(--color-surface);--ngs-action-text-color: var(--color-on-error-container);display:flex;width:100%;border-radius:1rem;padding:calc(var(--spacing, .25rem) * 6);gap:calc(var(--spacing, .25rem) * 8);align-items:center;background:var(--ngs-action-required-bg);color:var(--ngs-action-text-color)}:host .action-text{display:flex;border-radius:.75rem;background:var(--ngs-action-action-text-bg);padding:calc(var(--spacing, .25rem) * 2.5) calc(var(--spacing, .25rem) * 3) calc(var(--spacing, .25rem) * 2.5) calc(var(--spacing, .25rem) * 2.5);align-items:center;flex:none;font-size:var(--text-md);gap:calc(var(--spacing, .25rem) * 1.5)}:host .description{flex-grow:1}:host .button{flex:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { actionText: [{ type: i0.Input, args: [{ isSignal: true, alias: "actionText", required: false }] }], iconName: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconName", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: true }] }], buttonText: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonText", required: true }] }], buttonClicked: [{ type: i0.Output, args: ["buttonClicked"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ActionRequired };
//# sourceMappingURL=ngstarter-components-action-required.mjs.map
