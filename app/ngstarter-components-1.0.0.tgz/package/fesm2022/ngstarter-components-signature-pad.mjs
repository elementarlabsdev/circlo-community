import * as i0 from '@angular/core';
import { model, input, output, viewChild, signal, inject, PLATFORM_ID, DOCUMENT, afterNextRender, effect, ChangeDetectionStrategy, Component } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Subject, merge, fromEvent } from 'rxjs';
import { tap, filter, map, switchMap, takeUntil } from 'rxjs/operators';
import { ColorSwitcher } from '@ngstarter/components/color-switcher';
import { Icon } from '@ngstarter/components/icon';
import { Button } from '@ngstarter/components/button';

function ease(x) {
    return 1 - Math.sqrt(1 - Math.pow(x, 2));
}
class LazyPoint {
    x;
    y;
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    update(point) {
        this.x = point.x;
        this.y = point.y;
        return this;
    }
    moveByAngle(angle, distance, friction) {
        const angleRotated = angle + Math.PI / 2;
        if (friction) {
            this.x = this.x + Math.sin(angleRotated) * distance * ease(1 - friction);
            this.y = this.y - Math.cos(angleRotated) * distance * ease(1 - friction);
        }
        else {
            this.x = this.x + Math.sin(angleRotated) * distance;
            this.y = this.y - Math.cos(angleRotated) * distance;
        }
        return this;
    }
    equalsTo(point) {
        return this.x === point.x && this.y === point.y;
    }
    getDifferenceTo(point) {
        return new LazyPoint(this.x - point.x, this.y - point.y);
    }
    getDistanceTo(point) {
        const diff = this.getDifferenceTo(point);
        return Math.sqrt(Math.pow(diff.x, 2) + Math.pow(diff.y, 2));
    }
    getAngleTo(point) {
        const diff = this.getDifferenceTo(point);
        return Math.atan2(diff.y, diff.x);
    }
    toObject() {
        return {
            x: this.x,
            y: this.y
        };
    }
}

const RADIUS_DEFAULT = 30;
class LazyBrush {
    _isEnabled;
    _hasMoved;
    radius;
    pointer;
    brush;
    angle;
    distance;
    friction;
    constructor(options = {}) {
        const initialPoint = options.initialPoint || { x: 0, y: 0 };
        this.radius = options.radius || RADIUS_DEFAULT;
        this._isEnabled = options.enabled === false ? false : true;
        this.friction = options.friction || 0;
        this.pointer = new LazyPoint(initialPoint.x, initialPoint.y);
        this.brush = new LazyPoint(initialPoint.x, initialPoint.y);
        this.angle = 0;
        this.distance = 0;
        this._hasMoved = false;
    }
    enable() { this._isEnabled = true; }
    disable() { this._isEnabled = false; }
    isEnabled() { return this._isEnabled; }
    setRadius(radius) { this.radius = radius; }
    getRadius() { return this.radius; }
    setFriction(friction) { this.friction = Math.max(0, Math.min(1, friction)); }
    getFriction() { return this.friction; }
    getBrushCoordinates() { return this.brush.toObject(); }
    getPointerCoordinates() { return this.pointer.toObject(); }
    getBrush() { return this.brush; }
    getPointer() { return this.pointer; }
    getAngle() { return this.angle; }
    getDistance() { return this.distance; }
    brushHasMoved() { return this._hasMoved; }
    update(newPointerPoint, options = {}) {
        this._hasMoved = false;
        const currentFriction = options.friction !== undefined ? options.friction : this.friction;
        if (this.pointer.equalsTo(newPointerPoint) &&
            !options.both &&
            currentFriction === this.friction) {
            return false;
        }
        this.pointer.update(newPointerPoint);
        if (options.both) {
            this._hasMoved = true;
            this.brush.update(newPointerPoint);
            return true;
        }
        if (this._isEnabled) {
            this.distance = this.pointer.getDistanceTo(this.brush);
            this.angle = this.pointer.getAngleTo(this.brush);
            const isOutside = this.distance > this.radius;
            if (isOutside) {
                this.brush.moveByAngle(this.angle, this.distance - this.radius, currentFriction);
                this._hasMoved = true;
            }
        }
        else {
            this.distance = 0;
            this.angle = 0;
            this.brush.update(newPointerPoint);
            this._hasMoved = true;
        }
        return true;
    }
}

class SignaturePad {
    penColor = model('#000', ...(ngDevMode ? [{ debugName: "penColor" }] : /* istanbul ignore next */ []));
    lineWidth = input(4, ...(ngDevMode ? [{ debugName: "lineWidth" }] : /* istanbul ignore next */ []));
    backgroundColor = input('transparent', ...(ngDevMode ? [{ debugName: "backgroundColor" }] : /* istanbul ignore next */ []));
    lazyRadius = input(3, ...(ngDevMode ? [{ debugName: "lazyRadius" }] : /* istanbul ignore next */ []));
    lazyFriction = input(0.1, ...(ngDevMode ? [{ debugName: "lazyFriction" }] : /* istanbul ignore next */ []));
    lazyEnabled = input(true, ...(ngDevMode ? [{ debugName: "lazyEnabled" }] : /* istanbul ignore next */ []));
    colors = input(['#000', '#0059ff', '#ff0000'], ...(ngDevMode ? [{ debugName: "colors" }] : /* istanbul ignore next */ []));
    signatureSaved = output();
    signatureCleared = output();
    mainCanvasRef = viewChild.required('signatureCanvas');
    canvasWidth = signal(400, ...(ngDevMode ? [{ debugName: "canvasWidth" }] : /* istanbul ignore next */ []));
    canvasHeight = signal(200, ...(ngDevMode ? [{ debugName: "canvasHeight" }] : /* istanbul ignore next */ []));
    mainContext = signal(null, ...(ngDevMode ? [{ debugName: "mainContext" }] : /* istanbul ignore next */ []));
    memoryCanvasElement = null;
    memoryContext = signal(null, ...(ngDevMode ? [{ debugName: "memoryContext" }] : /* istanbul ignore next */ []));
    lazyBrushInstance;
    isDrawing = signal(false, ...(ngDevMode ? [{ debugName: "isDrawing" }] : /* istanbul ignore next */ []));
    currentStrokePoints = signal([], ...(ngDevMode ? [{ debugName: "currentStrokePoints" }] : /* istanbul ignore next */ []));
    resizeObserver;
    platformId = inject(PLATFORM_ID);
    document = inject(DOCUMENT);
    subscriptions = [];
    pointerDown$ = new Subject();
    constructor() {
        if (isPlatformBrowser(this.platformId)) {
            afterNextRender(() => {
                this.initializeLazyBrush();
                this.initializeCanvasesAndContexts();
                this.setupResizeObserver();
                this.setupPointerEvents();
            });
        }
        effect(() => {
            const currentWidth = this.canvasWidth();
            const currentHeight = this.canvasHeight();
            this.backgroundColor();
            if (this.mainContext() && this.memoryContext() && this.mainCanvasRef() && this.memoryCanvasElement && this.lazyBrushInstance) {
                const mainCanvasEl = this.mainCanvasRef().nativeElement;
                mainCanvasEl.width = currentWidth;
                mainCanvasEl.height = currentHeight;
                this.memoryCanvasElement.width = currentWidth;
                this.memoryCanvasElement.height = currentHeight;
                this.configureContextStyling(this.mainContext());
                this.configureContextStyling(this.memoryContext());
                this.mainContext().fillStyle = this.backgroundColor();
                this.mainContext().fillRect(0, 0, currentWidth, currentHeight);
                this.memoryContext().clearRect(0, 0, currentWidth, currentHeight);
                this.currentStrokePoints.set([]);
                this.lazyBrushInstance.pointer.update({ x: 0, y: 0 });
                this.lazyBrushInstance.brush.update({ x: 0, y: 0 });
            }
        });
        effect(() => {
            this.penColor();
            this.lineWidth();
            if (this.mainContext()) {
                this.mainContext().strokeStyle = this.penColor();
                this.mainContext().lineWidth = this.lineWidth();
                this.mainContext().fillStyle = this.penColor();
            }
            if (this.memoryContext()) {
                this.memoryContext().strokeStyle = this.penColor();
                this.memoryContext().lineWidth = this.lineWidth();
                this.memoryContext().fillStyle = this.penColor();
            }
        });
        effect(() => {
            if (this.lazyBrushInstance) {
                this.lazyBrushInstance.setRadius(this.lazyRadius());
                this.lazyBrushInstance.setFriction(this.lazyFriction());
                this.lazyEnabled() ? this.lazyBrushInstance.enable() : this.lazyBrushInstance.disable();
            }
        });
    }
    ngOnDestroy() {
        this.subscriptions.forEach(sub => sub.unsubscribe());
        if (this.resizeObserver && this.mainCanvasRef()) {
            this.resizeObserver.unobserve(this.mainCanvasRef().nativeElement);
        }
    }
    setupPointerEvents() {
        const canvasEl = this.mainCanvasRef().nativeElement;
        const pointerDownEvents$ = merge(fromEvent(canvasEl, 'mousedown'), fromEvent(canvasEl, 'touchstart').pipe(tap(event => { if (event.cancelable)
            event.preventDefault(); }))).pipe(filter(() => !!this.mainContext() && !!this.lazyBrushInstance), map(event => this.getCoordinates(event)), filter((coords) => coords !== null));
        const pointerMoveEvents$ = merge(fromEvent(this.document, 'mousemove'), fromEvent(this.document, 'touchmove').pipe(tap(event => { if (event.cancelable)
            event.preventDefault(); }))).pipe(map(event => this.getCoordinates(event)), filter((coords) => coords !== null));
        const pointerUpEvents$ = merge(fromEvent(this.document, 'mouseup'), fromEvent(this.document, 'touchend'), fromEvent(this.document, 'touchcancel'));
        const drawingStream$ = pointerDownEvents$.pipe(tap(coords => this.handlePointerDownLogic(coords)), switchMap(() => pointerMoveEvents$.pipe(takeUntil(pointerUpEvents$.pipe(tap(event => this.handlePointerUpLogic(event)))))));
        this.subscriptions.push(drawingStream$.subscribe(coords => {
            this.handlePointerMoveLogic(coords);
        }));
    }
    setupResizeObserver() {
        const canvasEl = this.mainCanvasRef().nativeElement;
        this.resizeObserver = new ResizeObserver(entries => {
            for (const entry of entries) {
                const contentBoxSize = Array.isArray(entry.contentBoxSize) ? entry.contentBoxSize[0] : entry.contentBoxSize;
                const newWidth = contentBoxSize ? contentBoxSize.inlineSize : entry.contentRect.width;
                const newHeight = contentBoxSize ? contentBoxSize.blockSize : entry.contentRect.height;
                if (newWidth > 0 && newHeight > 0 && (this.canvasWidth() !== newWidth || this.canvasHeight() !== newHeight)) {
                    this.canvasWidth.set(newWidth);
                    this.canvasHeight.set(newHeight);
                }
            }
        });
        this.resizeObserver.observe(canvasEl);
    }
    initializeLazyBrush() {
        const options = {
            radius: this.lazyRadius(),
            enabled: this.lazyEnabled(),
            initialPoint: { x: 0, y: 0 },
            friction: this.lazyFriction()
        };
        this.lazyBrushInstance = new LazyBrush(options);
    }
    initializeCanvasesAndContexts() {
        const mainCanvasEl = this.mainCanvasRef().nativeElement;
        const mainCtx = mainCanvasEl.getContext('2d');
        if (!mainCtx) {
            console.error('Failed to get 2D context for main canvas');
            return;
        }
        this.mainContext.set(mainCtx);
        this.memoryCanvasElement = document.createElement('canvas');
        const memCtx = this.memoryCanvasElement.getContext('2d');
        if (!memCtx) {
            console.error('Failed to get 2D context for memory canvas');
            return;
        }
        this.memoryContext.set(memCtx);
    }
    configureContextStyling(ctx) {
        ctx.strokeStyle = this.penColor();
        ctx.lineWidth = this.lineWidth();
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.fillStyle = this.penColor();
    }
    handlePointerDownLogic(coords) {
        this.isDrawing.set(true);
        this.lazyBrushInstance.update(coords, { both: true });
        this.currentStrokePoints.set([this.lazyBrushInstance.getBrushCoordinates()]);
    }
    handlePointerMoveLogic(coords) {
        const mainCtx = this.mainContext();
        const memCanvas = this.memoryCanvasElement;
        if (!mainCtx || !memCanvas || !this.lazyBrushInstance)
            return;
        this.lazyBrushInstance.update(coords);
        if (this.lazyBrushInstance.brushHasMoved()) {
            this.currentStrokePoints.update(points => [...points, this.lazyBrushInstance.getBrushCoordinates()]);
            mainCtx.clearRect(0, 0, this.canvasWidth(), this.canvasHeight());
            mainCtx.drawImage(memCanvas, 0, 0);
            this.drawSmoothStroke(mainCtx, this.currentStrokePoints());
        }
    }
    handlePointerUpLogic(event) {
        if (!this.isDrawing())
            return;
        const mainCtx = this.mainContext();
        const memCtx = this.memoryContext();
        const mainCanvasEl = this.mainCanvasRef().nativeElement;
        if (!mainCtx || !memCtx || !this.memoryCanvasElement || !this.lazyBrushInstance) {
            this.isDrawing.set(false);
            this.currentStrokePoints.set([]);
            return;
        }
        const coords = event ? this.getCoordinates(event) : this.lazyBrushInstance.getPointerCoordinates();
        if (coords) {
            this.lazyBrushInstance.update(coords);
            if (this.lazyBrushInstance.brushHasMoved()) {
                this.currentStrokePoints.update(points => [...points, this.lazyBrushInstance.getBrushCoordinates()]);
            }
        }
        if (this.currentStrokePoints().length > 0) {
            mainCtx.clearRect(0, 0, this.canvasWidth(), this.canvasHeight());
            mainCtx.drawImage(this.memoryCanvasElement, 0, 0);
            this.drawSmoothStroke(mainCtx, this.currentStrokePoints());
        }
        memCtx.clearRect(0, 0, this.canvasWidth(), this.canvasHeight());
        memCtx.drawImage(mainCanvasEl, 0, 0);
        this.isDrawing.set(false);
        this.currentStrokePoints.set([]);
        this.save();
    }
    drawSmoothStroke(ctx, points) {
        if (points.length === 0)
            return;
        ctx.strokeStyle = this.penColor();
        ctx.lineWidth = this.lineWidth();
        ctx.fillStyle = this.penColor();
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        if (points.length < 3) {
            const p1 = points[0];
            ctx.beginPath();
            if (points.length === 1) {
                const radius = this.lineWidth() / 2;
                ctx.arc(p1.x, p1.y, Math.max(0.5, radius), 0, Math.PI * 2, true);
                ctx.fill();
            }
            else {
                const p2 = points[1];
                ctx.moveTo(p1.x, p1.y);
                ctx.lineTo(p2.x, p2.y);
                ctx.stroke();
            }
            ctx.closePath();
            return;
        }
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        let i;
        for (i = 1; i < points.length - 2; i++) {
            const c = (points[i].x + points[i + 1].x) / 2;
            const d = (points[i].y + points[i + 1].y) / 2;
            ctx.quadraticCurveTo(points[i].x, points[i].y, c, d);
        }
        ctx.quadraticCurveTo(points[i].x, points[i].y, points[i + 1].x, points[i + 1].y);
        ctx.stroke();
        ctx.closePath();
    }
    getCoordinates(event) {
        const canvas = this.mainCanvasRef()?.nativeElement;
        if (!canvas)
            return null;
        const rect = canvas.getBoundingClientRect();
        let clientX, clientY;
        if (event instanceof MouseEvent) {
            clientX = event.clientX;
            clientY = event.clientY;
        }
        else if (event instanceof TouchEvent) {
            const touch = event.touches.length > 0 ? event.touches[0] :
                (event.changedTouches.length > 0 ? event.changedTouches[0] : null);
            if (touch) {
                clientX = touch.clientX;
                clientY = touch.clientY;
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        return {
            x: (clientX - rect.left) * scaleX,
            y: (clientY - rect.top) * scaleY,
        };
    }
    clear() {
        const mainCtx = this.mainContext();
        const memCtx = this.memoryContext();
        if (mainCtx) {
            mainCtx.clearRect(0, 0, this.canvasWidth(), this.canvasHeight());
            mainCtx.fillStyle = this.backgroundColor();
            mainCtx.fillRect(0, 0, this.canvasWidth(), this.canvasHeight());
        }
        if (memCtx) {
            memCtx.clearRect(0, 0, this.canvasWidth(), this.canvasHeight());
        }
        this.currentStrokePoints.set([]);
        if (this.lazyBrushInstance) {
            const currentPointer = this.lazyBrushInstance.getPointerCoordinates();
            this.lazyBrushInstance.update(currentPointer, { both: true });
        }
        this.signatureCleared.emit();
    }
    save() {
        const memCanvas = this.memoryCanvasElement;
        if (!memCanvas) {
            console.warn('Memory canvas not available for saving.');
            return;
        }
        if (this.isCanvasEffectivelyBlank(memCanvas)) {
            console.warn('Canvas is effectively empty or contains only background. Nothing to save.');
            return;
        }
        const dataUrl = memCanvas.toDataURL('image/png');
        this.signatureSaved.emit(dataUrl);
    }
    onColorChange(color) {
        this.penColor.set(color);
    }
    isCanvasEffectivelyBlank(canvas) {
        if (!canvas)
            return true;
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const tempCtx = tempCanvas.getContext('2d');
        if (!tempCtx)
            return true;
        tempCtx.fillStyle = this.backgroundColor();
        tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        return canvas.toDataURL() === tempCanvas.toDataURL();
    }
    handleEscapeKey(event) {
        this.clear();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SignaturePad, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: SignaturePad, isStandalone: true, selector: "ngs-signature-pad", inputs: { penColor: { classPropertyName: "penColor", publicName: "penColor", isSignal: true, isRequired: false, transformFunction: null }, lineWidth: { classPropertyName: "lineWidth", publicName: "lineWidth", isSignal: true, isRequired: false, transformFunction: null }, backgroundColor: { classPropertyName: "backgroundColor", publicName: "backgroundColor", isSignal: true, isRequired: false, transformFunction: null }, lazyRadius: { classPropertyName: "lazyRadius", publicName: "lazyRadius", isSignal: true, isRequired: false, transformFunction: null }, lazyFriction: { classPropertyName: "lazyFriction", publicName: "lazyFriction", isSignal: true, isRequired: false, transformFunction: null }, lazyEnabled: { classPropertyName: "lazyEnabled", publicName: "lazyEnabled", isSignal: true, isRequired: false, transformFunction: null }, colors: { classPropertyName: "colors", publicName: "colors", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { penColor: "penColorChange", signatureSaved: "signatureSaved", signatureCleared: "signatureCleared" }, host: { listeners: { "document:keydown.escape": "handleEscapeKey($event)" }, classAttribute: "ngs-signature-pad" }, viewQueries: [{ propertyName: "mainCanvasRef", first: true, predicate: ["signatureCanvas"], descendants: true, isSignal: true }], exportAs: ["ngsSignaturePad"], ngImport: i0, template: "<canvas #signatureCanvas\n        class=\"signature-canvas\">\n  Your browser does not support the HTML canvas tag.\n</canvas>\n<div class=\"line\"></div>\n<ngs-color-switcher [selectedColor]=\"penColor()\"\n                  [colors]=\"colors()\"\n                  (colorChange)=\"onColorChange($event)\"/>\n<div class=\"clear-button\">\n  <button ngsIconButton (click)=\"clear()\">\n    <ngs-icon name=\"fluent:dismiss-24-regular\"/>\n  </button>\n</div>\n", styles: [":host{display:block;position:relative;width:max-content;height:max-content;background:var(--color-surface-container-lowest)}:host canvas{width:500px;height:250px;z-index:1;position:relative}:host .ngs-brand-colors{--ngs-brand-colors-color-size: calc(var(--spacing, .25rem) * 5);--ngs-brand-colors-gap: calc(var(--spacing, .25rem) * 2);position:absolute;top:calc(var(--spacing, .25rem) * 3);right:calc(var(--spacing, .25rem) * 3);z-index:2}:host .clear-button{position:absolute;top:calc(var(--spacing, .25rem) * 1);left:calc(var(--spacing, .25rem) * 1);z-index:2}:host .line{position:absolute;height:1px;z-index:0;background:var(--color-surface-container-highest);left:40px;right:40px;bottom:50px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: ColorSwitcher, selector: "ngs-color-switcher", inputs: ["colors", "selectedColor", "disabled"], outputs: ["colorChange"], exportAs: ["ngsColorSwitcher"] }, { kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SignaturePad, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-signature-pad', exportAs: 'ngsSignaturePad', standalone: true, imports: [
                        ColorSwitcher,
                        Icon,
                        Button
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-signature-pad',
                        '(document:keydown.escape)': 'handleEscapeKey($event)',
                    }, template: "<canvas #signatureCanvas\n        class=\"signature-canvas\">\n  Your browser does not support the HTML canvas tag.\n</canvas>\n<div class=\"line\"></div>\n<ngs-color-switcher [selectedColor]=\"penColor()\"\n                  [colors]=\"colors()\"\n                  (colorChange)=\"onColorChange($event)\"/>\n<div class=\"clear-button\">\n  <button ngsIconButton (click)=\"clear()\">\n    <ngs-icon name=\"fluent:dismiss-24-regular\"/>\n  </button>\n</div>\n", styles: [":host{display:block;position:relative;width:max-content;height:max-content;background:var(--color-surface-container-lowest)}:host canvas{width:500px;height:250px;z-index:1;position:relative}:host .ngs-brand-colors{--ngs-brand-colors-color-size: calc(var(--spacing, .25rem) * 5);--ngs-brand-colors-gap: calc(var(--spacing, .25rem) * 2);position:absolute;top:calc(var(--spacing, .25rem) * 3);right:calc(var(--spacing, .25rem) * 3);z-index:2}:host .clear-button{position:absolute;top:calc(var(--spacing, .25rem) * 1);left:calc(var(--spacing, .25rem) * 1);z-index:2}:host .line{position:absolute;height:1px;z-index:0;background:var(--color-surface-container-highest);left:40px;right:40px;bottom:50px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { penColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "penColor", required: false }] }, { type: i0.Output, args: ["penColorChange"] }], lineWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "lineWidth", required: false }] }], backgroundColor: [{ type: i0.Input, args: [{ isSignal: true, alias: "backgroundColor", required: false }] }], lazyRadius: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyRadius", required: false }] }], lazyFriction: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyFriction", required: false }] }], lazyEnabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyEnabled", required: false }] }], colors: [{ type: i0.Input, args: [{ isSignal: true, alias: "colors", required: false }] }], signatureSaved: [{ type: i0.Output, args: ["signatureSaved"] }], signatureCleared: [{ type: i0.Output, args: ["signatureCleared"] }], mainCanvasRef: [{ type: i0.ViewChild, args: ['signatureCanvas', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { SignaturePad };
//# sourceMappingURL=ngstarter-components-signature-pad.mjs.map
