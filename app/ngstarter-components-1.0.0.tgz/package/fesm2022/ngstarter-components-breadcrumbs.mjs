import * as i0 from '@angular/core';
import { Directive, contentChild, TemplateRef, input, booleanAttribute, Component, inject, computed, ChangeDetectionStrategy } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { RouterLink } from '@angular/router';
import { signalStore, withState, withMethods, patchState } from '@ngrx/signals';
import { Icon } from '@ngstarter/components/icon';

class BreadcrumbItemDefDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbItemDefDirective, isStandalone: true, selector: "[ngsBreadcrumbItemDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBreadcrumbItemDef]'
                }]
        }] });

class BreadcrumbSeparatorDefDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbSeparatorDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbSeparatorDefDirective, isStandalone: true, selector: "[ngsBreadcrumbSeparatorDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbSeparatorDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBreadcrumbSeparatorDef]'
                }]
        }] });

class BreadcrumbActiveItemDefDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbActiveItemDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbActiveItemDefDirective, isStandalone: true, selector: "[ngsBreadcrumbActiveItemDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbActiveItemDefDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[ngsBreadcrumbActiveItemDef]' }]
        }] });

class Breadcrumbs {
    itemRef = contentChild.required(BreadcrumbItemDefDirective, {
        read: TemplateRef
    });
    activeItemRef = contentChild.required(BreadcrumbActiveItemDefDirective, {
        read: TemplateRef
    });
    separatorRef = contentChild.required(BreadcrumbSeparatorDefDirective, {
        read: TemplateRef
    });
    dataSource = input([], ...(ngDevMode ? [{ debugName: "dataSource" }] : /* istanbul ignore next */ []));
    lastItemAsLink = input(false, { ...(ngDevMode ? { debugName: "lastItemAsLink" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Breadcrumbs, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: Breadcrumbs, isStandalone: true, selector: "ngs-breadcrumbs", inputs: { dataSource: { classPropertyName: "dataSource", publicName: "dataSource", isSignal: true, isRequired: false, transformFunction: null }, lastItemAsLink: { classPropertyName: "lastItemAsLink", publicName: "lastItemAsLink", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.last-item-as-link": "lastItemAsLink()" }, classAttribute: "ngs-breadcrumbs" }, queries: [{ propertyName: "itemRef", first: true, predicate: BreadcrumbItemDefDirective, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "activeItemRef", first: true, predicate: BreadcrumbActiveItemDefDirective, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "separatorRef", first: true, predicate: BreadcrumbSeparatorDefDirective, descendants: true, read: TemplateRef, isSignal: true }], exportAs: ["ngsBreadcrumbs"], ngImport: i0, template: "@for (breadcrumb of dataSource(); track $index; let last = $last) {\n  @if (!last) {\n    <ng-container *ngTemplateOutlet=\"itemRef(); context: { $implicit: breadcrumb }\"/>\n    <ng-container *ngTemplateOutlet=\"separatorRef()\"/>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"activeItemRef(); context: { $implicit: breadcrumb }\"/>\n  }\n}\n\n<ng-content/>\n", styles: [":host{--ngs-breadcrumbs-gap: calc(var(--spacing, .25rem) * 2.5);--ngs-breadcrumbs-item-font-size: .875rem;--ngs-breadcrumbs-item-color: var(--color-secondary);--ngs-breadcrumbs-item-hover-color: var(--color-primary);--ngs-breadcrumbs-active-item-color: var(--color-primary);--ngs-breadcrumbs-item-font-weight: 400;--ngs-breadcrumbs-separator-color: var(--color-neutral-400);--ngs-breadcrumbs-separator-font-size: .825rem;--ngs-breadcrumbs-separator-position-top: 1px;--ngs-breadcrumbs-title-color: var(--color-neutral-800);--ngs-breadcrumbs-title-font-size: .75rem;display:flex;align-items:center;gap:var(--ngs-breadcrumbs-gap)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Breadcrumbs, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-breadcrumbs', exportAs: 'ngsBreadcrumbs', host: {
                        'class': 'ngs-breadcrumbs',
                        '[class.last-item-as-link]': 'lastItemAsLink()'
                    }, imports: [NgTemplateOutlet], template: "@for (breadcrumb of dataSource(); track $index; let last = $last) {\n  @if (!last) {\n    <ng-container *ngTemplateOutlet=\"itemRef(); context: { $implicit: breadcrumb }\"/>\n    <ng-container *ngTemplateOutlet=\"separatorRef()\"/>\n  } @else {\n    <ng-container *ngTemplateOutlet=\"activeItemRef(); context: { $implicit: breadcrumb }\"/>\n  }\n}\n\n<ng-content/>\n", styles: [":host{--ngs-breadcrumbs-gap: calc(var(--spacing, .25rem) * 2.5);--ngs-breadcrumbs-item-font-size: .875rem;--ngs-breadcrumbs-item-color: var(--color-secondary);--ngs-breadcrumbs-item-hover-color: var(--color-primary);--ngs-breadcrumbs-active-item-color: var(--color-primary);--ngs-breadcrumbs-item-font-weight: 400;--ngs-breadcrumbs-separator-color: var(--color-neutral-400);--ngs-breadcrumbs-separator-font-size: .825rem;--ngs-breadcrumbs-separator-position-top: 1px;--ngs-breadcrumbs-title-color: var(--color-neutral-800);--ngs-breadcrumbs-title-font-size: .75rem;display:flex;align-items:center;gap:var(--ngs-breadcrumbs-gap)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { itemRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BreadcrumbItemDefDirective), { ...{
                            read: TemplateRef
                        }, isSignal: true }] }], activeItemRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BreadcrumbActiveItemDefDirective), { ...{
                            read: TemplateRef
                        }, isSignal: true }] }], separatorRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BreadcrumbSeparatorDefDirective), { ...{
                            read: TemplateRef
                        }, isSignal: true }] }], dataSource: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataSource", required: false }] }], lastItemAsLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "lastItemAsLink", required: false }] }] } });

class BreadcrumbItem {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbItem, isStandalone: true, selector: "ngs-breadcrumb-item,[ngs-breadcrumb-item]", host: { classAttribute: "ngs-breadcrumb-item" }, exportAs: ["ngsBreadcrumbItem"], ngImport: i0, template: "<div class=\"icon\">\n  <ng-content select=\"[ngsBreadcrumbItemIcon]\"/>\n</div>\n<div class=\"content\">\n  <ng-content select=\"ngs-breadcrumb-title\"/>\n  <div class=\"name\">\n    <ng-content/>\n  </div>\n</div>\n", styles: [":host{font-size:var(--ngs-breadcrumbs-item-font-size);font-weight:var(--ngs-breadcrumbs-item-font-weight);color:var(--ngs-breadcrumbs-item-color);display:flex;gap:calc(var(--spacing, .25rem) * 1.5);cursor:pointer;text-decoration:none;align-items:center}:host .icon{line-height:11px}:host .icon ::ng-deep .ngs-breadcrumb-item-icon{font-size:22px;width:22px;height:22px;flex:none}:host .icon:empty{display:none}:host .content:has(.name:empty){display:none}:host:not(:last-child):hover .icon{color:var(--ngs-breadcrumbs-item-hover-color)}:host:not(:last-child):hover .name{color:var(--ngs-breadcrumbs-item-hover-color);text-decoration:underline;text-underline-offset:var(--underline-offset-1)}:host:last-child{cursor:auto;color:var(--ngs-breadcrumbs-active-item-color)}:host-context(.ngs-breadcrumbs.last-item-as-link):last-child{color:var(--ngs-breadcrumbs-item-color);cursor:pointer}:host-context(.ngs-breadcrumbs.last-item-as-link):last-child:hover .icon{color:var(--ngs-breadcrumbs-item-hover-color)}:host-context(.ngs-breadcrumbs.last-item-as-link):last-child:hover .name{color:var(--ngs-breadcrumbs-item-hover-color);text-decoration:underline;text-underline-offset:var(--underline-offset-1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItem, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-breadcrumb-item,[ngs-breadcrumb-item]', exportAs: 'ngsBreadcrumbItem', host: {
                        class: 'ngs-breadcrumb-item'
                    }, template: "<div class=\"icon\">\n  <ng-content select=\"[ngsBreadcrumbItemIcon]\"/>\n</div>\n<div class=\"content\">\n  <ng-content select=\"ngs-breadcrumb-title\"/>\n  <div class=\"name\">\n    <ng-content/>\n  </div>\n</div>\n", styles: [":host{font-size:var(--ngs-breadcrumbs-item-font-size);font-weight:var(--ngs-breadcrumbs-item-font-weight);color:var(--ngs-breadcrumbs-item-color);display:flex;gap:calc(var(--spacing, .25rem) * 1.5);cursor:pointer;text-decoration:none;align-items:center}:host .icon{line-height:11px}:host .icon ::ng-deep .ngs-breadcrumb-item-icon{font-size:22px;width:22px;height:22px;flex:none}:host .icon:empty{display:none}:host .content:has(.name:empty){display:none}:host:not(:last-child):hover .icon{color:var(--ngs-breadcrumbs-item-hover-color)}:host:not(:last-child):hover .name{color:var(--ngs-breadcrumbs-item-hover-color);text-decoration:underline;text-underline-offset:var(--underline-offset-1)}:host:last-child{cursor:auto;color:var(--ngs-breadcrumbs-active-item-color)}:host-context(.ngs-breadcrumbs.last-item-as-link):last-child{color:var(--ngs-breadcrumbs-item-color);cursor:pointer}:host-context(.ngs-breadcrumbs.last-item-as-link):last-child:hover .icon{color:var(--ngs-breadcrumbs-item-hover-color)}:host-context(.ngs-breadcrumbs.last-item-as-link):last-child:hover .name{color:var(--ngs-breadcrumbs-item-hover-color);text-decoration:underline;text-underline-offset:var(--underline-offset-1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class BreadcrumbSeparator {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbSeparator, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbSeparator, isStandalone: true, selector: "ngs-breadcrumb-separator", host: { classAttribute: "ngs-breadcrumb-separator" }, exportAs: ["ngsBreadcrumbSeparator"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{position:relative;color:var(--ngs-breadcrumbs-separator-color);font-size:var(--ngs-breadcrumbs-separator-font-size);top:var(--ngs-breadcrumbs-separator-position-top);line-height:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbSeparator, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-breadcrumb-separator', exportAs: 'ngsBreadcrumbSeparator', host: {
                        class: 'ngs-breadcrumb-separator'
                    }, template: "<ng-content/>\n", styles: [":host{position:relative;color:var(--ngs-breadcrumbs-separator-color);font-size:var(--ngs-breadcrumbs-separator-font-size);top:var(--ngs-breadcrumbs-separator-position-top);line-height:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class BreadcrumbTitle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbTitle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbTitle, isStandalone: true, selector: "ngs-breadcrumb-title", host: { classAttribute: "ngs-breadcrumb-title" }, exportAs: ["ngsBreadcrumbTitle"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;font-size:var(--ngs-breadcrumbs-title-font-size);color:var(--ngs-breadcrumbs-title-color);line-height:var(--leading-relaxed)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbTitle, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-breadcrumb-title', exportAs: 'ngsBreadcrumbTitle', imports: [], host: {
                        class: 'ngs-breadcrumb-title',
                    }, template: "<ng-content/>\n", styles: [":host{display:block;font-size:var(--ngs-breadcrumbs-title-font-size);color:var(--ngs-breadcrumbs-title-color);line-height:var(--leading-relaxed)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

const initialState = {
    breadcrumbs: []
};
const BreadcrumbsStore = signalStore({ providedIn: 'root' }, withState(initialState), withMethods((store) => ({
    setBreadcrumbs(breadcrumbs) {
        patchState(store, {
            breadcrumbs
        });
    }
})));

class BreadcrumbItemIconDefDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemIconDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbItemIconDefDirective, isStandalone: true, selector: "[ngsBreadcrumbItemIconDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemIconDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBreadcrumbItemIconDef]',
                    standalone: true
                }]
        }] });

class BreadcrumbItemIconDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbItemIconDirective, isStandalone: true, selector: "[ngsBreadcrumbItemIcon]", host: { classAttribute: "ngs-breadcrumb-item-icon" }, exportAs: ["ngsBreadcrumbItemIcon"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBreadcrumbItemIcon]',
                    exportAs: 'ngsBreadcrumbItemIcon',
                    standalone: true,
                    host: {
                        'class': 'ngs-breadcrumb-item-icon'
                    }
                }]
        }] });

class BreadcrumbItemNameDefDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemNameDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbItemNameDefDirective, isStandalone: true, selector: "[ngsBreadcrumbItemNameDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemNameDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBreadcrumbItemNameDef]'
                }]
        }] });

class BreadcrumbItemTitleDefDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemTitleDefDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BreadcrumbItemTitleDefDirective, isStandalone: true, selector: "[ngsBreadcrumbItemTitleDef]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbItemTitleDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBreadcrumbItemTitleDef]'
                }]
        }] });

class BreadcrumbsGlobal {
    _breadcrumbsStore = inject(BreadcrumbsStore);
    itemIconDef = contentChild(BreadcrumbItemIconDefDirective, ...(ngDevMode ? [{ debugName: "itemIconDef" }] : /* istanbul ignore next */ []));
    itemNameDef = contentChild(BreadcrumbItemNameDefDirective, ...(ngDevMode ? [{ debugName: "itemNameDef" }] : /* istanbul ignore next */ []));
    itemTitleDef = contentChild(BreadcrumbItemTitleDefDirective, ...(ngDevMode ? [{ debugName: "itemTitleDef" }] : /* istanbul ignore next */ []));
    breadcrumbs = computed(() => {
        return this._breadcrumbsStore.breadcrumbs();
    }, ...(ngDevMode ? [{ debugName: "breadcrumbs" }] : /* istanbul ignore next */ []));
    lastItemAsLink = input(false, { ...(ngDevMode ? { debugName: "lastItemAsLink" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    separator = input('/', ...(ngDevMode ? [{ debugName: "separator" }] : /* istanbul ignore next */ []));
    get iconTemplateRef() {
        return this.itemIconDef()?.templateRef;
    }
    get titleTemplateRef() {
        return this.itemTitleDef()?.templateRef;
    }
    get nameTemplateRef() {
        return this.itemNameDef()?.templateRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbsGlobal, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: BreadcrumbsGlobal, isStandalone: true, selector: "ngs-breadcrumbs-global", inputs: { lastItemAsLink: { classPropertyName: "lastItemAsLink", publicName: "lastItemAsLink", isSignal: true, isRequired: false, transformFunction: null }, separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "ngSkipHydration": "true" }, classAttribute: "ngs-breadcrumbs-global" }, queries: [{ propertyName: "itemIconDef", first: true, predicate: BreadcrumbItemIconDefDirective, descendants: true, isSignal: true }, { propertyName: "itemNameDef", first: true, predicate: BreadcrumbItemNameDefDirective, descendants: true, isSignal: true }, { propertyName: "itemTitleDef", first: true, predicate: BreadcrumbItemTitleDefDirective, descendants: true, isSignal: true }], exportAs: ["ngsBreadcrumbsGlobal"], ngImport: i0, template: "<ngs-breadcrumbs [lastItemAsLink]=\"lastItemAsLink()\">\n  @for (breadcrumb of breadcrumbs(); track $index; let last = $last) {\n    @switch (breadcrumb.type) {\n      @case ('link') {\n        <a ngs-breadcrumb-item [routerLink]=\"breadcrumb.route\">\n          <ng-container ngsBreadcrumbItemIcon>\n            @if (iconTemplateRef) {\n              <ng-container [ngTemplateOutlet]=\"iconTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            } @else {\n              @if (breadcrumb.icon) {\n                <ngs-icon name=\"{{ breadcrumb.icon }}\"/>\n              }\n            }\n          </ng-container>\n\n          @if (titleTemplateRef) {\n            <ngs-breadcrumb-title>\n              <ng-container [ngTemplateOutlet]=\"titleTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            </ngs-breadcrumb-title>\n          } @else {\n            @if (breadcrumb.title) {\n              <ngs-breadcrumb-title>{{ breadcrumb.title }}</ngs-breadcrumb-title>\n            }\n          }\n\n          @if (nameTemplateRef) {\n            <ng-container [ngTemplateOutlet]=\"nameTemplateRef\"\n                          [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n          } @else {\n            @if (breadcrumb.name) {\n              {{ breadcrumb.name }}\n            }\n          }\n        </a>\n      }\n      @default {\n        <ngs-breadcrumb-item>\n          <ng-container ngsBreadcrumbItemIcon>\n            @if (iconTemplateRef) {\n              <ng-container [ngTemplateOutlet]=\"iconTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            } @else if (breadcrumb.icon) {\n              <ngs-icon name=\"{{ breadcrumb.icon }}\"/>\n            }\n          </ng-container>\n\n          @if (titleTemplateRef) {\n            <ngs-breadcrumb-title>\n              <ng-container [ngTemplateOutlet]=\"titleTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            </ngs-breadcrumb-title>\n          } @else {\n            @if (breadcrumb.title) {\n              <ngs-breadcrumb-title>{{ breadcrumb.title }}</ngs-breadcrumb-title>\n            }\n          }\n\n          @if (nameTemplateRef) {\n            <ng-container [ngTemplateOutlet]=\"nameTemplateRef\"\n                          [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n          } @else {\n            @if (breadcrumb.name) {\n              {{ breadcrumb.name }}\n            }\n          }\n        </ngs-breadcrumb-item>\n      }\n    }\n\n    @if (!last) {\n      <ngs-breadcrumb-separator>{{ separator() }}</ngs-breadcrumb-separator>\n    }\n  }\n</ngs-breadcrumbs>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: BreadcrumbItem, selector: "ngs-breadcrumb-item,[ngs-breadcrumb-item]", exportAs: ["ngsBreadcrumbItem"] }, { kind: "component", type: BreadcrumbSeparator, selector: "ngs-breadcrumb-separator", exportAs: ["ngsBreadcrumbSeparator"] }, { kind: "component", type: BreadcrumbTitle, selector: "ngs-breadcrumb-title", exportAs: ["ngsBreadcrumbTitle"] }, { kind: "component", type: Breadcrumbs, selector: "ngs-breadcrumbs", inputs: ["dataSource", "lastItemAsLink"], exportAs: ["ngsBreadcrumbs"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: BreadcrumbItemIconDirective, selector: "[ngsBreadcrumbItemIcon]", exportAs: ["ngsBreadcrumbItemIcon"] }, { kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BreadcrumbsGlobal, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-breadcrumbs-global', exportAs: 'ngsBreadcrumbsGlobal', imports: [
                        BreadcrumbItem,
                        BreadcrumbSeparator,
                        BreadcrumbTitle,
                        Breadcrumbs,
                        RouterLink,
                        BreadcrumbItemIconDirective,
                        Icon,
                        NgTemplateOutlet
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-breadcrumbs-global',
                        ngSkipHydration: 'true'
                    }, template: "<ngs-breadcrumbs [lastItemAsLink]=\"lastItemAsLink()\">\n  @for (breadcrumb of breadcrumbs(); track $index; let last = $last) {\n    @switch (breadcrumb.type) {\n      @case ('link') {\n        <a ngs-breadcrumb-item [routerLink]=\"breadcrumb.route\">\n          <ng-container ngsBreadcrumbItemIcon>\n            @if (iconTemplateRef) {\n              <ng-container [ngTemplateOutlet]=\"iconTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            } @else {\n              @if (breadcrumb.icon) {\n                <ngs-icon name=\"{{ breadcrumb.icon }}\"/>\n              }\n            }\n          </ng-container>\n\n          @if (titleTemplateRef) {\n            <ngs-breadcrumb-title>\n              <ng-container [ngTemplateOutlet]=\"titleTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            </ngs-breadcrumb-title>\n          } @else {\n            @if (breadcrumb.title) {\n              <ngs-breadcrumb-title>{{ breadcrumb.title }}</ngs-breadcrumb-title>\n            }\n          }\n\n          @if (nameTemplateRef) {\n            <ng-container [ngTemplateOutlet]=\"nameTemplateRef\"\n                          [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n          } @else {\n            @if (breadcrumb.name) {\n              {{ breadcrumb.name }}\n            }\n          }\n        </a>\n      }\n      @default {\n        <ngs-breadcrumb-item>\n          <ng-container ngsBreadcrumbItemIcon>\n            @if (iconTemplateRef) {\n              <ng-container [ngTemplateOutlet]=\"iconTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            } @else if (breadcrumb.icon) {\n              <ngs-icon name=\"{{ breadcrumb.icon }}\"/>\n            }\n          </ng-container>\n\n          @if (titleTemplateRef) {\n            <ngs-breadcrumb-title>\n              <ng-container [ngTemplateOutlet]=\"titleTemplateRef\"\n                            [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n            </ngs-breadcrumb-title>\n          } @else {\n            @if (breadcrumb.title) {\n              <ngs-breadcrumb-title>{{ breadcrumb.title }}</ngs-breadcrumb-title>\n            }\n          }\n\n          @if (nameTemplateRef) {\n            <ng-container [ngTemplateOutlet]=\"nameTemplateRef\"\n                          [ngTemplateOutletContext]=\"{ $implicit: breadcrumb }\"/>\n          } @else {\n            @if (breadcrumb.name) {\n              {{ breadcrumb.name }}\n            }\n          }\n        </ngs-breadcrumb-item>\n      }\n    }\n\n    @if (!last) {\n      <ngs-breadcrumb-separator>{{ separator() }}</ngs-breadcrumb-separator>\n    }\n  }\n</ngs-breadcrumbs>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { itemIconDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BreadcrumbItemIconDefDirective), { isSignal: true }] }], itemNameDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BreadcrumbItemNameDefDirective), { isSignal: true }] }], itemTitleDef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BreadcrumbItemTitleDefDirective), { isSignal: true }] }], lastItemAsLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "lastItemAsLink", required: false }] }], separator: [{ type: i0.Input, args: [{ isSignal: true, alias: "separator", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { BreadcrumbActiveItemDefDirective, BreadcrumbItem, BreadcrumbItemDefDirective, BreadcrumbItemIconDefDirective, BreadcrumbItemIconDirective, BreadcrumbItemNameDefDirective, BreadcrumbItemTitleDefDirective, BreadcrumbSeparator, BreadcrumbSeparatorDefDirective, BreadcrumbTitle, Breadcrumbs, BreadcrumbsGlobal, BreadcrumbsStore };
//# sourceMappingURL=ngstarter-components-breadcrumbs.mjs.map
