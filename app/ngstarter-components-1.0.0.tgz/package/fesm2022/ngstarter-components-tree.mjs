import * as i0 from '@angular/core';
import { inject, ViewContainerRef, Directive, viewChild, ChangeDetectionStrategy, Component, input, numberAttribute, booleanAttribute, HostAttributeToken, effect } from '@angular/core';
import { CDK_TREE_NODE_OUTLET_NODE, CdkTreeNodeOutlet, CdkTree, CdkTreeNode, CdkNestedTreeNode, CdkTreeNodePadding, CdkTreeNodeToggle, CdkTreeNodeDef } from '@angular/cdk/tree';

class TreeNodeOutlet {
    viewContainer = inject(ViewContainerRef);
    _node = inject(CDK_TREE_NODE_OUTLET_NODE, { optional: true });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodeOutlet, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TreeNodeOutlet, isStandalone: true, selector: "[ngsTreeNodeOutlet]", providers: [
            {
                provide: CdkTreeNodeOutlet,
                useExisting: TreeNodeOutlet,
            },
        ], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodeOutlet, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTreeNodeOutlet]',
                    providers: [
                        {
                            provide: CdkTreeNodeOutlet,
                            useExisting: TreeNodeOutlet,
                        },
                    ],
                    standalone: true
                }]
        }] });
class Tree extends CdkTree {
    // Outlets within the tree's template where the dataNodes will be inserted.
    // We need an initializer here to avoid a TS error. The value will be set in `ngAfterViewInit`.
    _nodeOutlet = viewChild(TreeNodeOutlet);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Tree, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: Tree, isStandalone: true, selector: "ngs-tree", host: { classAttribute: "ngs-tree" }, providers: [{ provide: CdkTree, useExisting: Tree }], viewQueries: [{ propertyName: "_nodeOutlet", first: true, predicate: TreeNodeOutlet, descendants: true, isSignal: true }], exportAs: ["ngsTree"], usesInheritance: true, ngImport: i0, template: `<ng-container ngsTreeNodeOutlet />`, isInline: true, styles: [":host{display:block;background:var(--ngs-tree-container-background-color, transparent)}:host ::ng-deep .ngs-tree-node,:host ::ng-deep .ngs-nested-tree-node{color:var(--ngs-tree-node-text-color, inherit);font-family:var(--ngs-tree-node-text-font, inherit);font-size:var(--ngs-tree-node-text-size, inherit);font-weight:var(--ngs-tree-node-text-weight, inherit)}:host ::ng-deep .ngs-tree-node{display:flex;align-items:center;flex:1;word-wrap:break-word;min-height:var(--ngs-tree-node-min-height, 48px);box-sizing:border-box}:host ::ng-deep .ngs-nested-tree-node{border-bottom-width:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "directive", type: TreeNodeOutlet, selector: "[ngsTreeNodeOutlet]" }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Tree, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tree', exportAs: 'ngsTree', template: `<ng-container ngsTreeNodeOutlet />`, host: {
                        'class': 'ngs-tree',
                    }, changeDetection: ChangeDetectionStrategy.Default, providers: [{ provide: CdkTree, useExisting: Tree }], imports: [TreeNodeOutlet], standalone: true, styles: [":host{display:block;background:var(--ngs-tree-container-background-color, transparent)}:host ::ng-deep .ngs-tree-node,:host ::ng-deep .ngs-nested-tree-node{color:var(--ngs-tree-node-text-color, inherit);font-family:var(--ngs-tree-node-text-font, inherit);font-size:var(--ngs-tree-node-text-size, inherit);font-weight:var(--ngs-tree-node-text-weight, inherit)}:host ::ng-deep .ngs-tree-node{display:flex;align-items:center;flex:1;word-wrap:break-word;min-height:var(--ngs-tree-node-min-height, 48px);box-sizing:border-box}:host ::ng-deep .ngs-nested-tree-node{border-bottom-width:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { _nodeOutlet: [{ type: i0.ViewChild, args: [i0.forwardRef(() => TreeNodeOutlet), { isSignal: true }] }] } });

function isNoopTreeKeyManager(keyManager) {
    return !!keyManager._isNoopTreeKeyManager;
}
class TreeNode extends CdkTreeNode {
    tabIndexInputBinding = input(0, { ...(ngDevMode ? { debugName: "tabIndexInputBinding" } : /* istanbul ignore next */ {}), transform: (value) => (value == null ? 0 : numberAttribute(value)),
        alias: 'tabIndex' });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    defaultTabIndex = 0;
    constructor() {
        super();
        const tabIndex = inject(new HostAttributeToken('tabindex'), { optional: true });
        this._tabIndexInputBinding = Number(tabIndex) || this.defaultTabIndex;
        effect(() => {
            this.isDisabled = this.disabled();
        });
    }
    _getTabindexAttribute() {
        if (isNoopTreeKeyManager(this._tree._keyManager)) {
            return this.tabIndexInputBinding();
        }
        return this._tabindex;
    }
    ngOnInit() {
        super.ngOnInit();
    }
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNode, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: TreeNode, isStandalone: true, selector: "ngs-tree-node", inputs: { tabIndexInputBinding: { classPropertyName: "tabIndexInputBinding", publicName: "tabIndex", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activation: "activation", expandedChange: "expandedChange" }, host: { listeners: { "click": "_focusItem()" }, properties: { "attr.aria-expanded": "_getAriaExpanded()", "attr.aria-level": "level + 1", "attr.aria-posinset": "_getPositionInSet()", "attr.aria-setsize": "_getSetSize()", "tabindex": "_getTabindexAttribute()" }, classAttribute: "ngs-tree-node" }, providers: [{ provide: CdkTreeNode, useExisting: TreeNode }], exportAs: ["ngsTreeNode"], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNode, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ngs-tree-node',
                    exportAs: 'ngsTreeNode',
                    outputs: ['activation', 'expandedChange'],
                    providers: [{ provide: CdkTreeNode, useExisting: TreeNode }],
                    host: {
                        'class': 'ngs-tree-node',
                        '[attr.aria-expanded]': '_getAriaExpanded()',
                        '[attr.aria-level]': 'level + 1',
                        '[attr.aria-posinset]': '_getPositionInSet()',
                        '[attr.aria-setsize]': '_getSetSize()',
                        '(click)': '_focusItem()',
                        '[tabindex]': '_getTabindexAttribute()',
                    },
                    standalone: true
                }]
        }], ctorParameters: () => [], propDecorators: { tabIndexInputBinding: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabIndex", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
class NestedTreeNode extends CdkNestedTreeNode {
    node = input(undefined, { ...(ngDevMode ? { debugName: "node" } : /* istanbul ignore next */ {}), alias: 'ngsNestedTreeNode' });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tabIndexInput = input(0, { ...(ngDevMode ? { debugName: "tabIndexInput" } : /* istanbul ignore next */ {}), alias: 'tabIndex',
        transform: (value) => (value == null ? 0 : numberAttribute(value)) });
    constructor() {
        super();
        effect(() => {
            this.isDisabled = this.disabled();
        });
    }
    get tabIndex() {
        return this.isDisabled ? -1 : this.tabIndexInput();
    }
    ngOnInit() {
        super.ngOnInit();
    }
    ngAfterContentInit() {
        super.ngAfterContentInit();
    }
    ngOnDestroy() {
        super.ngOnDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NestedTreeNode, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: NestedTreeNode, isStandalone: true, selector: "ngs-nested-tree-node", inputs: { node: { classPropertyName: "node", publicName: "ngsNestedTreeNode", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, tabIndexInput: { classPropertyName: "tabIndexInput", publicName: "tabIndex", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activation: "activation", expandedChange: "expandedChange" }, host: { classAttribute: "ngs-nested-tree-node" }, providers: [
            { provide: CdkNestedTreeNode, useExisting: NestedTreeNode },
            { provide: CdkTreeNode, useExisting: NestedTreeNode },
            { provide: CDK_TREE_NODE_OUTLET_NODE, useExisting: NestedTreeNode },
        ], exportAs: ["ngsNestedTreeNode"], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NestedTreeNode, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ngs-nested-tree-node',
                    exportAs: 'ngsNestedTreeNode',
                    outputs: ['activation', 'expandedChange'],
                    providers: [
                        { provide: CdkNestedTreeNode, useExisting: NestedTreeNode },
                        { provide: CdkTreeNode, useExisting: NestedTreeNode },
                        { provide: CDK_TREE_NODE_OUTLET_NODE, useExisting: NestedTreeNode },
                    ],
                    host: {
                        'class': 'ngs-nested-tree-node',
                    },
                    standalone: true
                }]
        }], ctorParameters: () => [], propDecorators: { node: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsNestedTreeNode", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], tabIndexInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabIndex", required: false }] }] } });

class TreeNodePadding extends CdkTreeNodePadding {
    levelInput = input(0, { ...(ngDevMode ? { debugName: "levelInput" } : /* istanbul ignore next */ {}), alias: 'ngsTreeNodePadding',
        transform: numberAttribute });
    indentInput = input(40, { ...(ngDevMode ? { debugName: "indentInput" } : /* istanbul ignore next */ {}), alias: 'ngsTreeNodePaddingIndent' });
    constructor() {
        super();
        effect(() => {
            this.level = this.levelInput();
        });
        effect(() => {
            this._setIndentInput(this.indentInput());
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodePadding, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: TreeNodePadding, isStandalone: true, selector: "[ngsTreeNodePadding]", inputs: { levelInput: { classPropertyName: "levelInput", publicName: "ngsTreeNodePadding", isSignal: true, isRequired: false, transformFunction: null }, indentInput: { classPropertyName: "indentInput", publicName: "ngsTreeNodePaddingIndent", isSignal: true, isRequired: false, transformFunction: null } }, providers: [{ provide: CdkTreeNodePadding, useExisting: TreeNodePadding }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodePadding, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTreeNodePadding]',
                    providers: [{ provide: CdkTreeNodePadding, useExisting: TreeNodePadding }],
                    standalone: true
                }]
        }], ctorParameters: () => [], propDecorators: { levelInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsTreeNodePadding", required: false }] }], indentInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsTreeNodePaddingIndent", required: false }] }] } });

class TreeNodeToggle extends CdkTreeNodeToggle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodeToggle, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TreeNodeToggle, isStandalone: true, selector: "[ngsTreeNodeToggle]", inputs: { recursive: ["ngsTreeNodeToggleRecursive", "recursive"] }, providers: [{ provide: CdkTreeNodeToggle, useExisting: TreeNodeToggle }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodeToggle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTreeNodeToggle]',
                    providers: [{ provide: CdkTreeNodeToggle, useExisting: TreeNodeToggle }],
                    inputs: [{ name: 'recursive', alias: 'ngsTreeNodeToggleRecursive' }],
                    standalone: true
                }]
        }] });

class TreeNodeDef extends CdkTreeNodeDef {
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'ngsTreeNode' });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodeDef, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: TreeNodeDef, isStandalone: true, selector: "[ngsTreeNodeDef]", inputs: { when: { classPropertyName: "when", publicName: "ngsTreeNodeDefWhen", isSignal: false, isRequired: false, transformFunction: null }, data: { classPropertyName: "data", publicName: "ngsTreeNode", isSignal: true, isRequired: false, transformFunction: null } }, providers: [{ provide: CdkTreeNodeDef, useExisting: TreeNodeDef }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TreeNodeDef, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTreeNodeDef]',
                    inputs: [{ name: 'when', alias: 'ngsTreeNodeDefWhen' }],
                    providers: [{ provide: CdkTreeNodeDef, useExisting: TreeNodeDef }],
                    standalone: true
                }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsTreeNode", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { NestedTreeNode, Tree, TreeNode, TreeNodeDef, TreeNodeOutlet, TreeNodePadding, TreeNodeToggle };
//# sourceMappingURL=ngstarter-components-tree.mjs.map
