import * as i0 from '@angular/core';
import { Component } from '@angular/core';

class Kbd {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Kbd, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Kbd, isStandalone: true, selector: "ngs-kbd", host: { classAttribute: "ngs-kbd" }, exportAs: ["ngsKbd"], ngImport: i0, template: "<div class=\"content\">\n  <ng-content/>\n</div>\n<span class=\"plus\">+</span>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center}:host .content{display:inline-flex;align-items:center;justify-content:center;font-size:.75rem;padding:calc(var(--spacing, .25rem) * 1.5);height:calc(var(--spacing, .25rem) * 6);border-radius:.5rem;background:var(--color-surface-container);min-width:calc(var(--spacing, .25rem) * 6);line-height:0;flex:none;gap:calc(var(--spacing, .25rem) * .5)}:host .plus{display:none;font-size:.75rem}:host-context(.ngs-kdb-group):not(:last-child) .plus{display:inline-flex;margin:0 calc(var(--spacing, .25rem) * 1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Kbd, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-kbd', exportAs: 'ngsKbd', imports: [], host: {
                        'class': 'ngs-kbd',
                    }, template: "<div class=\"content\">\n  <ng-content/>\n</div>\n<span class=\"plus\">+</span>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center}:host .content{display:inline-flex;align-items:center;justify-content:center;font-size:.75rem;padding:calc(var(--spacing, .25rem) * 1.5);height:calc(var(--spacing, .25rem) * 6);border-radius:.5rem;background:var(--color-surface-container);min-width:calc(var(--spacing, .25rem) * 6);line-height:0;flex:none;gap:calc(var(--spacing, .25rem) * .5)}:host .plus{display:none;font-size:.75rem}:host-context(.ngs-kdb-group):not(:last-child) .plus{display:inline-flex;margin:0 calc(var(--spacing, .25rem) * 1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class KbdGroup {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: KbdGroup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: KbdGroup, isStandalone: true, selector: "ngs-kbd-group", host: { classAttribute: "ngs-kdb-group" }, exportAs: ["ngsKbdGroup"], ngImport: i0, template: "<ng-content select=\"ngs-kbd\"/>\n", styles: [":host{display:inline-flex;align-items:center;-webkit-user-select:none;user-select:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: KbdGroup, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-kbd-group', exportAs: 'ngsKbdGroup', imports: [], host: {
                        'class': 'ngs-kdb-group'
                    }, template: "<ng-content select=\"ngs-kbd\"/>\n", styles: [":host{display:inline-flex;align-items:center;-webkit-user-select:none;user-select:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Kbd, KbdGroup };
//# sourceMappingURL=ngstarter-components-kbd.mjs.map
