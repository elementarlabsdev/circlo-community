import * as i0 from '@angular/core';
import { input, booleanAttribute, TemplateRef, Component, Injectable } from '@angular/core';
import { ProgressBar } from '@ngstarter/components/progress-bar';
import { NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/cdk/overlay';
import { OverlayConfig } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { Subject } from 'rxjs';

class ScreenLoader {
    opened = input(false, { ...(ngDevMode ? { debugName: "opened" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    message = input(null, ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    isTemplateRef(value) {
        return value instanceof TemplateRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ScreenLoader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: ScreenLoader, isStandalone: true, selector: "ngs-screen-loader", inputs: { opened: { classPropertyName: "opened", publicName: "opened", isSignal: true, isRequired: false, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-opened": "opened()" }, classAttribute: "ngs-screen-loader not-prose" }, exportAs: ["ngsScreenLoader"], ngImport: i0, template: "<div class=\"message\">\n  @if (message(); as msg) {\n    @if (isTemplateRef(msg)) {\n      <ng-container *ngTemplateOutlet=\"msg\" />\n    } @else {\n      {{ msg }}\n    }\n  } @else {\n    <ng-content/>\n  }\n</div>\n<div class=\"progress-bar\">\n  <ngs-progress-bar mode=\"indeterminate\"/>\n</div>\n", styles: [":host{--ngs-screen-loader-bg: var(--color-background);opacity:0;position:fixed;inset:0;z-index:-9999;display:flex;align-items:center;justify-content:center;flex-direction:column;background:var(--ngs-screen-loader-bg)}:host.is-opened{z-index:9999;opacity:1}:host .message{max-width:600px;line-height:var(--leading-snug);text-align:center}:host .progress-bar{width:calc(var(--spacing, .25rem) * 64);margin-top:calc(var(--spacing, .25rem) * 5)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: ProgressBar, selector: "ngs-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["ngsProgressBar"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ScreenLoader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-screen-loader', exportAs: 'ngsScreenLoader', imports: [
                        ProgressBar,
                        NgTemplateOutlet
                    ], host: {
                        'class': 'ngs-screen-loader not-prose',
                        '[class.is-opened]': 'opened()'
                    }, template: "<div class=\"message\">\n  @if (message(); as msg) {\n    @if (isTemplateRef(msg)) {\n      <ng-container *ngTemplateOutlet=\"msg\" />\n    } @else {\n      {{ msg }}\n    }\n  } @else {\n    <ng-content/>\n  }\n</div>\n<div class=\"progress-bar\">\n  <ngs-progress-bar mode=\"indeterminate\"/>\n</div>\n", styles: [":host{--ngs-screen-loader-bg: var(--color-background);opacity:0;position:fixed;inset:0;z-index:-9999;display:flex;align-items:center;justify-content:center;flex-direction:column;background:var(--ngs-screen-loader-bg)}:host.is-opened{z-index:9999;opacity:1}:host .message{max-width:600px;line-height:var(--leading-snug);text-align:center}:host .progress-bar{width:calc(var(--spacing, .25rem) * 64);margin-top:calc(var(--spacing, .25rem) * 5)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { opened: [{ type: i0.Input, args: [{ isSignal: true, alias: "opened", required: false }] }], message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }] } });

class ScreenLoaderRef {
    overlayRef;
    _afterOpened = new Subject();
    _afterClosed = new Subject();
    constructor(overlayRef) {
        this.overlayRef = overlayRef;
        this.overlayRef.detachments().subscribe(() => {
            this._afterClosed.next();
            this._afterClosed.complete();
        });
    }
    close() {
        this.overlayRef.dispose();
    }
    afterOpened() {
        return this._afterOpened.asObservable();
    }
    afterClosed() {
        return this._afterClosed.asObservable();
    }
    _notifyOpened() {
        this._afterOpened.next();
        this._afterOpened.complete();
    }
}

class ScreenLoaderService {
    overlay;
    injector;
    constructor(overlay, injector) {
        this.overlay = overlay;
        this.injector = injector;
    }
    open(message) {
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            scrollStrategy: this.overlay.scrollStrategies.block(),
            positionStrategy: this.overlay.position().global(),
            width: '100%',
            height: '100%'
        });
        const overlayRef = this.overlay.create(overlayConfig);
        const screenLoaderRef = new ScreenLoaderRef(overlayRef);
        const componentPortal = new ComponentPortal(ScreenLoader, null, this.injector);
        const componentRef = overlayRef.attach(componentPortal);
        componentRef.setInput('opened', true);
        componentRef.setInput('message', message);
        screenLoaderRef._notifyOpened();
        return screenLoaderRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ScreenLoaderService, deps: [{ token: i1.Overlay }, { token: i0.Injector }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ScreenLoaderService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ScreenLoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1.Overlay }, { type: i0.Injector }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ScreenLoader, ScreenLoaderRef, ScreenLoaderService };
//# sourceMappingURL=ngstarter-components-screen-loader.mjs.map
