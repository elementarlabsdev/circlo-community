import * as i0 from '@angular/core';
import { Component } from '@angular/core';

class VisualBuilder {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VisualBuilder, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: VisualBuilder, isStandalone: true, selector: "ngs-visual-builder", ngImport: i0, template: "<p>visual-builder works!</p>\n", styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VisualBuilder, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-visual-builder', imports: [], template: "<p>visual-builder works!</p>\n" }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { VisualBuilder };
//# sourceMappingURL=ngstarter-components-visual-builder.mjs.map
