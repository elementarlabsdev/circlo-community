var index = null;

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=ngstarter-components.mjs.map
