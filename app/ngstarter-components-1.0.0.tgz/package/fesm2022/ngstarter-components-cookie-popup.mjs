import * as i0 from '@angular/core';
import { inject, ViewContainerRef, Injector, viewChild, input, booleanAttribute, output, effect, Component, Directive } from '@angular/core';
import { Overlay } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Button } from '@ngstarter/components/button';

class CookiePopup {
    _overlay = inject(Overlay);
    _viewContainerRef = inject(ViewContainerRef);
    _injector = inject(Injector);
    _contentRef = viewChild.required('contentRef');
    cookiePolicyUrl = input('', ...(ngDevMode ? [{ debugName: "cookiePolicyUrl" }] : /* istanbul ignore next */ []));
    visible = input(true, { ...(ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _overlayRef = null;
    cookieAccepted = output();
    constructor() {
        effect(() => {
            if (this.visible()) {
                this._show();
            }
            else {
                this._hide();
            }
        });
    }
    acceptNecessaryCookiesOnly() {
        this.cookieAccepted.emit('necessary');
        this._hide();
    }
    acceptAllCookies() {
        this.cookieAccepted.emit('all');
        this._hide();
    }
    _show() {
        if (this._overlayRef) {
            return;
        }
        const overlayPositionStrategy = this._overlay
            .position()
            .global()
            .start('20px')
            .bottom('20px');
        this._overlayRef = this._overlay.create({
            hasBackdrop: false,
            positionStrategy: overlayPositionStrategy,
            scrollStrategy: this._overlay.scrollStrategies.reposition(),
        });
        this._overlayRef.attach(new TemplatePortal(this._contentRef(), this._viewContainerRef, null, this._injector));
    }
    _hide() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef.detach();
            this._overlayRef = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: CookiePopup, isStandalone: true, selector: "ngs-cookie-popup", inputs: { cookiePolicyUrl: { classPropertyName: "cookiePolicyUrl", publicName: "cookiePolicyUrl", isSignal: true, isRequired: false, transformFunction: null }, visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { cookieAccepted: "cookieAccepted" }, viewQueries: [{ propertyName: "_contentRef", first: true, predicate: ["contentRef"], descendants: true, isSignal: true }], exportAs: ["ngsCookiePopup"], ngImport: i0, template: "<ng-template #contentRef>\n  <div class=\"ngs-cookie-popup\">\n    <h4 class=\"title\">\n      <ng-content select=\"[ngsCookiePopupTitle]\"/>\n    </h4>\n    <div class=\"message\">\n      <ng-content/>\n    </div>\n    <div class=\"controls\">\n      <button ngsButton=\"outlined\" class=\"control\" (click)=\"acceptNecessaryCookiesOnly()\">\n        <ng-content select=\"[ngsCookiePopupAcceptNecessaryOnlyButton]\"/>\n      </button>\n      <button ngsButton=\"filled\" class=\"control\" (click)=\"acceptAllCookies()\">\n        <ng-content select=\"[ngsCookiePopupAcceptAllButton]\"/>\n      </button>\n    </div>\n  </div>\n</ng-template>\n", styles: [":host{display:none;z-index:-99999;opacity:0}.ngs-cookie-popup{width:400px;border-radius:1rem;box-shadow:0 10px 15px -3px #0000001a,0 4px 6px -4px #0000001a;background:var(--color-surface-container-lowest);padding:calc(var(--spacing, .25rem) * 4)}.ngs-cookie-popup .title{margin-bottom:calc(var(--spacing, .25rem) * 3);font-weight:700}.ngs-cookie-popup .message{font-size:.875rem;margin-bottom:calc(var(--spacing, .25rem) * 4)}.ngs-cookie-popup .controls{display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 2)}.ngs-cookie-popup .control{width:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopup, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-cookie-popup', exportAs: 'ngsCookiePopup', imports: [
                        Button
                    ], template: "<ng-template #contentRef>\n  <div class=\"ngs-cookie-popup\">\n    <h4 class=\"title\">\n      <ng-content select=\"[ngsCookiePopupTitle]\"/>\n    </h4>\n    <div class=\"message\">\n      <ng-content/>\n    </div>\n    <div class=\"controls\">\n      <button ngsButton=\"outlined\" class=\"control\" (click)=\"acceptNecessaryCookiesOnly()\">\n        <ng-content select=\"[ngsCookiePopupAcceptNecessaryOnlyButton]\"/>\n      </button>\n      <button ngsButton=\"filled\" class=\"control\" (click)=\"acceptAllCookies()\">\n        <ng-content select=\"[ngsCookiePopupAcceptAllButton]\"/>\n      </button>\n    </div>\n  </div>\n</ng-template>\n", styles: [":host{display:none;z-index:-99999;opacity:0}.ngs-cookie-popup{width:400px;border-radius:1rem;box-shadow:0 10px 15px -3px #0000001a,0 4px 6px -4px #0000001a;background:var(--color-surface-container-lowest);padding:calc(var(--spacing, .25rem) * 4)}.ngs-cookie-popup .title{margin-bottom:calc(var(--spacing, .25rem) * 3);font-weight:700}.ngs-cookie-popup .message{font-size:.875rem;margin-bottom:calc(var(--spacing, .25rem) * 4)}.ngs-cookie-popup .controls{display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 2)}.ngs-cookie-popup .control{width:100%}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { _contentRef: [{ type: i0.ViewChild, args: ['contentRef', { isSignal: true }] }], cookiePolicyUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "cookiePolicyUrl", required: false }] }], visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }], cookieAccepted: [{ type: i0.Output, args: ["cookieAccepted"] }] } });

class CookiePopupTitleDirective {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopupTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CookiePopupTitleDirective, isStandalone: true, selector: "[ngsCookiePopupTitle]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopupTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsCookiePopupTitle]'
                }]
        }], ctorParameters: () => [] });

class CookiePopupAcceptAllButtonDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopupAcceptAllButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CookiePopupAcceptAllButtonDirective, isStandalone: true, selector: "[ngsCookiePopupAcceptAllButton]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopupAcceptAllButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsCookiePopupAcceptAllButton]'
                }]
        }] });

class CookiePopupAcceptNecessaryOnlyButtonDirective {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopupAcceptNecessaryOnlyButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CookiePopupAcceptNecessaryOnlyButtonDirective, isStandalone: true, selector: "[ngsCookiePopupAcceptNecessaryOnlyButton]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CookiePopupAcceptNecessaryOnlyButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsCookiePopupAcceptNecessaryOnlyButton]'
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { CookiePopup, CookiePopupAcceptAllButtonDirective, CookiePopupAcceptNecessaryOnlyButtonDirective, CookiePopupTitleDirective };
//# sourceMappingURL=ngstarter-components-cookie-popup.mjs.map
