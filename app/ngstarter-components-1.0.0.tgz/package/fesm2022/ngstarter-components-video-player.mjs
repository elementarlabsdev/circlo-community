import * as i0 from '@angular/core';
import { inject, PLATFORM_ID, DestroyRef, input, viewChild, signal, computed, effect, Component } from '@angular/core';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { Icon } from '@ngstarter/components/icon';
import { Button } from '@ngstarter/components/button';
import { Slider, SliderThumb } from '@ngstarter/components/slider';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

class VideoPlayer {
    platformId = inject(PLATFORM_ID);
    document = inject(DOCUMENT);
    destroyRef = inject(DestroyRef);
    src = input(null, ...(ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []));
    payload = input(null, ...(ngDevMode ? [{ debugName: "payload" }] : /* istanbul ignore next */ []));
    autoPlay = input(false, ...(ngDevMode ? [{ debugName: "autoPlay" }] : /* istanbul ignore next */ []));
    minimalControls = input(false, ...(ngDevMode ? [{ debugName: "minimalControls" }] : /* istanbul ignore next */ []));
    videoElement = viewChild('videoElement', ...(ngDevMode ? [{ debugName: "videoElement" }] : /* istanbul ignore next */ []));
    loaded = signal(false, ...(ngDevMode ? [{ debugName: "loaded" }] : /* istanbul ignore next */ []));
    isPlaying = signal(false, ...(ngDevMode ? [{ debugName: "isPlaying" }] : /* istanbul ignore next */ []));
    hasStarted = signal(false, ...(ngDevMode ? [{ debugName: "hasStarted" }] : /* istanbul ignore next */ []));
    currentTime = signal(0, ...(ngDevMode ? [{ debugName: "currentTime" }] : /* istanbul ignore next */ []));
    duration = signal(0, ...(ngDevMode ? [{ debugName: "duration" }] : /* istanbul ignore next */ []));
    volume = signal(1, ...(ngDevMode ? [{ debugName: "volume" }] : /* istanbul ignore next */ []));
    isMuted = signal(false, ...(ngDevMode ? [{ debugName: "isMuted" }] : /* istanbul ignore next */ []));
    isFullscreen = signal(false, ...(ngDevMode ? [{ debugName: "isFullscreen" }] : /* istanbul ignore next */ []));
    orientation = computed(() => {
        return this.payload()?.orientation || 'landscape';
    }, ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    player = null;
    constructor() {
        effect(() => {
            const src = this.src();
            if (src && isPlatformBrowser(this.platformId)) {
                this.loaded.set(false);
                this.updateSrc(src);
            }
        });
        effect(() => {
            const isMuted = this.isMuted();
            const videoElement = this.videoElement();
            if (videoElement) {
                videoElement.nativeElement.muted = isMuted;
            }
        });
    }
    ngAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            this.initPlayer();
            this.setupEvents();
        }
    }
    onLoadedData = () => {
        this.loaded.set(true);
    };
    onTimeUpdate = () => {
        const videoElement = this.videoElement();
        if (videoElement) {
            this.currentTime.set(videoElement.nativeElement.currentTime);
        }
    };
    onLoadedMetadata = () => {
        const videoElement = this.videoElement();
        if (videoElement) {
            this.duration.set(videoElement.nativeElement.duration);
        }
    };
    onPlay = () => {
        this.isPlaying.set(true);
        this.hasStarted.set(true);
    };
    onPause = () => {
        this.isPlaying.set(false);
    };
    setupEvents() {
        const videoElement = this.videoElement();
        if (!videoElement || !isPlatformBrowser(this.platformId)) {
            return;
        }
        const nativeElement = videoElement.nativeElement;
        fromEvent(nativeElement, 'loadeddata')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onLoadedData());
        fromEvent(nativeElement, 'canplay')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onLoadedData());
        fromEvent(nativeElement, 'timeupdate')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onTimeUpdate());
        fromEvent(nativeElement, 'loadedmetadata')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onLoadedMetadata());
        fromEvent(nativeElement, 'play')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onPlay());
        fromEvent(nativeElement, 'pause')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onPause());
        fromEvent(this.document, 'fullscreenchange')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onFullscreenChange());
    }
    onFullscreenChange = () => {
        this.isFullscreen.set(!!this.document.fullscreenElement);
    };
    toggleFullscreen() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        const container = this.videoElement()?.nativeElement.parentElement;
        if (!container)
            return;
        if (!this.document.fullscreenElement) {
            container.requestFullscreen().catch(err => {
                console.error(`Error attempting to enable full-screen mode: ${err.message}`);
            });
        }
        else {
            this.document.exitFullscreen();
        }
    }
    togglePlay() {
        const videoElement = this.videoElement();
        if (videoElement) {
            if (videoElement.nativeElement.paused) {
                videoElement.nativeElement.play();
            }
            else {
                videoElement.nativeElement.pause();
            }
        }
    }
    seek(event) {
        const videoElement = this.videoElement();
        if (videoElement) {
            videoElement.nativeElement.currentTime = event.target.value;
        }
    }
    toggleMute() {
        const videoElement = this.videoElement();
        if (videoElement) {
            videoElement.nativeElement.muted = !videoElement.nativeElement.muted;
            this.isMuted.set(videoElement.nativeElement.muted);
        }
    }
    async initPlayer() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        const videoElement = this.videoElement();
        if (!videoElement) {
            return;
        }
        const src = this.src();
        const payload = this.payload();
        const dashUrl = payload?.dash?.manifest;
        if (!src && !dashUrl) {
            return;
        }
        const finalSrc = dashUrl || src;
        if (finalSrc && finalSrc.endsWith('.mpd')) {
            const dashjs = await import('dashjs');
            this.player = dashjs.MediaPlayer().create();
            this.player.initialize(videoElement.nativeElement, finalSrc, this.autoPlay());
        }
        else if (finalSrc) {
            videoElement.nativeElement.src = finalSrc;
            videoElement.nativeElement.autoplay = this.autoPlay();
            videoElement.nativeElement.load();
        }
    }
    updateSrc(src) {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        if (this.player) {
            this.player.attachSource(src);
        }
        else {
            const videoElement = this.videoElement();
            if (videoElement) {
                if (src.endsWith('.mpd')) {
                    this.initPlayer();
                }
                else {
                    videoElement.nativeElement.src = src;
                    videoElement.nativeElement.load();
                }
            }
        }
    }
    ngOnDestroy() {
        if (this.player) {
            this.player.destroy();
            this.player = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: VideoPlayer, isStandalone: true, selector: "ngs-video-player", inputs: { src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, payload: { classPropertyName: "payload", publicName: "payload", isSignal: true, isRequired: false, transformFunction: null }, autoPlay: { classPropertyName: "autoPlay", publicName: "autoPlay", isSignal: true, isRequired: false, transformFunction: null }, minimalControls: { classPropertyName: "minimalControls", publicName: "minimalControls", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.aspect-video": "orientation() === \"landscape\"", "class.aspect-[9/16": "orientation() === \"portrait\"", "class.max-w-[400px": "orientation() === \"portrait\"", "class.aspect-square": "orientation() === \"square\"" }, classAttribute: "ngs-video-player" }, viewQueries: [{ propertyName: "videoElement", first: true, predicate: ["videoElement"], descendants: true, isSignal: true }], exportAs: ["ngsVideoPlayer"], ngImport: i0, template: "<div class=\"video-container group w-full h-full bg-black relative\" [class.is-playing]=\"isPlaying()\" (click)=\"togglePlay()\">\n  <video #videoElement class=\"w-full h-full object-contain relative z-[1]\" [class.hidden]=\"!loaded()\"></video>\n\n  @if (!loaded()) {\n    <div class=\"skeleton absolute inset-0 w-full h-full bg-[linear-gradient(90deg,#1e1e1e_25%,#2a2a2a_50%,#1e1e1e_75%)] bg-[length:200%_100%] animate-[skeleton-loading_1.5s_infinite] z-0 pointer-events-none\"></div>\n  }\n\n  <div class=\"controls-overlay absolute inset-0 w-full h-full flex flex-col bg-black/30 transition-all duration-300 z-[3] pointer-events-auto\"\n       [class.opacity-0]=\"isPlaying() || minimalControls()\"\n       [class.invisible]=\"isPlaying() || minimalControls()\"\n       [class.pointer-events-none]=\"isPlaying() || minimalControls()\"\n       [class.group-hover:opacity-100]=\"!minimalControls()\"\n       [class.group-hover:visible]=\"!minimalControls()\"\n       [class.group-hover:pointer-events-auto]=\"!minimalControls()\">\n    <div class=\"center-controls flex-1 flex justify-center items-center pointer-events-none absolute inset-0\" (click)=\"togglePlay()\">\n      <button class=\"play-button w-[120px] h-[120px] rounded-full bg-red-500 backdrop-blur-[4px] text-white flex justify-center items-center cursor-pointer transition-[transform,background-color] duration-200 pointer-events-auto hover:scale-110 hover:bg-red-600 active:scale-95\"\n              (click)=\"togglePlay(); $event.stopPropagation()\">\n        @if (isPlaying()) {\n          <ngs-icon name=\"fluent:pause-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\" />\n        } @else {\n          <ngs-icon name=\"fluent:play-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\" />\n        }\n      </button>\n    </div>\n  </div>\n\n  @if (hasStarted()) {\n    <div class=\"bottom-controls min-h-[80px] p-4 pb-2 flex items-center bg-gradient-to-t from-black/70 to-transparent gap-2 absolute bottom-0 left-0 right-0 invisible opacity-0 translate-y-2 transition-all duration-300 z-[4] pointer-events-none group-hover:visible group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto\"\n         (click)=\"$event.stopPropagation()\">\n      @if (!minimalControls()) {\n        <div class=\"seek-bar-container flex-grow w-full h-10 flex items-center\">\n          <ngs-slider min=\"0\" [max]=\"duration()\" step=\"0.1\" class=\"!w-full [&.ngs-mdc-slider]:[--mdc-slider-active-track-color:var(--color-primary)] [&.ngs-mdc-slider]:[--mdc-slider-inactive-track-color:rgba(255,255,255,0.3)] [&.ngs-mdc-slider]:[--mdc-slider-handle-color:var(--color-primary)] [&.ngs-mdc-slider]:[--mdc-slider-hover-handle-color:var(--color-primary)] [&.ngs-mdc-slider]:[--mdc-slider-focus-handle-color:var(--color-primary)]\">\n            <input ngsSliderThumb [value]=\"currentTime()\" (input)=\"seek($event)\">\n          </ngs-slider>\n        </div>\n      }\n      <div class=\"actions flex-none flex items-center h-12\" [class.w-full]=\"minimalControls()\">\n        <div class=\"flex-1\"></div>\n        <button ngsIconButton (click)=\"toggleMute()\">\n          @if (isMuted() || volume() === 0) {\n            <ngs-icon name=\"fluent:speaker-off-24-regular\" class=\"text-white\"/>\n          } @else {\n            <ngs-icon name=\"fluent:speaker-2-24-regular\" class=\"text-white\"/>\n          }\n        </button>\n        <button ngsIconButton (click)=\"toggleFullscreen()\">\n          @if (isFullscreen()) {\n            <ngs-icon name=\"fluent:full-screen-minimize-24-regular\" class=\"text-white\"/>\n          } @else {\n            <ngs-icon name=\"fluent:full-screen-maximize-24-regular\" class=\"text-white\"/>\n          }\n        </button>\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;position:relative;overflow:hidden}@keyframes skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"], dependencies: [{ kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "component", type: Slider, selector: "ngs-slider", inputs: ["disabled", "discrete", "showTickMarks", "min", "max", "step", "displayWith"], exportAs: ["ngsSlider"] }, { kind: "directive", type: SliderThumb, selector: "input[ngsSliderThumb]", inputs: ["value"], outputs: ["valueChange"], exportAs: ["ngsSliderThumb"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayer, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-video-player', exportAs: 'ngsVideoPlayer', imports: [
                        Icon,
                        Button,
                        Slider,
                        SliderThumb
                    ], host: {
                        'class': 'ngs-video-player',
                        '[class.aspect-video]': 'orientation() === "landscape"',
                        '[class.aspect-[9/16]]': 'orientation() === "portrait"',
                        '[class.max-w-[400px]]': 'orientation() === "portrait"',
                        '[class.aspect-square]': 'orientation() === "square"',
                    }, template: "<div class=\"video-container group w-full h-full bg-black relative\" [class.is-playing]=\"isPlaying()\" (click)=\"togglePlay()\">\n  <video #videoElement class=\"w-full h-full object-contain relative z-[1]\" [class.hidden]=\"!loaded()\"></video>\n\n  @if (!loaded()) {\n    <div class=\"skeleton absolute inset-0 w-full h-full bg-[linear-gradient(90deg,#1e1e1e_25%,#2a2a2a_50%,#1e1e1e_75%)] bg-[length:200%_100%] animate-[skeleton-loading_1.5s_infinite] z-0 pointer-events-none\"></div>\n  }\n\n  <div class=\"controls-overlay absolute inset-0 w-full h-full flex flex-col bg-black/30 transition-all duration-300 z-[3] pointer-events-auto\"\n       [class.opacity-0]=\"isPlaying() || minimalControls()\"\n       [class.invisible]=\"isPlaying() || minimalControls()\"\n       [class.pointer-events-none]=\"isPlaying() || minimalControls()\"\n       [class.group-hover:opacity-100]=\"!minimalControls()\"\n       [class.group-hover:visible]=\"!minimalControls()\"\n       [class.group-hover:pointer-events-auto]=\"!minimalControls()\">\n    <div class=\"center-controls flex-1 flex justify-center items-center pointer-events-none absolute inset-0\" (click)=\"togglePlay()\">\n      <button class=\"play-button w-[120px] h-[120px] rounded-full bg-red-500 backdrop-blur-[4px] text-white flex justify-center items-center cursor-pointer transition-[transform,background-color] duration-200 pointer-events-auto hover:scale-110 hover:bg-red-600 active:scale-95\"\n              (click)=\"togglePlay(); $event.stopPropagation()\">\n        @if (isPlaying()) {\n          <ngs-icon name=\"fluent:pause-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\" />\n        } @else {\n          <ngs-icon name=\"fluent:play-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\" />\n        }\n      </button>\n    </div>\n  </div>\n\n  @if (hasStarted()) {\n    <div class=\"bottom-controls min-h-[80px] p-4 pb-2 flex items-center bg-gradient-to-t from-black/70 to-transparent gap-2 absolute bottom-0 left-0 right-0 invisible opacity-0 translate-y-2 transition-all duration-300 z-[4] pointer-events-none group-hover:visible group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto\"\n         (click)=\"$event.stopPropagation()\">\n      @if (!minimalControls()) {\n        <div class=\"seek-bar-container flex-grow w-full h-10 flex items-center\">\n          <ngs-slider min=\"0\" [max]=\"duration()\" step=\"0.1\" class=\"!w-full [&.ngs-mdc-slider]:[--mdc-slider-active-track-color:var(--color-primary)] [&.ngs-mdc-slider]:[--mdc-slider-inactive-track-color:rgba(255,255,255,0.3)] [&.ngs-mdc-slider]:[--mdc-slider-handle-color:var(--color-primary)] [&.ngs-mdc-slider]:[--mdc-slider-hover-handle-color:var(--color-primary)] [&.ngs-mdc-slider]:[--mdc-slider-focus-handle-color:var(--color-primary)]\">\n            <input ngsSliderThumb [value]=\"currentTime()\" (input)=\"seek($event)\">\n          </ngs-slider>\n        </div>\n      }\n      <div class=\"actions flex-none flex items-center h-12\" [class.w-full]=\"minimalControls()\">\n        <div class=\"flex-1\"></div>\n        <button ngsIconButton (click)=\"toggleMute()\">\n          @if (isMuted() || volume() === 0) {\n            <ngs-icon name=\"fluent:speaker-off-24-regular\" class=\"text-white\"/>\n          } @else {\n            <ngs-icon name=\"fluent:speaker-2-24-regular\" class=\"text-white\"/>\n          }\n        </button>\n        <button ngsIconButton (click)=\"toggleFullscreen()\">\n          @if (isFullscreen()) {\n            <ngs-icon name=\"fluent:full-screen-minimize-24-regular\" class=\"text-white\"/>\n          } @else {\n            <ngs-icon name=\"fluent:full-screen-maximize-24-regular\" class=\"text-white\"/>\n          }\n        </button>\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:block;position:relative;overflow:hidden}@keyframes skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], payload: [{ type: i0.Input, args: [{ isSignal: true, alias: "payload", required: false }] }], autoPlay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoPlay", required: false }] }], minimalControls: [{ type: i0.Input, args: [{ isSignal: true, alias: "minimalControls", required: false }] }], videoElement: [{ type: i0.ViewChild, args: ['videoElement', { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { VideoPlayer };
//# sourceMappingURL=ngstarter-components-video-player.mjs.map
