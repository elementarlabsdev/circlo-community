import * as i0 from '@angular/core';
import { signal, Injectable, inject, PLATFORM_ID, DestroyRef, input, booleanAttribute, viewChild, computed, output, effect, untracked, ChangeDetectionStrategy, Component } from '@angular/core';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { Icon } from '@ngstarter/components/icon';
import { Button } from '@ngstarter/components/button';
import { Slider, SliderThumb } from '@ngstarter/components/slider';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

class VideoPlayerService {
    activePlayer = signal(null, ...(ngDevMode ? [{ debugName: "activePlayer" }] : /* istanbul ignore next */ []));
    setActivePlayer(player) {
        const currentActive = this.activePlayer();
        if (currentActive && currentActive !== player) {
            currentActive.pause();
        }
        this.activePlayer.set(player);
    }
    clearActivePlayer(player) {
        if (this.activePlayer() === player) {
            this.activePlayer.set(null);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class VideoPlayer {
    platformId = inject(PLATFORM_ID);
    document = inject(DOCUMENT);
    destroyRef = inject(DestroyRef);
    videoPlayerService = inject(VideoPlayerService);
    src = input(null, ...(ngDevMode ? [{ debugName: "src" }] : /* istanbul ignore next */ []));
    thumbnailUrl = input(null, ...(ngDevMode ? [{ debugName: "thumbnailUrl" }] : /* istanbul ignore next */ []));
    payload = input(null, ...(ngDevMode ? [{ debugName: "payload" }] : /* istanbul ignore next */ []));
    orientation = input(undefined, ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    autoPlay = input(false, { ...(ngDevMode ? { debugName: "autoPlay" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showPlayButton = input(true, { ...(ngDevMode ? { debugName: "showPlayButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showSpeaker = input(true, { ...(ngDevMode ? { debugName: "showSpeaker" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showFullscreen = input(true, { ...(ngDevMode ? { debugName: "showFullscreen" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showDurationSlider = input(true, { ...(ngDevMode ? { debugName: "showDurationSlider" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disableClickToPlay = input(false, { ...(ngDevMode ? { debugName: "disableClickToPlay" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    muted = input(false, { ...(ngDevMode ? { debugName: "muted" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    videoElement = viewChild('videoElement', ...(ngDevMode ? [{ debugName: "videoElement" }] : /* istanbul ignore next */ []));
    loaded = signal(false, ...(ngDevMode ? [{ debugName: "loaded" }] : /* istanbul ignore next */ []));
    isPlaying = signal(false, ...(ngDevMode ? [{ debugName: "isPlaying" }] : /* istanbul ignore next */ []));
    isPaused = computed(() => !this.isPlaying(), ...(ngDevMode ? [{ debugName: "isPaused" }] : /* istanbul ignore next */ []));
    hasStarted = signal(false, ...(ngDevMode ? [{ debugName: "hasStarted" }] : /* istanbul ignore next */ []));
    onPlay = output({ alias: 'play' });
    onPause = output({ alias: 'pause' });
    onEnded = output({ alias: 'ended' });
    onLoaded = output({ alias: 'loaded' });
    currentTime = signal(0, ...(ngDevMode ? [{ debugName: "currentTime" }] : /* istanbul ignore next */ []));
    duration = signal(0, ...(ngDevMode ? [{ debugName: "duration" }] : /* istanbul ignore next */ []));
    volume = signal(1, ...(ngDevMode ? [{ debugName: "volume" }] : /* istanbul ignore next */ []));
    isMuted = signal(false, ...(ngDevMode ? [{ debugName: "isMuted" }] : /* istanbul ignore next */ []));
    isFullscreen = signal(false, ...(ngDevMode ? [{ debugName: "isFullscreen" }] : /* istanbul ignore next */ []));
    finalOrientation = computed(() => {
        return this.orientation() || this.payload()?.orientation || 'landscape';
    }, ...(ngDevMode ? [{ debugName: "finalOrientation" }] : /* istanbul ignore next */ []));
    player = null;
    constructor() {
        effect(() => {
            this.isMuted.set(this.muted());
        });
        effect(() => {
            const src = this.src();
            if (isPlatformBrowser(this.platformId)) {
                untracked(() => {
                    // Only reset loaded state if the source actually changed
                    // This prevents "appearing then disappearing" if src is set to the same value
                    const videoElement = this.videoElement();
                    const currentSrc = videoElement?.nativeElement.src;
                    const absoluteSrc = src ? (src.startsWith('http') ? src : window.location.origin + src) : '';
                    if (currentSrc !== absoluteSrc) {
                        this.loaded.set(false);
                        this.isPlaying.set(false);
                        if (src) {
                            this.updateSrc(src);
                        }
                        else {
                            this.initPlayer(); // This will clear the src
                        }
                    }
                });
            }
        });
        effect(() => {
            const isMuted = this.isMuted();
            const videoElement = this.videoElement();
            if (videoElement) {
                videoElement.nativeElement.muted = isMuted;
            }
        });
        effect(() => {
            const isPlaying = this.isPlaying();
            if (isPlaying) {
                untracked(() => {
                    this.videoPlayerService.setActivePlayer(this);
                });
            }
        });
    }
    ngAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            this.setupEvents();
            this.initPlayer();
        }
    }
    onLoadedData = () => {
        if (this.loaded()) {
            return;
        }
        this.loaded.set(true);
        this.onLoaded.emit();
    };
    onTimeUpdate = () => {
        const videoElement = this.videoElement();
        if (videoElement) {
            const time = videoElement.nativeElement.currentTime;
            this.currentTime.set(time);
            if (time > 0.1 && !this.hasStarted()) {
                this.hasStarted.set(true);
            }
        }
    };
    onLoadedMetadata = () => {
        const videoElement = this.videoElement();
        if (videoElement) {
            this.duration.set(videoElement.nativeElement.duration);
        }
    };
    onPlayInternal = () => {
        this.isPlaying.set(true);
        // Explicitly set hasStarted to true when playback actually begins
        if (!this.hasStarted()) {
            this.hasStarted.set(true);
        }
    };
    onPauseInternal = () => {
        this.isPlaying.set(false);
        this.videoPlayerService.clearActivePlayer(this);
        // Note: we don't reset hasStarted on pause
    };
    setupEvents() {
        const videoElement = this.videoElement();
        if (!videoElement || !isPlatformBrowser(this.platformId)) {
            return;
        }
        const nativeElement = videoElement.nativeElement;
        // If the video is already loaded or in a state where it can be played, trigger onLoadedData
        if (nativeElement.readyState >= 2) {
            this.onLoadedData();
        }
        fromEvent(nativeElement, 'loadeddata')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.onLoadedData();
        });
        fromEvent(nativeElement, 'canplay')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.onLoadedData();
        });
        fromEvent(nativeElement, 'error')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((e) => {
            const error = e.target.error;
            console.error('VideoPlayer: element error', error);
        });
        fromEvent(nativeElement, 'timeupdate')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onTimeUpdate());
        fromEvent(nativeElement, 'loadedmetadata')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onLoadedMetadata());
        fromEvent(nativeElement, 'play')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.onPlayInternal();
            this.onPlay.emit();
        });
        fromEvent(nativeElement, 'playing')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.onPlayInternal();
        });
        fromEvent(nativeElement, 'pause')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.onPauseInternal();
            this.onPause.emit();
        });
        fromEvent(nativeElement, 'ended')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.onPauseInternal();
            this.onEnded.emit();
        });
        fromEvent(this.document, 'fullscreenchange')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onFullscreenChange());
    }
    onFullscreenChange = () => {
        this.isFullscreen.set(!!this.document.fullscreenElement);
    };
    toggleFullscreen() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        const container = this.videoElement()?.nativeElement.parentElement;
        if (!container)
            return;
        if (!this.document.fullscreenElement) {
            container.requestFullscreen().catch(err => {
                console.error(`Error attempting to enable full-screen mode: ${err.message}`);
            });
        }
        else {
            this.document.exitFullscreen();
        }
    }
    pause() {
        const videoElement = this.videoElement();
        if (videoElement) {
            videoElement.nativeElement.pause();
        }
    }
    togglePlay() {
        const videoElement = this.videoElement();
        if (videoElement) {
            const nativeElement = videoElement.nativeElement;
            if (nativeElement.paused) {
                // If the video source is not set or not yet loaded, try to load it
                if (!nativeElement.src && !this.player) {
                    this.initPlayer();
                }
                // Check again if we have a source or player
                if (!nativeElement.src && !this.player) {
                    console.warn('VideoPlayer: No video source to play');
                    return;
                }
                // Check readyState (0 = HAVE_NOTHING)
                if (nativeElement.readyState === 0 && !this.player) {
                    nativeElement.load();
                }
                nativeElement.play().then(() => {
                    this.hasStarted.set(true);
                    this.videoPlayerService.setActivePlayer(this);
                }).catch(err => {
                    console.error('Error attempting to play video:', err);
                });
            }
            else {
                nativeElement.pause();
            }
        }
    }
    seek(event) {
        const videoElement = this.videoElement();
        if (videoElement) {
            videoElement.nativeElement.currentTime = event.target.value;
        }
    }
    toggleMute() {
        const videoElement = this.videoElement();
        if (videoElement) {
            videoElement.nativeElement.muted = !videoElement.nativeElement.muted;
            this.isMuted.set(videoElement.nativeElement.muted);
            if (!this.hasStarted()) {
                this.togglePlay();
            }
        }
    }
    async initPlayer() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        const videoElement = this.videoElement();
        if (!videoElement) {
            return;
        }
        const src = this.src();
        const payload = this.payload();
        const dashUrl = payload?.dash?.manifest;
        if (!src && !dashUrl) {
            // Clear src if nothing to play
            videoElement.nativeElement.src = '';
            return;
        }
        const finalSrc = dashUrl || src;
        const autoPlay = this.autoPlay();
        if (finalSrc && finalSrc.endsWith('.mpd')) {
            const dashjs = await import('dashjs');
            if (this.player) {
                this.player.destroy();
            }
            this.player = dashjs.MediaPlayer().create();
            this.player.initialize(videoElement.nativeElement, finalSrc, autoPlay);
            if (autoPlay) {
                this.videoPlayerService.setActivePlayer(this);
            }
        }
        else if (finalSrc) {
            // If we're already on this src, don't reload unless absolutely necessary
            if (videoElement.nativeElement.src !== this.document.location.origin + finalSrc &&
                videoElement.nativeElement.src !== finalSrc) {
                videoElement.nativeElement.src = finalSrc;
                videoElement.nativeElement.autoplay = autoPlay;
                videoElement.nativeElement.load();
                if (autoPlay) {
                    this.videoPlayerService.setActivePlayer(this);
                }
            }
        }
    }
    updateSrc(src) {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        const isDash = src.endsWith('.mpd');
        const videoElement = this.videoElement();
        if (!videoElement) {
            return;
        }
        // Check if we already have this source to avoid unnecessary reloads
        const absoluteSrc = src.startsWith('http') ? src : window.location.origin + src;
        if (videoElement.nativeElement.src === absoluteSrc && !isDash) {
            return;
        }
        if (isDash) {
            if (this.player) {
                this.player.attachSource(src);
                if (this.autoPlay()) {
                    this.player.play();
                    this.videoPlayerService.setActivePlayer(this);
                }
            }
            else {
                // Clear native src before initializing dashjs
                videoElement.nativeElement.src = '';
                this.initPlayer();
            }
        }
        else {
            if (this.player) {
                this.player.destroy();
                this.player = null;
            }
            videoElement.nativeElement.src = src;
            videoElement.nativeElement.autoplay = this.autoPlay();
            videoElement.nativeElement.load();
            if (this.autoPlay()) {
                this.videoPlayerService.setActivePlayer(this);
            }
        }
    }
    ngOnDestroy() {
        this.videoPlayerService.clearActivePlayer(this);
        if (this.player) {
            this.player.destroy();
            this.player = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: VideoPlayer, isStandalone: true, selector: "ngs-video-player", inputs: { src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, thumbnailUrl: { classPropertyName: "thumbnailUrl", publicName: "thumbnailUrl", isSignal: true, isRequired: false, transformFunction: null }, payload: { classPropertyName: "payload", publicName: "payload", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, autoPlay: { classPropertyName: "autoPlay", publicName: "autoPlay", isSignal: true, isRequired: false, transformFunction: null }, showPlayButton: { classPropertyName: "showPlayButton", publicName: "showPlayButton", isSignal: true, isRequired: false, transformFunction: null }, showSpeaker: { classPropertyName: "showSpeaker", publicName: "showSpeaker", isSignal: true, isRequired: false, transformFunction: null }, showFullscreen: { classPropertyName: "showFullscreen", publicName: "showFullscreen", isSignal: true, isRequired: false, transformFunction: null }, showDurationSlider: { classPropertyName: "showDurationSlider", publicName: "showDurationSlider", isSignal: true, isRequired: false, transformFunction: null }, disableClickToPlay: { classPropertyName: "disableClickToPlay", publicName: "disableClickToPlay", isSignal: true, isRequired: false, transformFunction: null }, muted: { classPropertyName: "muted", publicName: "muted", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onPlay: "play", onPause: "pause", onEnded: "ended", onLoaded: "loaded" }, host: { properties: { "class.aspect-video": "finalOrientation() === \"landscape\"", "class.aspect-square": "finalOrientation() === \"square\"", "class.aspect-portrait": "finalOrientation() === \"portrait\"" }, classAttribute: "ngs-video-player not-prose" }, viewQueries: [{ propertyName: "videoElement", first: true, predicate: ["videoElement"], descendants: true, isSignal: true }], exportAs: ["ngsVideoPlayer"], ngImport: i0, template: "<div class=\"video-container group/video w-full h-full bg-surface-container relative\" [class.is-playing]=\"isPlaying()\" (click)=\"!disableClickToPlay() && togglePlay()\">\n  <video #videoElement class=\"not-prose w-full h-full object-contain relative z-[1]\" [class.hidden]=\"!loaded()\"></video>\n\n  @if (!loaded()) {\n    @if (thumbnailUrl()) {\n      <img [src]=\"thumbnailUrl()\" class=\"thumbnail-preview absolute inset-0 w-full h-full object-contain z-0\" alt=\"Video thumbnail\">\n    } @else {\n      <div\n        class=\"skeleton absolute inset-0 w-full h-full bg-[linear-gradient(90deg,#1e1e1e_25%,#2a2a2a_50%,#1e1e1e_75%)] bg-[length:200%_100%] animate-[skeleton-loading_1.5s_infinite] z-0 pointer-events-none\"></div>\n    }\n  }\n\n  @if (showPlayButton() && !isFullscreen()) {\n    <div class=\"controls-overlay absolute inset-0 w-full h-full flex flex-col bg-black/30 transition-all\n              duration-300 z-[3] pointer-events-auto opacity-100 [&.has-started]:opacity-0 [&.has-started]:group-hover/video:opacity-100\"\n         [class.has-started]=\"hasStarted() && !isPaused()\">\n      <div class=\"center-controls flex-1 flex justify-center items-center pointer-events-none absolute inset-0\">\n        <button\n          class=\"play-button w-[120px] h-[120px] rounded-full bg-red-500 backdrop-blur-[4px] text-white flex justify-center items-center cursor-pointer transition-[transform,background-color] duration-200 pointer-events-auto hover:scale-110 hover:bg-red-600 active:scale-95\"\n          (click)=\"togglePlay(); $event.stopPropagation()\"\n        >\n          @if (!isPaused()) {\n            <ngs-icon name=\"fluent:pause-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\"/>\n          } @else {\n            <ngs-icon name=\"fluent:play-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\"/>\n          }\n        </button>\n      </div>\n    </div>\n  }\n\n  @if (hasStarted() || !showPlayButton()) {\n    <div\n      class=\"bottom-controls min-h-[80px] p-4 pb-2 flex items-center justify-between bg-gradient-to-t from-black/70 to-transparent gap-2 absolute bottom-0 left-0 right-0 invisible opacity-0 translate-y-2 transition-all\n             duration-300 z-[4] pointer-events-none group-hover/video:visible group-hover/video:opacity-100\n             group-hover/video:translate-y-0 group-hover/video:pointer-events-auto\"\n      (click)=\"$event.stopPropagation()\">\n      @if (showDurationSlider() || isFullscreen()) {\n        <div class=\"seek-bar-container flex-grow w-full h-10 flex items-center\">\n          <ngs-slider min=\"0\" [max]=\"duration()\" step=\"0.1\">\n            <input ngsSliderThumb [value]=\"currentTime()\" (input)=\"seek($event)\">\n          </ngs-slider>\n        </div>\n      } @else {\n        <div class=\"flex-1\"></div>\n      }\n\n      @if (showSpeaker() || showFullscreen()) {\n        <div class=\"actions flex-none flex items-center h-12\" (click)=\"$event.stopPropagation()\">\n          <div class=\"flex-1\"></div>\n          @if (showSpeaker()) {\n            <button ngsIconButton (click)=\"toggleMute()\">\n              @if (isMuted() || volume() === 0) {\n                <ngs-icon name=\"fluent:speaker-off-24-regular\" class=\"text-white\"/>\n              } @else {\n                <ngs-icon name=\"fluent:speaker-2-24-regular\" class=\"text-white\"/>\n              }\n            </button>\n          }\n\n          @if (showFullscreen()) {\n            <button ngsIconButton (click)=\"toggleFullscreen()\">\n              @if (isFullscreen()) {\n                <ngs-icon name=\"fluent:full-screen-minimize-24-regular\" class=\"text-white\"/>\n              } @else {\n                <ngs-icon name=\"fluent:full-screen-maximize-24-regular\" class=\"text-white\"/>\n              }\n            </button>\n          }\n        </div>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;position:relative;overflow:hidden}:host.aspect-portrait{aspect-ratio:9/16}:host .thumbnail-preview{-webkit-user-select:none;user-select:none;pointer-events:none}@keyframes skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"], dependencies: [{ kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "component", type: Slider, selector: "ngs-slider", inputs: ["disabled", "discrete", "showTickMarks", "min", "max", "step", "displayWith"], exportAs: ["ngsSlider"] }, { kind: "directive", type: SliderThumb, selector: "input[ngsSliderThumb]", inputs: ["value"], outputs: ["valueChange"], exportAs: ["ngsSliderThumb"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoPlayer, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-video-player', exportAs: 'ngsVideoPlayer', standalone: true, imports: [
                        Icon,
                        Button,
                        Slider,
                        SliderThumb
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-video-player not-prose',
                        '[class.aspect-video]': 'finalOrientation() === "landscape"',
                        '[class.aspect-square]': 'finalOrientation() === "square"',
                        '[class.aspect-portrait]': 'finalOrientation() === "portrait"',
                    }, template: "<div class=\"video-container group/video w-full h-full bg-surface-container relative\" [class.is-playing]=\"isPlaying()\" (click)=\"!disableClickToPlay() && togglePlay()\">\n  <video #videoElement class=\"not-prose w-full h-full object-contain relative z-[1]\" [class.hidden]=\"!loaded()\"></video>\n\n  @if (!loaded()) {\n    @if (thumbnailUrl()) {\n      <img [src]=\"thumbnailUrl()\" class=\"thumbnail-preview absolute inset-0 w-full h-full object-contain z-0\" alt=\"Video thumbnail\">\n    } @else {\n      <div\n        class=\"skeleton absolute inset-0 w-full h-full bg-[linear-gradient(90deg,#1e1e1e_25%,#2a2a2a_50%,#1e1e1e_75%)] bg-[length:200%_100%] animate-[skeleton-loading_1.5s_infinite] z-0 pointer-events-none\"></div>\n    }\n  }\n\n  @if (showPlayButton() && !isFullscreen()) {\n    <div class=\"controls-overlay absolute inset-0 w-full h-full flex flex-col bg-black/30 transition-all\n              duration-300 z-[3] pointer-events-auto opacity-100 [&.has-started]:opacity-0 [&.has-started]:group-hover/video:opacity-100\"\n         [class.has-started]=\"hasStarted() && !isPaused()\">\n      <div class=\"center-controls flex-1 flex justify-center items-center pointer-events-none absolute inset-0\">\n        <button\n          class=\"play-button w-[120px] h-[120px] rounded-full bg-red-500 backdrop-blur-[4px] text-white flex justify-center items-center cursor-pointer transition-[transform,background-color] duration-200 pointer-events-auto hover:scale-110 hover:bg-red-600 active:scale-95\"\n          (click)=\"togglePlay(); $event.stopPropagation()\"\n        >\n          @if (!isPaused()) {\n            <ngs-icon name=\"fluent:pause-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\"/>\n          } @else {\n            <ngs-icon name=\"fluent:play-24-filled\" class=\"text-[52px] w-[52px] h-[52px]\"/>\n          }\n        </button>\n      </div>\n    </div>\n  }\n\n  @if (hasStarted() || !showPlayButton()) {\n    <div\n      class=\"bottom-controls min-h-[80px] p-4 pb-2 flex items-center justify-between bg-gradient-to-t from-black/70 to-transparent gap-2 absolute bottom-0 left-0 right-0 invisible opacity-0 translate-y-2 transition-all\n             duration-300 z-[4] pointer-events-none group-hover/video:visible group-hover/video:opacity-100\n             group-hover/video:translate-y-0 group-hover/video:pointer-events-auto\"\n      (click)=\"$event.stopPropagation()\">\n      @if (showDurationSlider() || isFullscreen()) {\n        <div class=\"seek-bar-container flex-grow w-full h-10 flex items-center\">\n          <ngs-slider min=\"0\" [max]=\"duration()\" step=\"0.1\">\n            <input ngsSliderThumb [value]=\"currentTime()\" (input)=\"seek($event)\">\n          </ngs-slider>\n        </div>\n      } @else {\n        <div class=\"flex-1\"></div>\n      }\n\n      @if (showSpeaker() || showFullscreen()) {\n        <div class=\"actions flex-none flex items-center h-12\" (click)=\"$event.stopPropagation()\">\n          <div class=\"flex-1\"></div>\n          @if (showSpeaker()) {\n            <button ngsIconButton (click)=\"toggleMute()\">\n              @if (isMuted() || volume() === 0) {\n                <ngs-icon name=\"fluent:speaker-off-24-regular\" class=\"text-white\"/>\n              } @else {\n                <ngs-icon name=\"fluent:speaker-2-24-regular\" class=\"text-white\"/>\n              }\n            </button>\n          }\n\n          @if (showFullscreen()) {\n            <button ngsIconButton (click)=\"toggleFullscreen()\">\n              @if (isFullscreen()) {\n                <ngs-icon name=\"fluent:full-screen-minimize-24-regular\" class=\"text-white\"/>\n              } @else {\n                <ngs-icon name=\"fluent:full-screen-maximize-24-regular\" class=\"text-white\"/>\n              }\n            </button>\n          }\n        </div>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{display:block;position:relative;overflow:hidden}:host.aspect-portrait{aspect-ratio:9/16}:host .thumbnail-preview{-webkit-user-select:none;user-select:none;pointer-events:none}@keyframes skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], thumbnailUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "thumbnailUrl", required: false }] }], payload: [{ type: i0.Input, args: [{ isSignal: true, alias: "payload", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], autoPlay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoPlay", required: false }] }], showPlayButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPlayButton", required: false }] }], showSpeaker: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSpeaker", required: false }] }], showFullscreen: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFullscreen", required: false }] }], showDurationSlider: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDurationSlider", required: false }] }], disableClickToPlay: [{ type: i0.Input, args: [{ isSignal: true, alias: "disableClickToPlay", required: false }] }], muted: [{ type: i0.Input, args: [{ isSignal: true, alias: "muted", required: false }] }], videoElement: [{ type: i0.ViewChild, args: ['videoElement', { isSignal: true }] }], onPlay: [{ type: i0.Output, args: ["play"] }], onPause: [{ type: i0.Output, args: ["pause"] }], onEnded: [{ type: i0.Output, args: ["ended"] }], onLoaded: [{ type: i0.Output, args: ["loaded"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { VideoPlayer };
//# sourceMappingURL=ngstarter-components-video-player.mjs.map
