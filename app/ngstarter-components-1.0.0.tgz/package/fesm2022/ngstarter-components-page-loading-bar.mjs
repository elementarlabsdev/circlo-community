import * as i0 from '@angular/core';
import { inject, DestroyRef, ChangeDetectorRef, input, booleanAttribute, Component } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationStart, NavigationError, NavigationEnd, NavigationCancel } from '@angular/router';
import { take, map } from 'rxjs/operators';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ProgressBar } from '@ngstarter/components/progress-bar';

class PageLoadingBar {
    _router = inject(Router);
    _destroyRef = inject(DestroyRef);
    _cdr = inject(ChangeDetectorRef);
    fixed = input(false, { ...(ngDevMode ? { debugName: "fixed" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visible = false;
    value = 0;
    _subscription;
    ngOnInit() {
        this._router.events
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe(event => {
            if (event instanceof NavigationStart) {
                this._start();
            }
            if ((event instanceof NavigationError || event instanceof NavigationEnd || event instanceof NavigationCancel)) {
                this._finish();
            }
        });
    }
    _start() {
        this._subscription?.unsubscribe();
        this.visible = false;
        this._subscription = timer(0, 250)
            .pipe(takeUntilDestroyed(this._destroyRef), take(6), map(_result => {
            const min = ((_result + 1) * 25) - 25;
            const max = (_result + 1) * 25;
            const loading = this._getRandom(min, max);
            return loading < 100 ? loading : 100;
        })).subscribe(_result => {
            this.value = _result;
            this._cdr.markForCheck();
        }, _ => {
        }, () => {
            this.visible = false;
            this._cdr.markForCheck();
        });
        this.visible = true;
        this.value = 0;
    }
    _finish() {
        if (this.value === 100) {
            this.visible = false;
            this._subscription.unsubscribe();
        }
    }
    _getRandom(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PageLoadingBar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: PageLoadingBar, isStandalone: true, selector: "ngs-page-loading-bar", inputs: { fixed: { classPropertyName: "fixed", publicName: "fixed", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-visible": "visible", "class.is-fixed": "fixed" }, classAttribute: "ngs--page-loading-bar" }, exportAs: ["ngsPageLoadingBar"], ngImport: i0, template: "@if (visible) {\n  <ngs-progress-bar [value]=\"value\" class=\"w-full h-full\"/>\n}\n", styles: [":host{--ngs-loading-bar-bg: none;--ngs-loading-bar-height: calc(var(--spacing, .25rem) * 1);position:absolute;top:0;left:0;right:0;z-index:-99999;display:none}:host .ngs-progress-bar{position:absolute;top:0;left:0;right:0;height:var(--ngs-loading-bar-height)}:host .ngs-progress-bar__progress{background:var(--ngs-loading-bar-bg);border-radius:0}:host .ngs-progress-bar__value{border-radius:0}:host.is-fixed{width:100vw;position:fixed}:host.is-visible{z-index:999;display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: ProgressBar, selector: "ngs-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["ngsProgressBar"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PageLoadingBar, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-page-loading-bar', exportAs: 'ngsPageLoadingBar', imports: [
                        ProgressBar
                    ], host: {
                        'class': 'ngs--page-loading-bar',
                        '[class.is-visible]': 'visible',
                        '[class.is-fixed]': 'fixed'
                    }, template: "@if (visible) {\n  <ngs-progress-bar [value]=\"value\" class=\"w-full h-full\"/>\n}\n", styles: [":host{--ngs-loading-bar-bg: none;--ngs-loading-bar-height: calc(var(--spacing, .25rem) * 1);position:absolute;top:0;left:0;right:0;z-index:-99999;display:none}:host .ngs-progress-bar{position:absolute;top:0;left:0;right:0;height:var(--ngs-loading-bar-height)}:host .ngs-progress-bar__progress{background:var(--ngs-loading-bar-bg);border-radius:0}:host .ngs-progress-bar__value{border-radius:0}:host.is-fixed{width:100vw;position:fixed}:host.is-visible{z-index:999;display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { fixed: [{ type: i0.Input, args: [{ isSignal: true, alias: "fixed", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { PageLoadingBar };
//# sourceMappingURL=ngstarter-components-page-loading-bar.mjs.map
