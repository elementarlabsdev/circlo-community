import * as i0 from '@angular/core';
import { InjectionToken, inject, signal, computed, Component, EventEmitter, Injector, DestroyRef, Directive, TemplateRef, contentChild, input, booleanAttribute } from '@angular/core';
import { Icon } from '@ngstarter/components/icon';
import { VideoPlayer } from '@ngstarter/components/video-player';
import { ProgressSpinner } from '@ngstarter/components/spinner';
import { NgTemplateOutlet } from '@angular/common';
import { Overlay } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

const VIDEO_VIEWER = new InjectionToken('VIDEO_VIEWER');
const VIDEO_VIEWER_REF = new InjectionToken('VIDEO_VIEWER_REF');
const VIDEO_VIEWER_DATA = new InjectionToken('VIDEO_VIEWER_DATA');

class VideoViewer {
    videoViewerRef = inject(VIDEO_VIEWER_REF);
    data = inject(VIDEO_VIEWER_DATA);
    isLoading = signal(true, ...(ngDevMode ? [{ debugName: "isLoading" }] : /* istanbul ignore next */ []));
    hasTitle = computed(() => {
        return !!(this.data.title || this.data.titleTplRef);
    }, ...(ngDevMode ? [{ debugName: "hasTitle" }] : /* istanbul ignore next */ []));
    hasAside = computed(() => {
        return !!(this.data.caption || this.data.description || this.data.captionTplRef || this.data.descriptionTplRef);
    }, ...(ngDevMode ? [{ debugName: "hasAside" }] : /* istanbul ignore next */ []));
    onBackdropClick() {
        this.videoViewerRef.close();
    }
    onPreventClick(event) {
        event.preventDefault();
        event.stopPropagation();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: VideoViewer, isStandalone: true, selector: "ngs-video-viewer", host: { classAttribute: "ngs-video-viewer" }, exportAs: ["ngsVideoViewer"], ngImport: i0, template: "@if (hasTitle()) {\n  <div class=\"title-container\">\n    <div class=\"title\">\n      @if (data.titleTplRef) {\n        <ng-container [ngTemplateOutlet]=\"data.titleTplRef\" />\n      } @else {\n        {{ data.title }}\n      }\n    </div>\n  </div>\n}\n<div class=\"controls\" (click)=\"onPreventClick($event)\">\n  <div class=\"w-max\">\n    <button (click)=\"videoViewerRef.close()\" class=\"close\">\n      <ngs-icon name=\"fluent:dismiss-24-regular\"/>\n    </button>\n  </div>\n</div>\n<div class=\"content\" (click)=\"onBackdropClick()\">\n  <div class=\"video-container\" [class.is-loading]=\"isLoading()\">\n    @if (isLoading()) {\n      <div class=\"loader-container\">\n        <ngs-progress-spinner mode=\"indeterminate\" [diameter]=\"48\" />\n      </div>\n    }\n    <ngs-video-player [src]=\"data.sourceUrl\"\n                      [payload]=\"data.payload\"\n                      [orientation]=\"data.orientation\"\n                      [autoPlay]=\"data.autoPlay ?? true\"\n                      [showPlayButton]=\"data.showPlayButton ?? true\"\n                      [showSpeaker]=\"data.showSpeaker ?? true\"\n                      [showFullscreen]=\"data.showFullscreen ?? true\"\n                      [showDurationSlider]=\"data.showDurationSlider ?? true\"\n                      [muted]=\"data.muted ?? false\"\n                      (loaded)=\"isLoading.set(false)\"\n                      (click)=\"onPreventClick($event)\"/>\n  </div>\n  @if (hasAside()) {\n    <aside class=\"aside\" (click)=\"onPreventClick($event)\">\n      <div class=\"aside-header\">\n        @if (data.captionTplRef) {\n          <ng-container [ngTemplateOutlet]=\"data.captionTplRef\" />\n        } @else if (data.caption) {\n          {{ data.caption }}\n        }\n      </div>\n      <div class=\"aside-body\">\n        <div class=\"aside-body-scroll\">\n          @if (data.descriptionTplRef) {\n            <ng-container [ngTemplateOutlet]=\"data.descriptionTplRef\" />\n          } @else if (data.description) {\n            {{ data.description }}\n          }\n        </div>\n      </div>\n    </aside>\n  }\n</div>\n", styles: [":host{width:100vw;height:100vh;display:flex;flex-direction:column}:host .title-container{position:absolute;inset-inline-start:calc(var(--spacing, .25rem) * 4);top:calc(var(--spacing, .25rem) * 4);z-index:3}:host .controls{position:absolute;inset-inline-end:calc(var(--spacing, .25rem) * 4);top:calc(var(--spacing, .25rem) * 4);z-index:3;display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 4)}:host .content{box-shadow:0 1px 3px #0000001a,0 1px 2px -1px #0000001a;z-index:2;display:flex;align-items:center;justify-content:center;gap:calc(var(--spacing, .25rem) * 8);width:100vw;height:100vh}:host:has(.aside) .content{padding-inline-end:420px}:host .title{font-weight:500;height:calc(var(--spacing, .25rem) * 10);border-radius:calc(infinity * 1px);padding-left:calc(var(--spacing, .25rem) * 4);padding-right:calc(var(--spacing, .25rem) * 4);font-size:var(--text-tiny);display:flex;align-items:center;background:var(--color-neutral-700);color:var(--color-neutral-300)}:host .close{width:calc(var(--spacing, .25rem) * 10);height:calc(var(--spacing, .25rem) * 10);border-radius:calc(infinity * 1px);cursor:pointer;display:flex;flex:none;align-items:center;justify-content:center;background:var(--color-neutral-700);color:var(--color-neutral-300)}:host .close:hover{background:var(--color-neutral-800);color:var(--color-neutral-200)}:host .close:active{background:var(--color-neutral-950);color:var(--color-neutral-100)}:host .aside{width:420px;position:absolute;inset-inline-end:0;top:0;bottom:0;flex:none;background:var(--color-neutral-50);display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 5);height:100%;padding-inline-end:calc(var(--spacing, .25rem) * 10)}:host .aside-header{font-weight:700;padding-left:calc(var(--spacing, .25rem) * 8);padding-right:calc(var(--spacing, .25rem) * 8);padding-top:calc(var(--spacing, .25rem) * 8)}:host .aside-body{position:relative;flex-grow:1;font-size:.875rem;color:var(--color-neutral-600);line-height:var(--leading-relaxed)}:host .aside-body-scroll{position:absolute;inset:0;overflow-y:auto;padding-left:calc(var(--spacing, .25rem) * 8);padding-right:calc(var(--spacing, .25rem) * 8);padding-bottom:calc(var(--spacing, .25rem) * 8)}:host .video-container{position:relative;display:flex;align-items:center;justify-content:center;height:90%;width:90%;max-height:90%;max-width:90%}:host .video-container.is-loading ngs-video-player{opacity:0}:host .video-container .loader-container{position:absolute;inset:calc(var(--spacing, .25rem) * 0);z-index:5;display:flex;align-items:center;justify-content:center}:host .video-container ngs-video-player{max-height:90%;max-width:90%;transition:opacity .3s ease-in-out}:host-context(html.dark) .title{background:var(--color-neutral-100);color:var(--color-neutral-600)}:host-context(html.dark) .close{background:var(--color-neutral-100);color:var(--color-neutral-600)}:host-context(html.dark) .close:hover{background:var(--color-neutral-200);color:var(--color-neutral-700)}:host-context(html.dark) .close:active{background:var(--color-neutral-300);color:var(--color-neutral-900)}:host-context(html.dark) .aside{background:var(--color-neutral-900)}:host-context(html.dark) .aside-body{color:var(--color-neutral-400)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: VideoPlayer, selector: "ngs-video-player", inputs: ["src", "thumbnailUrl", "payload", "orientation", "autoPlay", "showPlayButton", "showSpeaker", "showFullscreen", "showDurationSlider", "disableClickToPlay", "muted"], outputs: ["play", "pause", "ended", "loaded"], exportAs: ["ngsVideoPlayer"] }, { kind: "component", type: ProgressSpinner, selector: "ngs-progress-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["ngsProgressSpinner"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewer, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-video-viewer', exportAs: 'ngsVideoViewer', standalone: true, imports: [
                        Icon,
                        VideoPlayer,
                        ProgressSpinner,
                        NgTemplateOutlet
                    ], host: {
                        'class': 'ngs-video-viewer',
                    }, template: "@if (hasTitle()) {\n  <div class=\"title-container\">\n    <div class=\"title\">\n      @if (data.titleTplRef) {\n        <ng-container [ngTemplateOutlet]=\"data.titleTplRef\" />\n      } @else {\n        {{ data.title }}\n      }\n    </div>\n  </div>\n}\n<div class=\"controls\" (click)=\"onPreventClick($event)\">\n  <div class=\"w-max\">\n    <button (click)=\"videoViewerRef.close()\" class=\"close\">\n      <ngs-icon name=\"fluent:dismiss-24-regular\"/>\n    </button>\n  </div>\n</div>\n<div class=\"content\" (click)=\"onBackdropClick()\">\n  <div class=\"video-container\" [class.is-loading]=\"isLoading()\">\n    @if (isLoading()) {\n      <div class=\"loader-container\">\n        <ngs-progress-spinner mode=\"indeterminate\" [diameter]=\"48\" />\n      </div>\n    }\n    <ngs-video-player [src]=\"data.sourceUrl\"\n                      [payload]=\"data.payload\"\n                      [orientation]=\"data.orientation\"\n                      [autoPlay]=\"data.autoPlay ?? true\"\n                      [showPlayButton]=\"data.showPlayButton ?? true\"\n                      [showSpeaker]=\"data.showSpeaker ?? true\"\n                      [showFullscreen]=\"data.showFullscreen ?? true\"\n                      [showDurationSlider]=\"data.showDurationSlider ?? true\"\n                      [muted]=\"data.muted ?? false\"\n                      (loaded)=\"isLoading.set(false)\"\n                      (click)=\"onPreventClick($event)\"/>\n  </div>\n  @if (hasAside()) {\n    <aside class=\"aside\" (click)=\"onPreventClick($event)\">\n      <div class=\"aside-header\">\n        @if (data.captionTplRef) {\n          <ng-container [ngTemplateOutlet]=\"data.captionTplRef\" />\n        } @else if (data.caption) {\n          {{ data.caption }}\n        }\n      </div>\n      <div class=\"aside-body\">\n        <div class=\"aside-body-scroll\">\n          @if (data.descriptionTplRef) {\n            <ng-container [ngTemplateOutlet]=\"data.descriptionTplRef\" />\n          } @else if (data.description) {\n            {{ data.description }}\n          }\n        </div>\n      </div>\n    </aside>\n  }\n</div>\n", styles: [":host{width:100vw;height:100vh;display:flex;flex-direction:column}:host .title-container{position:absolute;inset-inline-start:calc(var(--spacing, .25rem) * 4);top:calc(var(--spacing, .25rem) * 4);z-index:3}:host .controls{position:absolute;inset-inline-end:calc(var(--spacing, .25rem) * 4);top:calc(var(--spacing, .25rem) * 4);z-index:3;display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 4)}:host .content{box-shadow:0 1px 3px #0000001a,0 1px 2px -1px #0000001a;z-index:2;display:flex;align-items:center;justify-content:center;gap:calc(var(--spacing, .25rem) * 8);width:100vw;height:100vh}:host:has(.aside) .content{padding-inline-end:420px}:host .title{font-weight:500;height:calc(var(--spacing, .25rem) * 10);border-radius:calc(infinity * 1px);padding-left:calc(var(--spacing, .25rem) * 4);padding-right:calc(var(--spacing, .25rem) * 4);font-size:var(--text-tiny);display:flex;align-items:center;background:var(--color-neutral-700);color:var(--color-neutral-300)}:host .close{width:calc(var(--spacing, .25rem) * 10);height:calc(var(--spacing, .25rem) * 10);border-radius:calc(infinity * 1px);cursor:pointer;display:flex;flex:none;align-items:center;justify-content:center;background:var(--color-neutral-700);color:var(--color-neutral-300)}:host .close:hover{background:var(--color-neutral-800);color:var(--color-neutral-200)}:host .close:active{background:var(--color-neutral-950);color:var(--color-neutral-100)}:host .aside{width:420px;position:absolute;inset-inline-end:0;top:0;bottom:0;flex:none;background:var(--color-neutral-50);display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 5);height:100%;padding-inline-end:calc(var(--spacing, .25rem) * 10)}:host .aside-header{font-weight:700;padding-left:calc(var(--spacing, .25rem) * 8);padding-right:calc(var(--spacing, .25rem) * 8);padding-top:calc(var(--spacing, .25rem) * 8)}:host .aside-body{position:relative;flex-grow:1;font-size:.875rem;color:var(--color-neutral-600);line-height:var(--leading-relaxed)}:host .aside-body-scroll{position:absolute;inset:0;overflow-y:auto;padding-left:calc(var(--spacing, .25rem) * 8);padding-right:calc(var(--spacing, .25rem) * 8);padding-bottom:calc(var(--spacing, .25rem) * 8)}:host .video-container{position:relative;display:flex;align-items:center;justify-content:center;height:90%;width:90%;max-height:90%;max-width:90%}:host .video-container.is-loading ngs-video-player{opacity:0}:host .video-container .loader-container{position:absolute;inset:calc(var(--spacing, .25rem) * 0);z-index:5;display:flex;align-items:center;justify-content:center}:host .video-container ngs-video-player{max-height:90%;max-width:90%;transition:opacity .3s ease-in-out}:host-context(html.dark) .title{background:var(--color-neutral-100);color:var(--color-neutral-600)}:host-context(html.dark) .close{background:var(--color-neutral-100);color:var(--color-neutral-600)}:host-context(html.dark) .close:hover{background:var(--color-neutral-200);color:var(--color-neutral-700)}:host-context(html.dark) .close:active{background:var(--color-neutral-300);color:var(--color-neutral-900)}:host-context(html.dark) .aside{background:var(--color-neutral-900)}:host-context(html.dark) .aside-body{color:var(--color-neutral-400)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class VideoViewerRef {
    closed = new EventEmitter();
    close() {
        this.closed.emit();
    }
}

class VideoViewerDirective {
    _overlay = inject(Overlay);
    _injector = inject(Injector);
    _destroyRef = inject(DestroyRef);
    get api() {
        return {
            open: (options) => this._open(options)
        };
    }
    _open(options) {
        const videoViewerRef = new VideoViewerRef();
        const overlayRef = this._overlay.create({
            positionStrategy: this._overlay.position().global(),
            hasBackdrop: true
        });
        const injector = Injector.create({
            providers: [
                {
                    provide: VIDEO_VIEWER_REF,
                    useValue: videoViewerRef
                },
                {
                    provide: VIDEO_VIEWER_DATA,
                    useValue: options
                }
            ],
            parent: this._injector
        });
        const portal = new ComponentPortal(VideoViewer, null, injector);
        overlayRef.attach(portal);
        videoViewerRef.closed.pipe(takeUntilDestroyed(this._destroyRef)).subscribe(() => {
            overlayRef.detach();
        });
        return videoViewerRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: VideoViewerDirective, isStandalone: true, selector: "[ngsVideoViewer]", host: { classAttribute: "ngs-video-viewer" }, exportAs: ["ngsVideoViewer"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsVideoViewer]',
                    exportAs: 'ngsVideoViewer',
                    standalone: true,
                    host: {
                        'class': 'ngs-video-viewer',
                    }
                }]
        }] });

class VideoViewerVideoCaptionDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoCaptionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: VideoViewerVideoCaptionDirective, isStandalone: true, selector: "[ngsVideoViewerVideoCaption]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoCaptionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsVideoViewerVideoCaption]',
                    standalone: true,
                }]
        }] });

class VideoViewerVideoDescriptionDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoDescriptionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: VideoViewerVideoDescriptionDirective, isStandalone: true, selector: "[ngsVideoViewerVideoDescription]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoDescriptionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsVideoViewerVideoDescription]',
                    standalone: true,
                }]
        }] });

class VideoViewerVideoTitleDirective {
    templateRef = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: VideoViewerVideoTitleDirective, isStandalone: true, selector: "[ngsVideoViewerVideoTitle]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsVideoViewerVideoTitle]',
                    standalone: true,
                }]
        }] });

class VideoViewerVideoDirective {
    _videoViewer = inject(VideoViewerDirective);
    _titleTplRef = contentChild(VideoViewerVideoTitleDirective, ...(ngDevMode ? [{ debugName: "_titleTplRef" }] : /* istanbul ignore next */ []));
    _captionTplRef = contentChild(VideoViewerVideoCaptionDirective, ...(ngDevMode ? [{ debugName: "_captionTplRef" }] : /* istanbul ignore next */ []));
    _descriptionTplRef = contentChild(VideoViewerVideoDescriptionDirective, ...(ngDevMode ? [{ debugName: "_descriptionTplRef" }] : /* istanbul ignore next */ []));
    sourceUrl = input.required(...(ngDevMode ? [{ debugName: "sourceUrl" }] : /* istanbul ignore next */ []));
    caption = input(...(ngDevMode ? [undefined, { debugName: "caption" }] : /* istanbul ignore next */ []));
    title = input(...(ngDevMode ? [undefined, { debugName: "title" }] : /* istanbul ignore next */ []));
    description = input(...(ngDevMode ? [undefined, { debugName: "description" }] : /* istanbul ignore next */ []));
    payload = input(null, ...(ngDevMode ? [{ debugName: "payload" }] : /* istanbul ignore next */ []));
    orientation = input(undefined, ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    autoPlay = input(false, { ...(ngDevMode ? { debugName: "autoPlay" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showPlayButton = input(true, { ...(ngDevMode ? { debugName: "showPlayButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showSpeaker = input(true, { ...(ngDevMode ? { debugName: "showSpeaker" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showFullscreen = input(true, { ...(ngDevMode ? { debugName: "showFullscreen" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showDurationSlider = input(true, { ...(ngDevMode ? { debugName: "showDurationSlider" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    muted = input(false, { ...(ngDevMode ? { debugName: "muted" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this._videoViewer.api.open({
            sourceUrl: this.sourceUrl(),
            title: this.title(),
            caption: this.caption(),
            description: this.description(),
            titleTplRef: this._titleTplRef()?.templateRef,
            captionTplRef: this._captionTplRef()?.templateRef,
            descriptionTplRef: this._descriptionTplRef()?.templateRef,
            payload: this.payload(),
            orientation: this.orientation(),
            autoPlay: this.autoPlay(),
            showPlayButton: this.showPlayButton(),
            showSpeaker: this.showSpeaker(),
            showFullscreen: this.showFullscreen(),
            showDurationSlider: this.showDurationSlider(),
            muted: this.muted()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "21.2.4", type: VideoViewerVideoDirective, isStandalone: true, selector: "[ngsVideoViewerVideo]", inputs: { sourceUrl: { classPropertyName: "sourceUrl", publicName: "sourceUrl", isSignal: true, isRequired: true, transformFunction: null }, caption: { classPropertyName: "caption", publicName: "caption", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, payload: { classPropertyName: "payload", publicName: "payload", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, autoPlay: { classPropertyName: "autoPlay", publicName: "autoPlay", isSignal: true, isRequired: false, transformFunction: null }, showPlayButton: { classPropertyName: "showPlayButton", publicName: "showPlayButton", isSignal: true, isRequired: false, transformFunction: null }, showSpeaker: { classPropertyName: "showSpeaker", publicName: "showSpeaker", isSignal: true, isRequired: false, transformFunction: null }, showFullscreen: { classPropertyName: "showFullscreen", publicName: "showFullscreen", isSignal: true, isRequired: false, transformFunction: null }, showDurationSlider: { classPropertyName: "showDurationSlider", publicName: "showDurationSlider", isSignal: true, isRequired: false, transformFunction: null }, muted: { classPropertyName: "muted", publicName: "muted", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick($event)" }, classAttribute: "ngs-video-viewer-video" }, providers: [
            {
                provide: VIDEO_VIEWER,
                useExisting: VideoViewerVideoDirective
            }
        ], queries: [{ propertyName: "_titleTplRef", first: true, predicate: VideoViewerVideoTitleDirective, descendants: true, isSignal: true }, { propertyName: "_captionTplRef", first: true, predicate: VideoViewerVideoCaptionDirective, descendants: true, isSignal: true }, { propertyName: "_descriptionTplRef", first: true, predicate: VideoViewerVideoDescriptionDirective, descendants: true, isSignal: true }], exportAs: ["ngsVideoViewerVideo"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: VideoViewerVideoDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsVideoViewerVideo]',
                    exportAs: 'ngsVideoViewerVideo',
                    standalone: true,
                    providers: [
                        {
                            provide: VIDEO_VIEWER,
                            useExisting: VideoViewerVideoDirective
                        }
                    ],
                    host: {
                        'class': 'ngs-video-viewer-video',
                        '(click)': 'onClick($event)'
                    }
                }]
        }], propDecorators: { _titleTplRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => VideoViewerVideoTitleDirective), { isSignal: true }] }], _captionTplRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => VideoViewerVideoCaptionDirective), { isSignal: true }] }], _descriptionTplRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => VideoViewerVideoDescriptionDirective), { isSignal: true }] }], sourceUrl: [{ type: i0.Input, args: [{ isSignal: true, alias: "sourceUrl", required: true }] }], caption: [{ type: i0.Input, args: [{ isSignal: true, alias: "caption", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], payload: [{ type: i0.Input, args: [{ isSignal: true, alias: "payload", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], autoPlay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoPlay", required: false }] }], showPlayButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPlayButton", required: false }] }], showSpeaker: [{ type: i0.Input, args: [{ isSignal: true, alias: "showSpeaker", required: false }] }], showFullscreen: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFullscreen", required: false }] }], showDurationSlider: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDurationSlider", required: false }] }], muted: [{ type: i0.Input, args: [{ isSignal: true, alias: "muted", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { VIDEO_VIEWER, VIDEO_VIEWER_DATA, VIDEO_VIEWER_REF, VideoViewer, VideoViewerDirective, VideoViewerRef, VideoViewerVideoCaptionDirective, VideoViewerVideoDescriptionDirective, VideoViewerVideoDirective, VideoViewerVideoTitleDirective };
//# sourceMappingURL=ngstarter-components-video-viewer.mjs.map
