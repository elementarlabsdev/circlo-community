import * as i0 from '@angular/core';
import { input, booleanAttribute, numberAttribute, output, forwardRef, ChangeDetectionStrategy, Component } from '@angular/core';
import { UntypedFormControl, Validators, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ProgressBar } from '@ngstarter/components/progress-bar';
import { Icon } from '@ngstarter/components/icon';
import { Button } from '@ngstarter/components/button';

var Colors;
(function (Colors) {
    Colors["primary"] = "primary";
    Colors["accent"] = "accent";
    Colors["warn"] = "warn";
    Colors["success"] = "green";
})(Colors || (Colors = {}));

var Criteria;
(function (Criteria) {
    Criteria["at_least_eight_chars"] = "minChar";
    Criteria["at_least_one_lower_case_char"] = "lowerCase";
    Criteria["at_least_one_upper_case_char"] = "upperCase";
    Criteria["at_least_one_digit_char"] = "digit";
    Criteria["at_least_one_special_char"] = " specialChar";
    Criteria["at_custom_chars"] = "customChars";
})(Criteria || (Criteria = {}));

class PasswordStrengthValidator {
    isUndefinedOrEmpty(control) {
        if (!control || !control.value || control.value.length === 0) {
            return undefined;
        }
    }
    validate(criteria, regex) {
        const validator = (control) => {
            this.isUndefinedOrEmpty(control);
            if (!regex.test(control.value)) {
                const failed = {};
                // @ts-ignore
                failed[criteria] = {
                    actualValue: control.value,
                    requiredPattern: regex
                };
                return failed;
            }
            return undefined;
        };
        return validator;
    }
    confirm(password) {
        const validator = (control) => {
            this.isUndefinedOrEmpty(control);
            if (control.value !== password) {
                return {
                    notConfirmed: {
                        password: password,
                        passwordConfirmation: control.value
                    }
                };
            }
            return undefined;
        };
        return validator;
    }
}

const RegExpValidator = {
    'lowerCase': RegExp(/^(?=.*?[a-z])/),
    'upperCase': RegExp(/^(?=.*?[A-Z])/),
    'digit': RegExp(/^(?=.*?[0-9])/),
    'specialChar': RegExp(/^(?=.*?[" !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"])/),
};

class PasswordStrength {
    password = input.required(...(ngDevMode ? [{ debugName: "password" }] : /* istanbul ignore next */ []));
    externalError = input(false, { ...(ngDevMode ? { debugName: "externalError" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    enableLengthRule = input(true, { ...(ngDevMode ? { debugName: "enableLengthRule" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    enableLowerCaseLetterRule = input(true, { ...(ngDevMode ? { debugName: "enableLowerCaseLetterRule" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    enableUpperCaseLetterRule = input(true, { ...(ngDevMode ? { debugName: "enableUpperCaseLetterRule" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    enableDigitRule = input(true, { ...(ngDevMode ? { debugName: "enableDigitRule" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    enableSpecialCharRule = input(true, { ...(ngDevMode ? { debugName: "enableSpecialCharRule" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    min = input(8, { ...(ngDevMode ? { debugName: "min" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    max = input(30, { ...(ngDevMode ? { debugName: "max" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    customValidator = input(...(ngDevMode ? [undefined, { debugName: "customValidator" }] : /* istanbul ignore next */ []));
    warnThreshold = input(21, { ...(ngDevMode ? { debugName: "warnThreshold" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    accentThreshold = input(81, { ...(ngDevMode ? { debugName: "accentThreshold" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    strengthChanged = output();
    criteriaMap = new Map();
    containAtLeastMinChars;
    containAtLeastOneLowerCaseLetter;
    containAtLeastOneUpperCaseLetter;
    containAtLeastOneDigit;
    containAtLeastOneSpecialChar;
    containAtCustomChars;
    // TO ACCESS VIA CONTENT CHILD
    passwordFormControl = new UntypedFormControl();
    passwordConfirmationFormControl = new UntypedFormControl();
    validatorsArray = [];
    Validators;
    passwordStrengthValidator = new PasswordStrengthValidator();
    _strength = 0;
    get strength() {
        return this._strength ? this._strength : 0;
    }
    get isLow() {
        return this.strength === 20;
    }
    get isWeak() {
        return this.strength === 40;
    }
    get isMedium() {
        return this.strength === 60;
    }
    get isStrong() {
        return this.strength === 80;
    }
    get isVeryStrong() {
        return this.strength === 100;
    }
    propagateChange = (_) => {
    };
    ngOnInit() {
        this.setRulesAndValidators();
    }
    ngOnChanges(changes) {
        if ((changes['externalError'] && changes['externalError'].firstChange) || (changes['password'] && changes['password'].firstChange)) {
            return;
        }
        else if (changes['externalError'] && changes['externalError'].currentValue) {
            // this._color = 'weak';
            return;
        }
        else if (changes['password'] && changes['password'].previousValue === changes['password'].currentValue && !changes['password'].firstChange) {
            this.calculatePasswordStrength();
        }
        else {
            this.password && this.password.length > 0 ?
                this.calculatePasswordStrength() : this.reset();
        }
    }
    setRulesAndValidators() {
        this.validatorsArray = [];
        this.criteriaMap = new Map();
        this.passwordConfirmationFormControl
            // @ts-ignore
            .setValidators(Validators.compose([
            Validators.required, this.passwordStrengthValidator.confirm(this.password())
        ]));
        this.validatorsArray.push(Validators.required);
        if (this.enableLengthRule()) {
            this.criteriaMap.set(Criteria.at_least_eight_chars, RegExp(`^.{${this.min()},${this.max()}}$`));
            this.validatorsArray.push(Validators.minLength(this.min()));
            this.validatorsArray.push(Validators.maxLength(this.max()));
        }
        if (this.enableLowerCaseLetterRule()) {
            this.criteriaMap.set(Criteria.at_least_one_lower_case_char, RegExpValidator.lowerCase);
            this.validatorsArray.push(Validators.pattern(RegExpValidator.lowerCase));
        }
        if (this.enableUpperCaseLetterRule()) {
            this.criteriaMap.set(Criteria.at_least_one_upper_case_char, RegExpValidator.upperCase);
            this.validatorsArray.push(Validators.pattern(RegExpValidator.upperCase));
        }
        if (this.enableDigitRule()) {
            this.criteriaMap.set(Criteria.at_least_one_digit_char, RegExpValidator.digit);
            this.validatorsArray.push(Validators.pattern(RegExpValidator.digit));
        }
        if (this.enableSpecialCharRule()) {
            this.criteriaMap.set(Criteria.at_least_one_special_char, RegExpValidator.specialChar);
            this.validatorsArray.push(Validators.pattern(RegExpValidator.specialChar));
        }
        if (this.customValidator()) {
            this.criteriaMap.set(Criteria.at_custom_chars, this.customValidator());
            this.validatorsArray.push(Validators.pattern(this.customValidator()));
        }
        this.criteriaMap.forEach((value, key) => {
            // @ts-ignore
            this.validatorsArray.push(this.passwordStrengthValidator.validate(key, value));
        });
        this.passwordFormControl.setValidators(Validators.compose([...this.validatorsArray]));
        this.Validators = Validators.compose([...this.validatorsArray]);
    }
    calculatePasswordStrength() {
        const requirements = [];
        const unit = 100 / this.criteriaMap.size;
        requirements.push(this.enableLengthRule() ? this._containAtLeastMinChars() : false, this.enableLowerCaseLetterRule() ? this._containAtLeastOneLowerCaseLetter() : false, this.enableUpperCaseLetterRule() ? this._containAtLeastOneUpperCaseLetter() : false, this.enableDigitRule() ? this._containAtLeastOneDigit() : false, this.enableSpecialCharRule() ? this._containAtLeastOneSpecialChar() : false, this.customValidator() ? this._containCustomChars() : false);
        this._strength = requirements.filter(v => v).length * unit;
        this.propagateChange(this.strength);
        this.strengthChanged.emit(this.strength);
        this.setRulesAndValidators();
    }
    reset() {
        this._strength = 0;
        this.containAtLeastMinChars = false;
        this.containAtLeastOneLowerCaseLetter = false;
        this.containAtLeastOneUpperCaseLetter = false;
        this.containAtLeastOneDigit = false;
        this.containAtCustomChars = false;
        this.containAtLeastOneSpecialChar = false;
    }
    writeValue(obj) {
        if (obj) {
            this._strength = obj;
        }
    }
    registerOnChange(fn) {
        this.propagateChange = fn;
    }
    registerOnTouched(fn) {
        // throw new Error("Method not implemented.");
    }
    setDisabledState(isDisabled) {
        // throw new Error("Method not implemented.");
    }
    _containAtLeastMinChars() {
        this.containAtLeastMinChars = this.password().length >= this.min();
        return this.containAtLeastMinChars;
    }
    _containAtLeastOneLowerCaseLetter() {
        // @ts-ignore
        this.containAtLeastOneLowerCaseLetter = this.criteriaMap
            .get(Criteria.at_least_one_lower_case_char)
            .test(this.password());
        return this.containAtLeastOneLowerCaseLetter;
    }
    _containAtLeastOneUpperCaseLetter() {
        // @ts-ignore
        this.containAtLeastOneUpperCaseLetter = this.criteriaMap
            .get(Criteria.at_least_one_upper_case_char)
            .test(this.password());
        return this.containAtLeastOneUpperCaseLetter;
    }
    _containAtLeastOneDigit() {
        // @ts-ignore
        this.containAtLeastOneDigit = this.criteriaMap
            .get(Criteria.at_least_one_digit_char)
            .test(this.password());
        return this.containAtLeastOneDigit;
    }
    _containAtLeastOneSpecialChar() {
        // @ts-ignore
        this.containAtLeastOneSpecialChar = this.criteriaMap
            .get(Criteria.at_least_one_special_char)
            .test(this.password());
        return this.containAtLeastOneSpecialChar;
    }
    _containCustomChars() {
        // @ts-ignore
        this.containAtCustomChars = this.criteriaMap
            .get(Criteria.at_custom_chars)
            .test(this.password());
        return this.containAtCustomChars;
    }
    ngAfterContentChecked() {
        if (this.password()) {
            this.calculatePasswordStrength();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PasswordStrength, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: PasswordStrength, isStandalone: true, selector: "ngs-password-strength", inputs: { password: { classPropertyName: "password", publicName: "password", isSignal: true, isRequired: true, transformFunction: null }, externalError: { classPropertyName: "externalError", publicName: "externalError", isSignal: true, isRequired: false, transformFunction: null }, enableLengthRule: { classPropertyName: "enableLengthRule", publicName: "enableLengthRule", isSignal: true, isRequired: false, transformFunction: null }, enableLowerCaseLetterRule: { classPropertyName: "enableLowerCaseLetterRule", publicName: "enableLowerCaseLetterRule", isSignal: true, isRequired: false, transformFunction: null }, enableUpperCaseLetterRule: { classPropertyName: "enableUpperCaseLetterRule", publicName: "enableUpperCaseLetterRule", isSignal: true, isRequired: false, transformFunction: null }, enableDigitRule: { classPropertyName: "enableDigitRule", publicName: "enableDigitRule", isSignal: true, isRequired: false, transformFunction: null }, enableSpecialCharRule: { classPropertyName: "enableSpecialCharRule", publicName: "enableSpecialCharRule", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, customValidator: { classPropertyName: "customValidator", publicName: "customValidator", isSignal: true, isRequired: false, transformFunction: null }, warnThreshold: { classPropertyName: "warnThreshold", publicName: "warnThreshold", isSignal: true, isRequired: false, transformFunction: null }, accentThreshold: { classPropertyName: "accentThreshold", publicName: "accentThreshold", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { strengthChanged: "strengthChanged" }, host: { properties: { "class.low": "isLow", "class.weak": "isWeak", "class.medium": "isMedium", "class.strong": "isStrong", "class.very-strong": "isVeryStrong" }, classAttribute: "ngs-password-strength" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => PasswordStrength),
                multi: true
            }
        ], exportAs: ["ngsPasswordStrength"], usesOnChanges: true, ngImport: i0, template: "<ngs-progress-bar [value]=\"strength\" mode=\"determinate\"/>\n", styles: [":host{margin-top:calc(var(--spacing, .25rem) * 1);display:block;--ngs-progress-bar-track-height: calc(var(--spacing, .25rem) * 2);--ngs-progress-bar-active-indicator-height: calc(var(--spacing, .25rem) * 2)}:host ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: transparent}:host.low ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: oklch(70.4% .191 22.216)}:host.weak ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: oklch(82.8% .189 84.429)}:host.medium ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: var(--color-green-500)}:host.strong ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: var(--color-green-500)}:host.very-strong ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: var(--color-green-500)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: ProgressBar, selector: "ngs-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["ngsProgressBar"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PasswordStrength, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-password-strength', exportAs: 'ngsPasswordStrength', imports: [
                        ProgressBar
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => PasswordStrength),
                            multi: true
                        }
                    ], host: {
                        'class': 'ngs-password-strength',
                        '[class.low]': 'isLow',
                        '[class.weak]': 'isWeak',
                        '[class.medium]': 'isMedium',
                        '[class.strong]': 'isStrong',
                        '[class.very-strong]': 'isVeryStrong',
                    }, template: "<ngs-progress-bar [value]=\"strength\" mode=\"determinate\"/>\n", styles: [":host{margin-top:calc(var(--spacing, .25rem) * 1);display:block;--ngs-progress-bar-track-height: calc(var(--spacing, .25rem) * 2);--ngs-progress-bar-active-indicator-height: calc(var(--spacing, .25rem) * 2)}:host ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: transparent}:host.low ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: oklch(70.4% .191 22.216)}:host.weak ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: oklch(82.8% .189 84.429)}:host.medium ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: var(--color-green-500)}:host.strong ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: var(--color-green-500)}:host.very-strong ::ng-deep .mdc-linear-progress__bar-inner{--ngs-progress-bar-active-indicator-color: var(--color-green-500)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { password: [{ type: i0.Input, args: [{ isSignal: true, alias: "password", required: true }] }], externalError: [{ type: i0.Input, args: [{ isSignal: true, alias: "externalError", required: false }] }], enableLengthRule: [{ type: i0.Input, args: [{ isSignal: true, alias: "enableLengthRule", required: false }] }], enableLowerCaseLetterRule: [{ type: i0.Input, args: [{ isSignal: true, alias: "enableLowerCaseLetterRule", required: false }] }], enableUpperCaseLetterRule: [{ type: i0.Input, args: [{ isSignal: true, alias: "enableUpperCaseLetterRule", required: false }] }], enableDigitRule: [{ type: i0.Input, args: [{ isSignal: true, alias: "enableDigitRule", required: false }] }], enableSpecialCharRule: [{ type: i0.Input, args: [{ isSignal: true, alias: "enableSpecialCharRule", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], customValidator: [{ type: i0.Input, args: [{ isSignal: true, alias: "customValidator", required: false }] }], warnThreshold: [{ type: i0.Input, args: [{ isSignal: true, alias: "warnThreshold", required: false }] }], accentThreshold: [{ type: i0.Input, args: [{ isSignal: true, alias: "accentThreshold", required: false }] }], strengthChanged: [{ type: i0.Output, args: ["strengthChanged"] }] } });

class PassToggleVisibility {
    visible = input(false, { ...(ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tabindex = input('', ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    _visible = this.visible();
    get type() {
        return this._visible ? 'text' : 'password';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PassToggleVisibility, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: PassToggleVisibility, isStandalone: true, selector: "ngs-pass-toggle-visibility", inputs: { visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ngs-pass-toggle-visibility" }, exportAs: ["ngsPassToggleVisibility"], ngImport: i0, template: "<button (click)=\"_visible = !_visible\" ngsIconButton\n        [attr.tabindex]=\"tabindex() ? tabindex() : null\" type=\"button\">\n  @if (_visible) {\n    <ngs-icon name=\"fluent:eye-24-regular\"/>\n  } @else {\n    <ngs-icon name=\"fluent:visibility_off-24-regular\"/>\n  }\n</button>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PassToggleVisibility, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-pass-toggle-visibility', exportAs: 'ngsPassToggleVisibility', imports: [
                        Icon,
                        Button
                    ], host: {
                        'class': 'ngs-pass-toggle-visibility',
                    }, template: "<button (click)=\"_visible = !_visible\" ngsIconButton\n        [attr.tabindex]=\"tabindex() ? tabindex() : null\" type=\"button\">\n  @if (_visible) {\n    <ngs-icon name=\"fluent:eye-24-regular\"/>\n  } @else {\n    <ngs-icon name=\"fluent:visibility_off-24-regular\"/>\n  }\n</button>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }] } });

class PasswordStrengthInfo {
    passwordComponent = input.required(...(ngDevMode ? [{ debugName: "passwordComponent" }] : /* istanbul ignore next */ []));
    enableScoreInfo = input(false, { ...(ngDevMode ? { debugName: "enableScoreInfo" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lowerCaseCriteriaMessage = input('contains at least one lower character', ...(ngDevMode ? [{ debugName: "lowerCaseCriteriaMessage" }] : /* istanbul ignore next */ []));
    upperCaseCriteriaMessage = input('contains at least one upper character', ...(ngDevMode ? [{ debugName: "upperCaseCriteriaMessage" }] : /* istanbul ignore next */ []));
    digitsCriteriaMessage = input('contains at least one digit character', ...(ngDevMode ? [{ debugName: "digitsCriteriaMessage" }] : /* istanbul ignore next */ []));
    specialCharsCriteriaMessage = input('contains at least one special character', ...(ngDevMode ? [{ debugName: "specialCharsCriteriaMessage" }] : /* istanbul ignore next */ []));
    customCharsCriteriaMessage = input('contains at least one custom character', ...(ngDevMode ? [{ debugName: "customCharsCriteriaMessage" }] : /* istanbul ignore next */ []));
    minCharsCriteriaMessage = input(`contains at least minimum characters`, ...(ngDevMode ? [{ debugName: "minCharsCriteriaMessage" }] : /* istanbul ignore next */ []));
    ngsIconDone = input('checkmark-24-regular', ...(ngDevMode ? [{ debugName: "ngsIconDone" }] : /* istanbul ignore next */ []));
    ngsIconError = input('error-circle-24-regular', ...(ngDevMode ? [{ debugName: "ngsIconError" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PasswordStrengthInfo, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: PasswordStrengthInfo, isStandalone: true, selector: "ngs-password-strength-info", inputs: { passwordComponent: { classPropertyName: "passwordComponent", publicName: "passwordComponent", isSignal: true, isRequired: true, transformFunction: null }, enableScoreInfo: { classPropertyName: "enableScoreInfo", publicName: "enableScoreInfo", isSignal: true, isRequired: false, transformFunction: null }, lowerCaseCriteriaMessage: { classPropertyName: "lowerCaseCriteriaMessage", publicName: "lowerCaseCriteriaMessage", isSignal: true, isRequired: false, transformFunction: null }, upperCaseCriteriaMessage: { classPropertyName: "upperCaseCriteriaMessage", publicName: "upperCaseCriteriaMessage", isSignal: true, isRequired: false, transformFunction: null }, digitsCriteriaMessage: { classPropertyName: "digitsCriteriaMessage", publicName: "digitsCriteriaMessage", isSignal: true, isRequired: false, transformFunction: null }, specialCharsCriteriaMessage: { classPropertyName: "specialCharsCriteriaMessage", publicName: "specialCharsCriteriaMessage", isSignal: true, isRequired: false, transformFunction: null }, customCharsCriteriaMessage: { classPropertyName: "customCharsCriteriaMessage", publicName: "customCharsCriteriaMessage", isSignal: true, isRequired: false, transformFunction: null }, minCharsCriteriaMessage: { classPropertyName: "minCharsCriteriaMessage", publicName: "minCharsCriteriaMessage", isSignal: true, isRequired: false, transformFunction: null }, ngsIconDone: { classPropertyName: "ngsIconDone", publicName: "ngsIconDone", isSignal: true, isRequired: false, transformFunction: null }, ngsIconError: { classPropertyName: "ngsIconError", publicName: "ngsIconError", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ngs-password-strength-info" }, exportAs: ["ngsPasswordStrengthInfo"], ngImport: i0, template: "<div class=\"flex flex-col gap-1.5 mt-4\">\n  @if (passwordComponent().enableLowerCaseLetterRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneLowerCaseLetter) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ lowerCaseCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableUpperCaseLetterRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneUpperCaseLetter) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ upperCaseCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableDigitRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneDigit) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ digitsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableSpecialCharRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneSpecialChar) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ specialCharsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableLengthRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastMinChars) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ minCharsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().customValidator()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtCustomChars) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ customCharsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (enableScoreInfo()) {\n    <div class=\"row\">\n      @if (passwordComponent().strength === 100) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span>Password's strength = {{ passwordComponent().strength }} %100</span>\n    </div>\n  }\n</div>\n", styles: [".row{flex-direction:row;display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 1.5)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PasswordStrengthInfo, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-password-strength-info', exportAs: 'ngsPasswordStrengthInfo', imports: [
                        Icon
                    ], host: {
                        'class': 'ngs-password-strength-info',
                    }, template: "<div class=\"flex flex-col gap-1.5 mt-4\">\n  @if (passwordComponent().enableLowerCaseLetterRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneLowerCaseLetter) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ lowerCaseCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableUpperCaseLetterRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneUpperCaseLetter) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ upperCaseCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableDigitRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneDigit) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ digitsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableSpecialCharRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastOneSpecialChar) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ specialCharsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().enableLengthRule()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtLeastMinChars) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ minCharsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (passwordComponent().customValidator()) {\n    <div class=\"row\">\n      @if (passwordComponent().containAtCustomChars) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span class=\"text-tiny\">{{ customCharsCriteriaMessage() }}</span>\n    </div>\n  }\n\n  @if (enableScoreInfo()) {\n    <div class=\"row\">\n      @if (passwordComponent().strength === 100) {\n        <ngs-icon name=\"fluent:{{ ngsIconDone() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      } @else {\n        <ngs-icon name=\"fluent:{{ ngsIconError() }}\" class=\"font-icon !text-xl !h-7 !w-5\"/>\n      }\n\n      <span>Password's strength = {{ passwordComponent().strength }} %100</span>\n    </div>\n  }\n</div>\n", styles: [".row{flex-direction:row;display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 1.5)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { passwordComponent: [{ type: i0.Input, args: [{ isSignal: true, alias: "passwordComponent", required: true }] }], enableScoreInfo: [{ type: i0.Input, args: [{ isSignal: true, alias: "enableScoreInfo", required: false }] }], lowerCaseCriteriaMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "lowerCaseCriteriaMessage", required: false }] }], upperCaseCriteriaMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "upperCaseCriteriaMessage", required: false }] }], digitsCriteriaMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "digitsCriteriaMessage", required: false }] }], specialCharsCriteriaMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "specialCharsCriteriaMessage", required: false }] }], customCharsCriteriaMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "customCharsCriteriaMessage", required: false }] }], minCharsCriteriaMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "minCharsCriteriaMessage", required: false }] }], ngsIconDone: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsIconDone", required: false }] }], ngsIconError: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsIconError", required: false }] }] } });

// validator

/**
 * Generated bundle index. Do not edit.
 */

export { PassToggleVisibility, PasswordStrength, PasswordStrengthInfo, PasswordStrengthValidator, RegExpValidator };
//# sourceMappingURL=ngstarter-components-password-strength.mjs.map
