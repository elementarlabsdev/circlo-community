function expiryDateValidator() {
    return (control) => {
        const value = control.value;
        if (!value || value.length !== 4) {
            return null;
        }
        const month = parseInt(value.substring(0, 2), 10);
        const year = parseInt(value.substring(2, 4), 10);
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth() + 1;
        const currentYear = parseInt(currentDate.getFullYear().toString().substring(2, 4));
        if (year < currentYear || (year === currentYear && month < currentMonth)) {
            return { expiryDateInPast: true };
        }
        return null;
    };
}

/**
 * Generated bundle index. Do not edit.
 */

export { expiryDateValidator };
//# sourceMappingURL=ngstarter-components-input-validator.mjs.map
