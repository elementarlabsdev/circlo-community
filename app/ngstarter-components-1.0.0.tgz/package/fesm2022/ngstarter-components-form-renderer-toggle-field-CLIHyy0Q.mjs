import * as i0 from '@angular/core';
import { input, ChangeDetectionStrategy, Component } from '@angular/core';
import { SlideToggle } from '@ngstarter/components/slide-toggle';
import * as i1 from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

class ToggleField {
    control = input.required(...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ToggleField, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: ToggleField, isStandalone: true, selector: "ngs-toggle-field", inputs: { control: { classPropertyName: "control", publicName: "control", isSignal: true, isRequired: true, transformFunction: null }, config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, exportAs: ["ngsToggleField"], ngImport: i0, template: "@if(control() && config()) {\n  <ngs-slide-toggle [formControl]=\"control()\">\n    {{ config().label }}\n  </ngs-slide-toggle>\n}\n", styles: [":host{display:block;margin-bottom:calc(var(--spacing, .25rem) * 3)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: SlideToggle, selector: "ngs-slide-toggle", inputs: ["id", "name", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "disabled", "disableRipple", "tabIndex", "hideIcon", "color", "checked"], outputs: ["disabledChange", "checkedChange", "change", "toggleChange"], exportAs: ["ngsSlideToggle"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ToggleField, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-toggle-field', exportAs: 'ngsToggleField', imports: [
                        SlideToggle,
                        ReactiveFormsModule
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if(control() && config()) {\n  <ngs-slide-toggle [formControl]=\"control()\">\n    {{ config().label }}\n  </ngs-slide-toggle>\n}\n", styles: [":host{display:block;margin-bottom:calc(var(--spacing, .25rem) * 3)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { control: [{ type: i0.Input, args: [{ isSignal: true, alias: "control", required: true }] }], config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }] } });

export { ToggleField };
//# sourceMappingURL=ngstarter-components-form-renderer-toggle-field-CLIHyy0Q.mjs.map
