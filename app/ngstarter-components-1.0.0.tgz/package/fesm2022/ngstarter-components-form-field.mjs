import * as i0 from '@angular/core';
import { Component, Injectable, input, Directive, InjectionToken, booleanAttribute, inject, ElementRef, viewChild, contentChild, contentChildren, computed, HostListener } from '@angular/core';

class Label {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Label, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Label, isStandalone: true, selector: "ngs-label", host: { classAttribute: "ngs-label" }, ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:inline-block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Label, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-label', host: {
                        'class': 'ngs-label',
                    }, template: "<ng-content/>\n", styles: [":host{display:inline-block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class FormFieldControl {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: FormFieldControl, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: FormFieldControl });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: FormFieldControl, decorators: [{
            type: Injectable
        }] });

class Hint {
    align = input('start', ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Hint, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: Hint, isStandalone: true, selector: "ngs-hint", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ngs-hint-end": "align() === \"end\"" }, classAttribute: "ngs-hint" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block}:host.ngs-hint-end{margin-left:auto}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Hint, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-hint', standalone: true, host: {
                        'class': 'ngs-hint',
                        '[class.ngs-hint-end]': 'align() === "end"',
                    }, template: "<ng-content />\n", styles: [":host{display:block}:host.ngs-hint-end{margin-left:auto}\n"] }]
        }], propDecorators: { align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }] } });

class Error {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Error, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Error, isStandalone: true, selector: "ngs-error", host: { attributes: { "role": "alert" }, classAttribute: "ngs-error" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block;color:var(--ngs-form-field-error-color, var(--input-error))}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Error, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-error', standalone: true, host: {
                        'class': 'ngs-error',
                        'role': 'alert',
                    }, template: "<ng-content />\n", styles: [":host{display:block;color:var(--ngs-form-field-error-color, var(--input-error))}\n"] }]
        }] });

class Prefix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Prefix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: Prefix, isStandalone: true, selector: "[ngsPrefix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Prefix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsPrefix]',
                }]
        }] });
class TextPrefix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextPrefix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextPrefix, isStandalone: true, selector: "[ngsTextPrefix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextPrefix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextPrefix]',
                }]
        }] });
class IconPrefix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconPrefix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: IconPrefix, isStandalone: true, selector: "[ngsIconPrefix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconPrefix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsIconPrefix]',
                }]
        }] });
class IconButtonPrefix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconButtonPrefix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: IconButtonPrefix, isStandalone: true, selector: "[ngsIconButtonPrefix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconButtonPrefix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsIconButtonPrefix]',
                }]
        }] });
class Suffix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Suffix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: Suffix, isStandalone: true, selector: "[ngsSuffix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Suffix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSuffix]',
                }]
        }] });
class TextSuffix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextSuffix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextSuffix, isStandalone: true, selector: "[ngsTextSuffix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextSuffix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextSuffix]',
                }]
        }] });
class IconSuffix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconSuffix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: IconSuffix, isStandalone: true, selector: "[ngsIconSuffix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconSuffix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsIconSuffix]',
                }]
        }] });
class IconButtonSuffix {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconButtonSuffix, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: IconButtonSuffix, isStandalone: true, selector: "[ngsIconButtonSuffix]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: IconButtonSuffix, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsIconButtonSuffix]',
                }]
        }] });

const FORM_FIELD = new InjectionToken('FORM_FIELD');

class FormField {
    subscriptHiddenIfEmpty = input(false, { ...(ngDevMode ? { debugName: "subscriptHiddenIfEmpty" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    elementRef = inject(ElementRef);
    wrapper = viewChild.required('wrapper');
    container = viewChild.required('container');
    control = contentChild(FormFieldControl, ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    labelChild = contentChild(Label, ...(ngDevMode ? [{ debugName: "labelChild" }] : /* istanbul ignore next */ []));
    prefixChildren = contentChildren(Prefix, ...(ngDevMode ? [{ debugName: "prefixChildren" }] : /* istanbul ignore next */ []));
    iconPrefixChildren = contentChildren(IconPrefix, ...(ngDevMode ? [{ debugName: "iconPrefixChildren" }] : /* istanbul ignore next */ []));
    iconButtonPrefixChildren = contentChildren(IconButtonPrefix, ...(ngDevMode ? [{ debugName: "iconButtonPrefixChildren" }] : /* istanbul ignore next */ []));
    textPrefixChildren = contentChildren(TextPrefix, ...(ngDevMode ? [{ debugName: "textPrefixChildren" }] : /* istanbul ignore next */ []));
    suffixChildren = contentChildren(Suffix, ...(ngDevMode ? [{ debugName: "suffixChildren" }] : /* istanbul ignore next */ []));
    iconSuffixChildren = contentChildren(IconSuffix, ...(ngDevMode ? [{ debugName: "iconSuffixChildren" }] : /* istanbul ignore next */ []));
    iconButtonSuffixChildren = contentChildren(IconButtonSuffix, ...(ngDevMode ? [{ debugName: "iconButtonSuffixChildren" }] : /* istanbul ignore next */ []));
    textSuffixChildren = contentChildren(TextSuffix, ...(ngDevMode ? [{ debugName: "textSuffixChildren" }] : /* istanbul ignore next */ []));
    hintChildren = contentChildren(Hint, ...(ngDevMode ? [{ debugName: "hintChildren" }] : /* istanbul ignore next */ []));
    errorChildren = contentChildren(Error, ...(ngDevMode ? [{ debugName: "errorChildren" }] : /* istanbul ignore next */ []));
    isRequired = computed(() => {
        const control = this.control();
        if (!control) {
            return false;
        }
        if (control.required) {
            return true;
        }
        const ngControl = control.ngControl;
        if (ngControl && ngControl.control && ngControl.control.validator) {
            const validator = ngControl.control.validator({});
            if (validator && validator['required']) {
                return true;
            }
        }
        return false;
    }, ...(ngDevMode ? [{ debugName: "isRequired" }] : /* istanbul ignore next */ []));
    shouldLabelFloat() {
        return !!this.control()?.shouldLabelFloat;
    }
    _onClick(event) {
        const target = event.target;
        const wrapper = this.wrapper().nativeElement;
        const isInsideWrapper = wrapper.contains(target);
        if (!isInsideWrapper) {
            return;
        }
        const isIconButton = !!target.closest('.ngs-icon-button') || !!target.closest('[ngsIconButton]');
        const isToggle = !!target.closest('ngs-datepicker-toggle') || !!target.closest('ngs-date-range-picker');
        if (this.control()?.focused || isIconButton || isToggle) {
            return;
        }
        this.focus();
        event.stopPropagation();
    }
    focus() {
        const control = this.control();
        if (control && !control.disabled) {
            control.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: FormField, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: FormField, isStandalone: true, selector: "ngs-form-field", inputs: { subscriptHiddenIfEmpty: { classPropertyName: "subscriptHiddenIfEmpty", publicName: "subscriptHiddenIfEmpty", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_onClick($event)" }, properties: { "class.ngs-form-field-disabled": "control()?.disabled", "class.ngs-form-field-invalid": "control()?.errorState", "class.ngs-form-field-should-float": "shouldLabelFloat()", "class.ngs-form-field-has-label": "labelChild()", "class.ngs-form-field-empty": "control()?.empty", "class.ngs-form-field-focused": "control()?.focused", "class.ngs-form-field-subscript-hidden-if-empty": "subscriptHiddenIfEmpty()", "class.ngs-form-field-has-icon-prefix": "iconPrefixChildren().length > 0", "class.ngs-form-field-has-icon-button-prefix": "iconButtonPrefixChildren().length > 0", "class.ngs-form-field-has-icon-suffix": "iconSuffixChildren().length > 0", "class.ngs-form-field-has-icon-button-suffix": "iconButtonSuffixChildren().length > 0" }, classAttribute: "ngs-form-field" }, providers: [
            {
                provide: FORM_FIELD,
                useExisting: FormField
            }
        ], queries: [{ propertyName: "control", first: true, predicate: FormFieldControl, descendants: true, isSignal: true }, { propertyName: "labelChild", first: true, predicate: Label, descendants: true, isSignal: true }, { propertyName: "prefixChildren", predicate: Prefix, isSignal: true }, { propertyName: "iconPrefixChildren", predicate: IconPrefix, isSignal: true }, { propertyName: "iconButtonPrefixChildren", predicate: IconButtonPrefix, isSignal: true }, { propertyName: "textPrefixChildren", predicate: TextPrefix, isSignal: true }, { propertyName: "suffixChildren", predicate: Suffix, isSignal: true }, { propertyName: "iconSuffixChildren", predicate: IconSuffix, isSignal: true }, { propertyName: "iconButtonSuffixChildren", predicate: IconButtonSuffix, isSignal: true }, { propertyName: "textSuffixChildren", predicate: TextSuffix, isSignal: true }, { propertyName: "hintChildren", predicate: Hint, isSignal: true }, { propertyName: "errorChildren", predicate: Error, isSignal: true }], viewQueries: [{ propertyName: "wrapper", first: true, predicate: ["wrapper"], descendants: true, isSignal: true }, { propertyName: "container", first: true, predicate: ["container"], descendants: true, isSignal: true }], exportAs: ["ngsFormField"], ngImport: i0, template: "<div class=\"ngs-form-field-wrapper\" #wrapper>\n  <div class=\"ngs-form-field-container\" #container>\n    @if (prefixChildren().length > 0) {\n      <div class=\"ngs-form-field-prefix\">\n        <ng-content select=\"[ngsPrefix]\"/>\n      </div>\n    }\n\n    @if (iconPrefixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-prefix\">\n        <ng-content select=\"[ngsIconPrefix]\"/>\n      </div>\n    }\n\n    @if (iconButtonPrefixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-button-prefix\">\n        <ng-content select=\"[ngsIconButtonPrefix]\"/>\n      </div>\n    }\n\n    @if (textPrefixChildren().length > 0) {\n      <div class=\"ngs-form-field-text-prefix\">\n        <ng-content select=\"[ngsTextPrefix]\"/>\n      </div>\n    }\n\n    <div class=\"ngs-form-field-infix\">\n      @if (labelChild()) {\n        <label class=\"ngs-form-field-label\" [attr.for]=\"control()?.id\">\n          <ng-content select=\"ngs-label\"/>\n\n          @if (isRequired()) {\n            <span class=\"ngs-form-field-required-marker\">*</span>\n          }\n        </label>\n      }\n      <ng-content/>\n    </div>\n\n    @if (textSuffixChildren().length > 0) {\n      <div class=\"ngs-form-field-text-suffix\">\n        <ng-content select=\"[ngsTextSuffix]\"/>\n      </div>\n    }\n\n    @if (iconButtonSuffixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-button-suffix\">\n        <ng-content select=\"[ngsIconButtonSuffix]\"/>\n      </div>\n    }\n\n    @if (iconSuffixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-suffix\">\n        <ng-content select=\"[ngsIconSuffix]\"/>\n      </div>\n    }\n\n    @if (suffixChildren().length > 0) {\n      <div class=\"ngs-form-field-suffix\">\n        <ng-content select=\"[ngsSuffix]\"/>\n      </div>\n    }\n  </div>\n</div>\n\n<div class=\"subscript-wrapper\">\n  @if (control()?.errorState && errorChildren().length > 0) {\n    <ng-content select=\"ngs-error\"/>\n  } @else if (hintChildren().length > 0) {\n    <div class=\"ngs-form-field-hint-wrapper\">\n      <ng-content select=\"ngs-hint\"/>\n    </div>\n  }\n</div>\n", styles: [":host{--ngs-form-field-color: var(--input-color);--ngs-form-field-border-color: var(--input-border-color);--ngs-form-field-border-width: 1px;--ngs-form-field-border-radius: calc(var(--spacing, .25rem) * 3);--ngs-form-field-padding-x: .75rem;--ngs-form-field-padding-y: 1.75rem;--ngs-form-field-bg: var(--color-surface);--ngs-form-field-disabled-bg: var(--color-surface-container-low);--ngs-form-field-label-color: var(--input-label-color);--ngs-form-field-error-color: var(--input-error);--ngs-form-field-container-min-height: 50px;--ngs-form-field-infix-min-height: 50px;--ngs-form-field-infix-padding-top: 23px;--ngs-form-field-infix-padding-bottom: 8px;display:block;width:var(--ngs-form-field-width, 100%)}:host.ngs-form-field-disabled{cursor:default}:host.ngs-form-field-disabled .ngs-form-field-container{background:var(--color-on-surface);border-color:var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled .ngs-form-field-container{background:color-mix(in srgb,var(--color-on-surface),transparent 95%)}}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled .ngs-form-field-container{border-color:color-mix(in srgb,var(--color-on-surface),transparent 90%)}}:host.ngs-form-field-disabled .ngs-form-field-label{color:var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled .ngs-form-field-label{color:color-mix(in srgb,var(--color-on-surface),transparent 62%)}}:host.ngs-form-field-disabled ::ng-deep input{color:var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled ::ng-deep input{color:color-mix(in srgb,var(--color-on-surface),transparent 62%)}}:host.ngs-form-field-focused .ngs-form-field-container{border-color:var(--input-outlined-border-focus);box-shadow:0 0 0 1px var(--input-outlined-border-focus)}:host.ngs-form-field-focused .ngs-form-field-label{color:var(--ngs-form-field-color)}:host.ngs-form-field-invalid .ngs-form-field-container{border-color:var(--ngs-form-field-error-color)}:host.ngs-form-field-invalid.ngs-form-field-focused .ngs-form-field-container{box-shadow:0 0 0 1px var(--ngs-form-field-error-color)}:host.ngs-form-field-invalid .ngs-form-field-label{color:var(--ngs-form-field-error-color)}:host .ngs-form-field-wrapper{display:flex;flex-direction:column}:host .ngs-form-field-container{position:relative;border:var(--ngs-form-field-border-width) solid var(--ngs-form-field-border-color);border-radius:var(--ngs-form-field-border-radius);background:var(--ngs-form-field-bg);padding:0 var(--ngs-form-field-padding-x);transition:border-color .2s,box-shadow .2s;min-height:var(--ngs-form-field-container-min-height);display:flex;align-items:center}:host .ngs-form-field-container:has(.ngs-form-field-icon-prefix){padding-left:calc(var(--spacing, .25rem) * 2)}:host .ngs-form-field-container:has(.ngs-form-field-icon-button-prefix){padding-left:calc(var(--spacing, .25rem) * 1)}:host .ngs-form-field-container:has(.ngs-form-field-icon-suffix){padding-right:calc(var(--spacing, .25rem) * 2)}:host .ngs-form-field-container:has(.ngs-form-field-icon-button-suffix){padding-right:calc(var(--spacing, .25rem) * 1)}:host .ngs-form-field-infix{flex:1;position:relative;padding:var(--ngs-form-field-infix-padding-top) 0 var(--ngs-form-field-infix-padding-bottom) 0;min-width:0;min-height:var(--ngs-form-field-infix-min-height);display:flex;flex-direction:column;overflow:hidden}:host:not(.ngs-form-field-has-label) .ngs-form-field-infix{padding:8px 0;display:flex;justify-content:center}:host:not(.ngs-form-field-has-label) .ngs-form-field-text-prefix,:host:not(.ngs-form-field-has-label) .ngs-form-field-text-suffix{padding:8px 0}:host .ngs-form-field-label{position:absolute;left:0;transform:translateY(-50%);top:calc(var(--ngs-form-field-container-min-height) / 2);transform-origin:left top;font-size:var(--input-font-size);color:var(--ngs-form-field-label-color);transition:transform .2s ease,font-size .2s ease,color .2s ease,top .2s ease;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;display:flex;align-items:center;gap:.125rem;pointer-events:none;z-index:1;-webkit-user-select:none;user-select:none}:host .ngs-form-field-required-marker{color:var(--ngs-form-field-error-color)}:host.ngs-form-field-should-float .ngs-form-field-label{top:4px;font-size:var(--input-label-float-font-size);transform:translateY(0)}:host ::ng-deep input{line-height:var(--input-line-height);outline:none!important;text-align:var(--ngs-form-field-input-text-align, start)}:host ::ng-deep input::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep textarea{min-height:22px;line-height:var(--input-line-height);outline:none!important;text-align:var(--ngs-form-field-input-text-align, start)}:host ::ng-deep textarea[ngsTextareaAutoSize]{resize:none!important}:host ::ng-deep textarea::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep .ngs-input,:host ::ng-deep .ngs-chip-input,:host ::ng-deep .ngs-phone-input,:host ::ng-deep .ngs-number-input,:host ::ng-deep ngs-select{width:100%;border:none!important;background:transparent!important;padding:0!important;color:inherit;outline:none!important;display:block}:host ::ng-deep .ngs-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep .ngs-chip-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep .ngs-phone-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep .ngs-number-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep ngs-select:not(textarea):not(ngs-select):not(.ngs-chip-input){height:20px}:host ::ng-deep .ngs-input::placeholder,:host ::ng-deep .ngs-chip-input::placeholder,:host ::ng-deep .ngs-phone-input::placeholder,:host ::ng-deep .ngs-number-input::placeholder,:host ::ng-deep ngs-select::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep ngs-chip-grid:empty{display:none}:host ::ng-deep ngs-chip-grid{margin:calc(var(--spacing, .25rem) * 1) 0}:host ::ng-deep .ngs-date-range-input{width:100%;border:none!important;background:transparent!important;padding:0!important;font-size:var(--input-font-size);line-height:var(--input-line-height);color:inherit;outline:none!important;display:flex;height:20px}:host ::ng-deep .ngs-date-range-input::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep input{resize:none;font-size:var(--input-font-size);line-height:var(--input-line-height)}:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-chip-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-chip-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-phone-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-phone-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-number-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-number-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep ngs-select::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep ngs-select .ngs-select-placeholder{opacity:0!important;color:transparent!important}:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-date-range-input::placeholder{opacity:0!important;color:transparent!important}:host .ngs-form-field-prefix,:host .ngs-form-field-icon-prefix,:host .ngs-form-field-icon-button-prefix,:host .ngs-form-field-suffix,:host .ngs-form-field-icon-suffix,:host .ngs-form-field-icon-button-suffix,:host .ngs-form-field-text-prefix,:host .ngs-form-field-text-suffix{display:flex;align-items:center}:host .ngs-form-field-prefix,:host .ngs-form-field-icon-prefix,:host .ngs-form-field-icon-button-prefix,:host .ngs-form-field-text-prefix{margin-right:.5rem}:host .ngs-form-field-suffix,:host .ngs-form-field-icon-suffix,:host .ngs-form-field-icon-button-suffix,:host .ngs-form-field-text-suffix{margin-left:.5rem}:host .ngs-form-field-text-prefix,:host .ngs-form-field-text-suffix{color:var(--ngs-form-field-label-color);white-space:nowrap;font-size:var(--input-font-size);line-height:var(--input-line-height);padding-top:var(--ngs-form-field-infix-padding-top);padding-bottom:var(--ngs-form-field-infix-padding-bottom)}:host .subscript-wrapper{margin-top:.25rem;padding:0 .5rem;font-size:.75rem;min-height:calc(var(--spacing, .25rem) * 5.5)}:host.ngs-form-field-subscript-hidden-if-empty .subscript-wrapper:empty{display:none}:host .ngs-form-field-error{display:none}:host .ngs-form-field-hint-wrapper{display:flex;justify-content:space-between;color:var(--ngs-form-field-label-color)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: FormField, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-form-field', exportAs: 'ngsFormField', imports: [], providers: [
                        {
                            provide: FORM_FIELD,
                            useExisting: FormField
                        }
                    ], host: {
                        'class': 'ngs-form-field',
                        '[class.ngs-form-field-disabled]': 'control()?.disabled',
                        '[class.ngs-form-field-invalid]': 'control()?.errorState',
                        '[class.ngs-form-field-should-float]': 'shouldLabelFloat()',
                        '[class.ngs-form-field-has-label]': 'labelChild()',
                        '[class.ngs-form-field-empty]': 'control()?.empty',
                        '[class.ngs-form-field-focused]': 'control()?.focused',
                        '[class.ngs-form-field-subscript-hidden-if-empty]': 'subscriptHiddenIfEmpty()',
                        '[class.ngs-form-field-has-icon-prefix]': 'iconPrefixChildren().length > 0',
                        '[class.ngs-form-field-has-icon-button-prefix]': 'iconButtonPrefixChildren().length > 0',
                        '[class.ngs-form-field-has-icon-suffix]': 'iconSuffixChildren().length > 0',
                        '[class.ngs-form-field-has-icon-button-suffix]': 'iconButtonSuffixChildren().length > 0',
                    }, template: "<div class=\"ngs-form-field-wrapper\" #wrapper>\n  <div class=\"ngs-form-field-container\" #container>\n    @if (prefixChildren().length > 0) {\n      <div class=\"ngs-form-field-prefix\">\n        <ng-content select=\"[ngsPrefix]\"/>\n      </div>\n    }\n\n    @if (iconPrefixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-prefix\">\n        <ng-content select=\"[ngsIconPrefix]\"/>\n      </div>\n    }\n\n    @if (iconButtonPrefixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-button-prefix\">\n        <ng-content select=\"[ngsIconButtonPrefix]\"/>\n      </div>\n    }\n\n    @if (textPrefixChildren().length > 0) {\n      <div class=\"ngs-form-field-text-prefix\">\n        <ng-content select=\"[ngsTextPrefix]\"/>\n      </div>\n    }\n\n    <div class=\"ngs-form-field-infix\">\n      @if (labelChild()) {\n        <label class=\"ngs-form-field-label\" [attr.for]=\"control()?.id\">\n          <ng-content select=\"ngs-label\"/>\n\n          @if (isRequired()) {\n            <span class=\"ngs-form-field-required-marker\">*</span>\n          }\n        </label>\n      }\n      <ng-content/>\n    </div>\n\n    @if (textSuffixChildren().length > 0) {\n      <div class=\"ngs-form-field-text-suffix\">\n        <ng-content select=\"[ngsTextSuffix]\"/>\n      </div>\n    }\n\n    @if (iconButtonSuffixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-button-suffix\">\n        <ng-content select=\"[ngsIconButtonSuffix]\"/>\n      </div>\n    }\n\n    @if (iconSuffixChildren().length > 0) {\n      <div class=\"ngs-form-field-icon-suffix\">\n        <ng-content select=\"[ngsIconSuffix]\"/>\n      </div>\n    }\n\n    @if (suffixChildren().length > 0) {\n      <div class=\"ngs-form-field-suffix\">\n        <ng-content select=\"[ngsSuffix]\"/>\n      </div>\n    }\n  </div>\n</div>\n\n<div class=\"subscript-wrapper\">\n  @if (control()?.errorState && errorChildren().length > 0) {\n    <ng-content select=\"ngs-error\"/>\n  } @else if (hintChildren().length > 0) {\n    <div class=\"ngs-form-field-hint-wrapper\">\n      <ng-content select=\"ngs-hint\"/>\n    </div>\n  }\n</div>\n", styles: [":host{--ngs-form-field-color: var(--input-color);--ngs-form-field-border-color: var(--input-border-color);--ngs-form-field-border-width: 1px;--ngs-form-field-border-radius: calc(var(--spacing, .25rem) * 3);--ngs-form-field-padding-x: .75rem;--ngs-form-field-padding-y: 1.75rem;--ngs-form-field-bg: var(--color-surface);--ngs-form-field-disabled-bg: var(--color-surface-container-low);--ngs-form-field-label-color: var(--input-label-color);--ngs-form-field-error-color: var(--input-error);--ngs-form-field-container-min-height: 50px;--ngs-form-field-infix-min-height: 50px;--ngs-form-field-infix-padding-top: 23px;--ngs-form-field-infix-padding-bottom: 8px;display:block;width:var(--ngs-form-field-width, 100%)}:host.ngs-form-field-disabled{cursor:default}:host.ngs-form-field-disabled .ngs-form-field-container{background:var(--color-on-surface);border-color:var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled .ngs-form-field-container{background:color-mix(in srgb,var(--color-on-surface),transparent 95%)}}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled .ngs-form-field-container{border-color:color-mix(in srgb,var(--color-on-surface),transparent 90%)}}:host.ngs-form-field-disabled .ngs-form-field-label{color:var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled .ngs-form-field-label{color:color-mix(in srgb,var(--color-on-surface),transparent 62%)}}:host.ngs-form-field-disabled ::ng-deep input{color:var(--color-on-surface)}@supports (color: color-mix(in lab,red,red)){:host.ngs-form-field-disabled ::ng-deep input{color:color-mix(in srgb,var(--color-on-surface),transparent 62%)}}:host.ngs-form-field-focused .ngs-form-field-container{border-color:var(--input-outlined-border-focus);box-shadow:0 0 0 1px var(--input-outlined-border-focus)}:host.ngs-form-field-focused .ngs-form-field-label{color:var(--ngs-form-field-color)}:host.ngs-form-field-invalid .ngs-form-field-container{border-color:var(--ngs-form-field-error-color)}:host.ngs-form-field-invalid.ngs-form-field-focused .ngs-form-field-container{box-shadow:0 0 0 1px var(--ngs-form-field-error-color)}:host.ngs-form-field-invalid .ngs-form-field-label{color:var(--ngs-form-field-error-color)}:host .ngs-form-field-wrapper{display:flex;flex-direction:column}:host .ngs-form-field-container{position:relative;border:var(--ngs-form-field-border-width) solid var(--ngs-form-field-border-color);border-radius:var(--ngs-form-field-border-radius);background:var(--ngs-form-field-bg);padding:0 var(--ngs-form-field-padding-x);transition:border-color .2s,box-shadow .2s;min-height:var(--ngs-form-field-container-min-height);display:flex;align-items:center}:host .ngs-form-field-container:has(.ngs-form-field-icon-prefix){padding-left:calc(var(--spacing, .25rem) * 2)}:host .ngs-form-field-container:has(.ngs-form-field-icon-button-prefix){padding-left:calc(var(--spacing, .25rem) * 1)}:host .ngs-form-field-container:has(.ngs-form-field-icon-suffix){padding-right:calc(var(--spacing, .25rem) * 2)}:host .ngs-form-field-container:has(.ngs-form-field-icon-button-suffix){padding-right:calc(var(--spacing, .25rem) * 1)}:host .ngs-form-field-infix{flex:1;position:relative;padding:var(--ngs-form-field-infix-padding-top) 0 var(--ngs-form-field-infix-padding-bottom) 0;min-width:0;min-height:var(--ngs-form-field-infix-min-height);display:flex;flex-direction:column;overflow:hidden}:host:not(.ngs-form-field-has-label) .ngs-form-field-infix{padding:8px 0;display:flex;justify-content:center}:host:not(.ngs-form-field-has-label) .ngs-form-field-text-prefix,:host:not(.ngs-form-field-has-label) .ngs-form-field-text-suffix{padding:8px 0}:host .ngs-form-field-label{position:absolute;left:0;transform:translateY(-50%);top:calc(var(--ngs-form-field-container-min-height) / 2);transform-origin:left top;font-size:var(--input-font-size);color:var(--ngs-form-field-label-color);transition:transform .2s ease,font-size .2s ease,color .2s ease,top .2s ease;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;display:flex;align-items:center;gap:.125rem;pointer-events:none;z-index:1;-webkit-user-select:none;user-select:none}:host .ngs-form-field-required-marker{color:var(--ngs-form-field-error-color)}:host.ngs-form-field-should-float .ngs-form-field-label{top:4px;font-size:var(--input-label-float-font-size);transform:translateY(0)}:host ::ng-deep input{line-height:var(--input-line-height);outline:none!important;text-align:var(--ngs-form-field-input-text-align, start)}:host ::ng-deep input::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep textarea{min-height:22px;line-height:var(--input-line-height);outline:none!important;text-align:var(--ngs-form-field-input-text-align, start)}:host ::ng-deep textarea[ngsTextareaAutoSize]{resize:none!important}:host ::ng-deep textarea::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep .ngs-input,:host ::ng-deep .ngs-chip-input,:host ::ng-deep .ngs-phone-input,:host ::ng-deep .ngs-number-input,:host ::ng-deep ngs-select{width:100%;border:none!important;background:transparent!important;padding:0!important;color:inherit;outline:none!important;display:block}:host ::ng-deep .ngs-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep .ngs-chip-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep .ngs-phone-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep .ngs-number-input:not(textarea):not(ngs-select):not(.ngs-chip-input),:host ::ng-deep ngs-select:not(textarea):not(ngs-select):not(.ngs-chip-input){height:20px}:host ::ng-deep .ngs-input::placeholder,:host ::ng-deep .ngs-chip-input::placeholder,:host ::ng-deep .ngs-phone-input::placeholder,:host ::ng-deep .ngs-number-input::placeholder,:host ::ng-deep ngs-select::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep ngs-chip-grid:empty{display:none}:host ::ng-deep ngs-chip-grid{margin:calc(var(--spacing, .25rem) * 1) 0}:host ::ng-deep .ngs-date-range-input{width:100%;border:none!important;background:transparent!important;padding:0!important;font-size:var(--input-font-size);line-height:var(--input-line-height);color:inherit;outline:none!important;display:flex;height:20px}:host ::ng-deep .ngs-date-range-input::placeholder{color:var(--ngs-form-field-label-color);transition:opacity .2s}:host ::ng-deep input{resize:none;font-size:var(--input-font-size);line-height:var(--input-line-height)}:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-chip-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-chip-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-phone-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-phone-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-number-input::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-number-input .ngs-select-placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep ngs-select::placeholder,:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep ngs-select .ngs-select-placeholder{opacity:0!important;color:transparent!important}:host.ngs-form-field-has-label:not(.ngs-form-field-should-float) ::ng-deep .ngs-date-range-input::placeholder{opacity:0!important;color:transparent!important}:host .ngs-form-field-prefix,:host .ngs-form-field-icon-prefix,:host .ngs-form-field-icon-button-prefix,:host .ngs-form-field-suffix,:host .ngs-form-field-icon-suffix,:host .ngs-form-field-icon-button-suffix,:host .ngs-form-field-text-prefix,:host .ngs-form-field-text-suffix{display:flex;align-items:center}:host .ngs-form-field-prefix,:host .ngs-form-field-icon-prefix,:host .ngs-form-field-icon-button-prefix,:host .ngs-form-field-text-prefix{margin-right:.5rem}:host .ngs-form-field-suffix,:host .ngs-form-field-icon-suffix,:host .ngs-form-field-icon-button-suffix,:host .ngs-form-field-text-suffix{margin-left:.5rem}:host .ngs-form-field-text-prefix,:host .ngs-form-field-text-suffix{color:var(--ngs-form-field-label-color);white-space:nowrap;font-size:var(--input-font-size);line-height:var(--input-line-height);padding-top:var(--ngs-form-field-infix-padding-top);padding-bottom:var(--ngs-form-field-infix-padding-bottom)}:host .subscript-wrapper{margin-top:.25rem;padding:0 .5rem;font-size:.75rem;min-height:calc(var(--spacing, .25rem) * 5.5)}:host.ngs-form-field-subscript-hidden-if-empty .subscript-wrapper:empty{display:none}:host .ngs-form-field-error{display:none}:host .ngs-form-field-hint-wrapper{display:flex;justify-content:space-between;color:var(--ngs-form-field-label-color)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { subscriptHiddenIfEmpty: [{ type: i0.Input, args: [{ isSignal: true, alias: "subscriptHiddenIfEmpty", required: false }] }], wrapper: [{ type: i0.ViewChild, args: ['wrapper', { isSignal: true }] }], container: [{ type: i0.ViewChild, args: ['container', { isSignal: true }] }], control: [{ type: i0.ContentChild, args: [i0.forwardRef(() => FormFieldControl), { isSignal: true }] }], labelChild: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Label), { isSignal: true }] }], prefixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => Prefix), { isSignal: true }] }], iconPrefixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => IconPrefix), { isSignal: true }] }], iconButtonPrefixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => IconButtonPrefix), { isSignal: true }] }], textPrefixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => TextPrefix), { isSignal: true }] }], suffixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => Suffix), { isSignal: true }] }], iconSuffixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => IconSuffix), { isSignal: true }] }], iconButtonSuffixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => IconButtonSuffix), { isSignal: true }] }], textSuffixChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => TextSuffix), { isSignal: true }] }], hintChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => Hint), { isSignal: true }] }], errorChildren: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => Error), { isSignal: true }] }], _onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

const FORM_FIELD_DEFAULT_OPTIONS = new InjectionToken('FORM_FIELD_DEFAULT_OPTIONS');

/**
 * Generated bundle index. Do not edit.
 */

export { Error, FORM_FIELD, FORM_FIELD_DEFAULT_OPTIONS, FormField, FormFieldControl, Hint, IconButtonPrefix, IconButtonSuffix, IconPrefix, IconSuffix, Label, Prefix, Suffix, TextPrefix, TextSuffix };
//# sourceMappingURL=ngstarter-components-form-field.mjs.map
