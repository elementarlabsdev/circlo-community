import * as i0 from '@angular/core';
import { Component, input } from '@angular/core';

class Logo {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Logo, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Logo, isStandalone: true, selector: "ngs-logo,[ngs-logo]", host: { classAttribute: "ngs-logo" }, exportAs: ["ngsLogo"], ngImport: i0, template: "<ng-content select=\"ngs-logo-shape\"/>\n<div class=\"content\">\n  <ng-content select=\"ngs-logo-text\"/>\n  <ng-content select=\"ngs-logo-description\"/>\n  <ng-content/>\n</div>\n", styles: [":host{--ngs-logo-text-font-size: 1.25rem;--ngs-logo-text-font-weight: 800;--ngs-logo-text-color: var(--color-primary);--ngs-logo-text-hover-color: var(--color-tertiary);display:inline-flex;align-items:center;gap:calc(var(--spacing, .25rem) * 3)}:host:hover{filter:brightness(110%)}:host .content{display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 1)}:host .content:empty{display:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Logo, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-logo,[ngs-logo]', exportAs: 'ngsLogo', imports: [], host: {
                        'class': 'ngs-logo',
                    }, template: "<ng-content select=\"ngs-logo-shape\"/>\n<div class=\"content\">\n  <ng-content select=\"ngs-logo-text\"/>\n  <ng-content select=\"ngs-logo-description\"/>\n  <ng-content/>\n</div>\n", styles: [":host{--ngs-logo-text-font-size: 1.25rem;--ngs-logo-text-font-weight: 800;--ngs-logo-text-color: var(--color-primary);--ngs-logo-text-hover-color: var(--color-tertiary);display:inline-flex;align-items:center;gap:calc(var(--spacing, .25rem) * 3)}:host:hover{filter:brightness(110%)}:host .content{display:flex;flex-direction:column;gap:calc(var(--spacing, .25rem) * 1)}:host .content:empty{display:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class LogoShape {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LogoShape, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: LogoShape, isStandalone: true, selector: "ngs-logo-shape", ngImport: i0, template: "<ng-content select=\"img\"/>\n", styles: [":host{display:block;width:calc(var(--spacing, .25rem) * 9);height:calc(var(--spacing, .25rem) * 9);flex:none;border-radius:calc(var(--spacing, .25rem) * 8);background:linear-gradient(135deg,var(--color-primary),var(--color-tertiary));line-height:0;overflow:hidden}:host ::ng-deep img{width:100%;height:100%;object-fit:cover}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LogoShape, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-logo-shape', imports: [], template: "<ng-content select=\"img\"/>\n", styles: [":host{display:block;width:calc(var(--spacing, .25rem) * 9);height:calc(var(--spacing, .25rem) * 9);flex:none;border-radius:calc(var(--spacing, .25rem) * 8);background:linear-gradient(135deg,var(--color-primary),var(--color-tertiary));line-height:0;overflow:hidden}:host ::ng-deep img{width:100%;height:100%;object-fit:cover}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class LogoText {
    size = input('default', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LogoText, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: LogoText, isStandalone: true, selector: "ngs-logo-text", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-size": "size()" }, classAttribute: "ngs-logo-text" }, exportAs: ["ngsLogoText"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;color:var(--ngs-logo-text-color);font-size:var(--ngs-logo-text-font-size);font-weight:var(--ngs-logo-text-font-weight);line-height:1}:host[data-size=small]{--ngs-logo-text-font-size: .875rem}:host[data-size=default]{--ngs-logo-text-font-size: 1.25rem}:host[data-size=large]{--ngs-logo-text-font-size: 1.875rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LogoText, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-logo-text', exportAs: 'ngsLogoText', host: {
                        'class': 'ngs-logo-text',
                        '[attr.data-size]': 'size()',
                    }, template: "<ng-content/>\n", styles: [":host{display:block;color:var(--ngs-logo-text-color);font-size:var(--ngs-logo-text-font-size);font-weight:var(--ngs-logo-text-font-weight);line-height:1}:host[data-size=small]{--ngs-logo-text-font-size: .875rem}:host[data-size=default]{--ngs-logo-text-font-size: 1.25rem}:host[data-size=large]{--ngs-logo-text-font-size: 1.875rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

class LogoDescription {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LogoDescription, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: LogoDescription, isStandalone: true, selector: "ngs-logo-description", ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;font-size:.75rem;line-height:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LogoDescription, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-logo-description', imports: [], template: "<ng-content/>\n", styles: [":host{display:block;font-size:.75rem;line-height:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Logo, LogoDescription, LogoShape, LogoText };
//# sourceMappingURL=ngstarter-components-logo.mjs.map
