import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component, InjectionToken, makeEnvironmentProviders, inject, input, contentChild, booleanAttribute, Directive } from '@angular/core';

class CardFooter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardFooter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: CardFooter, isStandalone: true, selector: "ngs-card-footer, [ngs-card-footer], [ngsCardFooter]", host: { classAttribute: "ngs-card-footer" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block;padding:0 var(--ngs-card-padding) var(--ngs-card-padding) var(--ngs-card-padding);flex:none}:host:has(ngs-progress-bar){padding:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardFooter, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-footer, [ngs-card-footer], [ngsCardFooter]', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-footer'
                    }, template: "<ng-content />\n", styles: [":host{display:block;padding:0 var(--ngs-card-padding) var(--ngs-card-padding) var(--ngs-card-padding);flex:none}:host:has(ngs-progress-bar){padding:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

const CARD_CONFIG = new InjectionToken('CARD_CONFIG');
function provideCard(config) {
    return makeEnvironmentProviders([
        { provide: CARD_CONFIG, useValue: config }
    ]);
}

class Card {
    _config = inject(CARD_CONFIG, { optional: true });
    appearance = input(this._config?.appearance || 'outlined', ...(ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []));
    _footer = contentChild(CardFooter, ...(ngDevMode ? [{ debugName: "_footer" }] : /* istanbul ignore next */ []));
    get hasFooter() {
        return !!this._footer();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Card, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: Card, isStandalone: true, selector: "ngs-card", inputs: { appearance: { classPropertyName: "appearance", publicName: "appearance", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ngs-card-outlined": "appearance() === \"outlined\"", "class.ngs-card-filled": "appearance() === \"filled\"", "class.ngs-card-raised": "appearance() === \"raised\"" }, classAttribute: "ngs-card not-prose" }, queries: [{ propertyName: "_footer", first: true, predicate: CardFooter, descendants: true, isSignal: true }], exportAs: ["ngsCard"], ngImport: i0, template: "<ng-content/>\n@if (hasFooter) {\n  <ng-content select=\"ngs-card-footer\"/>\n}\n", styles: [":host{--ngs-card-bg: var(--color-surface-container);--ngs-card-color: var(--color-on-surface);--ngs-card-border-radius: 1rem;--ngs-card-border-color: var(--color-subtle);--ngs-card-shadow: none;--ngs-card-padding: calc(var(--spacing, .25rem) * 4);display:flex;flex-direction:column;box-sizing:border-box;position:relative;border-radius:var(--ngs-card-border-radius);background:var(--ngs-card-bg);color:var(--ngs-card-color);box-shadow:var(--ngs-card-shadow);border-width:0;border-style:solid;border-color:var(--ngs-card-border-color)}:host(.ngs-card-outlined){--ngs-card-shadow: none;--ngs-card-bg: transparent;border-width:1px}:host(.ngs-card-raised){--ngs-card-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--ngs-card-bg: var(--color-surface-container)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Card, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card', exportAs: 'ngsCard', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card not-prose',
                        '[class.ngs-card-outlined]': 'appearance() === "outlined"',
                        '[class.ngs-card-filled]': 'appearance() === "filled"',
                        '[class.ngs-card-raised]': 'appearance() === "raised"',
                    }, template: "<ng-content/>\n@if (hasFooter) {\n  <ng-content select=\"ngs-card-footer\"/>\n}\n", styles: [":host{--ngs-card-bg: var(--color-surface-container);--ngs-card-color: var(--color-on-surface);--ngs-card-border-radius: 1rem;--ngs-card-border-color: var(--color-subtle);--ngs-card-shadow: none;--ngs-card-padding: calc(var(--spacing, .25rem) * 4);display:flex;flex-direction:column;box-sizing:border-box;position:relative;border-radius:var(--ngs-card-border-radius);background:var(--ngs-card-bg);color:var(--ngs-card-color);box-shadow:var(--ngs-card-shadow);border-width:0;border-style:solid;border-color:var(--ngs-card-border-color)}:host(.ngs-card-outlined){--ngs-card-shadow: none;--ngs-card-bg: transparent;border-width:1px}:host(.ngs-card-raised){--ngs-card-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--ngs-card-bg: var(--color-surface-container)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { appearance: [{ type: i0.Input, args: [{ isSignal: true, alias: "appearance", required: false }] }], _footer: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CardFooter), { isSignal: true }] }] } });

class CardHeader {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: CardHeader, isStandalone: true, selector: "ngs-card-header", host: { classAttribute: "ngs-card-header" }, ngImport: i0, template: "<div class=\"flex items-center gap-3\">\n  <ng-content select=\"ngs-card-avatar, [ngs-card-avatar], [ngsCardAvatar]\"/>\n  <div class=\"ngs-card-header-text\">\n    <div>\n      <ng-content select=\"ngs-card-title, [ngs-card-title], [ngsCardTitle]\"/>\n      <ng-content select=\"ngs-card-subtitle, [ngs-card-subtitle], [ngsCardSubtitle]\"/>\n    </div>\n    <ng-content/>\n  </div>\n</div>\n<div class=\"aside\">\n  <ng-content select=\"ngs-card-aside, [ngs-card-aside], [ngsCardAside]\"/>\n</div>\n", styles: [":host{display:flex;flex-direction:row;align-items:center;justify-content:space-between;padding:var(--ngs-card-padding, calc(var(--spacing, .25rem) * 3));gap:calc(var(--spacing, .25rem) * 3);flex:none}:host .aside:empty{display:none}:host .aside{flex:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-header', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-header'
                    }, template: "<div class=\"flex items-center gap-3\">\n  <ng-content select=\"ngs-card-avatar, [ngs-card-avatar], [ngsCardAvatar]\"/>\n  <div class=\"ngs-card-header-text\">\n    <div>\n      <ng-content select=\"ngs-card-title, [ngs-card-title], [ngsCardTitle]\"/>\n      <ng-content select=\"ngs-card-subtitle, [ngs-card-subtitle], [ngsCardSubtitle]\"/>\n    </div>\n    <ng-content/>\n  </div>\n</div>\n<div class=\"aside\">\n  <ng-content select=\"ngs-card-aside, [ngs-card-aside], [ngsCardAside]\"/>\n</div>\n", styles: [":host{display:flex;flex-direction:row;align-items:center;justify-content:space-between;padding:var(--ngs-card-padding, calc(var(--spacing, .25rem) * 3));gap:calc(var(--spacing, .25rem) * 3);flex:none}:host .aside:empty{display:none}:host .aside{flex:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class CardTitle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardTitle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: CardTitle, isStandalone: true, selector: "ngs-card-title, [ngs-card-title], [ngsCardTitle]", host: { classAttribute: "ngs-card-title" }, exportAs: ["ngsCardTitle"], ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block;margin-bottom:8px;font-size:var(--ngs-card-title-font-size, 20px);font-weight:var(--ngs-card-title-font-weight, 500);line-height:var(--ngs-card-title-line-height, 32px);letter-spacing:var(--ngs-card-title-letter-spacing, .0125em)}:host:last-child{margin-bottom:0}:host-context(.ngs-card-header-text){margin-bottom:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardTitle, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-title, [ngs-card-title], [ngsCardTitle]', exportAs: 'ngsCardTitle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-title'
                    }, template: "<ng-content />\n", styles: [":host{display:block;margin-bottom:8px;font-size:var(--ngs-card-title-font-size, 20px);font-weight:var(--ngs-card-title-font-weight, 500);line-height:var(--ngs-card-title-line-height, 32px);letter-spacing:var(--ngs-card-title-letter-spacing, .0125em)}:host:last-child{margin-bottom:0}:host-context(.ngs-card-header-text){margin-bottom:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class CardSubtitle {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardSubtitle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: CardSubtitle, isStandalone: true, selector: "ngs-card-subtitle, [ngs-card-subtitle], [ngsCardSubtitle]", host: { classAttribute: "ngs-card-subtitle" }, exportAs: ["ngsCardSubtitle"], ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block;margin-bottom:16px;color:var(--ngs-card-subtitle-color, rgba(0, 0, 0, .54));font-size:var(--ngs-card-subtitle-font-size, 14px);font-weight:var(--ngs-card-subtitle-font-weight, 400);line-height:var(--ngs-card-subtitle-line-height, 20px);letter-spacing:var(--ngs-card-subtitle-letter-spacing, .0178571429em)}:host:last-child{margin-bottom:0}:host-context(.ngs-card-header-text){margin-bottom:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardSubtitle, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-subtitle, [ngs-card-subtitle], [ngsCardSubtitle]', exportAs: 'ngsCardSubtitle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-subtitle'
                    }, template: "<ng-content />\n", styles: [":host{display:block;margin-bottom:16px;color:var(--ngs-card-subtitle-color, rgba(0, 0, 0, .54));font-size:var(--ngs-card-subtitle-font-size, 14px);font-weight:var(--ngs-card-subtitle-font-weight, 400);line-height:var(--ngs-card-subtitle-line-height, 20px);letter-spacing:var(--ngs-card-subtitle-letter-spacing, .0178571429em)}:host:last-child{margin-bottom:0}:host-context(.ngs-card-header-text){margin-bottom:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class CardContent {
    withoutPadding = input(false, { ...(ngDevMode ? { debugName: "withoutPadding" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: CardContent, isStandalone: true, selector: "ngs-card-content, [ngs-card-content], [ngsCardContent]", inputs: { withoutPadding: { classPropertyName: "withoutPadding", publicName: "withoutPadding", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.without-padding": "withoutPadding()" }, classAttribute: "ngs-card-content" }, exportAs: ["ngsCardContent"], ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block;padding:0 var(--ngs-card-padding, 16px) var(--ngs-card-padding, 16px) var(--ngs-card-padding, 16px);font-size:var(--ngs-card-content-font-size, 14px);line-height:var(--ngs-card-content-line-height, 20px);letter-spacing:var(--ngs-card-content-letter-spacing, .0178571429em);flex-grow:1}:host:first-child{padding-top:var(--ngs-card-padding, 16px)}:host.without-padding,:host.without-padding:first-child{padding:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-content, [ngs-card-content], [ngsCardContent]', exportAs: 'ngsCardContent', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-content',
                        '[class.without-padding]': 'withoutPadding()',
                    }, template: "<ng-content />\n", styles: [":host{display:block;padding:0 var(--ngs-card-padding, 16px) var(--ngs-card-padding, 16px) var(--ngs-card-padding, 16px);font-size:var(--ngs-card-content-font-size, 14px);line-height:var(--ngs-card-content-line-height, 20px);letter-spacing:var(--ngs-card-content-letter-spacing, .0178571429em);flex-grow:1}:host:first-child{padding-top:var(--ngs-card-padding, 16px)}:host.without-padding,:host.without-padding:first-child{padding:0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { withoutPadding: [{ type: i0.Input, args: [{ isSignal: true, alias: "withoutPadding", required: false }] }] } });

class CardActions {
    align = input('start', ...(ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardActions, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: CardActions, isStandalone: true, selector: "ngs-card-actions, [ngs-card-actions], [ngsCardActions]", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ngs-card-actions-align-end": "align() === \"end\"", "class.ngs-card-actions-align-center": "align() === \"center\"", "class.ngs-card-actions-align-between": "align() === \"between\"" }, classAttribute: "ngs-card-actions" }, ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;flex-direction:row;align-items:center;box-sizing:border-box;padding:8px;gap:8px;flex:none}:host(.ngs-card-actions-align-center){justify-content:center}:host(.ngs-card-actions-align-end){justify-content:flex-end}:host(.ngs-card-actions-align-between){justify-content:space-between}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardActions, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-actions, [ngs-card-actions], [ngsCardActions]', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-actions',
                        '[class.ngs-card-actions-align-end]': 'align() === "end"',
                        '[class.ngs-card-actions-align-center]': 'align() === "center"',
                        '[class.ngs-card-actions-align-between]': 'align() === "between"',
                    }, template: "<ng-content/>\n", styles: [":host{display:flex;flex-direction:row;align-items:center;box-sizing:border-box;padding:8px;gap:8px;flex:none}:host(.ngs-card-actions-align-center){justify-content:center}:host(.ngs-card-actions-align-end){justify-content:flex-end}:host(.ngs-card-actions-align-between){justify-content:space-between}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }] } });

class CardAside {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardAside, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: CardAside, isStandalone: true, selector: "ngs-card-aside, [ngs-card-aside], ngsCardAside", ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardAside, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-aside, [ngs-card-aside], ngsCardAside', imports: [], template: "<ng-content/>\n", styles: [":host{display:flex;align-items:center;gap:calc(var(--spacing, .25rem) * 1)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class CardImage {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImage, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: CardImage, isStandalone: true, selector: "ngs-card-image, [ngs-card-image], [ngsCardImage]", host: { classAttribute: "ngs-card-image" }, ngImport: i0, template: "<ng-content />\n", styles: [":host{display:block;width:100%}:host(.ngs-card-sm-image){width:80px;height:80px}:host(.ngs-card-md-image){width:110px;height:110px}:host(.ngs-card-lg-image){width:150px;height:150px}:host(.ngs-card-xl-image){width:240px;height:240px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImage, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-image, [ngs-card-image], [ngsCardImage]', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-card-image'
                    }, template: "<ng-content />\n", styles: [":host{display:block;width:100%}:host(.ngs-card-sm-image){width:80px;height:80px}:host(.ngs-card-md-image){width:110px;height:110px}:host(.ngs-card-lg-image){width:150px;height:150px}:host(.ngs-card-xl-image){width:240px;height:240px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });
class CardImageSmall {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageSmall, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CardImageSmall, isStandalone: true, selector: "[ngs-card-sm-image], [ngsCardImageSmall]", host: { classAttribute: "ngs-card-image ngs-card-sm-image" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageSmall, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngs-card-sm-image], [ngsCardImageSmall]',
                    standalone: true,
                    host: {
                        'class': 'ngs-card-image ngs-card-sm-image'
                    }
                }]
        }] });
class CardImageMedium {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageMedium, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CardImageMedium, isStandalone: true, selector: "[ngs-card-md-image], [ngsCardImageMedium]", host: { classAttribute: "ngs-card-image ngs-card-md-image" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageMedium, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngs-card-md-image], [ngsCardImageMedium]',
                    standalone: true,
                    host: {
                        'class': 'ngs-card-image ngs-card-md-image'
                    }
                }]
        }] });
class CardImageLarge {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageLarge, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CardImageLarge, isStandalone: true, selector: "[ngs-card-lg-image], [ngsCardImageLarge]", host: { classAttribute: "ngs-card-image ngs-card-lg-image" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageLarge, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngs-card-lg-image], [ngsCardImageLarge]',
                    standalone: true,
                    host: {
                        'class': 'ngs-card-image ngs-card-lg-image'
                    }
                }]
        }] });
class CardImageXLarge {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageXLarge, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CardImageXLarge, isStandalone: true, selector: "[ngs-card-xl-image], [ngsCardImageXLarge]", host: { classAttribute: "ngs-card-image ngs-card-xl-image" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardImageXLarge, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngs-card-xl-image], [ngsCardImageXLarge]',
                    standalone: true,
                    host: {
                        'class': 'ngs-card-image ngs-card-xl-image'
                    }
                }]
        }] });

class CardAvatar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardAvatar, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CardAvatar, isStandalone: true, selector: "ngs-card-avatar, [ngs-card-avatar], [ngsCardAvatar]", host: { classAttribute: "ngs-card-avatar" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardAvatar, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ngs-card-avatar, [ngs-card-avatar], [ngsCardAvatar]',
                    standalone: true,
                    host: {
                        'class': 'ngs-card-avatar'
                    },
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { CARD_CONFIG, Card, CardActions, CardAside, CardAvatar, CardContent, CardFooter, CardHeader, CardImage, CardImageLarge, CardImageMedium, CardImageSmall, CardImageXLarge, CardSubtitle, CardTitle, provideCard };
//# sourceMappingURL=ngstarter-components-card.mjs.map
