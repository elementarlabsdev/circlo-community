import * as i0 from '@angular/core';
import { input, booleanAttribute, Component } from '@angular/core';

class Skeleton {
    roundedFull = input(false, { ...(ngDevMode ? { debugName: "roundedFull" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Skeleton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: Skeleton, isStandalone: true, selector: "ngs-skeleton", inputs: { roundedFull: { classPropertyName: "roundedFull", publicName: "roundedFull", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.rounded-full": "roundedFull" }, classAttribute: "ngs-skeleton" }, exportAs: ["ngsSkeleton"], ngImport: i0, template: '', isInline: true, styles: [":host{--ngs-skeleton-item-border-radius: 1rem;--ngs-skeleton-from-bg: var(--color-neutral-200);--ngs-skeleton-to-bg: var(--color-neutral-300);display:block;background:linear-gradient(90deg,var(--ngs-skeleton-from-bg),var(--ngs-skeleton-to-bg));flex:none;animation:ngs-skeleton-loading 1s linear infinite alternate}@keyframes ngs-skeleton-loading{0%{background:var(--ngs-skeleton-from-bg)}to{background:var(--ngs-skeleton-to-bg)}}:host-context(html.dark){--ngs-skeleton-from-bg: var(--color-neutral-500);--ngs-skeleton-to-bg: var(--color-neutral-600)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Skeleton, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-skeleton', exportAs: 'ngsSkeleton', imports: [], template: '', host: {
                        class: 'ngs-skeleton',
                        '[class.rounded-full]': 'roundedFull'
                    }, styles: [":host{--ngs-skeleton-item-border-radius: 1rem;--ngs-skeleton-from-bg: var(--color-neutral-200);--ngs-skeleton-to-bg: var(--color-neutral-300);display:block;background:linear-gradient(90deg,var(--ngs-skeleton-from-bg),var(--ngs-skeleton-to-bg));flex:none;animation:ngs-skeleton-loading 1s linear infinite alternate}@keyframes ngs-skeleton-loading{0%{background:var(--ngs-skeleton-from-bg)}to{background:var(--ngs-skeleton-to-bg)}}:host-context(html.dark){--ngs-skeleton-from-bg: var(--color-neutral-500);--ngs-skeleton-to-bg: var(--color-neutral-600)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { roundedFull: [{ type: i0.Input, args: [{ isSignal: true, alias: "roundedFull", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { Skeleton };
//# sourceMappingURL=ngstarter-components-skeleton.mjs.map
