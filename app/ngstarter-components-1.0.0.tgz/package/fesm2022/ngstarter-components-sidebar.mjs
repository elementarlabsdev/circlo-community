import * as i0 from '@angular/core';
import { Component, InjectionToken, inject, ElementRef, input, booleanAttribute, signal, ChangeDetectionStrategy, Directive, contentChildren, contentChild, forwardRef, output, afterNextRender } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import * as i1 from '@ngstarter/components/core';
import { Ripple } from '@ngstarter/components/core';
import { signalStore, withState, withMethods, patchState } from '@ngrx/signals';

class Sidebar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Sidebar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Sidebar, isStandalone: true, selector: "ngs-sidebar", host: { classAttribute: "ngs-sidebar" }, exportAs: ["ngsSidebar"], ngImport: i0, template: "<ng-content select=\"ngs-sidebar-header\"/>\n<ng-content select=\"ngs-sidebar-body\"/>\n<ng-content select=\"ngs-sidebar-footer\"/>\n", styles: [":host{--ngs-sidebar-bg: transparent;display:flex;flex-direction:column;overflow-x:hidden;height:100%;width:var(--ngs-sidebar-width);transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s;background:var(--ngs-sidebar-bg)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Sidebar, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar', exportAs: 'ngsSidebar', host: {
                        'class': 'ngs-sidebar',
                    }, template: "<ng-content select=\"ngs-sidebar-header\"/>\n<ng-content select=\"ngs-sidebar-body\"/>\n<ng-content select=\"ngs-sidebar-footer\"/>\n", styles: [":host{--ngs-sidebar-bg: transparent;display:flex;flex-direction:column;overflow-x:hidden;height:100%;width:var(--ngs-sidebar-width);transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s;background:var(--ngs-sidebar-bg)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SidebarHeader {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidebarHeader, isStandalone: true, selector: "ngs-sidebar-header", host: { classAttribute: "ngs-sidebar-header" }, exportAs: ["ngsSidebarHeader"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{--ngs-sidebar-header-compact-padding: calc(var(--spacing, .25rem) * 4) 0;flex:none;width:100%}:host ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host-context(.ngs-sidebar.compact:not(:hover)){padding:var(--ngs-sidebar-header-compact-padding);display:flex;align-items:center;justify-content:center;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}:host-context(.ngs-sidebar.compact:not(:hover)) ::ng-deep .ngs-sidebar-full-view-mode{display:none}:host-context(.ngs-sidebar.compact:not(:hover)) ::ng-deep .ngs-sidebar-compact-view-mode{display:block}:host-context(.ngs-sidebar.compact:hover) ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host-context(.ngs-sidebar.compact:hover) ::ng-deep .ngs-sidebar-full-view-mode{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-header', exportAs: 'ngsSidebarHeader', host: {
                        'class': 'ngs-sidebar-header',
                    }, template: "<ng-content/>\n", styles: [":host{--ngs-sidebar-header-compact-padding: calc(var(--spacing, .25rem) * 4) 0;flex:none;width:100%}:host ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host-context(.ngs-sidebar.compact:not(:hover)){padding:var(--ngs-sidebar-header-compact-padding);display:flex;align-items:center;justify-content:center;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}:host-context(.ngs-sidebar.compact:not(:hover)) ::ng-deep .ngs-sidebar-full-view-mode{display:none}:host-context(.ngs-sidebar.compact:not(:hover)) ::ng-deep .ngs-sidebar-compact-view-mode{display:block}:host-context(.ngs-sidebar.compact:hover) ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host-context(.ngs-sidebar.compact:hover) ::ng-deep .ngs-sidebar-full-view-mode{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SidebarBody {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarBody, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidebarBody, isStandalone: true, selector: "ngs-sidebar-body", host: { classAttribute: "ngs-sidebar-body" }, exportAs: ["ngsSidebarBody"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;width:100%;flex-grow:1;overflow-y:auto;overflow-x:hidden;position:relative}:host .scroll-content{padding:0}:host-context(.ngs-sidebar.compact){overflow-y:hidden;padding:0}:host-context(.ngs-sidebar.compact:hover){overflow-y:auto}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarBody, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-body', exportAs: 'ngsSidebarBody', imports: [], host: {
                        'class': 'ngs-sidebar-body'
                    }, template: "<ng-content/>\n", styles: [":host{display:block;width:100%;flex-grow:1;overflow-y:auto;overflow-x:hidden;position:relative}:host .scroll-content{padding:0}:host-context(.ngs-sidebar.compact){overflow-y:hidden;padding:0}:host-context(.ngs-sidebar.compact:hover){overflow-y:auto}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

const SIDEBAR_NAVIGATION = new InjectionToken('Sidebar navigation');
const SIDEBAR_NAVIGATION_GROUP = new InjectionToken('SIDEBAR_NAVIGATION_GROUP');

const initialState = {
    activeItemKey: null,
    activeGroupKey: null,
};
const SidebarNavStore = signalStore(withState(initialState), withMethods((store) => ({
    setItemActiveKey(activeItemKey) {
        patchState(store, { activeItemKey });
    },
    isItemActive(activeItemKey) {
        return store.activeItemKey() === activeItemKey;
    },
    setGroupActiveKey(activeGroupKey) {
        patchState(store, { activeGroupKey });
    },
    isGroupActive(activeGroupKey) {
        return store.activeGroupKey() === activeGroupKey;
    }
})));

class SidebarNavItemInterface {
    active;
}
class SidebarNavItem {
    _navigation = inject(SIDEBAR_NAVIGATION);
    _elementRef = inject(ElementRef);
    _navStore = inject(SidebarNavStore);
    get api() {
        return {
            isActive: () => this.active
        };
    }
    key = input(Math.random(), ...(ngDevMode ? [{ debugName: "key" }] : /* istanbul ignore next */ []));
    forceActive = input(false, { ...(ngDevMode ? { debugName: "forceActive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    click(event) {
        if (!this.key()) {
            return;
        }
        this._navStore.setItemActiveKey(this.key());
        this._navigation.itemClicked.emit(this.key());
    }
    get active() {
        return this._navStore.isItemActive(this.key());
    }
    get _hostElement() {
        return this._elementRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: SidebarNavItem, isStandalone: true, selector: "ngs-sidebar-nav-item,[ngs-sidebar-nav-item]", inputs: { key: { classPropertyName: "key", publicName: "key", isSignal: true, isRequired: false, transformFunction: null }, forceActive: { classPropertyName: "forceActive", publicName: "forceActive", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "click($event)" }, properties: { "class.is-active": "forceActive() || active" }, classAttribute: "ngs-sidebar-nav-item" }, exportAs: ["ngs-sidebar-nav-item"], ngImport: i0, template: "<div class=\"inner\" ngsRipple>\n  <div class=\"icon\">\n    <ng-content select=\"[ngsSidebarNavItemIcon]\"/>\n  </div>\n  <span class=\"text grow\"><ng-content/></span>\n  <div class=\"badge\">\n    <ng-content select=\"[ngsSidebarNavItemBadge]\"/>\n  </div>\n</div>\n", styles: [":host{display:block;text-decoration:none;position:relative}:host .inner{display:flex;align-items:center;min-width:0;white-space:nowrap;flex:none;cursor:pointer;-webkit-user-select:none;user-select:none;margin:0;width:var(--ngs-sidebar-nav-item-width);background:var(--ngs-sidebar-nav-item-bg);min-height:var(--ngs-sidebar-nav-item-height);padding:var(--ngs-sidebar-nav-item-padding);font-size:var(--ngs-sidebar-nav-item-font-size);border-radius:var(--ngs-sidebar-nav-item-radius);font-weight:var(--ngs-sidebar-nav-item-font-weight);color:var(--ngs-sidebar-nav-item-color);gap:var(--ngs-sidebar-nav-item-gap)}:host:hover .inner{transition:background-color .2s}:host .text{overflow:hidden;text-overflow:ellipsis}:host .badge:empty{display:none}:host .badge{display:inline-flex;flex:none;border-radius:calc(infinity * 1px);height:calc(var(--spacing, .25rem) * 5);min-width:calc(var(--spacing, .25rem) * 5);align-items:center;justify-content:center;font-size:.625rem;padding:0 calc(var(--spacing, .25rem) * 1.5);background:var(--color-primary);color:var(--color-on-primary)}:host .icon{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:none;width:var(--ngs-sidebar-nav-item-icon-width);color:var(--ngs-sidebar-nav-item-icon-color)}:host .icon:empty{display:none}:host:hover{text-decoration:none}:host:hover .inner{background:var(--ngs-sidebar-nav-item-hover-bg);color:var(--ngs-sidebar-nav-item-hover-color)}:host.is-active .inner,:host.is-active:hover .inner{background:var(--ngs-sidebar-nav-item-active-bg);color:var(--ngs-sidebar-nav-item-active-color)}:host.is-active .icon{color:var(--ngs-sidebar-nav-item-active-icon-color)}:host:not(.is-active):hover{text-decoration:none}:host:not(.is-active):hover .icon{color:var(--ngs-sidebar-nav-item-hover-icon-color)}:host-context(.ngs-sidebar-nav-group-menu) .inner{margin:var(--ngs-sidebar-nav-nested-item-margin);width:calc(var(--ngs-sidebar-nav-item-width) - var(--ngs-sidebar-nav-nested-item-margin));background:var(--ngs-sidebar-nav-nested-item-bg);min-height:var(--ngs-sidebar-nav-nested-item-height);padding:var(--ngs-sidebar-nav-nested-item-padding);color:var(--ngs-sidebar-nav-nested-item-color)}:host-context(.ngs-sidebar-nav-group-menu):hover .inner{background:var(--ngs-sidebar-nav-nested-item-hover-bg);color:var(--ngs-sidebar-nav-nested-item-hover-color)}:host-context(.ngs-sidebar-nav-group-menu).is-active .inner,:host-context(.ngs-sidebar-nav-group-menu).is-active:hover .inner{background:var(--ngs-sidebar-nav-nested-item-active-bg);color:var(--ngs-sidebar-nav-nested-item-active-color)}:host-context(.ngs-sidebar-nav-group-menu):not(:last-child):before{content:\"\";position:absolute;top:0;left:20px;bottom:-10px;width:1px;background:var(--ngs-sidebar-nav-group-tree-lines-color);z-index:0}:host-context(.ngs-sidebar-nav-group-menu):after{content:\"\";position:absolute;top:0;left:20px;width:calc(var(--ngs-sidebar-nav-nested-item-height) / 1.5);height:calc(var(--ngs-sidebar-nav-nested-item-height) / 2);border-bottom-left-radius:calc(var(--ngs-sidebar-nav-nested-item-height) / 4);border-left:1px solid var(--ngs-sidebar-nav-group-tree-lines-color);border-bottom:1px solid var(--ngs-sidebar-nav-group-tree-lines-color)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "directive", type: Ripple, selector: "[ngsRipple]", inputs: ["ngsRippleColor", "ngsRippleUnbounded", "ngsRippleCentered", "ngsRippleRadius", "ngsRippleAnimation", "ngsRippleDisabled", "ngsRippleTrigger"], outputs: ["ngsRippleCenteredChange", "ngsRippleDisabledChange", "ngsRippleTriggerChange"], exportAs: ["ngsRipple"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItem, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-nav-item,[ngs-sidebar-nav-item]', exportAs: 'ngs-sidebar-nav-item', imports: [
                        Ripple
                    ], host: {
                        'class': 'ngs-sidebar-nav-item',
                        '[class.is-active]': 'forceActive() || active',
                        '(click)': 'click($event)'
                    }, template: "<div class=\"inner\" ngsRipple>\n  <div class=\"icon\">\n    <ng-content select=\"[ngsSidebarNavItemIcon]\"/>\n  </div>\n  <span class=\"text grow\"><ng-content/></span>\n  <div class=\"badge\">\n    <ng-content select=\"[ngsSidebarNavItemBadge]\"/>\n  </div>\n</div>\n", styles: [":host{display:block;text-decoration:none;position:relative}:host .inner{display:flex;align-items:center;min-width:0;white-space:nowrap;flex:none;cursor:pointer;-webkit-user-select:none;user-select:none;margin:0;width:var(--ngs-sidebar-nav-item-width);background:var(--ngs-sidebar-nav-item-bg);min-height:var(--ngs-sidebar-nav-item-height);padding:var(--ngs-sidebar-nav-item-padding);font-size:var(--ngs-sidebar-nav-item-font-size);border-radius:var(--ngs-sidebar-nav-item-radius);font-weight:var(--ngs-sidebar-nav-item-font-weight);color:var(--ngs-sidebar-nav-item-color);gap:var(--ngs-sidebar-nav-item-gap)}:host:hover .inner{transition:background-color .2s}:host .text{overflow:hidden;text-overflow:ellipsis}:host .badge:empty{display:none}:host .badge{display:inline-flex;flex:none;border-radius:calc(infinity * 1px);height:calc(var(--spacing, .25rem) * 5);min-width:calc(var(--spacing, .25rem) * 5);align-items:center;justify-content:center;font-size:.625rem;padding:0 calc(var(--spacing, .25rem) * 1.5);background:var(--color-primary);color:var(--color-on-primary)}:host .icon{position:relative;display:inline-flex;align-items:center;justify-content:center;flex:none;width:var(--ngs-sidebar-nav-item-icon-width);color:var(--ngs-sidebar-nav-item-icon-color)}:host .icon:empty{display:none}:host:hover{text-decoration:none}:host:hover .inner{background:var(--ngs-sidebar-nav-item-hover-bg);color:var(--ngs-sidebar-nav-item-hover-color)}:host.is-active .inner,:host.is-active:hover .inner{background:var(--ngs-sidebar-nav-item-active-bg);color:var(--ngs-sidebar-nav-item-active-color)}:host.is-active .icon{color:var(--ngs-sidebar-nav-item-active-icon-color)}:host:not(.is-active):hover{text-decoration:none}:host:not(.is-active):hover .icon{color:var(--ngs-sidebar-nav-item-hover-icon-color)}:host-context(.ngs-sidebar-nav-group-menu) .inner{margin:var(--ngs-sidebar-nav-nested-item-margin);width:calc(var(--ngs-sidebar-nav-item-width) - var(--ngs-sidebar-nav-nested-item-margin));background:var(--ngs-sidebar-nav-nested-item-bg);min-height:var(--ngs-sidebar-nav-nested-item-height);padding:var(--ngs-sidebar-nav-nested-item-padding);color:var(--ngs-sidebar-nav-nested-item-color)}:host-context(.ngs-sidebar-nav-group-menu):hover .inner{background:var(--ngs-sidebar-nav-nested-item-hover-bg);color:var(--ngs-sidebar-nav-nested-item-hover-color)}:host-context(.ngs-sidebar-nav-group-menu).is-active .inner,:host-context(.ngs-sidebar-nav-group-menu).is-active:hover .inner{background:var(--ngs-sidebar-nav-nested-item-active-bg);color:var(--ngs-sidebar-nav-nested-item-active-color)}:host-context(.ngs-sidebar-nav-group-menu):not(:last-child):before{content:\"\";position:absolute;top:0;left:20px;bottom:-10px;width:1px;background:var(--ngs-sidebar-nav-group-tree-lines-color);z-index:0}:host-context(.ngs-sidebar-nav-group-menu):after{content:\"\";position:absolute;top:0;left:20px;width:calc(var(--ngs-sidebar-nav-nested-item-height) / 1.5);height:calc(var(--ngs-sidebar-nav-nested-item-height) / 2);border-bottom-left-radius:calc(var(--ngs-sidebar-nav-nested-item-height) / 4);border-left:1px solid var(--ngs-sidebar-nav-group-tree-lines-color);border-bottom:1px solid var(--ngs-sidebar-nav-group-tree-lines-color)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { key: [{ type: i0.Input, args: [{ isSignal: true, alias: "key", required: false }] }], forceActive: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceActive", required: false }] }] } });

class SidebarNavGroupToggle {
    _navStore = inject(SidebarNavStore);
    for = signal(null, ...(ngDevMode ? [{ debugName: "for" }] : /* istanbul ignore next */ []));
    get active() {
        if (!this.for()) {
            return false;
        }
        return this._navStore.isGroupActive(this.for());
    }
    toggle(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this._navStore.isGroupActive(this.for())) {
            this._navStore.setGroupActiveKey(null);
        }
        else {
            this._navStore.setGroupActiveKey(this.for());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroupToggle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidebarNavGroupToggle, isStandalone: true, selector: "ngs-sidebar-nav-group-toggle", host: { listeners: { "click": "toggle($event)" }, properties: { "class.is-active": "active" }, classAttribute: "ngs-sidebar-nav-group-toggle" }, exportAs: ["ngsSidebarNavGroupToggle"], hostDirectives: [{ directive: i1.Ripple }], ngImport: i0, template: "<div class=\"icon\"><ng-content select=\"[ngsSidebarNavItemIcon]\"/></div>\n<span class=\"text grow\"><ng-content/></span>\n<div class=\"flex items-center gap-0.5\">\n  <div class=\"badge\">\n    <ng-content select=\"[ngsSidebarNavItemBadge]\"/>\n  </div>\n  <div class=\"arrow\">\n    <ng-content select=\"[ngsSidebarNavGroupToggleIcon]\"/>\n  </div>\n</div>\n", styles: [":host{display:flex;align-items:center;min-width:0;white-space:nowrap;position:relative;flex:none;cursor:pointer;-webkit-user-select:none;user-select:none;background:var(--ngs-sidebar-nav-group-toggle-bg);min-height:var(--ngs-sidebar-nav-item-height);padding:var(--ngs-sidebar-nav-item-padding);font-size:var(--ngs-sidebar-nav-item-font-size);border-radius:var(--ngs-sidebar-nav-item-radius);font-weight:var(--ngs-sidebar-nav-item-font-weight);color:var(--ngs-sidebar-nav-item-color);gap:var(--ngs-sidebar-nav-item-gap);width:var(--ngs-sidebar-nav-item-width)}:host .text{overflow:hidden;text-overflow:ellipsis}:host .text ::ng-deep .ngs-sidebar-full-view-mode{display:block}:host .text ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host .badge:empty{display:none}:host .badge{display:inline-flex;flex:none;border-radius:calc(infinity * 1px);height:calc(var(--spacing, .25rem) * 5);align-items:center;justify-content:center;min-width:calc(var(--spacing, .25rem) * 5);font-size:.625rem;padding:0 calc(var(--spacing, .25rem) * 1.5);background:var(--color-primary);color:var(--color-on-primary)}:host .icon{display:inline-flex;align-items:center;justify-content:center;width:var(--ngs-sidebar-nav-item-icon-width);color:var(--ngs-sidebar-nav-group-toggle-icon-color);flex:none}:host .icon:empty{display:none}:host .arrow{display:inline-flex;align-items:center;justify-content:center;transition:transform .2s ease;color:var(--ngs-sidebar-nav-group-arrow-color);width:calc(var(--spacing, .25rem) * 7);height:calc(var(--spacing, .25rem) * 7);flex:none}:host .arrow:empty{display:none}:host:hover{background:var(--ngs-sidebar-nav-item-hover-bg);color:var(--ngs-sidebar-nav-group-toggle-hover-icon-color);transition:background-color .2s}:host.is-active,:host.is-active:hover{background:var(--ngs-sidebar-nav-group-toggle-active-bg);color:var(--ngs-sidebar-nav-group-toggle-active-color)}:host:not(.is-active):hover .icon{color:var(--ngs-sidebar-nav-item-hover-icon-color)}:host.is-active .icon{color:var(--ngs-sidebar-nav-group-toggle-active-icon-color)}:host.is-active .arrow{transform:rotate(-180deg)}:host:has(.arrow:not(:empty)){padding-inline-end:var(--ngs-sidebar-nav-group-toggle-has-icon-padding-end)}:host-context(.ngs-sidebar.compact) .text ::ng-deep .ngs-sidebar-full-view-mode{display:none}:host-context(.ngs-sidebar.compact) .text ::ng-deep .ngs-sidebar-compact-view-mode{display:block}:host-context(.ngs-sidebar.compact:hover) .text ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host-context(.ngs-sidebar.compact:hover) .text ::ng-deep .ngs-sidebar-full-view-mode{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroupToggle, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-nav-group-toggle', exportAs: 'ngsSidebarNavGroupToggle', changeDetection: ChangeDetectionStrategy.OnPush, hostDirectives: [
                        Ripple
                    ], host: {
                        'class': 'ngs-sidebar-nav-group-toggle',
                        '[class.is-active]': 'active',
                        '(click)': 'toggle($event)'
                    }, template: "<div class=\"icon\"><ng-content select=\"[ngsSidebarNavItemIcon]\"/></div>\n<span class=\"text grow\"><ng-content/></span>\n<div class=\"flex items-center gap-0.5\">\n  <div class=\"badge\">\n    <ng-content select=\"[ngsSidebarNavItemBadge]\"/>\n  </div>\n  <div class=\"arrow\">\n    <ng-content select=\"[ngsSidebarNavGroupToggleIcon]\"/>\n  </div>\n</div>\n", styles: [":host{display:flex;align-items:center;min-width:0;white-space:nowrap;position:relative;flex:none;cursor:pointer;-webkit-user-select:none;user-select:none;background:var(--ngs-sidebar-nav-group-toggle-bg);min-height:var(--ngs-sidebar-nav-item-height);padding:var(--ngs-sidebar-nav-item-padding);font-size:var(--ngs-sidebar-nav-item-font-size);border-radius:var(--ngs-sidebar-nav-item-radius);font-weight:var(--ngs-sidebar-nav-item-font-weight);color:var(--ngs-sidebar-nav-item-color);gap:var(--ngs-sidebar-nav-item-gap);width:var(--ngs-sidebar-nav-item-width)}:host .text{overflow:hidden;text-overflow:ellipsis}:host .text ::ng-deep .ngs-sidebar-full-view-mode{display:block}:host .text ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host .badge:empty{display:none}:host .badge{display:inline-flex;flex:none;border-radius:calc(infinity * 1px);height:calc(var(--spacing, .25rem) * 5);align-items:center;justify-content:center;min-width:calc(var(--spacing, .25rem) * 5);font-size:.625rem;padding:0 calc(var(--spacing, .25rem) * 1.5);background:var(--color-primary);color:var(--color-on-primary)}:host .icon{display:inline-flex;align-items:center;justify-content:center;width:var(--ngs-sidebar-nav-item-icon-width);color:var(--ngs-sidebar-nav-group-toggle-icon-color);flex:none}:host .icon:empty{display:none}:host .arrow{display:inline-flex;align-items:center;justify-content:center;transition:transform .2s ease;color:var(--ngs-sidebar-nav-group-arrow-color);width:calc(var(--spacing, .25rem) * 7);height:calc(var(--spacing, .25rem) * 7);flex:none}:host .arrow:empty{display:none}:host:hover{background:var(--ngs-sidebar-nav-item-hover-bg);color:var(--ngs-sidebar-nav-group-toggle-hover-icon-color);transition:background-color .2s}:host.is-active,:host.is-active:hover{background:var(--ngs-sidebar-nav-group-toggle-active-bg);color:var(--ngs-sidebar-nav-group-toggle-active-color)}:host:not(.is-active):hover .icon{color:var(--ngs-sidebar-nav-item-hover-icon-color)}:host.is-active .icon{color:var(--ngs-sidebar-nav-group-toggle-active-icon-color)}:host.is-active .arrow{transform:rotate(-180deg)}:host:has(.arrow:not(:empty)){padding-inline-end:var(--ngs-sidebar-nav-group-toggle-has-icon-padding-end)}:host-context(.ngs-sidebar.compact) .text ::ng-deep .ngs-sidebar-full-view-mode{display:none}:host-context(.ngs-sidebar.compact) .text ::ng-deep .ngs-sidebar-compact-view-mode{display:block}:host-context(.ngs-sidebar.compact:hover) .text ::ng-deep .ngs-sidebar-compact-view-mode{display:none}:host-context(.ngs-sidebar.compact:hover) .text ::ng-deep .ngs-sidebar-full-view-mode{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SidebarNavItemDefDirective {
    template;
    when = input(undefined, { ...(ngDevMode ? { debugName: "when" } : /* istanbul ignore next */ {}), alias: 'ngsSidebarNavItemDef' });
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItemDefDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: SidebarNavItemDefDirective, isStandalone: true, selector: "[ngsSidebarNavItemDef]", inputs: { when: { classPropertyName: "when", publicName: "ngsSidebarNavItemDef", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItemDefDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSidebarNavItemDef]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { when: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsSidebarNavItemDef", required: false }] }] } });

class SidebarNavGroupMenu {
    navigation = inject(SIDEBAR_NAVIGATION);
    _group = inject(SIDEBAR_NAVIGATION_GROUP);
    _navStore = inject(SidebarNavStore);
    _items = contentChildren(SidebarNavItem, { ...(ngDevMode ? { debugName: "_items" } : /* istanbul ignore next */ {}), descendants: true });
    _defs = contentChildren(SidebarNavItemDefDirective, ...(ngDevMode ? [{ debugName: "_defs" }] : /* istanbul ignore next */ []));
    key = signal(this._group._groupId, ...(ngDevMode ? [{ debugName: "key" }] : /* istanbul ignore next */ []));
    dataSource = input(...(ngDevMode ? [undefined, { debugName: "dataSource" }] : /* istanbul ignore next */ []));
    itemTypeProperty = input('type', ...(ngDevMode ? [{ debugName: "itemTypeProperty" }] : /* istanbul ignore next */ []));
    get active() {
        return this._navStore.isGroupActive(this.key());
    }
    ngOnInit() {
        this.navigation
            .itemClicked
            .subscribe(() => {
            if (!this.hasActiveItem() && this._group._groupId === this._navStore.activeGroupKey()) {
                this._navStore.setGroupActiveKey(null);
            }
        });
    }
    ngAfterContentInit() {
        this._checkIfActive();
    }
    hasActiveItem() {
        const fromItems = this._items().some(item => item.active);
        if (fromItems) {
            return true;
        }
        const data = this.dataSource();
        if (data) {
            const activeKey = this._navStore.activeItemKey();
            return data.some(item => this._isActive(item, activeKey));
        }
        return false;
    }
    getTemplate(item) {
        const def = this._defs().find(d => {
            const whenValue = d.when();
            if (whenValue) {
                if (typeof whenValue === 'function') {
                    return whenValue(item);
                }
                return item[this.itemTypeProperty()] === whenValue;
            }
            return false;
        }) || this._defs().find(d => !d.when());
        return def?.template || null;
    }
    _checkIfActive() {
        if (this.hasActiveItem()) {
            this._navStore.setGroupActiveKey(this.key());
        }
    }
    _isActive(item, activeKey) {
        if (item.key === activeKey) {
            return true;
        }
        if (item.children && Array.isArray(item.children)) {
            return item.children.some((child) => this._isActive(child, activeKey));
        }
        return false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroupMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: SidebarNavGroupMenu, isStandalone: true, selector: "ngs-sidebar-nav-group-menu", inputs: { dataSource: { classPropertyName: "dataSource", publicName: "dataSource", isSignal: true, isRequired: false, transformFunction: null }, itemTypeProperty: { classPropertyName: "itemTypeProperty", publicName: "itemTypeProperty", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-active": "active" }, classAttribute: "ngs-sidebar-nav-group-menu" }, queries: [{ propertyName: "_items", predicate: SidebarNavItem, descendants: true, isSignal: true }, { propertyName: "_defs", predicate: SidebarNavItemDefDirective, isSignal: true }], exportAs: ["ngsSidebarNavGroupMenu"], ngImport: i0, template: "@if (dataSource(); as data) {\n  <div class=\"inner\">\n    @for (item of data; track item) {\n      <ng-container *ngTemplateOutlet=\"getTemplate(item); context: { $implicit: item }\" />\n    }\n  </div>\n} @else {\n  <div class=\"inner\">\n    <ng-content/>\n  </div>\n}\n", styles: [":host{position:relative;padding-inline-start:var(--ngs-sidebar-nav-group-menu-padding-start);transition:grid-template-rows .2s ease;grid-template-rows:0fr;display:grid}:host .inner{overflow:hidden;display:flex;flex-direction:column;gap:var(--ngs-sidebar-nav-items-gap)}:host.is-active{grid-template-rows:1fr;margin-top:var(--ngs-sidebar-nav-item-space-y)}:host.is-active .inner{padding:calc(var(--ngs-sidebar-nav-items-gap) * 2) 0 var(--ngs-sidebar-nav-items-gap) 0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroupMenu, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-nav-group-menu', exportAs: 'ngsSidebarNavGroupMenu', changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, imports: [
                        NgTemplateOutlet
                    ], host: {
                        'class': 'ngs-sidebar-nav-group-menu',
                        '[class.is-active]': 'active'
                    }, template: "@if (dataSource(); as data) {\n  <div class=\"inner\">\n    @for (item of data; track item) {\n      <ng-container *ngTemplateOutlet=\"getTemplate(item); context: { $implicit: item }\" />\n    }\n  </div>\n} @else {\n  <div class=\"inner\">\n    <ng-content/>\n  </div>\n}\n", styles: [":host{position:relative;padding-inline-start:var(--ngs-sidebar-nav-group-menu-padding-start);transition:grid-template-rows .2s ease;grid-template-rows:0fr;display:grid}:host .inner{overflow:hidden;display:flex;flex-direction:column;gap:var(--ngs-sidebar-nav-items-gap)}:host.is-active{grid-template-rows:1fr;margin-top:var(--ngs-sidebar-nav-item-space-y)}:host.is-active .inner{padding:calc(var(--ngs-sidebar-nav-items-gap) * 2) 0 var(--ngs-sidebar-nav-items-gap) 0}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { _items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SidebarNavItem), { ...{ descendants: true }, isSignal: true }] }], _defs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SidebarNavItemDefDirective), { isSignal: true }] }], dataSource: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataSource", required: false }] }], itemTypeProperty: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTypeProperty", required: false }] }] } });

let nextId = 0;
class SidebarNavGroup {
    _toggle = contentChild.required(SidebarNavGroupToggle, {
        descendants: false,
    });
    _menu = contentChild.required(SidebarNavGroupMenu, {
        descendants: false,
    });
    _groupId = `sidebar-nav-group-${nextId++}`;
    ngAfterContentInit() {
        this._toggle().for.set(this._groupId);
    }
    hasActiveItem() {
        return this._menu().hasActiveItem();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: SidebarNavGroup, isStandalone: true, selector: "ngs-sidebar-nav-group", providers: [
            {
                provide: SIDEBAR_NAVIGATION_GROUP,
                useExisting: forwardRef(() => SidebarNavGroup),
            }
        ], queries: [{ propertyName: "_toggle", first: true, predicate: SidebarNavGroupToggle, isSignal: true }, { propertyName: "_menu", first: true, predicate: SidebarNavGroupMenu, isSignal: true }], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;border-radius:var(--ngs-sidebar-nav-group-border-radius)}:host:has(.ngs-sidebar-nav-group-toggle.is-active){background:var(--ngs-sidebar-nav-group-active-bg)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroup, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-nav-group', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: SIDEBAR_NAVIGATION_GROUP,
                            useExisting: forwardRef(() => SidebarNavGroup),
                        }
                    ], template: "<ng-content/>\n", styles: [":host{display:block;border-radius:var(--ngs-sidebar-nav-group-border-radius)}:host:has(.ngs-sidebar-nav-group-toggle.is-active){background:var(--ngs-sidebar-nav-group-active-bg)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { _toggle: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SidebarNavGroupToggle), { ...{
                            descendants: false,
                        }, isSignal: true }] }], _menu: [{ type: i0.ContentChild, args: [i0.forwardRef(() => SidebarNavGroupMenu), { ...{
                            descendants: false,
                        }, isSignal: true }] }] } });

class SidebarNav {
    _elementRef = inject(ElementRef);
    _navStore = inject(SidebarNavStore);
    _items = contentChildren(SidebarNavItem, { ...(ngDevMode ? { debugName: "_items" } : /* istanbul ignore next */ {}), descendants: true });
    _groups = contentChildren(SidebarNavGroup, { ...(ngDevMode ? { debugName: "_groups" } : /* istanbul ignore next */ {}), descendants: true });
    _defs = contentChildren(SidebarNavItemDefDirective, ...(ngDevMode ? [{ debugName: "_defs" }] : /* istanbul ignore next */ []));
    activeKey = input(...(ngDevMode ? [undefined, { debugName: "activeKey" }] : /* istanbul ignore next */ []));
    dataSource = input(...(ngDevMode ? [undefined, { debugName: "dataSource" }] : /* istanbul ignore next */ []));
    itemTypeProperty = input('type', ...(ngDevMode ? [{ debugName: "itemTypeProperty" }] : /* istanbul ignore next */ []));
    autoScrollToActiveItem = input(false, { ...(ngDevMode ? { debugName: "autoScrollToActiveItem" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    itemClicked = output();
    constructor() {
        // scroll to the active item if it is not visible in the viewport
        afterNextRender(() => {
            if (this.autoScrollToActiveItem()) {
                this._scrollToActiveItem();
            }
        });
    }
    ngOnChanges(changes) {
        if (changes['activeKey']) {
            this._navStore.setItemActiveKey(changes['activeKey'].currentValue);
            this._groups().forEach((group) => {
                if (group.hasActiveItem()) {
                    this._navStore.setGroupActiveKey(group._groupId);
                    requestAnimationFrame(() => {
                        this._scrollToActiveItem();
                    });
                }
            });
        }
    }
    ngAfterContentInit() {
    }
    _hasScroll(element) {
        if (!element.getBoundingClientRect) {
            return false;
        }
        return Math.ceil(element.scrollHeight) > Math.ceil(element.getBoundingClientRect().height);
    }
    _isScrolledIntoView(element, parent) {
        const elementRect = element.getBoundingClientRect();
        const parentRect = parent.getBoundingClientRect();
        return (elementRect.top >= 0) && (elementRect.bottom <= parentRect.height);
    }
    getTemplate(item) {
        const def = this._defs().find(d => {
            const whenValue = d.when();
            if (whenValue) {
                if (typeof whenValue === 'function') {
                    return whenValue(item);
                }
                return item[this.itemTypeProperty()] === whenValue;
            }
            return false;
        }) || this._defs().find(d => !d.when());
        return def?.template || null;
    }
    _scrollToActiveItem() {
        this._items().forEach((item) => {
            if (item.active) {
                let scrollContainer = this._elementRef.nativeElement.closest('.scrollable-content');
                const itemElement = item._hostElement.nativeElement;
                if (this._hasScroll(scrollContainer)) {
                    if (!this._isScrolledIntoView(itemElement, scrollContainer)) {
                        const parentRect = scrollContainer.getBoundingClientRect();
                        const elementRect = itemElement.getBoundingClientRect();
                        scrollContainer.scrollTop = elementRect.top - parentRect.height / 2;
                    }
                }
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNav, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: SidebarNav, isStandalone: true, selector: "ngs-sidebar-nav", inputs: { activeKey: { classPropertyName: "activeKey", publicName: "activeKey", isSignal: true, isRequired: false, transformFunction: null }, dataSource: { classPropertyName: "dataSource", publicName: "dataSource", isSignal: true, isRequired: false, transformFunction: null }, itemTypeProperty: { classPropertyName: "itemTypeProperty", publicName: "itemTypeProperty", isSignal: true, isRequired: false, transformFunction: null }, autoScrollToActiveItem: { classPropertyName: "autoScrollToActiveItem", publicName: "autoScrollToActiveItem", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemClicked: "itemClicked" }, host: { classAttribute: "ngs-sidebar-nav" }, providers: [
            {
                provide: SIDEBAR_NAVIGATION,
                useExisting: forwardRef(() => SidebarNav),
            },
            SidebarNavStore
        ], queries: [{ propertyName: "_items", predicate: SidebarNavItem, descendants: true, isSignal: true }, { propertyName: "_groups", predicate: SidebarNavGroup, descendants: true, isSignal: true }, { propertyName: "_defs", predicate: SidebarNavItemDefDirective, isSignal: true }], exportAs: ["ngsSidebarNav"], usesOnChanges: true, ngImport: i0, template: "@if (dataSource(); as data) {\n  @for (item of data; track item) {\n    <ng-container *ngTemplateOutlet=\"getTemplate(item); context: { $implicit: item }\" />\n  }\n} @else {\n  <ng-content/>\n}\n", styles: [":host{--ngs-sidebar-nav-bg: inherit;--ngs-sidebar-nav-items-gap: calc(var(--spacing, .25rem) * .5);--ngs-sidebar-nav-item-width: 100%;--ngs-sidebar-nav-item-bg: transparent;--ngs-sidebar-nav-item-height: calc(var(--spacing, .25rem) * 11);--ngs-sidebar-nav-item-padding: 0 calc(var(--spacing, .25rem) * 3);--ngs-sidebar-nav-item-font-size: var(--nav-item-font-size);--ngs-sidebar-nav-item-radius: var(--nav-item-radius);--ngs-sidebar-nav-item-border-width: 0;--ngs-sidebar-nav-item-border-color: transparent;--ngs-sidebar-nav-item-font-weight: 500;--ngs-sidebar-nav-item-color: var(--nav-item-color);--ngs-sidebar-nav-item-hover-bg: var(--nav-item-hover-bg);--ngs-sidebar-nav-item-active-bg: var(--nav-item-active-bg);--ngs-sidebar-nav-item-active-color: var(--nav-item-active-color);--ngs-sidebar-nav-item-icon-font-size: 1.5rem;--ngs-sidebar-nav-item-icon-color: var(--nav-item-icon-color);--ngs-sidebar-nav-group-arrow-color: var(--nav-item-icon-color);--ngs-sidebar-nav-item-icon-width: 24px;--ngs-sidebar-nav-item-hover-icon-color: var(--nav-item-hover-icon-color);--ngs-sidebar-nav-item-active-icon-color: var(--nav-item-active-icon-color);--ngs-sidebar-nav-item-icon-size: calc(var(--spacing, .25rem) * 6);--ngs-sidebar-nav-item-gap: calc(var(--spacing, .25rem) * 2.5);--ngs-sidebar-nav-item-has-icon-padding-start: calc(var(--spacing, .25rem) * 2.5);--ngs-sidebar-nav-heading-color: var(--color-neutral-400);--ngs-sidebar-nav-heading-font-size: .625rem;--ngs-sidebar-nav-heading-font-weight: 700;--ngs-sidebar-nav-heading-padding: 0 calc(var(--spacing, .25rem) * 3);--ngs-sidebar-nav-heading-margin-top: calc(var(--spacing, .25rem) * 6);--ngs-sidebar-nav-heading-margin-bottom: calc(var(--spacing, .25rem) * 2);--ngs-sidebar-nav-heading-after-margin: calc(var(--spacing, .25rem) * 8);--ngs-sidebar-nav-heading-text-transform: uppercase;--ngs-sidebar-nav-divider-height: 1px;--ngs-sidebar-nav-divider-bg: var(--color-outline-variant);--ngs-sidebar-nav-divider-margin: calc(var(--spacing, .25rem) * 6) 0;--ngs-sidebar-nav-group-toggle-has-icon-padding-end: calc(var(--spacing, .25rem) * 1.5);--ngs-sidebar-nav-group-toggle-icon-color: var(--color-on-surface-variant);--ngs-sidebar-nav-group-toggle-icon-position-end: calc(var(--spacing, .25rem) * 3);--ngs-sidebar-nav-group-toggle-icon-size: calc(var(--spacing, .25rem) * 4);--ngs-sidebar-nav-group-menu-padding-start: 0;--ngs-sidebar-nav-group-toggle-bg: transparent;--ngs-sidebar-nav-group-toggle-active-bg: var(--nav-item-active-bg);--ngs-sidebar-nav-group-toggle-active-color: var(--nav-item-active-color);--ngs-sidebar-nav-group-toggle-hover-icon-color: var(--nav-item-hover-icon-color);--ngs-sidebar-nav-group-toggle-active-icon-color: var(--nav-item-active-icon-color);--ngs-sidebar-nav-nested-item-bg: transparent;--ngs-sidebar-nav-nested-item-height: calc(var(--spacing, .25rem) * 11);--ngs-sidebar-nav-nested-item-padding: 0 calc(var(--spacing, .25rem) * 4);--ngs-sidebar-nav-nested-item-margin: 0 0 0 52px;--ngs-sidebar-nav-nested-item-border-radius: 0;--ngs-sidebar-nav-nested-item-color: var(--nav-item-color);--ngs-sidebar-nav-nested-item-hover-bg: var(--nav-item-hover-bg);--ngs-sidebar-nav-nested-item-active-bg: var(--nav-item-active-bg);--ngs-sidebar-nav-nested-item-hover-color: var(--nav-item-hover-color);--ngs-sidebar-nav-nested-item-active-color: var(--nav-item-active-color);--ngs-sidebar-nav-nested-item-indicator-width: calc(var(--spacing, .25rem) * 3.5);--ngs-sidebar-nav-nested-item-indicator-height: calc(var(--spacing, .25rem) * .5);--ngs-sidebar-nav-nested-item-indicator-bg: var(--color-outline);--ngs-sidebar-nav-nested-item-indicator-position-start: calc(calc(var(--spacing, .25rem) * 2.5) * -1);--ngs-sidebar-nav-group-active-bg: transparent;--ngs-sidebar-nav-group-border-radius: 0;--ngs-sidebar-nav-group-tree-lines-color: var(--color-subtle);--ngs-sidebar-nav-heading-text-align: start;flex-grow:1;overflow-x:hidden;overflow-y:auto;display:flex;flex-direction:column;gap:var(--ngs-sidebar-nav-items-gap);background:var(--ngs-sidebar-nav-bg)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNav, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-nav', exportAs: 'ngsSidebarNav', changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, imports: [
                        NgTemplateOutlet
                    ], providers: [
                        {
                            provide: SIDEBAR_NAVIGATION,
                            useExisting: forwardRef(() => SidebarNav),
                        },
                        SidebarNavStore
                    ], host: {
                        'class': 'ngs-sidebar-nav',
                    }, template: "@if (dataSource(); as data) {\n  @for (item of data; track item) {\n    <ng-container *ngTemplateOutlet=\"getTemplate(item); context: { $implicit: item }\" />\n  }\n} @else {\n  <ng-content/>\n}\n", styles: [":host{--ngs-sidebar-nav-bg: inherit;--ngs-sidebar-nav-items-gap: calc(var(--spacing, .25rem) * .5);--ngs-sidebar-nav-item-width: 100%;--ngs-sidebar-nav-item-bg: transparent;--ngs-sidebar-nav-item-height: calc(var(--spacing, .25rem) * 11);--ngs-sidebar-nav-item-padding: 0 calc(var(--spacing, .25rem) * 3);--ngs-sidebar-nav-item-font-size: var(--nav-item-font-size);--ngs-sidebar-nav-item-radius: var(--nav-item-radius);--ngs-sidebar-nav-item-border-width: 0;--ngs-sidebar-nav-item-border-color: transparent;--ngs-sidebar-nav-item-font-weight: 500;--ngs-sidebar-nav-item-color: var(--nav-item-color);--ngs-sidebar-nav-item-hover-bg: var(--nav-item-hover-bg);--ngs-sidebar-nav-item-active-bg: var(--nav-item-active-bg);--ngs-sidebar-nav-item-active-color: var(--nav-item-active-color);--ngs-sidebar-nav-item-icon-font-size: 1.5rem;--ngs-sidebar-nav-item-icon-color: var(--nav-item-icon-color);--ngs-sidebar-nav-group-arrow-color: var(--nav-item-icon-color);--ngs-sidebar-nav-item-icon-width: 24px;--ngs-sidebar-nav-item-hover-icon-color: var(--nav-item-hover-icon-color);--ngs-sidebar-nav-item-active-icon-color: var(--nav-item-active-icon-color);--ngs-sidebar-nav-item-icon-size: calc(var(--spacing, .25rem) * 6);--ngs-sidebar-nav-item-gap: calc(var(--spacing, .25rem) * 2.5);--ngs-sidebar-nav-item-has-icon-padding-start: calc(var(--spacing, .25rem) * 2.5);--ngs-sidebar-nav-heading-color: var(--color-neutral-400);--ngs-sidebar-nav-heading-font-size: .625rem;--ngs-sidebar-nav-heading-font-weight: 700;--ngs-sidebar-nav-heading-padding: 0 calc(var(--spacing, .25rem) * 3);--ngs-sidebar-nav-heading-margin-top: calc(var(--spacing, .25rem) * 6);--ngs-sidebar-nav-heading-margin-bottom: calc(var(--spacing, .25rem) * 2);--ngs-sidebar-nav-heading-after-margin: calc(var(--spacing, .25rem) * 8);--ngs-sidebar-nav-heading-text-transform: uppercase;--ngs-sidebar-nav-divider-height: 1px;--ngs-sidebar-nav-divider-bg: var(--color-outline-variant);--ngs-sidebar-nav-divider-margin: calc(var(--spacing, .25rem) * 6) 0;--ngs-sidebar-nav-group-toggle-has-icon-padding-end: calc(var(--spacing, .25rem) * 1.5);--ngs-sidebar-nav-group-toggle-icon-color: var(--color-on-surface-variant);--ngs-sidebar-nav-group-toggle-icon-position-end: calc(var(--spacing, .25rem) * 3);--ngs-sidebar-nav-group-toggle-icon-size: calc(var(--spacing, .25rem) * 4);--ngs-sidebar-nav-group-menu-padding-start: 0;--ngs-sidebar-nav-group-toggle-bg: transparent;--ngs-sidebar-nav-group-toggle-active-bg: var(--nav-item-active-bg);--ngs-sidebar-nav-group-toggle-active-color: var(--nav-item-active-color);--ngs-sidebar-nav-group-toggle-hover-icon-color: var(--nav-item-hover-icon-color);--ngs-sidebar-nav-group-toggle-active-icon-color: var(--nav-item-active-icon-color);--ngs-sidebar-nav-nested-item-bg: transparent;--ngs-sidebar-nav-nested-item-height: calc(var(--spacing, .25rem) * 11);--ngs-sidebar-nav-nested-item-padding: 0 calc(var(--spacing, .25rem) * 4);--ngs-sidebar-nav-nested-item-margin: 0 0 0 52px;--ngs-sidebar-nav-nested-item-border-radius: 0;--ngs-sidebar-nav-nested-item-color: var(--nav-item-color);--ngs-sidebar-nav-nested-item-hover-bg: var(--nav-item-hover-bg);--ngs-sidebar-nav-nested-item-active-bg: var(--nav-item-active-bg);--ngs-sidebar-nav-nested-item-hover-color: var(--nav-item-hover-color);--ngs-sidebar-nav-nested-item-active-color: var(--nav-item-active-color);--ngs-sidebar-nav-nested-item-indicator-width: calc(var(--spacing, .25rem) * 3.5);--ngs-sidebar-nav-nested-item-indicator-height: calc(var(--spacing, .25rem) * .5);--ngs-sidebar-nav-nested-item-indicator-bg: var(--color-outline);--ngs-sidebar-nav-nested-item-indicator-position-start: calc(calc(var(--spacing, .25rem) * 2.5) * -1);--ngs-sidebar-nav-group-active-bg: transparent;--ngs-sidebar-nav-group-border-radius: 0;--ngs-sidebar-nav-group-tree-lines-color: var(--color-subtle);--ngs-sidebar-nav-heading-text-align: start;flex-grow:1;overflow-x:hidden;overflow-y:auto;display:flex;flex-direction:column;gap:var(--ngs-sidebar-nav-items-gap);background:var(--ngs-sidebar-nav-bg)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { _items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SidebarNavItem), { ...{ descendants: true }, isSignal: true }] }], _groups: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SidebarNavGroup), { ...{ descendants: true }, isSignal: true }] }], _defs: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => SidebarNavItemDefDirective), { isSignal: true }] }], activeKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeKey", required: false }] }], dataSource: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataSource", required: false }] }], itemTypeProperty: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTypeProperty", required: false }] }], autoScrollToActiveItem: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoScrollToActiveItem", required: false }] }], itemClicked: [{ type: i0.Output, args: ["itemClicked"] }] } });

class SidebarFooter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarFooter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidebarFooter, isStandalone: true, selector: "ngs-sidebar-footer", host: { classAttribute: "ngs-sidebar-footer" }, exportAs: ["ngsSidebarFooter"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarFooter, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-footer', exportAs: 'ngsSidebarFooter', host: {
                        'class': 'ngs-sidebar-footer',
                    }, template: "<ng-content/>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SidebarNavHeading {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavHeading, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidebarNavHeading, isStandalone: true, selector: "ngs-sidebar-nav-heading", host: { classAttribute: "ngs-sidebar-nav-heading" }, exportAs: ["ngsSidebarNavHeading"], ngImport: i0, template: "<div class=\"line\"></div>\n<div class=\"content\">\n  <ng-content/>\n</div>\n", styles: [":host{display:block;text-transform:var(--ngs-sidebar-nav-heading-text-transform);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;min-width:0;color:var(--ngs-sidebar-nav-heading-color);font-size:var(--ngs-sidebar-nav-heading-font-size);font-weight:var(--ngs-sidebar-nav-heading-font-weight);padding:var(--ngs-sidebar-nav-heading-padding);margin-top:var(--ngs-sidebar-nav-heading-margin-top);margin-bottom:var(--ngs-sidebar-nav-heading-margin-bottom);text-align:var(--ngs-sidebar-nav-heading-text-align);height:calc(var(--spacing, .25rem) * 6);align-items:center;position:relative}:host:first-child{margin-top:0}:host .content{overflow:hidden;text-overflow:ellipsis}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavHeading, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-nav-heading', exportAs: 'ngsSidebarNavHeading', imports: [], host: {
                        class: 'ngs-sidebar-nav-heading',
                    }, template: "<div class=\"line\"></div>\n<div class=\"content\">\n  <ng-content/>\n</div>\n", styles: [":host{display:block;text-transform:var(--ngs-sidebar-nav-heading-text-transform);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;min-width:0;color:var(--ngs-sidebar-nav-heading-color);font-size:var(--ngs-sidebar-nav-heading-font-size);font-weight:var(--ngs-sidebar-nav-heading-font-weight);padding:var(--ngs-sidebar-nav-heading-padding);margin-top:var(--ngs-sidebar-nav-heading-margin-top);margin-bottom:var(--ngs-sidebar-nav-heading-margin-bottom);text-align:var(--ngs-sidebar-nav-heading-text-align);height:calc(var(--spacing, .25rem) * 6);align-items:center;position:relative}:host:first-child{margin-top:0}:host .content{overflow:hidden;text-overflow:ellipsis}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SidebarDivider {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarDivider, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: SidebarDivider, isStandalone: true, selector: "ngs-sidebar-divider", ngImport: i0, template: "<p>sidebar-divider works!</p>\n", styles: [":host{display:block;height:var(--ngs-sidebar-divider-height);background:var(--ngs-sidebar-divider-bg);margin:var(--ngs-sidebar-divider-margin)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarDivider, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-sidebar-divider', imports: [], template: "<p>sidebar-divider works!</p>\n", styles: [":host{display:block;height:var(--ngs-sidebar-divider-height);background:var(--ngs-sidebar-divider-bg);margin:var(--ngs-sidebar-divider-margin)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class SidebarNavItemIconDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItemIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SidebarNavItemIconDirective, isStandalone: true, selector: "[ngsSidebarNavItemIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItemIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSidebarNavItemIcon]'
                }]
        }] });

class SidebarNavItemBadgeDirective {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItemBadgeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SidebarNavItemBadgeDirective, isStandalone: true, selector: "[ngsSidebarNavItemBadge]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavItemBadgeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSidebarNavItemBadge]'
                }]
        }], ctorParameters: () => [] });

class SidebarNavGroupToggleIconDirective {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroupToggleIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: SidebarNavGroupToggleIconDirective, isStandalone: true, selector: "[ngsSidebarNavGroupToggleIcon]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SidebarNavGroupToggleIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSidebarNavGroupToggleIcon]'
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { SIDEBAR_NAVIGATION, SIDEBAR_NAVIGATION_GROUP, Sidebar, SidebarBody, SidebarDivider, SidebarFooter, SidebarHeader, SidebarNav, SidebarNavGroup, SidebarNavGroupMenu, SidebarNavGroupToggle, SidebarNavGroupToggleIconDirective, SidebarNavHeading, SidebarNavItem, SidebarNavItemBadgeDirective, SidebarNavItemDefDirective, SidebarNavItemIconDirective, SidebarNavItemInterface };
//# sourceMappingURL=ngstarter-components-sidebar.mjs.map
