import * as i0 from '@angular/core';
import { EventEmitter, inject, signal, Component, DestroyRef, Injectable } from '@angular/core';
import { DIALOG_DATA } from '@angular/cdk/dialog';
import { ReactiveFormsModule } from '@angular/forms';
import { Button } from '@ngstarter/components/button';
import { DialogClose, DialogActions, DialogContent, DialogTitle, Dialog } from '@ngstarter/components/dialog';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

class ConfirmRef {
    canceled = new EventEmitter();
    confirmed = new EventEmitter();
    closed = new EventEmitter();
    close() {
        this.closed.emit();
    }
    cancel() {
        this.canceled.emit();
        this.close();
    }
    confirm() {
        this.confirmed.emit();
        this.close();
    }
}

class Confirm {
    _data = inject(DIALOG_DATA);
    title = signal(this._data.title, ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    description = signal(this._data.description, ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Confirm, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: Confirm, isStandalone: true, selector: "ngs-confirm", host: { classAttribute: "ngs-confirm" }, exportAs: ["ngsConfirm"], ngImport: i0, template: "<h3 ngs-dialog-title>{{ title() }}</h3>\n<ngs-dialog-content>\n  {{ description() }}\n</ngs-dialog-content>\n<ngs-dialog-actions align=\"end\">\n  <button ngsButton [ngs-dialog-close]=\"false\">Cancel</button>\n  <button ngsButton=\"filled\" [ngs-dialog-close]=\"true\">Confirm</button>\n</ngs-dialog-actions>\n", styles: [":host{display:block;width:500px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "directive", type: DialogClose, selector: "[ngs-dialog-close], [ngsDialogClose]", inputs: ["ngs-dialog-close", "ngsDialogClose", "ariaLabel", "type"], exportAs: ["ngsDialogClose"] }, { kind: "component", type: DialogActions, selector: "ngs-dialog-actions, [ngs-dialog-actions], [ngsDialogActions]", inputs: ["align"] }, { kind: "component", type: DialogContent, selector: "ngs-dialog-content,[ngs-dialog-content],[ngsDialogContent]" }, { kind: "component", type: DialogTitle, selector: "ngs-dialog-title, [ngs-dialog-title], [ngsDialogTitle]", inputs: ["id"], exportAs: ["ngsDialogTitle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Confirm, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-confirm', exportAs: 'ngsConfirm', imports: [
                        ReactiveFormsModule,
                        Button,
                        DialogClose,
                        DialogActions,
                        DialogContent,
                        DialogTitle
                    ], host: {
                        'class': 'ngs-confirm'
                    }, template: "<h3 ngs-dialog-title>{{ title() }}</h3>\n<ngs-dialog-content>\n  {{ description() }}\n</ngs-dialog-content>\n<ngs-dialog-actions align=\"end\">\n  <button ngsButton [ngs-dialog-close]=\"false\">Cancel</button>\n  <button ngsButton=\"filled\" [ngs-dialog-close]=\"true\">Confirm</button>\n</ngs-dialog-actions>\n", styles: [":host{display:block;width:500px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class ConfirmManager {
    _dialog = inject(Dialog);
    _destroyRef = inject(DestroyRef);
    open(options) {
        const confirmRef = new ConfirmRef();
        const dialogRef = this._dialog.open(Confirm, {
            data: options,
            closeOnNavigation: true,
            disableClose: true
        });
        dialogRef
            .afterClosed()
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe((isConfirmed) => {
            if (isConfirmed) {
                confirmRef.confirm();
            }
            else {
                confirmRef.cancel();
            }
        });
        return confirmRef;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ConfirmManager, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ConfirmManager, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ConfirmManager, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Confirm, ConfirmManager, ConfirmRef };
//# sourceMappingURL=ngstarter-components-confirm.mjs.map
