import * as i0 from '@angular/core';
import { Component, input, booleanAttribute, contentChild, InjectionToken, inject, ElementRef, forwardRef } from '@angular/core';
import * as i1 from '@angular/cdk/scrolling';
import { CdkScrollable } from '@angular/cdk/scrolling';

class PanelSidebar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelSidebar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: PanelSidebar, isStandalone: true, selector: "ngs-panel-sidebar", host: { classAttribute: "ngs-panel-sidebar" }, ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;overflow:hidden;position:relative}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelSidebar, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel-sidebar', imports: [], host: {
                        'class': 'ngs-panel-sidebar'
                    }, template: "<ng-content/>\n", styles: [":host{display:block;overflow:hidden;position:relative}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class PanelAside {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelAside, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: PanelAside, isStandalone: true, selector: "ngs-panel-aside", host: { classAttribute: "ngs-panel-aside" }, ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;overflow:hidden;position:relative}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelAside, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel-aside', imports: [], host: {
                        'class': 'ngs-panel-aside'
                    }, template: "<ng-content/>\n", styles: [":host{display:block;overflow:hidden;position:relative}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class PanelHeader {
    autoHeight = input(false, { ...(ngDevMode ? { debugName: "autoHeight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: PanelHeader, isStandalone: true, selector: "ngs-panel-header", inputs: { autoHeight: { classPropertyName: "autoHeight", publicName: "autoHeight", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-auto-height": "autoHeight()" }, classAttribute: "ngs-panel-header" }, exportAs: ["ngsPanelHeader"], ngImport: i0, template: "<ng-content />\n", styles: [":host{--ngs-panel-header-height: calc(var(--spacing, .25rem) * 14);flex:none;grid-area:header}:host:not([class*=h-]):not(.is-auto-height){height:var(--ngs-panel-header-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel-header', exportAs: 'ngsPanelHeader', host: {
                        'class': 'ngs-panel-header',
                        '[class.is-auto-height]': 'autoHeight()'
                    }, template: "<ng-content />\n", styles: [":host{--ngs-panel-header-height: calc(var(--spacing, .25rem) * 14);flex:none;grid-area:header}:host:not([class*=h-]):not(.is-auto-height){height:var(--ngs-panel-header-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { autoHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHeight", required: false }] }] } });

class PanelSubheader {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelSubheader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: PanelSubheader, isStandalone: true, selector: "ngs-panel-subheader", host: { classAttribute: "ngs-panel-subheader" }, exportAs: ["ngsPanelSubheader"], ngImport: i0, template: "<p>panel-subheader works!</p>\n", styles: [":host{--ngs-panel-subheader-height: calc(var(--spacing, .25rem) * 14);flex:none;grid-area:subheader}:host:not([class*=h-]):not(.is-auto-height){height:var(--ngs-panel-subheader-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelSubheader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel-subheader', exportAs: 'ngsPanelSubheader', imports: [], host: {
                        'class': 'ngs-panel-subheader'
                    }, template: "<p>panel-subheader works!</p>\n", styles: [":host{--ngs-panel-subheader-height: calc(var(--spacing, .25rem) * 14);flex:none;grid-area:subheader}:host:not([class*=h-]):not(.is-auto-height){height:var(--ngs-panel-subheader-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class PanelFooter {
    autoHeight = input(false, { ...(ngDevMode ? { debugName: "autoHeight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelFooter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: PanelFooter, isStandalone: true, selector: "ngs-panel-footer", inputs: { autoHeight: { classPropertyName: "autoHeight", publicName: "autoHeight", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-auto-height": "autoHeight()" }, classAttribute: "ngs-panel-footer" }, exportAs: ["ngsPanelFooter"], ngImport: i0, template: "<ng-content />\n", styles: [":host{--ngs-panel-footer-height: calc(var(--spacing, .25rem) * 14);flex:none;grid-area:footer}:host:not([class*=h-]):not(.is-auto-height){height:var(--ngs-panel-footer-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelFooter, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel-footer', exportAs: 'ngsPanelFooter', host: {
                        'class': 'ngs-panel-footer',
                        '[class.is-auto-height]': 'autoHeight()'
                    }, template: "<ng-content />\n", styles: [":host{--ngs-panel-footer-height: calc(var(--spacing, .25rem) * 14);flex:none;grid-area:footer}:host:not([class*=h-]):not(.is-auto-height){height:var(--ngs-panel-footer-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { autoHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHeight", required: false }] }] } });

class Panel {
    header = contentChild(PanelHeader, ...(ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []));
    subheader = contentChild(PanelSubheader, ...(ngDevMode ? [{ debugName: "subheader" }] : /* istanbul ignore next */ []));
    sidebar = contentChild(PanelSidebar, ...(ngDevMode ? [{ debugName: "sidebar" }] : /* istanbul ignore next */ []));
    aside = contentChild(PanelAside, ...(ngDevMode ? [{ debugName: "aside" }] : /* istanbul ignore next */ []));
    footer = contentChild(PanelFooter, ...(ngDevMode ? [{ debugName: "footer" }] : /* istanbul ignore next */ []));
    absolute = input(false, { ...(ngDevMode ? { debugName: "absolute" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Panel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: Panel, isStandalone: true, selector: "ngs-panel", inputs: { absolute: { classPropertyName: "absolute", publicName: "absolute", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-absolute": "absolute()", "class.has-header": "header()", "class.has-subheader": "subheader()", "class.has-sidebar": "sidebar()", "class.has-aside": "aside()", "class.has-footer": "footer()" }, classAttribute: "ngs-panel" }, queries: [{ propertyName: "header", first: true, predicate: PanelHeader, descendants: true, isSignal: true }, { propertyName: "subheader", first: true, predicate: PanelSubheader, descendants: true, isSignal: true }, { propertyName: "sidebar", first: true, predicate: PanelSidebar, descendants: true, isSignal: true }, { propertyName: "aside", first: true, predicate: PanelAside, descendants: true, isSignal: true }, { propertyName: "footer", first: true, predicate: PanelFooter, descendants: true, isSignal: true }], exportAs: ["ngsPanel"], ngImport: i0, template: "<ng-content select=\"ngs-panel-header\"/>\n<ng-content select=\"ngs-panel-subheader\"/>\n<ng-content select=\"ngs-panel-sidebar\"/>\n<ng-content select=\"ngs-panel-content\"/>\n<ng-content select=\"ngs-panel-aside\"/>\n<ng-content select=\"ngs-panel-footer\"/>\n", styles: [":host{display:grid;grid-template-areas:\"header header header\" \"subheader subheader subheader\" \"sidebar body aside\" \"footer footer footer\";grid-template-rows:0 0 1fr 0;grid-template-columns:0 1fr 0}:host.has-header{grid-template-rows:auto 0 1fr 0}:host.has-header.has-subheader{grid-template-rows:auto auto 1fr 0}:host.has-header.has-subheader.has-footer{grid-template-rows:auto auto 1fr auto}:host.has-header.has-footer{grid-template-rows:auto 0 1fr auto}:host.has-subheader:not(.has-header){grid-template-rows:0 auto 1fr 0}:host.has-subheader:not(.has-header).has-footer{grid-template-rows:0 auto 1fr auto}:host:not(.has-header):not(.has-subheader).has-footer{grid-template-rows:0 0 1fr auto}:host.has-sidebar{grid-template-columns:auto 1fr 0}:host.has-sidebar.has-aside{grid-template-columns:auto 1fr auto}:host:not(.has-sidebar).has-aside{grid-template-columns:0 1fr auto}:host:not([class*=w-]){width:100%}:host:not([class*=h-]){height:100%}:host.is-absolute{position:absolute;inset:0}:host ::ng-deep .ngs-panel-header{grid-area:header}:host ::ng-deep .ngs-panel-subheader{grid-area:subheader}:host ::ng-deep .ngs-panel-sidebar{grid-area:sidebar}:host ::ng-deep .ngs-panel-content{grid-area:body;min-height:0}:host ::ng-deep .ngs-panel-aside{grid-area:aside}:host ::ng-deep .ngs-panel-footer{grid-area:footer}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Panel, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel', exportAs: 'ngsPanel', host: {
                        'class': 'ngs-panel',
                        '[class.is-absolute]': 'absolute()',
                        '[class.has-header]': 'header()',
                        '[class.has-subheader]': 'subheader()',
                        '[class.has-sidebar]': 'sidebar()',
                        '[class.has-aside]': 'aside()',
                        '[class.has-footer]': 'footer()'
                    }, template: "<ng-content select=\"ngs-panel-header\"/>\n<ng-content select=\"ngs-panel-subheader\"/>\n<ng-content select=\"ngs-panel-sidebar\"/>\n<ng-content select=\"ngs-panel-content\"/>\n<ng-content select=\"ngs-panel-aside\"/>\n<ng-content select=\"ngs-panel-footer\"/>\n", styles: [":host{display:grid;grid-template-areas:\"header header header\" \"subheader subheader subheader\" \"sidebar body aside\" \"footer footer footer\";grid-template-rows:0 0 1fr 0;grid-template-columns:0 1fr 0}:host.has-header{grid-template-rows:auto 0 1fr 0}:host.has-header.has-subheader{grid-template-rows:auto auto 1fr 0}:host.has-header.has-subheader.has-footer{grid-template-rows:auto auto 1fr auto}:host.has-header.has-footer{grid-template-rows:auto 0 1fr auto}:host.has-subheader:not(.has-header){grid-template-rows:0 auto 1fr 0}:host.has-subheader:not(.has-header).has-footer{grid-template-rows:0 auto 1fr auto}:host:not(.has-header):not(.has-subheader).has-footer{grid-template-rows:0 0 1fr auto}:host.has-sidebar{grid-template-columns:auto 1fr 0}:host.has-sidebar.has-aside{grid-template-columns:auto 1fr auto}:host:not(.has-sidebar).has-aside{grid-template-columns:0 1fr auto}:host:not([class*=w-]){width:100%}:host:not([class*=h-]){height:100%}:host.is-absolute{position:absolute;inset:0}:host ::ng-deep .ngs-panel-header{grid-area:header}:host ::ng-deep .ngs-panel-subheader{grid-area:subheader}:host ::ng-deep .ngs-panel-sidebar{grid-area:sidebar}:host ::ng-deep .ngs-panel-content{grid-area:body;min-height:0}:host ::ng-deep .ngs-panel-aside{grid-area:aside}:host ::ng-deep .ngs-panel-footer{grid-area:footer}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { header: [{ type: i0.ContentChild, args: [i0.forwardRef(() => PanelHeader), { isSignal: true }] }], subheader: [{ type: i0.ContentChild, args: [i0.forwardRef(() => PanelSubheader), { isSignal: true }] }], sidebar: [{ type: i0.ContentChild, args: [i0.forwardRef(() => PanelSidebar), { isSignal: true }] }], aside: [{ type: i0.ContentChild, args: [i0.forwardRef(() => PanelAside), { isSignal: true }] }], footer: [{ type: i0.ContentChild, args: [i0.forwardRef(() => PanelFooter), { isSignal: true }] }], absolute: [{ type: i0.Input, args: [{ isSignal: true, alias: "absolute", required: false }] }] } });

const PANEL_CONTENT = new InjectionToken('PANEL_CONTENT');

class PanelContent {
    elementRef = inject(ElementRef);
    scrollable = inject(CdkScrollable);
    scrollContainer() {
        return this.elementRef.nativeElement;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: PanelContent, isStandalone: true, selector: "ngs-panel-content", host: { classAttribute: "ngs-panel-content" }, providers: [
            {
                provide: PANEL_CONTENT,
                useExisting: forwardRef(() => PanelContent)
            }
        ], exportAs: ["ngsPanelContent"], hostDirectives: [{ directive: i1.CdkScrollable }], ngImport: i0, template: "<ng-content/>\n", styles: [":host{overflow:auto;position:relative}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PanelContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-panel-content', exportAs: 'ngsPanelContent', hostDirectives: [
                        CdkScrollable
                    ], providers: [
                        {
                            provide: PANEL_CONTENT,
                            useExisting: forwardRef(() => PanelContent)
                        }
                    ], host: {
                        'class': 'ngs-panel-content'
                    }, template: "<ng-content/>\n", styles: [":host{overflow:auto;position:relative}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PANEL_CONTENT, Panel, PanelAside, PanelContent, PanelFooter, PanelHeader, PanelSidebar };
//# sourceMappingURL=ngstarter-components-panel.mjs.map
