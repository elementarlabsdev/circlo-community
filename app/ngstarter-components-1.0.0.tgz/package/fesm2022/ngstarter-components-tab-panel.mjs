import * as i0 from '@angular/core';
import { EventEmitter, Injectable, inject, DestroyRef, input, booleanAttribute, output, Component, InjectionToken, TemplateRef, ViewContainerRef, Directive } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i1 from '@ngstarter/components/core';
import { Ripple } from '@ngstarter/components/core';

class TabPanelApiService {
    _selectionModel = new SelectionModel(false);
    itemIdChanged = new EventEmitter();
    activate(id, emitEvent = true) {
        this._selectionModel.select(id);
        if (emitEvent) {
            this.itemIdChanged.emit(id);
        }
    }
    isActive(id) {
        return this._selectionModel.isSelected(id);
    }
    hasActive() {
        return this._selectionModel.hasValue();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelApiService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelApiService, decorators: [{
            type: Injectable
        }] });

class TabPanel {
    _destroyRef = inject(DestroyRef);
    api = inject(TabPanelApiService);
    hideContentIfTabNotSelected = input(false, { ...(ngDevMode ? { debugName: "hideContentIfTabNotSelected" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    activeItemId = input(...(ngDevMode ? [undefined, { debugName: "activeItemId" }] : /* istanbul ignore next */ []));
    compact = input(false, { ...(ngDevMode ? { debugName: "compact" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    itemIdChanged = output();
    ngOnInit() {
        this.api
            .itemIdChanged
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe(() => {
            this.itemIdChanged.emit();
        });
    }
    ngOnChanges(changes) {
        if (changes['activeItemId']) {
            this.api.activate(changes['activeItemId'].currentValue);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: TabPanel, isStandalone: true, selector: "ngs-tab-panel", inputs: { hideContentIfTabNotSelected: { classPropertyName: "hideContentIfTabNotSelected", publicName: "hideContentIfTabNotSelected", isSignal: true, isRequired: false, transformFunction: null }, activeItemId: { classPropertyName: "activeItemId", publicName: "activeItemId", isSignal: true, isRequired: false, transformFunction: null }, compact: { classPropertyName: "compact", publicName: "compact", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemIdChanged: "itemIdChanged" }, host: { properties: { "class.is-hide-content-if-tab-not-selected": "hideContentIfTabNotSelected()", "class.is-compact": "compact()" }, classAttribute: "ngs-tab-panel" }, providers: [
            TabPanelApiService
        ], exportAs: ["ngsTabPanel"], usesOnChanges: true, ngImport: i0, template: "<div class=\"panel\">\n  <ng-content select=\"ngs-tab-panel-header\"/>\n  <ng-content select=\"ngs-tab-panel-content\"/>\n  <ng-content select=\"ngs-tab-panel-footer\"/>\n</div>\n<ng-content select=\"ngs-tab-panel-aside\"/>\n", styles: [":host{--ngs-tab-panel-width: calc(var(--spacing, .25rem) * 20);--ngs-tab-panel-item-width: calc(var(--spacing, .25rem) * 15);--ngs-tab-panel-item-height: calc(var(--spacing, .25rem) * 15);--ngs-tab-panel-item-padding: calc(var(--spacing, .25rem) * 2);--ngs-tab-panel-item-gap: calc(var(--spacing, .25rem) * 1);--ngs-tab-panel-item-color: var(--nav-item-color);--ngs-tab-panel-item-hover-bg: var(--nav-item-hover-bg);--ngs-tab-panel-item-hover-color: var(--nav-item-hover-color);--ngs-tab-panel-item-active-bg: var(--nav-item-active-bg);--ngs-tab-panel-item-active-color: var(--nav-item-active-color);--ngs-tab-panel-item-border-radius: .75rem;--ngs-tab-panel-aside-width: calc(var(--spacing, .25rem) * 75);--ngs-tab-panel-nav-padding: 0;--ngs-tab-panel-nav-gap: calc(var(--spacing, .25rem) * 3);--ngs-tab-panel-item-text-font-size: .75rem;--ngs-tab-panel-item-icon-font-size: 1.5rem;--ngs-tab-panel-compact-width: calc(var(--spacing, .25rem) * 14);--ngs-tab-panel-compact-item-width: calc(var(--spacing, .25rem) * 10);--ngs-tab-panel-compact-item-height: calc(var(--spacing, .25rem) * 10);display:flex;width:min-content;align-items:stretch}:host .panel{display:flex;flex-direction:column;width:var(--ngs-tab-panel-width);flex:none}:host.is-compact .panel{width:var(--ngs-tab-panel-compact-width)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanel, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel', exportAs: 'ngsTabPanel', providers: [
                        TabPanelApiService
                    ], host: {
                        'class': 'ngs-tab-panel',
                        '[class.is-hide-content-if-tab-not-selected]': 'hideContentIfTabNotSelected()',
                        '[class.is-compact]': 'compact()',
                    }, template: "<div class=\"panel\">\n  <ng-content select=\"ngs-tab-panel-header\"/>\n  <ng-content select=\"ngs-tab-panel-content\"/>\n  <ng-content select=\"ngs-tab-panel-footer\"/>\n</div>\n<ng-content select=\"ngs-tab-panel-aside\"/>\n", styles: [":host{--ngs-tab-panel-width: calc(var(--spacing, .25rem) * 20);--ngs-tab-panel-item-width: calc(var(--spacing, .25rem) * 15);--ngs-tab-panel-item-height: calc(var(--spacing, .25rem) * 15);--ngs-tab-panel-item-padding: calc(var(--spacing, .25rem) * 2);--ngs-tab-panel-item-gap: calc(var(--spacing, .25rem) * 1);--ngs-tab-panel-item-color: var(--nav-item-color);--ngs-tab-panel-item-hover-bg: var(--nav-item-hover-bg);--ngs-tab-panel-item-hover-color: var(--nav-item-hover-color);--ngs-tab-panel-item-active-bg: var(--nav-item-active-bg);--ngs-tab-panel-item-active-color: var(--nav-item-active-color);--ngs-tab-panel-item-border-radius: .75rem;--ngs-tab-panel-aside-width: calc(var(--spacing, .25rem) * 75);--ngs-tab-panel-nav-padding: 0;--ngs-tab-panel-nav-gap: calc(var(--spacing, .25rem) * 3);--ngs-tab-panel-item-text-font-size: .75rem;--ngs-tab-panel-item-icon-font-size: 1.5rem;--ngs-tab-panel-compact-width: calc(var(--spacing, .25rem) * 14);--ngs-tab-panel-compact-item-width: calc(var(--spacing, .25rem) * 10);--ngs-tab-panel-compact-item-height: calc(var(--spacing, .25rem) * 10);display:flex;width:min-content;align-items:stretch}:host .panel{display:flex;flex-direction:column;width:var(--ngs-tab-panel-width);flex:none}:host.is-compact .panel{width:var(--ngs-tab-panel-compact-width)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { hideContentIfTabNotSelected: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideContentIfTabNotSelected", required: false }] }], activeItemId: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItemId", required: false }] }], compact: [{ type: i0.Input, args: [{ isSignal: true, alias: "compact", required: false }] }], itemIdChanged: [{ type: i0.Output, args: ["itemIdChanged"] }] } });

class TabPanelHeader {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelHeader, isStandalone: true, selector: "ngs-tab-panel-header", host: { classAttribute: "ngs-tab-panel-header" }, exportAs: ["ngsTabPanelHeader"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-header', exportAs: 'ngsTabPanelHeader', host: {
                        'class': 'ngs-tab-panel-header'
                    }, template: "<ng-content/>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TabPanelFooter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelFooter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelFooter, isStandalone: true, selector: "ngs-tab-panel-footer", host: { classAttribute: "ngs-tab-panel-footer" }, exportAs: ["ngsTabPanelFooter"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelFooter, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-footer', exportAs: 'ngsTabPanelFooter', host: {
                        'class': 'ngs-tab-panel-footer'
                    }, template: "<ng-content/>\n", styles: [":host{display:block}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

const TAB_PANEL_NAV = new InjectionToken('TAB_PANEL_NAV');
const TAB_PANEL_ASIDE = new InjectionToken('TAB_PANEL_ASIDE');

class TabPanelItem {
    api = inject(TabPanelApiService);
    _nav = inject(TAB_PANEL_NAV, { optional: true });
    for = input(this._nav ? this._nav.nextId++ : null, ...(ngDevMode ? [{ debugName: "for" }] : /* istanbul ignore next */ []));
    _handleClick() {
        if (!this.for()) {
            return;
        }
        this.api.activate(this.for());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: TabPanelItem, isStandalone: true, selector: "ngs-tab-panel-item", inputs: { for: { classPropertyName: "for", publicName: "for", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_handleClick()" }, properties: { "class.is-active": "api.isActive(this.for())" }, classAttribute: "ngs-tab-panel-item" }, exportAs: ["ngsTabPanelItem"], hostDirectives: [{ directive: i1.Ripple }], ngImport: i0, template: "<div class=\"icon\">\n  <ng-content select=\"[ngsTabPanelItemIcon]\"/>\n</div>\n<div class=\"text\">\n  <ng-content/>\n</div>\n", styles: [":host{display:flex;flex-direction:column;cursor:pointer;align-items:center;justify-content:center;flex:none;-webkit-user-select:none;user-select:none;width:var(--ngs-tab-panel-item-width);height:var(--ngs-tab-panel-item-height);padding:var(--ngs-tab-panel-item-padding);border-radius:var(--ngs-tab-panel-item-border-radius);color:var(--ngs-tab-panel-item-color);gap:var(--ngs-tab-panel-item-gap)}:host:not(.is-active):hover{background:var(--ngs-tab-panel-item-hover-bg);color:var(--ngs-tab-panel-item-hover-color)}:host.is-active{background:var(--ngs-tab-panel-item-active-bg);color:var(--ngs-tab-panel-item-active-color)}:host .icon{line-height:0;display:inline-block}:host .icon:empty{display:none}:host .text{top:-1px;white-space:nowrap;position:relative;line-height:1;overflow:hidden;text-overflow:ellipsis;width:var(--ngs-tab-panel-item-width);padding:0 calc(var(--spacing, .25rem) * 1);text-align:center}:host-context(.ngs-tab-panel.is-compact){width:var(--ngs-tab-panel-compact-item-width);height:var(--ngs-tab-panel-compact-item-height)}:host-context(.ngs-tab-panel.is-compact) .text{display:none;width:var(--ngs-tab-panel-compact-item-width)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelItem, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-item', exportAs: 'ngsTabPanelItem', hostDirectives: [
                        Ripple
                    ], host: {
                        'class': 'ngs-tab-panel-item',
                        '[class.is-active]': 'api.isActive(this.for())',
                        '(click)': '_handleClick()'
                    }, template: "<div class=\"icon\">\n  <ng-content select=\"[ngsTabPanelItemIcon]\"/>\n</div>\n<div class=\"text\">\n  <ng-content/>\n</div>\n", styles: [":host{display:flex;flex-direction:column;cursor:pointer;align-items:center;justify-content:center;flex:none;-webkit-user-select:none;user-select:none;width:var(--ngs-tab-panel-item-width);height:var(--ngs-tab-panel-item-height);padding:var(--ngs-tab-panel-item-padding);border-radius:var(--ngs-tab-panel-item-border-radius);color:var(--ngs-tab-panel-item-color);gap:var(--ngs-tab-panel-item-gap)}:host:not(.is-active):hover{background:var(--ngs-tab-panel-item-hover-bg);color:var(--ngs-tab-panel-item-hover-color)}:host.is-active{background:var(--ngs-tab-panel-item-active-bg);color:var(--ngs-tab-panel-item-active-color)}:host .icon{line-height:0;display:inline-block}:host .icon:empty{display:none}:host .text{top:-1px;white-space:nowrap;position:relative;line-height:1;overflow:hidden;text-overflow:ellipsis;width:var(--ngs-tab-panel-item-width);padding:0 calc(var(--spacing, .25rem) * 1);text-align:center}:host-context(.ngs-tab-panel.is-compact){width:var(--ngs-tab-panel-compact-item-width);height:var(--ngs-tab-panel-compact-item-height)}:host-context(.ngs-tab-panel.is-compact) .text{display:none;width:var(--ngs-tab-panel-compact-item-width)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { for: [{ type: i0.Input, args: [{ isSignal: true, alias: "for", required: false }] }] } });

class TabPanelNav {
    nextId = 0;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelNav, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelNav, isStandalone: true, selector: "ngs-tab-panel-nav", host: { classAttribute: "ngs-tab-panel-nav" }, providers: [
            {
                provide: TAB_PANEL_NAV,
                useExisting: TabPanelNav
            }
        ], exportAs: ["ngsTabPanelNav"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;flex-direction:column;align-items:center;gap:var(--ngs-tab-panel-nav-gap);padding:var(--ngs-tab-panel-nav-padding)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelNav, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-nav', exportAs: 'ngsTabPanelNav', providers: [
                        {
                            provide: TAB_PANEL_NAV,
                            useExisting: TabPanelNav
                        }
                    ], host: {
                        'class': 'ngs-tab-panel-nav'
                    }, template: "<ng-content/>\n", styles: [":host{display:flex;flex-direction:column;align-items:center;gap:var(--ngs-tab-panel-nav-gap);padding:var(--ngs-tab-panel-nav-padding)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TabPanelItemText {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelItemText, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelItemText, isStandalone: true, selector: "ngs-tab-panel-item-text", host: { classAttribute: "ngs-tab-panel-item-text" }, exportAs: ["ngsTabPanelItemText"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{font-size:var(--ngs-tab-panel-item-text-font-size)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelItemText, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-item-text', exportAs: 'ngsTabPanelItemText', host: {
                        'class': 'ngs-tab-panel-item-text'
                    }, template: "<ng-content/>\n", styles: [":host{font-size:var(--ngs-tab-panel-item-text-font-size)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TabPanelAside {
    nextId = 0;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelAside, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelAside, isStandalone: true, selector: "ngs-tab-panel-aside", host: { classAttribute: "ngs-tab-panel-aside" }, providers: [
            {
                provide: TAB_PANEL_ASIDE,
                useExisting: TabPanelAside
            }
        ], exportAs: ["ngsTabPanelAside"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;flex:none;width:var(--ngs-tab-panel-aside-width);position:relative}:host-context(.ngs-tab-panel.is-hide-content-if-tab-not-selected):empty{display:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelAside, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-aside', exportAs: 'ngsTabPanelAside', providers: [
                        {
                            provide: TAB_PANEL_ASIDE,
                            useExisting: TabPanelAside
                        }
                    ], host: {
                        'class': 'ngs-tab-panel-aside'
                    }, template: "<ng-content/>\n", styles: [":host{display:block;flex:none;width:var(--ngs-tab-panel-aside-width);position:relative}:host-context(.ngs-tab-panel.is-hide-content-if-tab-not-selected):empty{display:none}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TabPanelContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelContent, isStandalone: true, selector: "ngs-tab-panel-content", host: { classAttribute: "ngs-tab-panel-content" }, exportAs: ["ngsTabPanelContent"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:block;flex-grow:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelContent, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-content', exportAs: 'ngsTabPanelContent', host: {
                        'class': 'ngs-tab-panel-content'
                    }, template: "<ng-content/>\n", styles: [":host{display:block;flex-grow:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TabPanelCustomItem {
    api = inject(TabPanelApiService);
    for = input(...(ngDevMode ? [undefined, { debugName: "for" }] : /* istanbul ignore next */ []));
    _handleClick() {
        if (!this.for()) {
            return;
        }
        this.api.activate(this.for());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelCustomItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: TabPanelCustomItem, isStandalone: true, selector: "ngs-tab-panel-custom-item", inputs: { for: { classPropertyName: "for", publicName: "for", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_handleClick()" }, classAttribute: "ngs-tab-panel-custom-item" }, exportAs: ["ngsTabPanelCustomItem"], ngImport: i0, template: "<ng-content/>\n", styles: [":host{display:flex;flex-direction:column;cursor:pointer;align-items:center;justify-content:center;flex:none;-webkit-user-select:none;user-select:none;width:var(--ngs-tab-panel-item-width);height:var(--ngs-tab-panel-item-height)}:host-context(.ngs-tab-panel.is-compact){width:var(--ngs-tab-panel-compact-item-width);height:var(--ngs-tab-panel-compact-item-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelCustomItem, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-tab-panel-custom-item', exportAs: 'ngsTabPanelCustomItem', host: {
                        'class': 'ngs-tab-panel-custom-item',
                        '(click)': '_handleClick()'
                    }, template: "<ng-content/>\n", styles: [":host{display:flex;flex-direction:column;cursor:pointer;align-items:center;justify-content:center;flex:none;-webkit-user-select:none;user-select:none;width:var(--ngs-tab-panel-item-width);height:var(--ngs-tab-panel-item-height)}:host-context(.ngs-tab-panel.is-compact){width:var(--ngs-tab-panel-compact-item-width);height:var(--ngs-tab-panel-compact-item-height)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { for: [{ type: i0.Input, args: [{ isSignal: true, alias: "for", required: false }] }] } });

class TabPanelAsideContentDirective {
    _aside = inject(TAB_PANEL_ASIDE, { optional: true });
    _api = inject(TabPanelApiService);
    _templateRef = inject(TemplateRef);
    _viewContainer = inject(ViewContainerRef);
    _destroyRef = inject(DestroyRef);
    id = input(this._aside ? this._aside.nextId++ : null, { ...(ngDevMode ? { debugName: "id" } : /* istanbul ignore next */ {}), alias: 'ngsTabPanelAsideContent' });
    ngOnInit() {
        if (this._api.isActive(this.id())) {
            this._show();
        }
        else {
            this._hide();
        }
        this._api
            .itemIdChanged
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe(id => {
            if (this.id() === id) {
                this._show();
            }
            else {
                this._hide();
            }
        });
    }
    _show() {
        this._viewContainer.clear();
        this._viewContainer.createEmbeddedView(this._templateRef);
    }
    _hide() {
        this._viewContainer.clear();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelAsideContentDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: TabPanelAsideContentDirective, isStandalone: true, selector: "[ngsTabPanelAsideContent]", inputs: { id: { classPropertyName: "id", publicName: "ngsTabPanelAsideContent", isSignal: true, isRequired: false, transformFunction: null } }, exportAs: ["ngsTabPanelAsideContent"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelAsideContentDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTabPanelAsideContent]',
                    exportAs: 'ngsTabPanelAsideContent'
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "ngsTabPanelAsideContent", required: false }] }] } });

class TabPanelItemIconDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelItemIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TabPanelItemIconDirective, isStandalone: true, selector: "[ngsTabPanelItemIcon]", host: { classAttribute: "ngs-tab-panel-item-icon" }, exportAs: ["ngsTabPanelItemIcon"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TabPanelItemIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTabPanelItemIcon]',
                    exportAs: 'ngsTabPanelItemIcon',
                    host: {
                        'class': 'ngs-tab-panel-item-icon'
                    }
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { TabPanel, TabPanelAside, TabPanelAsideContentDirective, TabPanelContent, TabPanelCustomItem, TabPanelFooter, TabPanelHeader, TabPanelItem, TabPanelItemIconDirective, TabPanelItemText, TabPanelNav };
//# sourceMappingURL=ngstarter-components-tab-panel.mjs.map
