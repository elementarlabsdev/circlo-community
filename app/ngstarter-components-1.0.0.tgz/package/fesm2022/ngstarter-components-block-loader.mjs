import * as i0 from '@angular/core';
import { input, booleanAttribute, numberAttribute, ChangeDetectionStrategy, Component, inject, ElementRef, Renderer2, Directive } from '@angular/core';
import { ProgressSpinner } from '@ngstarter/components/spinner';

class BlockLoader {
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    spinnerDiameter = input(48, { ...(ngDevMode ? { debugName: "spinnerDiameter" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    spinnerStrokeWidth = input(4, { ...(ngDevMode ? { debugName: "spinnerStrokeWidth" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BlockLoader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: BlockLoader, isStandalone: true, selector: "ngs-block-loader", inputs: { loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, spinnerDiameter: { classPropertyName: "spinnerDiameter", publicName: "spinnerDiameter", isSignal: true, isRequired: false, transformFunction: null }, spinnerStrokeWidth: { classPropertyName: "spinnerStrokeWidth", publicName: "spinnerStrokeWidth", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.is-loading": "loading()" }, classAttribute: "ngs-block-loader" }, exportAs: ["ngsBlockLoader"], ngImport: i0, template: "<ngs-progress-spinner [diameter]=\"spinnerDiameter()\"\n                      [strokeWidth]=\"spinnerStrokeWidth()\"/>\n<div class=\"message\">\n  <ng-content/>\n</div>\n", styles: [":host{--ngs-block-loader-bg: rgba(255, 255, 255, .5);position:absolute;inset:0;background:var(--ngs-block-loader-bg);visibility:hidden;z-index:-99;pointer-events:none;display:flex;align-items:center;justify-content:center;border-radius:inherit;flex-direction:column;gap:calc(var(--spacing, .25rem) * 4);-webkit-user-select:none;user-select:none}:host.is-loading{visibility:visible;z-index:99;pointer-events:auto}:host .message:empty{display:none}:host .message{font-size:.875rem;text-align:center;max-width:800px}:host-context(html.dark){--ngs-block-loader-bg: rgba(0, 0, 0, .7)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: ProgressSpinner, selector: "ngs-progress-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["ngsProgressSpinner"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BlockLoader, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-block-loader', exportAs: 'ngsBlockLoader', imports: [
                        ProgressSpinner
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-block-loader',
                        '[class.is-loading]': 'loading()'
                    }, template: "<ngs-progress-spinner [diameter]=\"spinnerDiameter()\"\n                      [strokeWidth]=\"spinnerStrokeWidth()\"/>\n<div class=\"message\">\n  <ng-content/>\n</div>\n", styles: [":host{--ngs-block-loader-bg: rgba(255, 255, 255, .5);position:absolute;inset:0;background:var(--ngs-block-loader-bg);visibility:hidden;z-index:-99;pointer-events:none;display:flex;align-items:center;justify-content:center;border-radius:inherit;flex-direction:column;gap:calc(var(--spacing, .25rem) * 4);-webkit-user-select:none;user-select:none}:host.is-loading{visibility:visible;z-index:99;pointer-events:auto}:host .message:empty{display:none}:host .message{font-size:.875rem;text-align:center;max-width:800px}:host-context(html.dark){--ngs-block-loader-bg: rgba(0, 0, 0, .7)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], spinnerDiameter: [{ type: i0.Input, args: [{ isSignal: true, alias: "spinnerDiameter", required: false }] }], spinnerStrokeWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "spinnerStrokeWidth", required: false }] }] } });

class BlockLoaderContainerDirective {
    elementRef = inject(ElementRef);
    renderer = inject(Renderer2);
    ngOnInit() {
        const element = this.elementRef.nativeElement;
        this.renderer.setStyle(element, 'position', 'relative');
    }
    ngOnDestroy() {
        const element = this.elementRef.nativeElement;
        this.renderer.removeStyle(element, 'position');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BlockLoaderContainerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: BlockLoaderContainerDirective, isStandalone: true, selector: "[ngsBlockLoaderContainer]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: BlockLoaderContainerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsBlockLoaderContainer]'
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { BlockLoader, BlockLoaderContainerDirective };
//# sourceMappingURL=ngstarter-components-block-loader.mjs.map
