import * as i0 from '@angular/core';
import { InjectionToken, ApplicationRef, createComponent, ElementRef, input, Component, inject, DOCUMENT, ChangeDetectorRef, Injector, viewChild, output, forwardRef, Directive, DestroyRef, numberAttribute } from '@angular/core';
import { NodeView, Node, mergeAttributes, Editor } from '@tiptap/core';
import Document from '@tiptap/extension-document';
import Paragraph from '@tiptap/extension-paragraph';
import Text from '@tiptap/extension-text';
import Bold from '@tiptap/extension-bold';
import Italic from '@tiptap/extension-italic';
import Strike from '@tiptap/extension-strike';
import { Blockquote } from '@tiptap/extension-blockquote';
import CodeBlock from '@tiptap/extension-code-block';
import BulletList from '@tiptap/extension-bullet-list';
import OrderedList from '@tiptap/extension-ordered-list';
import ListItem from '@tiptap/extension-list-item';
import Code from '@tiptap/extension-code';
import History from '@tiptap/extension-history';
import Dropcursor from '@tiptap/extension-dropcursor';
import Youtube from '@tiptap/extension-youtube';
import Image$1 from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import Placeholder from '@tiptap/extension-placeholder';
import BubbleMenu from '@tiptap/extension-bubble-menu';
import { FloatingMenu } from '@tiptap/extension-floating-menu';
import { ProgressSpinner } from '@ngstarter/components/spinner';
import Heading from '@tiptap/extension-heading';
import { HorizontalRule } from '@tiptap/extension-horizontal-rule';
import { DialogRef, DIALOG_DATA, DialogActions, DialogContent, DialogTitle, Dialog } from '@ngstarter/components/dialog';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Input } from '@ngstarter/components/input';
import * as i1 from '@angular/forms';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Button } from '@ngstarter/components/button';
import { FormField, Label } from '@ngstarter/components/form-field';
import * as i1$1 from '@ngstarter/components/upload';
import { UploadTriggerDirective } from '@ngstarter/components/upload';

const TEXT_EDITOR = new InjectionToken('TEXT_EDITOR');
const TEXT_EDITOR_BUBBLE_MENU = new InjectionToken('TEXT_EDITOR_BUBBLE_MENU');

class AngularRenderer {
    applicationRef;
    componentRef;
    constructor(ViewComponent, injector, props) {
        this.applicationRef = injector.get(ApplicationRef);
        this.componentRef = createComponent(ViewComponent, {
            environmentInjector: this.applicationRef.injector,
            elementInjector: injector,
        });
        // set input props to the component
        this.updateProps(props);
        this.applicationRef.attachView(this.componentRef.hostView);
    }
    get instance() {
        return this.componentRef.instance;
    }
    get elementRef() {
        return this.componentRef.injector.get(ElementRef);
    }
    get dom() {
        return this.elementRef.nativeElement;
    }
    updateProps(props) {
        Object.entries(props).forEach(([key, value]) => {
            this.componentRef.setInput(key, value);
        });
    }
    detectChanges() {
        this.componentRef.changeDetectorRef.detectChanges();
    }
    destroy() {
        this.componentRef.destroy();
        this.applicationRef.detachView(this.componentRef.hostView);
    }
}

class AngularNodeViewContainer extends NodeView {
    renderer;
    contentDOMElement;
    mount() {
        const injector = this.options.injector;
        const props = {
            editor: this.editor,
            node: this.node,
            // @ts-ignore
            decorations: this.decorations,
            selected: false,
            extension: this.extension,
            getPos: () => this.getPos(),
            updateAttributes: (attributes = {}) => this.updateAttributes(attributes),
            deleteNode: () => this.deleteNode(),
        };
        this.handleSelectionUpdate = this.handleSelectionUpdate.bind(this);
        this.editor.on('selectionUpdate', this.handleSelectionUpdate);
        // create renderer
        this.renderer = new AngularRenderer(this.component, injector, props);
        // Register drag handler
        if (this.extension.config.draggable) {
            this.renderer.elementRef.nativeElement.ondragstart = (e) => {
                this.onDragStart(e);
            };
        }
        this.contentDOMElement = this.node.isLeaf ? null : document.createElement(this.node.isInline ? 'span' : 'div');
        if (this.contentDOMElement) {
            // For some reason the whiteSpace prop is not inherited properly in Chrome and Safari
            // With this fix it seems to work fine
            // See: https://github.com/ueberdosis/tiptap/issues/1197
            this.contentDOMElement.style.whiteSpace = 'inherit';
            // Required for editable node views
            // The content won't be rendered if `editable` is set to `false`
            this.renderer.detectChanges();
        }
        this.appendContendDom();
    }
    get dom() {
        return this.renderer.dom;
    }
    get contentDOM() {
        if (this.node.isLeaf) {
            return null;
        }
        return this.contentDOMElement;
    }
    appendContendDom() {
        const contentElement = this.dom.querySelector('[data-node-view-content]');
        if (this.contentDOMElement
            && contentElement
            && !contentElement.contains(this.contentDOMElement)) {
            contentElement.appendChild(this.contentDOMElement);
        }
    }
    handleSelectionUpdate() {
        const { from, to } = this.editor.state.selection;
        if (from <= this.getPos() && to >= this.getPos() + this.node.nodeSize) {
            this.selectNode();
        }
        else {
            this.deselectNode();
        }
    }
    update(node, decorations) {
        const updateProps = () => {
            this.renderer.updateProps({ node, decorations });
        };
        if (this.options.update) {
            const oldNode = this.node;
            const oldDecorations = this.decorations;
            this.node = node;
            this.decorations = decorations;
            return this.options.update({
                oldNode,
                // @ts-ignore
                oldDecorations,
                newNode: node,
                newDecorations: decorations,
                updateProps: () => updateProps(),
            });
        }
        if (node.type !== this.node.type) {
            return false;
        }
        if (node === this.node && this.decorations === decorations) {
            return true;
        }
        this.node = node;
        this.decorations = decorations;
        updateProps();
        return true;
    }
    selectNode() {
        this.renderer.updateProps({ selected: true });
    }
    deselectNode() {
        this.renderer.updateProps({ selected: false });
    }
    destroy() {
        this.renderer.destroy();
        this.editor.off('selectionUpdate', this.handleSelectionUpdate);
        this.contentDOMElement = null;
    }
}
const AngularNodeViewRenderer = (ViewComponent, options) => {
    // @ts-ignore
    return (props) => {
        return new AngularNodeViewContainer(ViewComponent, props, options);
    };
};

class AngularNodeView {
    editor = input.required(...(ngDevMode ? [{ debugName: "editor" }] : /* istanbul ignore next */ []));
    node = input.required(...(ngDevMode ? [{ debugName: "node" }] : /* istanbul ignore next */ []));
    decorations = input.required(...(ngDevMode ? [{ debugName: "decorations" }] : /* istanbul ignore next */ []));
    selected = input.required(...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    extension = input.required(...(ngDevMode ? [{ debugName: "extension" }] : /* istanbul ignore next */ []));
    getPos = input.required(...(ngDevMode ? [{ debugName: "getPos" }] : /* istanbul ignore next */ []));
    updateAttributes = input.required(...(ngDevMode ? [{ debugName: "updateAttributes" }] : /* istanbul ignore next */ []));
    deleteNode = input.required(...(ngDevMode ? [{ debugName: "deleteNode" }] : /* istanbul ignore next */ []));
    HTMLAttributes = input({}, ...(ngDevMode ? [{ debugName: "HTMLAttributes" }] : /* istanbul ignore next */ []));
    innerDecorations = input(undefined, ...(ngDevMode ? [{ debugName: "innerDecorations" }] : /* istanbul ignore next */ []));
    view = input(undefined, ...(ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: AngularNodeView, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: AngularNodeView, isStandalone: true, selector: "ng-component", inputs: { editor: { classPropertyName: "editor", publicName: "editor", isSignal: true, isRequired: true, transformFunction: null }, node: { classPropertyName: "node", publicName: "node", isSignal: true, isRequired: true, transformFunction: null }, decorations: { classPropertyName: "decorations", publicName: "decorations", isSignal: true, isRequired: true, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: true, transformFunction: null }, extension: { classPropertyName: "extension", publicName: "extension", isSignal: true, isRequired: true, transformFunction: null }, getPos: { classPropertyName: "getPos", publicName: "getPos", isSignal: true, isRequired: true, transformFunction: null }, updateAttributes: { classPropertyName: "updateAttributes", publicName: "updateAttributes", isSignal: true, isRequired: true, transformFunction: null }, deleteNode: { classPropertyName: "deleteNode", publicName: "deleteNode", isSignal: true, isRequired: true, transformFunction: null }, HTMLAttributes: { classPropertyName: "HTMLAttributes", publicName: "HTMLAttributes", isSignal: true, isRequired: false, transformFunction: null }, innerDecorations: { classPropertyName: "innerDecorations", publicName: "innerDecorations", isSignal: true, isRequired: false, transformFunction: null }, view: { classPropertyName: "view", publicName: "view", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: AngularNodeView, decorators: [{
            type: Component,
            args: [{ standalone: true, template: '' }]
        }], propDecorators: { editor: [{ type: i0.Input, args: [{ isSignal: true, alias: "editor", required: true }] }], node: [{ type: i0.Input, args: [{ isSignal: true, alias: "node", required: true }] }], decorations: [{ type: i0.Input, args: [{ isSignal: true, alias: "decorations", required: true }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: true }] }], extension: [{ type: i0.Input, args: [{ isSignal: true, alias: "extension", required: true }] }], getPos: [{ type: i0.Input, args: [{ isSignal: true, alias: "getPos", required: true }] }], updateAttributes: [{ type: i0.Input, args: [{ isSignal: true, alias: "updateAttributes", required: true }] }], deleteNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "deleteNode", required: true }] }], HTMLAttributes: [{ type: i0.Input, args: [{ isSignal: true, alias: "HTMLAttributes", required: false }] }], innerDecorations: [{ type: i0.Input, args: [{ isSignal: true, alias: "innerDecorations", required: false }] }], view: [{ type: i0.Input, args: [{ isSignal: true, alias: "view", required: false }] }] } });

class ImageUploadingPlaceholder extends AngularNodeView {
    src;
    error;
    _canceled = false;
    ngOnInit() {
        const uploadFn = this.extension().options['uploadFn'];
        this.src = this.node().attrs['src'];
        const blob = this._dataURItoBlob(this.src);
        uploadFn(blob).then((src) => {
            if (this._canceled) {
                return;
            }
            const image = new Image();
            image.src = src;
            image.onload = () => {
                this.editor().chain().focus().setImage({ src }).run();
            };
        }, (error) => {
            this.error = error;
        });
    }
    ngOnDestroy() {
        this._canceled = true;
    }
    _dataURItoBlob(dataURI) {
        // convert base64 to raw binary data held in a string
        // doesn't handle URLEncoded DataURIs - see SO answer #6850276 for code that does this
        const byteString = atob(dataURI.split(',')[1]);
        // separate out the mime component
        const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
        // write the bytes of the string to an ArrayBuffer
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ab], { type: mimeString });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ImageUploadingPlaceholder, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: ImageUploadingPlaceholder, isStandalone: true, selector: "ngs-image-uploading-placeholder", host: { properties: { "class.selected": "selected()" }, classAttribute: "ngs-image-uploading-placeholder" }, exportAs: ["ngsTextEditorUploadingPlaceholder"], usesInheritance: true, ngImport: i0, template: "@if (src) {\n  <div class=\"flex items-center justify-center relative\">\n    @if (error) {\n      <div class=\"absolute top-0 start-0 right-0 min-h-8 bg-error z-[2]\n                    text-on-error text-tiny flex items-center px-3\">{{ error }}</div>\n    }\n    <div class=\"w-max absolute start-1/2 top-1/2 z-[1] -translate-y-1/2 -translate-x-1/2\">\n      @if (!error) {\n        <ngs-progress-spinner />\n      }\n    </div>\n    <img [src]=\"src\" alt=\"\" class=\"max-w-full opacity-70\">\n  </div>\n}\n", styles: [":host{display:block}:host.selected{outline:var(--sys-tertiary) solid 4px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: ProgressSpinner, selector: "ngs-progress-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["ngsProgressSpinner"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ImageUploadingPlaceholder, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-image-uploading-placeholder', exportAs: 'ngsTextEditorUploadingPlaceholder', imports: [
                        ProgressSpinner
                    ], host: {
                        'class': 'ngs-image-uploading-placeholder',
                        '[class.selected]': 'selected()'
                    }, template: "@if (src) {\n  <div class=\"flex items-center justify-center relative\">\n    @if (error) {\n      <div class=\"absolute top-0 start-0 right-0 min-h-8 bg-error z-[2]\n                    text-on-error text-tiny flex items-center px-3\">{{ error }}</div>\n    }\n    <div class=\"w-max absolute start-1/2 top-1/2 z-[1] -translate-y-1/2 -translate-x-1/2\">\n      @if (!error) {\n        <ngs-progress-spinner />\n      }\n    </div>\n    <img [src]=\"src\" alt=\"\" class=\"max-w-full opacity-70\">\n  </div>\n}\n", styles: [":host{display:block}:host.selected{outline:var(--sys-tertiary) solid 4px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

const ImageUploadingPlaceholderExtension = (injector, options) => {
    return Node.create({
        name: 'imageUploadingPlaceholder',
        draggable: false,
        group: 'block',
        addOptions() {
            return {
                uploadFn: options.uploadFn
            };
        },
        addAttributes() {
            return {
                uploadId: {
                    default: ''
                },
                src: {
                    default: null
                }
            };
        },
        addCommands() {
            return {
                addImageUploadingPlaceholder: options => ({ commands }) => {
                    return commands.insertContent({
                        type: this.name,
                        attrs: {
                            src: options.src
                        }
                    });
                },
            };
        },
        addNodeView() {
            return AngularNodeViewRenderer(ImageUploadingPlaceholder, { injector });
        },
        parseHTML() {
            return [
                {
                    tag: 'image-uploading-placeholder',
                }
            ];
        },
        renderHTML({ HTMLAttributes }) {
            return [
                'image-uploading-placeholder', mergeAttributes(HTMLAttributes),
            ];
        }
    });
};

class TextEditor {
    _document = inject(DOCUMENT);
    _cdr = inject(ChangeDetectorRef);
    _injector = inject(Injector);
    _content = viewChild.required('content');
    _bubbleMenu = viewChild.required('bubbleMenu');
    _imageBubbleMenu = viewChild.required('imageBubbleMenu');
    _floatingMenu = viewChild.required('floatingMenu');
    _value = '';
    editor;
    content = input('', ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    extensions = input([], ...(ngDevMode ? [{ debugName: "extensions" }] : /* istanbul ignore next */ []));
    contentMaxHeight = input(...(ngDevMode ? [undefined, { debugName: "contentMaxHeight" }] : /* istanbul ignore next */ []));
    placeholder = input('Write something …', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    imageUploadFn = input(...(ngDevMode ? [undefined, { debugName: "imageUploadFn" }] : /* istanbul ignore next */ []));
    contentChange = output();
    get api() {
        return {
            isCommandDisabled: (command, options) => this.isCommandDisabled(command, options),
            isActive: (command, options) => this.editor?.isActive(command, options),
            runCommand: (command, options) => this._runCommand(command, options),
            editor: () => this.editor
        };
    }
    ngOnInit() {
        this._init();
    }
    isCommandDisabled(command, options) {
        if (!this.editor) {
            return true;
        }
        try {
            const canFocus = this.editor.can().chain().focus();
            return !canFocus[command](options).run() || null;
        }
        catch (e) {
            return true;
        }
    }
    ngOnDestroy() {
        this.editor?.destroy();
    }
    _runCommand(command, options) {
        if (!this.editor) {
            return;
        }
        const chainFocus = this.editor.chain().focus();
        chainFocus[command](options).run();
    }
    _init() {
        const extensions = [
            ...this.extensions(),
            Heading.configure({
                levels: [1, 2, 3],
            }),
            HorizontalRule,
            Document,
            Paragraph,
            Text,
            Bold,
            Italic,
            Strike,
            Blockquote,
            CodeBlock,
            BulletList,
            OrderedList,
            ListItem,
            Code,
            History,
            Dropcursor,
            Youtube.configure({
                controls: false,
                nocookie: true,
            }),
            ImageUploadingPlaceholderExtension(this._injector, {
                uploadFn: this.imageUploadFn(),
            }),
            Image$1.configure({
                inline: true,
                allowBase64: true
            }),
            Link.configure({
                openOnClick: false,
                defaultProtocol: 'https',
            }),
            Placeholder.configure({
                placeholder: this.placeholder()
            }),
            // BubbleMenu.configure({
            //   element: this._imageBubbleMenu().nativeElement,
            //   shouldShow: ({ editor, view, state, oldState, from, to }) => {
            //     // return editor.isActive('image');
            //     return false;
            //   },
            // }),
            BubbleMenu.configure({
                element: this._bubbleMenu().nativeElement,
                tippyOptions: {
                    appendTo: this._document.body,
                    zIndex: 999
                },
                shouldShow: ({ editor, view, state, oldState, from, to }) => {
                    return !editor.isActive('image') &&
                        !editor.isActive('youtube') &&
                        !editor.isActive('imageUploadingPlaceholder') &&
                        !editor.view.state.selection.empty;
                },
            })
        ];
        if (this._floatingMenu()) {
            extensions.push(FloatingMenu.configure({
                element: this._floatingMenu().nativeElement
            }));
        }
        this.editor = new Editor({
            element: this._content().nativeElement,
            extensions,
            content: this.content(),
            onUpdate: ({ editor }) => {
                this._value = !editor.isEmpty ? editor.getHTML() : '';
                this.contentChange.emit(this._value);
            }
        });
        this._cdr.detectChanges();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditor, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: TextEditor, isStandalone: true, selector: "ngs-text-editor", inputs: { content: { classPropertyName: "content", publicName: "content", isSignal: true, isRequired: false, transformFunction: null }, extensions: { classPropertyName: "extensions", publicName: "extensions", isSignal: true, isRequired: false, transformFunction: null }, contentMaxHeight: { classPropertyName: "contentMaxHeight", publicName: "contentMaxHeight", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, imageUploadFn: { classPropertyName: "imageUploadFn", publicName: "imageUploadFn", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { contentChange: "contentChange" }, host: { classAttribute: "ngs-text-editor" }, providers: [
            {
                provide: TEXT_EDITOR,
                useExisting: forwardRef(() => TextEditor)
            }
        ], viewQueries: [{ propertyName: "_content", first: true, predicate: ["content"], descendants: true, isSignal: true }, { propertyName: "_bubbleMenu", first: true, predicate: ["bubbleMenu"], descendants: true, isSignal: true }, { propertyName: "_imageBubbleMenu", first: true, predicate: ["imageBubbleMenu"], descendants: true, isSignal: true }, { propertyName: "_floatingMenu", first: true, predicate: ["floatingMenu"], descendants: true, isSignal: true }], exportAs: ["ngsTextEditor"], ngImport: i0, template: "<ng-content select=\"ngs-text-editor-toolbar\"/>\n<div #content class=\"content prose dark:prose-invert max-w-full\"></div>\n<div #imageBubbleMenu class=\"ngs-text-editor-bubble-menu\"></div>\n<div #bubbleMenu>\n  <ng-content select=\"ngs-text-editor-bubble-menu\"/>\n</div>\n<div #floatingMenu class=\"floating-menu\">\n  <ng-content select=\"ngs-text-editor-floating-menu\"/>\n</div>\n", styles: [":host{--ngs-text-editor-bg: transparent;--ngs-text-editor-content-max-height: 9999px;--ngs-text-editor-content-padding: calc(var(--spacing, .25rem) * 6);display:block}:host:not([class*=bg-]){background:var(--ngs-text-editor-bg)}:host .floating-menu:empty{display:none}:host ::ng-deep .tippy-box{max-width:800px!important}:host .content ::ng-deep .tiptap{padding:var(--ngs-text-editor-content-padding);min-height:100%}:host .content ::ng-deep .tiptap:focus{outline:none}:host .content ::ng-deep .tiptap div[data-youtube-video]{cursor:move;background:var(--color-neutral-100);padding:calc(var(--spacing, .25rem) * 6);display:flex;align-items:center;justify-content:center}:host .content ::ng-deep .tiptap div[data-youtube-video] iframe{width:100%;aspect-ratio:16/9;border:none;display:block;min-height:200px;min-width:200px;outline:none}:host .content ::ng-deep .tiptap div[data-youtube-video].ProseMirror-selectednode iframe{outline:var(--sys-tertiary) solid 4px;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}:host .content ::ng-deep .tiptap img{display:block;height:auto;margin:calc(var(--spacing, .25rem) * 6) 0;max-width:100%}:host .content ::ng-deep .tiptap img.ProseMirror-selectednode{outline:var(--sys-tertiary) solid 4px;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}:host .content ::ng-deep .tiptap p.is-editor-empty:first-child:before{content:attr(data-placeholder);color:var(--color-neutral-500);float:left;height:0;pointer-events:none;font-size:.875rem}:host .content ::ng-deep .tiptap.ProseMirror-focused p.is-editor-empty:first-child:before{content:none}:host .content ::ng-deep .tiptap p.is-empty:before{content:attr(data-placeholder);color:var(--color-neutral-500);float:left;height:0;pointer-events:none;font-size:.875rem}:host .content ::ng-deep p:first-child,:host .content ::ng-deep pre:first-child{margin-top:0}:host .content ::ng-deep p:last-child,:host .content ::ng-deep pre:last-child{margin-bottom:0}:host .button.active,:host ::ng-deep .button.active{background:var(--color-neutral-100)}:host-context(html.dark) .button.active,:host-context(html.dark) ::ng-deep .button.active{background:var(--color-neutral-650);color:var(--color-neutral-200)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditor, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-editor', exportAs: 'ngsTextEditor', imports: [], providers: [
                        {
                            provide: TEXT_EDITOR,
                            useExisting: forwardRef(() => TextEditor)
                        }
                    ], host: {
                        'class': 'ngs-text-editor'
                    }, template: "<ng-content select=\"ngs-text-editor-toolbar\"/>\n<div #content class=\"content prose dark:prose-invert max-w-full\"></div>\n<div #imageBubbleMenu class=\"ngs-text-editor-bubble-menu\"></div>\n<div #bubbleMenu>\n  <ng-content select=\"ngs-text-editor-bubble-menu\"/>\n</div>\n<div #floatingMenu class=\"floating-menu\">\n  <ng-content select=\"ngs-text-editor-floating-menu\"/>\n</div>\n", styles: [":host{--ngs-text-editor-bg: transparent;--ngs-text-editor-content-max-height: 9999px;--ngs-text-editor-content-padding: calc(var(--spacing, .25rem) * 6);display:block}:host:not([class*=bg-]){background:var(--ngs-text-editor-bg)}:host .floating-menu:empty{display:none}:host ::ng-deep .tippy-box{max-width:800px!important}:host .content ::ng-deep .tiptap{padding:var(--ngs-text-editor-content-padding);min-height:100%}:host .content ::ng-deep .tiptap:focus{outline:none}:host .content ::ng-deep .tiptap div[data-youtube-video]{cursor:move;background:var(--color-neutral-100);padding:calc(var(--spacing, .25rem) * 6);display:flex;align-items:center;justify-content:center}:host .content ::ng-deep .tiptap div[data-youtube-video] iframe{width:100%;aspect-ratio:16/9;border:none;display:block;min-height:200px;min-width:200px;outline:none}:host .content ::ng-deep .tiptap div[data-youtube-video].ProseMirror-selectednode iframe{outline:var(--sys-tertiary) solid 4px;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}:host .content ::ng-deep .tiptap img{display:block;height:auto;margin:calc(var(--spacing, .25rem) * 6) 0;max-width:100%}:host .content ::ng-deep .tiptap img.ProseMirror-selectednode{outline:var(--sys-tertiary) solid 4px;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s}:host .content ::ng-deep .tiptap p.is-editor-empty:first-child:before{content:attr(data-placeholder);color:var(--color-neutral-500);float:left;height:0;pointer-events:none;font-size:.875rem}:host .content ::ng-deep .tiptap.ProseMirror-focused p.is-editor-empty:first-child:before{content:none}:host .content ::ng-deep .tiptap p.is-empty:before{content:attr(data-placeholder);color:var(--color-neutral-500);float:left;height:0;pointer-events:none;font-size:.875rem}:host .content ::ng-deep p:first-child,:host .content ::ng-deep pre:first-child{margin-top:0}:host .content ::ng-deep p:last-child,:host .content ::ng-deep pre:last-child{margin-bottom:0}:host .button.active,:host ::ng-deep .button.active{background:var(--color-neutral-100)}:host-context(html.dark) .button.active,:host-context(html.dark) ::ng-deep .button.active{background:var(--color-neutral-650);color:var(--color-neutral-200)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { _content: [{ type: i0.ViewChild, args: ['content', { isSignal: true }] }], _bubbleMenu: [{ type: i0.ViewChild, args: ['bubbleMenu', { isSignal: true }] }], _imageBubbleMenu: [{ type: i0.ViewChild, args: ['imageBubbleMenu', { isSignal: true }] }], _floatingMenu: [{ type: i0.ViewChild, args: ['floatingMenu', { isSignal: true }] }], content: [{ type: i0.Input, args: [{ isSignal: true, alias: "content", required: false }] }], extensions: [{ type: i0.Input, args: [{ isSignal: true, alias: "extensions", required: false }] }], contentMaxHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentMaxHeight", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], imageUploadFn: [{ type: i0.Input, args: [{ isSignal: true, alias: "imageUploadFn", required: false }] }], contentChange: [{ type: i0.Output, args: ["contentChange"] }] } });

class TextEditorToolbar {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorToolbar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorToolbar, isStandalone: true, selector: "ngs-text-editor-toolbar", exportAs: ["ngsTextEditorToolbar"], ngImport: i0, template: "<ng-content select=\"[ngsTextEditorCommand],ngs-text-editor-divider\"/>\n\n", styles: [":host{border-top-left-radius:inherit;border-top-right-radius:inherit;gap:calc(var(--spacing, .25rem) * .5);border-bottom:1px solid var(--color-border);height:calc(var(--spacing, .25rem) * 14);padding-left:calc(var(--spacing, .25rem) * 3);padding-right:calc(var(--spacing, .25rem) * 3);display:flex;align-items:center;z-index:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorToolbar, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-editor-toolbar', exportAs: 'ngsTextEditorToolbar', imports: [], template: "<ng-content select=\"[ngsTextEditorCommand],ngs-text-editor-divider\"/>\n\n", styles: [":host{border-top-left-radius:inherit;border-top-right-radius:inherit;gap:calc(var(--spacing, .25rem) * .5);border-bottom:1px solid var(--color-border);height:calc(var(--spacing, .25rem) * 14);padding-left:calc(var(--spacing, .25rem) * 3);padding-right:calc(var(--spacing, .25rem) * 3);display:flex;align-items:center;z-index:1}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TextEditorDivider {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorDivider, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorDivider, isStandalone: true, selector: "ngs-text-editor-divider", exportAs: ["ngsTextEditorDivider"], ngImport: i0, template: "<div class=\"divider\"></div>\n", styles: [":host{display:block;padding:0 calc(var(--spacing, .25rem) * 2)}:host .divider{height:calc(var(--spacing, .25rem) * 6);background:var(--color-neutral-300);width:1px}:host-context(html.dark) .divider{background:var(--color-neutral-500)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorDivider, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-editor-divider', exportAs: 'ngsTextEditorDivider', imports: [], template: "<div class=\"divider\"></div>\n", styles: [":host{display:block;padding:0 calc(var(--spacing, .25rem) * 2)}:host .divider{height:calc(var(--spacing, .25rem) * 6);background:var(--color-neutral-300);width:1px}:host-context(html.dark) .divider{background:var(--color-neutral-500)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TextEditorBubbleMenu {
    textEditor = inject(TEXT_EDITOR);
    getLinkUrl() {
        return (this.textEditor.api.editor()?.getAttributes('link')).href || null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorBubbleMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: TextEditorBubbleMenu, isStandalone: true, selector: "ngs-text-editor-bubble-menu", providers: [
            {
                provide: TEXT_EDITOR_BUBBLE_MENU,
                useExisting: forwardRef(() => TextEditorBubbleMenu)
            }
        ], exportAs: ["emitTextEditorBubbleMenu"], ngImport: i0, template: "@if (this.textEditor.api.isActive('link') && getLinkUrl()) {\n  <div class=\"flex items-center gap-1 h-11 border-b border-b-muted border-b-neutral-700\">\n    <div class=\"grow text-sm overflow-hidden text-ellipsis whitespace-nowrap w-[116px]\">\n      <a [href]=\"getLinkUrl()\" target=\"_blank\" class=\"link\">{{ getLinkUrl() }}</a>\n    </div>\n    <div class=\"flex items-center flex-none\">\n      <ng-content select=\"[ngsTextEditorCommandEditLink],[ngsCommentEditorCommandUnsetLink]\"/>\n    </div>\n  </div>\n}\n<div class=\"h-12 flex items-center justify-center gap-0.5\">\n  <ng-content select=\"[ngsTextEditorCommand],ngs-text-editor-divider\"/>\n</div>\n", styles: [":host{display:block;box-shadow:0 1px 3px #0000001a,0 1px 2px -1px #0000001a;background:var(--color-neutral-950);color:var(--color-neutral-200);min-height:calc(var(--spacing, .25rem) * 12);border-radius:1rem;top:1px;padding-inline-start:calc(var(--spacing, .25rem) * 2);padding-inline-end:calc(var(--spacing, .25rem) * 2)}:host .button,:host ::ng-deep .button{width:calc(var(--spacing, .25rem) * 10);height:calc(var(--spacing, .25rem) * 10);display:flex;align-items:center;justify-content:center;--icon-size: 1.25rem;border-radius:calc(infinity * 1px)}:host .button:hover,:host ::ng-deep .button:hover{color:var(--color-tertiary-300);background:var(--color-neutral-700);padding:calc(var(--spacing, .25rem) * 1.5)}:host .button.active,:host ::ng-deep .button.active{color:var(--color-tertiary-300);background:var(--color-neutral-700)}:host .button ngs-icon,:host ::ng-deep .button ngs-icon{width:calc(var(--spacing, .25rem) * 6);height:calc(var(--spacing, .25rem) * 6);font-size:1.25rem;line-height:1.25}:host .button:disabled,:host ::ng-deep .button:disabled{pointer-events:none;opacity:70%}:host .link{color:var(--color-tertiary-300);position:relative;top:1px}:host .link:hover{color:var(--color-tertiary-100)}:host-context(html.dark){background:var(--color-tertiary-200);color:var(--color-neutral-900)}:host-context(html.dark) .link{color:var(--color-tertiary-700)}:host-context(html.dark) .link:hover{color:var(--color-tertiary-800)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorBubbleMenu, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-editor-bubble-menu', exportAs: 'emitTextEditorBubbleMenu', imports: [], providers: [
                        {
                            provide: TEXT_EDITOR_BUBBLE_MENU,
                            useExisting: forwardRef(() => TextEditorBubbleMenu)
                        }
                    ], template: "@if (this.textEditor.api.isActive('link') && getLinkUrl()) {\n  <div class=\"flex items-center gap-1 h-11 border-b border-b-muted border-b-neutral-700\">\n    <div class=\"grow text-sm overflow-hidden text-ellipsis whitespace-nowrap w-[116px]\">\n      <a [href]=\"getLinkUrl()\" target=\"_blank\" class=\"link\">{{ getLinkUrl() }}</a>\n    </div>\n    <div class=\"flex items-center flex-none\">\n      <ng-content select=\"[ngsTextEditorCommandEditLink],[ngsCommentEditorCommandUnsetLink]\"/>\n    </div>\n  </div>\n}\n<div class=\"h-12 flex items-center justify-center gap-0.5\">\n  <ng-content select=\"[ngsTextEditorCommand],ngs-text-editor-divider\"/>\n</div>\n", styles: [":host{display:block;box-shadow:0 1px 3px #0000001a,0 1px 2px -1px #0000001a;background:var(--color-neutral-950);color:var(--color-neutral-200);min-height:calc(var(--spacing, .25rem) * 12);border-radius:1rem;top:1px;padding-inline-start:calc(var(--spacing, .25rem) * 2);padding-inline-end:calc(var(--spacing, .25rem) * 2)}:host .button,:host ::ng-deep .button{width:calc(var(--spacing, .25rem) * 10);height:calc(var(--spacing, .25rem) * 10);display:flex;align-items:center;justify-content:center;--icon-size: 1.25rem;border-radius:calc(infinity * 1px)}:host .button:hover,:host ::ng-deep .button:hover{color:var(--color-tertiary-300);background:var(--color-neutral-700);padding:calc(var(--spacing, .25rem) * 1.5)}:host .button.active,:host ::ng-deep .button.active{color:var(--color-tertiary-300);background:var(--color-neutral-700)}:host .button ngs-icon,:host ::ng-deep .button ngs-icon{width:calc(var(--spacing, .25rem) * 6);height:calc(var(--spacing, .25rem) * 6);font-size:1.25rem;line-height:1.25}:host .button:disabled,:host ::ng-deep .button:disabled{pointer-events:none;opacity:70%}:host .link{color:var(--color-tertiary-300);position:relative;top:1px}:host .link:hover{color:var(--color-tertiary-100)}:host-context(html.dark){background:var(--color-tertiary-200);color:var(--color-neutral-900)}:host-context(html.dark) .link{color:var(--color-tertiary-700)}:host-context(html.dark) .link:hover{color:var(--color-tertiary-800)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TextEditorFloatingMenu {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorFloatingMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorFloatingMenu, isStandalone: true, selector: "ngs-text-editor-floating-menu", host: { classAttribute: "ngs-text-editor-floating-menu" }, exportAs: ["ngsTextEditorFloatingMenu"], ngImport: i0, template: "<ng-content select=\"[ngsTextEditorCommand],ngs-text-editor-divider\"/>\n", styles: [":host{box-shadow:0 1px 3px #0000001a,0 1px 2px -1px #0000001a;margin-left:calc(var(--spacing, .25rem) * 3);margin-right:calc(var(--spacing, .25rem) * 3);background:var(--sys-surface-container-lowest);padding:calc(var(--spacing, .25rem) * 1.5) calc(var(--spacing, .25rem) * 2);display:flex;align-items:center;flex-wrap:wrap;gap:calc(var(--spacing, .25rem) * .5);border:1px solid var(--color-border);border-radius:1rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorFloatingMenu, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-text-editor-floating-menu', exportAs: 'ngsTextEditorFloatingMenu', imports: [], host: {
                        'class': 'ngs-text-editor-floating-menu'
                    }, template: "<ng-content select=\"[ngsTextEditorCommand],ngs-text-editor-divider\"/>\n", styles: [":host{box-shadow:0 1px 3px #0000001a,0 1px 2px -1px #0000001a;margin-left:calc(var(--spacing, .25rem) * 3);margin-right:calc(var(--spacing, .25rem) * 3);background:var(--sys-surface-container-lowest);padding:calc(var(--spacing, .25rem) * 1.5) calc(var(--spacing, .25rem) * 2);display:flex;align-items:center;flex-wrap:wrap;gap:calc(var(--spacing, .25rem) * .5);border:1px solid var(--color-border);border-radius:1rem}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TextEditorCommandBlockquoteDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleBlockquote');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandBlockquoteDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandBlockquoteDirective, isStandalone: true, selector: "[ngsTextEditorCommandBlockquote]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleBlockquote')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('blockquote')" } }, exportAs: ["ngsTextEditorCommandBlockquote"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandBlockquoteDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandBlockquote]',
                    exportAs: 'ngsTextEditorCommandBlockquote',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleBlockquote')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('blockquote')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandBoldDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleBold');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandBoldDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandBoldDirective, isStandalone: true, selector: "[ngsTextEditorCommandBold]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleBold')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('bold')" } }, exportAs: ["ngsTextEditorCommandBold"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandBoldDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandBold]',
                    exportAs: 'ngsTextEditorCommandBold',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleBold')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('bold')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandBulletListDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleBulletList');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandBulletListDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandBulletListDirective, isStandalone: true, selector: "[ngsTextEditorCommandBulletList]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleBulletList')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('bulletList')" } }, exportAs: ["ngsTextEditorCommandBulletList"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandBulletListDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandBulletList]',
                    exportAs: 'ngsTextEditorCommandBulletList',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleBulletList')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('bulletList')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandCodeBlockDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleCodeBlock');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandCodeBlockDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandCodeBlockDirective, isStandalone: true, selector: "[ngsTextEditorCommandCodeBlock]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleCodeBlock')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('codeBlock')" } }, exportAs: ["ngsTextEditorCommandCodeBlock"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandCodeBlockDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandCodeBlock]',
                    exportAs: 'ngsTextEditorCommandCodeBlock',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleCodeBlock')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('codeBlock')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandCodeDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleCode');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandCodeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandCodeDirective, isStandalone: true, selector: "[ngsTextEditorCommandCode]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleCode')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('code')" } }, exportAs: ["ngsTextEditorCommandCode"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandCodeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandCode]',
                    exportAs: 'ngsTextEditorCommandCode',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleCode')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('code')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class LinkDialog {
    _dialogRef = inject(DialogRef);
    _data = inject(DIALOG_DATA);
    linkUrl = this._data.linkUrl || '';
    isUpdate = !!this._data.linkUrl;
    onSubmit() {
        this._dialogRef.close(this.linkUrl);
    }
    _onNoClick() {
        this._dialogRef.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LinkDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: LinkDialog, isStandalone: true, selector: "ngs-link", exportAs: ["ngsLink"], ngImport: i0, template: "<form class=\"w-[500px]\" (ngSubmit)=\"onSubmit()\">\n  <h3 ngs-dialog-title>\n    @if (isUpdate) {\n      Update Link\n    } @else {\n      Add Link\n    }</h3>\n  <ngs-dialog-content>\n    <div class=\"pt-4\">\n      <ngs-form-field class=\"w-full\">\n        <ngs-label>Paste Link</ngs-label>\n        <input name=\"linkUrl\" ngsInput [(ngModel)]=\"linkUrl\">\n      </ngs-form-field>\n    </div>\n  </ngs-dialog-content>\n  <div ngs-dialog-actions align=\"end\">\n    <button ngsButton (click)=\"_onNoClick()\">Cancel</button>\n    <button type=\"submit\" ngsButton=\"filled\" color=\"primary\"\n            cdkFocusInitial [disabled]=\"!linkUrl.trim() || null\">\n      @if (isUpdate) {\n        Save\n      } @else {\n        Add link\n      }\n    </button>\n  </div>\n</form>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "component", type: DialogActions, selector: "ngs-dialog-actions, [ngs-dialog-actions], [ngsDialogActions]", inputs: ["align"] }, { kind: "component", type: DialogContent, selector: "ngs-dialog-content,[ngs-dialog-content],[ngsDialogContent]" }, { kind: "component", type: DialogTitle, selector: "ngs-dialog-title, [ngs-dialog-title], [ngsDialogTitle]", inputs: ["id"], exportAs: ["ngsDialogTitle"] }, { kind: "component", type: FormField, selector: "ngs-form-field", inputs: ["subscriptHiddenIfEmpty"], exportAs: ["ngsFormField"] }, { kind: "directive", type: Input, selector: "input[ngsInput], textarea[ngsInput]", inputs: ["id", "placeholder", "required", "disabled", "readonly", "errorStateMatcher"], exportAs: ["ngsInput"] }, { kind: "component", type: Label, selector: "ngs-label" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: LinkDialog, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-link', exportAs: 'ngsLink', imports: [
                        Button,
                        DialogActions,
                        DialogContent,
                        DialogTitle,
                        FormField,
                        Input,
                        Label,
                        ReactiveFormsModule,
                        FormsModule
                    ], template: "<form class=\"w-[500px]\" (ngSubmit)=\"onSubmit()\">\n  <h3 ngs-dialog-title>\n    @if (isUpdate) {\n      Update Link\n    } @else {\n      Add Link\n    }</h3>\n  <ngs-dialog-content>\n    <div class=\"pt-4\">\n      <ngs-form-field class=\"w-full\">\n        <ngs-label>Paste Link</ngs-label>\n        <input name=\"linkUrl\" ngsInput [(ngModel)]=\"linkUrl\">\n      </ngs-form-field>\n    </div>\n  </ngs-dialog-content>\n  <div ngs-dialog-actions align=\"end\">\n    <button ngsButton (click)=\"_onNoClick()\">Cancel</button>\n    <button type=\"submit\" ngsButton=\"filled\" color=\"primary\"\n            cdkFocusInitial [disabled]=\"!linkUrl.trim() || null\">\n      @if (isUpdate) {\n        Save\n      } @else {\n        Add link\n      }\n    </button>\n  </div>\n</form>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TextEditorCommandEditLinkDirective {
    _destroyRef = inject(DestroyRef);
    _dialog = inject(Dialog);
    textEditor = inject(TEXT_EDITOR);
    setLinkActive = false;
    onClick() {
        this.setLinkActive = true;
        const dialogRef = this._dialog.open(LinkDialog, {
            data: {
                linkUrl: this.textEditor.api.editor().getAttributes('link').href
            }
        });
        dialogRef
            .afterClosed()
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe((linkUrl) => {
            this.setLinkActive = false;
            if (typeof linkUrl === 'undefined') {
                return;
            }
            this._setLink(linkUrl);
        });
    }
    _setLink(url) {
        // cancelled
        if (url === null) {
            return;
        }
        // empty
        if (url === '') {
            this.textEditor.api.editor()
                .chain()
                .focus()
                .extendMarkRange('link')
                .unsetLink()
                .run();
            return;
        }
        // update link
        this.textEditor.api.editor()
            .chain()
            .focus()
            .extendMarkRange('link')
            .setLink({ href: url })
            .run();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandEditLinkDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandEditLinkDirective, isStandalone: true, selector: "[ngsTextEditorCommandEditLink]", host: { listeners: { "click": "onClick()" }, properties: { "class.button": "true" } }, exportAs: ["ngsTextEditorCommandEditLink"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandEditLinkDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandEditLink]',
                    exportAs: 'ngsTextEditorCommandEditLink',
                    host: {
                        '[class.button]': 'true',
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandImageDirective {
    textEditor = inject(TEXT_EDITOR);
    onImageSelected(event) {
        const file = event.files[0];
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const src = reader.result;
            this.textEditor.api.editor().chain().focus().addImageUploadingPlaceholder({ src, file }).run();
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandImageDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandImageDirective, isStandalone: true, selector: "[ngsTextEditorCommandImage]", host: { listeners: { "fileSelected": "onImageSelected($event)" }, properties: { "attr.accept": "\"image/*\"" } }, exportAs: ["ngsTextEditorCommandImage"], hostDirectives: [{ directive: i1$1.UploadTriggerDirective, outputs: ["fileSelected", "fileSelected"] }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandImageDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandImage]',
                    exportAs: 'ngsTextEditorCommandImage',
                    hostDirectives: [
                        {
                            directive: UploadTriggerDirective,
                            outputs: ['fileSelected']
                        }
                    ],
                    host: {
                        '[attr.accept]': '"image/*"',
                        '(fileSelected)': `onImageSelected($event)`
                    }
                }]
        }] });

class TextEditorCommandItalicDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleItalic');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandItalicDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandItalicDirective, isStandalone: true, selector: "[ngsTextEditorCommandItalic]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleItalic')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('italic')" } }, exportAs: ["ngsTextEditorCommandItalic"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandItalicDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandItalic]',
                    exportAs: 'ngsTextEditorCommandItalic',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleItalic')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('italic')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandDirective, isStandalone: true, selector: "[ngsTextEditorCommand]", host: { properties: { "class.button": "true" } }, exportAs: ["ngsTextEditorCommand"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommand]',
                    exportAs: 'ngsTextEditorCommand',
                    host: {
                        '[class.button]': 'true'
                    }
                }]
        }] });

class YoutubeDialog {
    _dialogRef = inject(DialogRef);
    _data = inject(DIALOG_DATA);
    linkUrl = this._data.linkUrl || '';
    isUpdate = !!this._data.linkUrl;
    onSubmit() {
        this._dialogRef.close(this.linkUrl);
    }
    _onNoClick() {
        this._dialogRef.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: YoutubeDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: YoutubeDialog, isStandalone: true, selector: "ngs-youtube", exportAs: ["ngsYoutube"], ngImport: i0, template: "<form class=\"w-[500px]\" (ngSubmit)=\"onSubmit()\">\n  <h3 ngs-dialog-title>\n    @if (isUpdate) {\n      Update Youtube\n    } @else {\n      Add Youtube\n    }\n  </h3>\n  <ngs-dialog-content>\n    <div class=\"pt-4\">\n      <ngs-form-field class=\"w-full\">\n        <ngs-label>Paste Url</ngs-label>\n        <input name=\"linkUrl\" ngsInput [(ngModel)]=\"linkUrl\">\n      </ngs-form-field>\n    </div>\n  </ngs-dialog-content>\n  <div ngs-dialog-actions align=\"end\">\n    <button ngsButton (click)=\"_onNoClick()\">Cancel</button>\n    <button type=\"submit\" ngsButton=\"filled\" color=\"primary\"\n            cdkFocusInitial [disabled]=\"!linkUrl.trim() || null\">\n      @if (isUpdate) {\n        Save\n      } @else {\n        Add url\n      }\n    </button>\n  </div>\n</form>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "component", type: DialogActions, selector: "ngs-dialog-actions, [ngs-dialog-actions], [ngsDialogActions]", inputs: ["align"] }, { kind: "component", type: DialogContent, selector: "ngs-dialog-content,[ngs-dialog-content],[ngsDialogContent]" }, { kind: "component", type: DialogTitle, selector: "ngs-dialog-title, [ngs-dialog-title], [ngsDialogTitle]", inputs: ["id"], exportAs: ["ngsDialogTitle"] }, { kind: "component", type: FormField, selector: "ngs-form-field", inputs: ["subscriptHiddenIfEmpty"], exportAs: ["ngsFormField"] }, { kind: "directive", type: Input, selector: "input[ngsInput], textarea[ngsInput]", inputs: ["id", "placeholder", "required", "disabled", "readonly", "errorStateMatcher"], exportAs: ["ngsInput"] }, { kind: "component", type: Label, selector: "ngs-label" }, { kind: "ngmodule", type: ReactiveFormsModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: YoutubeDialog, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-youtube', exportAs: 'ngsYoutube', imports: [
                        FormsModule,
                        Button,
                        DialogActions,
                        DialogContent,
                        DialogTitle,
                        FormField,
                        Input,
                        Label,
                        ReactiveFormsModule
                    ], template: "<form class=\"w-[500px]\" (ngSubmit)=\"onSubmit()\">\n  <h3 ngs-dialog-title>\n    @if (isUpdate) {\n      Update Youtube\n    } @else {\n      Add Youtube\n    }\n  </h3>\n  <ngs-dialog-content>\n    <div class=\"pt-4\">\n      <ngs-form-field class=\"w-full\">\n        <ngs-label>Paste Url</ngs-label>\n        <input name=\"linkUrl\" ngsInput [(ngModel)]=\"linkUrl\">\n      </ngs-form-field>\n    </div>\n  </ngs-dialog-content>\n  <div ngs-dialog-actions align=\"end\">\n    <button ngsButton (click)=\"_onNoClick()\">Cancel</button>\n    <button type=\"submit\" ngsButton=\"filled\" color=\"primary\"\n            cdkFocusInitial [disabled]=\"!linkUrl.trim() || null\">\n      @if (isUpdate) {\n        Save\n      } @else {\n        Add url\n      }\n    </button>\n  </div>\n</form>\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class TextEditorCommandYoutubeDirective {
    textEditor = inject(TEXT_EDITOR);
    _dialog = inject(Dialog);
    _destroyRef = inject(DestroyRef);
    onClick() {
        const dialogRef = this._dialog.open(YoutubeDialog, {
            data: {
                linkUrl: this.textEditor.api.editor().getAttributes('iframe').src
            }
        });
        dialogRef
            .afterClosed()
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe((linkUrl) => {
            if (typeof linkUrl === 'undefined') {
                return;
            }
            this.textEditor.api.editor().commands.setYoutubeVideo({
                src: linkUrl
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandYoutubeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandYoutubeDirective, isStandalone: true, selector: "[ngsTextEditorCommandYoutube]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleBlockquote')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('blockquote')" } }, exportAs: ["ngsTextEditorCommandYoutube"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandYoutubeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandYoutube]',
                    exportAs: 'ngsTextEditorCommandYoutube',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleBlockquote')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('blockquote')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandUnsetLinkDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.editor().commands.unsetLink();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandUnsetLinkDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandUnsetLinkDirective, isStandalone: true, selector: "[ngsTextEditorCommandUnsetLink]", host: { listeners: { "click": "onClick()" }, properties: { "class.button": "true" } }, exportAs: ["ngsTextEditorCommandUnsetLink"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandUnsetLinkDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandUnsetLink]',
                    exportAs: 'ngsTextEditorCommandUnsetLink',
                    host: {
                        '[class.button]': 'true',
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandStrikeDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleStrike');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandStrikeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandStrikeDirective, isStandalone: true, selector: "[ngsTextEditorCommandStrike]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleStrike')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('strike')" } }, exportAs: ["ngsTextEditorCommandStrike"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandStrikeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandStrike]',
                    exportAs: 'ngsTextEditorCommandStrike',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleStrike')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('strike')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandOrderedListDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.runCommand('toggleOrderedList');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandOrderedListDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandOrderedListDirective, isStandalone: true, selector: "[ngsTextEditorCommandOrderedList]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleOrderedList')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('orderedList')" } }, exportAs: ["ngsTextEditorCommandOrderedList"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandOrderedListDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandOrderedList]',
                    exportAs: 'ngsTextEditorCommandOrderedList',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleOrderedList')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('orderedList')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandLinkDirective {
    _destroyRef = inject(DestroyRef);
    _dialog = inject(Dialog);
    textEditor = inject(TEXT_EDITOR);
    setLinkActive = false;
    onClick() {
        this.setLinkActive = true;
        const dialogRef = this._dialog.open(LinkDialog, {
            data: {
                linkUrl: this.textEditor.api.editor().getAttributes('link').href
            }
        });
        dialogRef
            .afterClosed()
            .pipe(takeUntilDestroyed(this._destroyRef))
            .subscribe((linkUrl) => {
            this.setLinkActive = false;
            if (typeof linkUrl === 'undefined') {
                return;
            }
            this._setLink(linkUrl);
        });
    }
    _setLink(url) {
        // cancelled
        if (url === null) {
            return;
        }
        // empty
        if (url === '') {
            this.textEditor.api.editor()
                .chain()
                .focus()
                .extendMarkRange('link')
                .unsetLink()
                .run();
            return;
        }
        // update link
        this.textEditor.api.editor()
            .chain()
            .focus()
            .extendMarkRange('link')
            .setLink({ href: url })
            .run();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandLinkDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandLinkDirective, isStandalone: true, selector: "[ngsTextEditorCommandLink]", host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "(textEditor && textEditor.api.isCommandDisabled('toggleLink')) ? '' : null", "class.active": "textEditor && textEditor.api.isActive('link')" } }, exportAs: ["ngsTextEditorCommandLink"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandLinkDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandLink]',
                    exportAs: 'ngsTextEditorCommandLink',
                    host: {
                        '[attr.disabled]': `(textEditor && textEditor.api.isCommandDisabled('toggleLink')) ? '' : null`,
                        '[class.active]': `textEditor && textEditor.api.isActive('link')`,
                        '(click)': `onClick()`
                    }
                }]
        }] });

class TextEditorCommandHeadingDirective {
    textEditor = inject(TEXT_EDITOR);
    level = input.required({ ...(ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    get isActive() {
        return !!(this.textEditor && this.textEditor.api.isActive('heading', { level: this.level() }));
    }
    get isDisabled() {
        return !!(this.textEditor && this.textEditor.api.isCommandDisabled('toggleHeading', { level: this.level() }));
    }
    onClick() {
        this.textEditor.api.runCommand('toggleHeading', { level: this.level() });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandHeadingDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.4", type: TextEditorCommandHeadingDirective, isStandalone: true, selector: "[ngsTextEditorCommandHeading]", inputs: { level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: true, transformFunction: null } }, host: { listeners: { "click": "onClick()" }, properties: { "attr.disabled": "isDisabled ? '' : null", "class.active": "isActive" } }, exportAs: ["ngsTextEditorCommandHeading"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandHeadingDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandHeading]',
                    exportAs: 'ngsTextEditorCommandHeading',
                    host: {
                        '[attr.disabled]': `isDisabled ? '' : null`,
                        '[class.active]': `isActive`,
                        '(click)': `onClick()`
                    }
                }]
        }], propDecorators: { level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: true }] }] } });

class TextEditorCommandHorizontalRuleDirective {
    textEditor = inject(TEXT_EDITOR);
    onClick() {
        this.textEditor.api.editor().chain().focus().setHorizontalRule().run();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandHorizontalRuleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: TextEditorCommandHorizontalRuleDirective, isStandalone: true, selector: "[ngsTextEditorCommandHorizontalRule]", host: { listeners: { "click": "onClick()" }, properties: { "class.button": "true" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: TextEditorCommandHorizontalRuleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsTextEditorCommandHorizontalRule]',
                    host: {
                        '[class.button]': 'true',
                        '(click)': `onClick()`
                    }
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { TEXT_EDITOR, TEXT_EDITOR_BUBBLE_MENU, TextEditor, TextEditorBubbleMenu, TextEditorCommandBlockquoteDirective, TextEditorCommandBoldDirective, TextEditorCommandBulletListDirective, TextEditorCommandCodeBlockDirective, TextEditorCommandCodeDirective, TextEditorCommandDirective, TextEditorCommandEditLinkDirective, TextEditorCommandHeadingDirective, TextEditorCommandHorizontalRuleDirective, TextEditorCommandImageDirective, TextEditorCommandItalicDirective, TextEditorCommandLinkDirective, TextEditorCommandOrderedListDirective, TextEditorCommandStrikeDirective, TextEditorCommandUnsetLinkDirective, TextEditorCommandYoutubeDirective, TextEditorDivider, TextEditorFloatingMenu, TextEditorToolbar };
//# sourceMappingURL=ngstarter-components-text-editor.mjs.map
