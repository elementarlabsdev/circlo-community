import * as i0 from '@angular/core';
import { input, booleanAttribute, Component, inject, ElementRef, Renderer2, Directive } from '@angular/core';

class CardOverlay {
    withTranslate = input(false, { ...(ngDevMode ? { debugName: "withTranslate" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    withBlur = input(false, { ...(ngDevMode ? { debugName: "withBlur" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardOverlay, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: CardOverlay, isStandalone: true, selector: "ngs-card-overlay", inputs: { withTranslate: { classPropertyName: "withTranslate", publicName: "withTranslate", isSignal: true, isRequired: false, transformFunction: null }, withBlur: { classPropertyName: "withBlur", publicName: "withBlur", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.with-translate": "withTranslate()", "class.with-blur": "withBlur()", "class.is-disabled": "disabled()" }, classAttribute: "ngs-card-overlay" }, exportAs: ["ngsCardOverlay"], ngImport: i0, template: "<div class=\"background\"></div>\n<div class=\"content\">\n  <ng-content/>\n</div>\n", styles: [":host{display:flex;align-items:center;justify-content:center;position:absolute;inset:0;z-index:1;border-radius:inherit}:host .background{background:#0000004d;position:absolute;inset:0;z-index:0;opacity:0;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s;border-radius:inherit}:host .content{z-index:1;opacity:0;border-radius:inherit}:host.with-translate .background{transition:all .15s cubic-bezier(.4,0,.2,1)}:host.with-blur .background{-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}:host.is-disabled{z-index:-1}:host-context(.ngs-card-overlay-container:hover):not(.is-disabled) .background,:host-context(.ngs-card-overlay-container:hover):not(.is-disabled) .content{opacity:100%}:host-context(.ngs-card-overlay-container:hover):not(.is-disabled).with-translate .background{transition:all .15s cubic-bezier(.4,0,.2,1)}:host-context(html.dark) .background{background:#fff3}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardOverlay, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-card-overlay', exportAs: 'ngsCardOverlay', imports: [], host: {
                        'class': 'ngs-card-overlay',
                        '[class.with-translate]': 'withTranslate()',
                        '[class.with-blur]': 'withBlur()',
                        '[class.is-disabled]': 'disabled()',
                    }, template: "<div class=\"background\"></div>\n<div class=\"content\">\n  <ng-content/>\n</div>\n", styles: [":host{display:flex;align-items:center;justify-content:center;position:absolute;inset:0;z-index:1;border-radius:inherit}:host .background{background:#0000004d;position:absolute;inset:0;z-index:0;opacity:0;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1);transition-duration:.15s;border-radius:inherit}:host .content{z-index:1;opacity:0;border-radius:inherit}:host.with-translate .background{transition:all .15s cubic-bezier(.4,0,.2,1)}:host.with-blur .background{-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}:host.is-disabled{z-index:-1}:host-context(.ngs-card-overlay-container:hover):not(.is-disabled) .background,:host-context(.ngs-card-overlay-container:hover):not(.is-disabled) .content{opacity:100%}:host-context(.ngs-card-overlay-container:hover):not(.is-disabled).with-translate .background{transition:all .15s cubic-bezier(.4,0,.2,1)}:host-context(html.dark) .background{background:#fff3}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { withTranslate: [{ type: i0.Input, args: [{ isSignal: true, alias: "withTranslate", required: false }] }], withBlur: [{ type: i0.Input, args: [{ isSignal: true, alias: "withBlur", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

class CardOverlayContainerDirective {
    _elementRef = inject(ElementRef);
    _renderer = inject(Renderer2);
    ngOnInit() {
        const nativeElement = this._elementRef.nativeElement;
        this._renderer.setStyle(nativeElement, 'position', 'relative');
        this._renderer.setStyle(nativeElement, 'overflow', 'hidden');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardOverlayContainerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: CardOverlayContainerDirective, isStandalone: true, selector: "[ngsCardOverlayContainer]", host: { classAttribute: "ngs-card-overlay-container" }, exportAs: ["ngsCardOverlayContainer"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CardOverlayContainerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsCardOverlayContainer]',
                    exportAs: 'ngsCardOverlayContainer',
                    standalone: true,
                    host: {
                        'class': 'ngs-card-overlay-container',
                    }
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { CardOverlay, CardOverlayContainerDirective };
//# sourceMappingURL=ngstarter-components-card-overlay.mjs.map
