import * as i0 from '@angular/core';
import { input, booleanAttribute, ChangeDetectionStrategy, Component, inject, ElementRef, Directive, numberAttribute, contentChildren, output, forwardRef, ChangeDetectorRef, model } from '@angular/core';
import * as i1 from '@ngstarter/components/core';
import { Ripple } from '@ngstarter/components/core';
import { SelectionModel } from '@angular/cdk/collections';
import { Checkbox } from '@ngstarter/components/checkbox';
import { RadioButton } from '@ngstarter/components/radio';

class List {
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disableRipple = input(false, { ...(ngDevMode ? { debugName: "disableRipple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: List, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.4", type: List, isStandalone: true, selector: "ngs-list", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, disableRipple: { classPropertyName: "disableRipple", publicName: "disableRipple", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-disabled": "disabled()", "class.ngs-list-disabled": "disabled()" }, classAttribute: "ngs-list" }, exportAs: ["ngsList"], ngImport: i0, template: "<ng-content />\n", styles: [":host{--ngs-list-padding: calc(var(--spacing, .25rem) * 3) 0;--ngs-list-item-padding: calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-list-item-min-height: calc(var(--spacing, .25rem) * 12);--ngs-list-item-hover-bg: var(--nav-item-hover-bg);--ngs-list-item-active-bg: var(--nav-item-active-bg);--ngs-list-item-disabled-opacity: .38;--ngs-list-item-title-font-size: 1rem;--ngs-list-item-font-size: var(--nav-item-font-size);--ngs-list-item-gap: calc(var(--spacing, .25rem) * 2);--ngs-list-item-radius: var(--nav-item-radius);display:block;padding:var(--ngs-list-padding)}:host.ngs-list-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: List, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-list', exportAs: 'ngsList', host: {
                        'class': 'ngs-list',
                        '[attr.aria-disabled]': 'disabled()',
                        '[class.ngs-list-disabled]': 'disabled()',
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: [":host{--ngs-list-padding: calc(var(--spacing, .25rem) * 3) 0;--ngs-list-item-padding: calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-list-item-min-height: calc(var(--spacing, .25rem) * 12);--ngs-list-item-hover-bg: var(--nav-item-hover-bg);--ngs-list-item-active-bg: var(--nav-item-active-bg);--ngs-list-item-disabled-opacity: .38;--ngs-list-item-title-font-size: 1rem;--ngs-list-item-font-size: var(--nav-item-font-size);--ngs-list-item-gap: calc(var(--spacing, .25rem) * 2);--ngs-list-item-radius: var(--nav-item-radius);display:block;padding:var(--ngs-list-padding)}:host.ngs-list-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], disableRipple: [{ type: i0.Input, args: [{ isSignal: true, alias: "disableRipple", required: false }] }] } });

class ActionList extends List {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ActionList, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: ActionList, isStandalone: true, selector: "ngs-action-list", host: { properties: { "attr.aria-disabled": "disabled" }, classAttribute: "ngs-action-list ngs-list" }, providers: [
            { provide: List, useExisting: ActionList }
        ], exportAs: ["ngsActionList"], usesInheritance: true, ngImport: i0, template: "<ng-content />\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ActionList, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-action-list', exportAs: 'ngsActionList', host: {
                        'class': 'ngs-action-list ngs-list',
                        '[attr.aria-disabled]': 'disabled',
                    }, providers: [
                        { provide: List, useExisting: ActionList }
                    ], standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: ["/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class NavList extends List {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NavList, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.4", type: NavList, isStandalone: true, selector: "ngs-nav-list", host: { attributes: { "role": "navigation" }, properties: { "attr.aria-disabled": "disabled()" }, classAttribute: "ngs-nav-list" }, providers: [
            { provide: List, useExisting: NavList }
        ], exportAs: ["ngsNavList"], usesInheritance: true, ngImport: i0, template: "<ng-content />\n", styles: [":host{--ngs-list-padding: calc(var(--spacing, .25rem) * 3) 0;--ngs-list-item-padding: calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-list-item-min-height: calc(var(--spacing, .25rem) * 12);--ngs-list-item-hover-bg: var(--nav-item-hover-bg);--ngs-list-item-active-bg: var(--nav-item-active-bg);--ngs-list-item-disabled-opacity: .38;--ngs-list-item-title-font-size: 1rem;--ngs-list-item-font-size: var(--nav-item-font-size);--ngs-list-item-gap: calc(var(--spacing, .25rem) * 2);--ngs-list-item-radius: var(--nav-item-radius);display:block;padding:var(--ngs-list-padding)}:host.ngs-list-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: NavList, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-nav-list', exportAs: 'ngsNavList', host: {
                        'class': 'ngs-nav-list',
                        'role': 'navigation',
                        '[attr.aria-disabled]': 'disabled()',
                    }, providers: [
                        { provide: List, useExisting: NavList }
                    ], standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: [":host{--ngs-list-padding: calc(var(--spacing, .25rem) * 3) 0;--ngs-list-item-padding: calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-list-item-min-height: calc(var(--spacing, .25rem) * 12);--ngs-list-item-hover-bg: var(--nav-item-hover-bg);--ngs-list-item-active-bg: var(--nav-item-active-bg);--ngs-list-item-disabled-opacity: .38;--ngs-list-item-title-font-size: 1rem;--ngs-list-item-font-size: var(--nav-item-font-size);--ngs-list-item-gap: calc(var(--spacing, .25rem) * 2);--ngs-list-item-radius: var(--nav-item-radius);display:block;padding:var(--ngs-list-padding)}:host.ngs-list-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }] });

class ListItemAvatar {
    _elementRef = inject(ElementRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemAvatar, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: ListItemAvatar, isStandalone: true, selector: "[ngsListItemAvatar]", host: { classAttribute: "ngs-list-item-avatar" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemAvatar, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsListItemAvatar]',
                    standalone: true,
                    host: {
                        'class': 'ngs-list-item-avatar',
                    },
                }]
        }] });

class ListItemIcon {
    _elementRef = inject(ElementRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemIcon, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: ListItemIcon, isStandalone: true, selector: "[ngsListItemIcon]", host: { classAttribute: "ngs-list-item-icon" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemIcon, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsListItemIcon]',
                    standalone: true,
                    host: {
                        'class': 'ngs-list-item-icon',
                    },
                }]
        }] });

class ListItemTitle {
    _elementRef = inject(ElementRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemTitle, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: ListItemTitle, isStandalone: true, selector: "[ngsListItemTitle]", host: { classAttribute: "ngs-list-item-title" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsListItemTitle]',
                    standalone: true,
                    host: {
                        'class': 'ngs-list-item-title',
                    },
                }]
        }] });

class ListItemLine {
    _elementRef = inject(ElementRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemLine, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: ListItemLine, isStandalone: true, selector: "[ngsListItemLine], [ngsLine]", host: { classAttribute: "ngs-list-item-line" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemLine, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsListItemLine], [ngsLine]',
                    standalone: true,
                    host: {
                        'class': 'ngs-list-item-line',
                    },
                }]
        }] });

class ListItemMeta {
    _elementRef = inject(ElementRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemMeta, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: ListItemMeta, isStandalone: true, selector: "[ngsListItemMeta]", host: { classAttribute: "ngs-list-item-meta" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItemMeta, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsListItemMeta]',
                    standalone: true,
                    host: {
                        'class': 'ngs-list-item-meta',
                    },
                }]
        }] });

class ListItem {
    _list = inject(List, { optional: true });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    lines = input(null, { ...(ngDevMode ? { debugName: "lines" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    _avatars = contentChildren(ListItemAvatar, { ...(ngDevMode ? { debugName: "_avatars" } : /* istanbul ignore next */ {}), descendants: true });
    _icons = contentChildren(ListItemIcon, { ...(ngDevMode ? { debugName: "_icons" } : /* istanbul ignore next */ {}), descendants: true });
    _titles = contentChildren(ListItemTitle, { ...(ngDevMode ? { debugName: "_titles" } : /* istanbul ignore next */ {}), descendants: true });
    _lines = contentChildren(ListItemLine, { ...(ngDevMode ? { debugName: "_lines" } : /* istanbul ignore next */ {}), descendants: true });
    _meta = contentChildren(ListItemMeta, { ...(ngDevMode ? { debugName: "_meta" } : /* istanbul ignore next */ {}), descendants: true });
    get disableRipple() {
        return this.disabled() || this._list?.disableRipple();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: ListItem, isStandalone: true, selector: "ngs-list-item, a[ngs-list-item], button[ngs-list-item]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, lines: { classPropertyName: "lines", publicName: "lines", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.ngs-list-item-disabled": "disabled()", "attr.aria-disabled": "disabled()", "class.ngs-list-item-with-avatar": "_avatars().length > 0", "class.ngs-list-item-with-icon": "_icons().length > 0", "class.ngs-list-item-with-meta": "_meta().length > 0", "attr.data-lines": "lines()" }, classAttribute: "ngs-list-item" }, queries: [{ propertyName: "_avatars", predicate: ListItemAvatar, descendants: true, isSignal: true }, { propertyName: "_icons", predicate: ListItemIcon, descendants: true, isSignal: true }, { propertyName: "_titles", predicate: ListItemTitle, descendants: true, isSignal: true }, { propertyName: "_lines", predicate: ListItemLine, descendants: true, isSignal: true }, { propertyName: "_meta", predicate: ListItemMeta, descendants: true, isSignal: true }], exportAs: ["ngsListItem"], hostDirectives: [{ directive: i1.Ripple, inputs: ["ngsRippleDisabled", "disableRipple"] }], ngImport: i0, template: "<ng-content select=\"[ngsListItemAvatar],[ngsListItemIcon]\" />\n\n<span class=\"ngs-list-item-content\">\n  <div class=\"ngs-list-item-title\">\n    <ng-content select=\"[ngsListItemTitle]\" />\n  </div>\n  <div class=\"ngs-list-item-line\">\n    <ng-content select=\"[ngsListItemLine],[ngsLine]\" />\n  </div>\n  <span class=\"ngs-list-item-unscoped-content\">\n    <ng-content />\n  </span>\n</span>\n\n<ng-content select=\"[ngsListItemMeta]\" />\n", styles: [":host{display:flex;align-items:center;padding:var(--ngs-list-item-padding);min-height:var(--ngs-list-item-min-height);cursor:pointer;position:relative;overflow:hidden;box-sizing:border-box;text-decoration:none;gap:var(--ngs-list-item-gap);border-radius:var(--ngs-list-item-radius);color:var(--nav-item-color);font-size:var(--ngs-list-item-font-size)}:host:not(.is-active):hover{color:var(--nav-item-hover-color);background:var(--ngs-list-item-hover-bg)}:host.is-active{background:var(--ngs-list-item-active-bg);color:var(--ngs-list-item-active-color)}:host.ngs-list-item-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}:host .ngs-list-item-content{display:flex;flex-direction:column;flex:1;overflow:hidden}:host .ngs-list-item-title{font-size:var(--ngs-list-item-title-font-size);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-title:empty{display:none}:host .ngs-list-item-line{font-size:var(--ngs-list-item-line-font-size);color:var(--ngs-list-item-line-color);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-line:empty{display:none}:host .ngs-list-item-avatar{flex-shrink:0}:host .ngs-list-item-meta{flex-shrink:0;margin-left:auto}:host .ngs-subheader{display:block;padding:16px;font-size:14px;font-weight:500;color:var(--ngs-list-item-line-color)}:host[data-lines=\"2\"]{--ngs-list-item-min-height: 72px}:host[data-lines=\"3\"]{--ngs-list-item-min-height: 88px}:host.ngs-list-item-with-avatar{--ngs-list-item-min-height: 56px}:host.ngs-list-item-with-icon{--ngs-list-item-min-height: 48px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListItem, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-list-item, a[ngs-list-item], button[ngs-list-item]', exportAs: 'ngsListItem', hostDirectives: [
                        {
                            directive: Ripple,
                            inputs: ['ngsRippleDisabled: disableRipple']
                        }
                    ], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-list-item',
                        '[class.ngs-list-item-disabled]': 'disabled()',
                        '[attr.aria-disabled]': 'disabled()',
                        '[class.ngs-list-item-with-avatar]': '_avatars().length > 0',
                        '[class.ngs-list-item-with-icon]': '_icons().length > 0',
                        '[class.ngs-list-item-with-meta]': '_meta().length > 0',
                        '[attr.data-lines]': 'lines()',
                    }, template: "<ng-content select=\"[ngsListItemAvatar],[ngsListItemIcon]\" />\n\n<span class=\"ngs-list-item-content\">\n  <div class=\"ngs-list-item-title\">\n    <ng-content select=\"[ngsListItemTitle]\" />\n  </div>\n  <div class=\"ngs-list-item-line\">\n    <ng-content select=\"[ngsListItemLine],[ngsLine]\" />\n  </div>\n  <span class=\"ngs-list-item-unscoped-content\">\n    <ng-content />\n  </span>\n</span>\n\n<ng-content select=\"[ngsListItemMeta]\" />\n", styles: [":host{display:flex;align-items:center;padding:var(--ngs-list-item-padding);min-height:var(--ngs-list-item-min-height);cursor:pointer;position:relative;overflow:hidden;box-sizing:border-box;text-decoration:none;gap:var(--ngs-list-item-gap);border-radius:var(--ngs-list-item-radius);color:var(--nav-item-color);font-size:var(--ngs-list-item-font-size)}:host:not(.is-active):hover{color:var(--nav-item-hover-color);background:var(--ngs-list-item-hover-bg)}:host.is-active{background:var(--ngs-list-item-active-bg);color:var(--ngs-list-item-active-color)}:host.ngs-list-item-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}:host .ngs-list-item-content{display:flex;flex-direction:column;flex:1;overflow:hidden}:host .ngs-list-item-title{font-size:var(--ngs-list-item-title-font-size);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-title:empty{display:none}:host .ngs-list-item-line{font-size:var(--ngs-list-item-line-font-size);color:var(--ngs-list-item-line-color);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-line:empty{display:none}:host .ngs-list-item-avatar{flex-shrink:0}:host .ngs-list-item-meta{flex-shrink:0;margin-left:auto}:host .ngs-subheader{display:block;padding:16px;font-size:14px;font-weight:500;color:var(--ngs-list-item-line-color)}:host[data-lines=\"2\"]{--ngs-list-item-min-height: 72px}:host[data-lines=\"3\"]{--ngs-list-item-min-height: 88px}:host.ngs-list-item-with-avatar{--ngs-list-item-min-height: 56px}:host.ngs-list-item-with-icon{--ngs-list-item-min-height: 48px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], lines: [{ type: i0.Input, args: [{ isSignal: true, alias: "lines", required: false }] }], _avatars: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemAvatar), { ...{ descendants: true }, isSignal: true }] }], _icons: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemIcon), { ...{ descendants: true }, isSignal: true }] }], _titles: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemTitle), { ...{ descendants: true }, isSignal: true }] }], _lines: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemLine), { ...{ descendants: true }, isSignal: true }] }], _meta: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemMeta), { ...{ descendants: true }, isSignal: true }] }] } });

class SelectionList extends List {
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selectionChange = output();
    options = contentChildren(forwardRef(() => ListOption), { ...(ngDevMode ? { debugName: "options" } : /* istanbul ignore next */ {}), descendants: true });
    selectedOptions;
    constructor() {
        super();
    }
    ngOnInit() {
        this.selectedOptions = new SelectionModel(this.multiple());
        this.selectedOptions.changed.subscribe(event => {
            if (this.multiple()) {
                event.added.forEach(option => option.selected.set(true));
                event.removed.forEach(option => option.selected.set(false));
            }
            else {
                this.options().forEach(option => {
                    option.selected.set(this.selectedOptions.isSelected(option));
                });
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SelectionList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.4", type: SelectionList, isStandalone: true, selector: "ngs-selection-list", inputs: { multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange" }, host: { attributes: { "role": "listbox" }, properties: { "attr.aria-disabled": "disabled()", "attr.aria-multiselectable": "multiple()" }, classAttribute: "ngs-selection-list ngs-list" }, providers: [
            { provide: List, useExisting: SelectionList }
        ], queries: [{ propertyName: "options", predicate: i0.forwardRef(() => ListOption), descendants: true, isSignal: true }], exportAs: ["ngsSelectionList"], usesInheritance: true, ngImport: i0, template: "<ng-content />\n", styles: [":host{--ngs-list-padding: calc(var(--spacing, .25rem) * 3) 0;--ngs-list-item-padding: calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-list-item-min-height: calc(var(--spacing, .25rem) * 12);--ngs-list-item-hover-bg: var(--nav-item-hover-bg);--ngs-list-item-active-bg: var(--nav-item-active-bg);--ngs-list-item-disabled-opacity: .38;--ngs-list-item-title-font-size: 1rem;--ngs-list-item-font-size: var(--nav-item-font-size);--ngs-list-item-gap: calc(var(--spacing, .25rem) * 2);--ngs-list-item-radius: var(--nav-item-radius);display:block;padding:var(--ngs-list-padding)}:host.ngs-list-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n", "/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: SelectionList, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-selection-list', exportAs: 'ngsSelectionList', host: {
                        'class': 'ngs-selection-list ngs-list',
                        '[attr.aria-disabled]': 'disabled()',
                        'role': 'listbox',
                        '[attr.aria-multiselectable]': 'multiple()',
                    }, providers: [
                        { provide: List, useExisting: SelectionList }
                    ], standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content />\n", styles: [":host{--ngs-list-padding: calc(var(--spacing, .25rem) * 3) 0;--ngs-list-item-padding: calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-list-item-min-height: calc(var(--spacing, .25rem) * 12);--ngs-list-item-hover-bg: var(--nav-item-hover-bg);--ngs-list-item-active-bg: var(--nav-item-active-bg);--ngs-list-item-disabled-opacity: .38;--ngs-list-item-title-font-size: 1rem;--ngs-list-item-font-size: var(--nav-item-font-size);--ngs-list-item-gap: calc(var(--spacing, .25rem) * 2);--ngs-list-item-radius: var(--nav-item-radius);display:block;padding:var(--ngs-list-padding)}:host.ngs-list-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n", "/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], options: [{ type: i0.ContentChildren, args: [forwardRef(() => ListOption), { ...{ descendants: true }, isSignal: true }] }] } });

class ListOption extends ListItem {
    _selectionList = inject(SelectionList);
    _changeDetectorRef = inject(ChangeDetectorRef);
    _avatars = contentChildren(ListItemAvatar, { ...(ngDevMode ? { debugName: "_avatars" } : /* istanbul ignore next */ {}), descendants: true });
    _icons = contentChildren(ListItemIcon, { ...(ngDevMode ? { debugName: "_icons" } : /* istanbul ignore next */ {}), descendants: true });
    _meta = contentChildren(ListItemMeta, { ...(ngDevMode ? { debugName: "_meta" } : /* istanbul ignore next */ {}), descendants: true });
    selected = model(false, ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    value = input(...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    selectedChange = output();
    _toggle() {
        if (this.disabled()) {
            return;
        }
        if (this._selectionList.multiple()) {
            this.selected.set(!this.selected());
            this._selectionList.selectedOptions.toggle(this);
        }
        else {
            this.selected.set(true);
            this._selectionList.selectedOptions.select(this);
        }
        this.selectedChange.emit(this.selected());
        this._selectionList.selectionChange.emit({
            option: this,
            selected: this.selected()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListOption, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: ListOption, isStandalone: true, selector: "ngs-list-option", inputs: { selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selected: "selectedChange", selectedChange: "selectedChange" }, host: { attributes: { "role": "option" }, listeners: { "click": "_toggle()" }, properties: { "class.ngs-list-item-disabled": "disabled()", "class.ngs-list-option-selected": "selected()", "attr.aria-selected": "selected()", "attr.aria-disabled": "disabled()", "class.ngs-list-item-with-avatar": "_avatars().length > 0", "class.ngs-list-item-with-icon": "_icons().length > 0", "class.ngs-list-item-with-meta": "_meta().length > 0" }, classAttribute: "ngs-list-option ngs-list-item" }, queries: [{ propertyName: "_avatars", predicate: ListItemAvatar, descendants: true, isSignal: true }, { propertyName: "_icons", predicate: ListItemIcon, descendants: true, isSignal: true }, { propertyName: "_meta", predicate: ListItemMeta, descendants: true, isSignal: true }], exportAs: ["ngsListOption"], usesInheritance: true, ngImport: i0, template: "<ng-content select=\"[ngsListItemAvatar],[ngsListItemIcon]\" />\n\n<span class=\"ngs-list-item-content\">\n  <div class=\"ngs-list-item-title\">\n    <ng-content select=\"[ngsListItemTitle]\" />\n  </div>\n  <div class=\"ngs-list-item-line\">\n    <ng-content select=\"[ngsListItemLine],[ngsLine]\" />\n  </div>\n  <span class=\"ngs-list-item-unscoped-content\">\n    <ng-content />\n  </span>\n</span>\n\n<ng-content select=\"[ngsListItemMeta]\" />\n\n@if (_selectionList.multiple()) {\n  <ngs-checkbox [checked]=\"selected()\" [disabled]=\"disabled()\" />\n} @else {\n  <ngs-radio-button [checked]=\"selected()\" [disabled]=\"disabled()\" />\n}\n", styles: [":host{display:flex;align-items:center;padding:var(--ngs-list-item-padding);min-height:var(--ngs-list-item-min-height);cursor:pointer;position:relative;overflow:hidden;box-sizing:border-box;text-decoration:none;gap:var(--ngs-list-item-gap);border-radius:var(--ngs-list-item-radius);color:var(--nav-item-color);font-size:var(--ngs-list-item-font-size)}:host:not(.is-active):hover{color:var(--nav-item-hover-color);background:var(--ngs-list-item-hover-bg)}:host.is-active{background:var(--ngs-list-item-active-bg);color:var(--ngs-list-item-active-color)}:host.ngs-list-item-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}:host .ngs-list-item-content{display:flex;flex-direction:column;flex:1;overflow:hidden}:host .ngs-list-item-title{font-size:var(--ngs-list-item-title-font-size);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-title:empty{display:none}:host .ngs-list-item-line{font-size:var(--ngs-list-item-line-font-size);color:var(--ngs-list-item-line-color);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-line:empty{display:none}:host .ngs-list-item-avatar{flex-shrink:0}:host .ngs-list-item-meta{flex-shrink:0;margin-left:auto}:host .ngs-subheader{display:block;padding:16px;font-size:14px;font-weight:500;color:var(--ngs-list-item-line-color)}:host[data-lines=\"2\"]{--ngs-list-item-min-height: 72px}:host[data-lines=\"3\"]{--ngs-list-item-min-height: 88px}:host.ngs-list-item-with-avatar{--ngs-list-item-min-height: 56px}:host.ngs-list-item-with-icon{--ngs-list-item-min-height: 48px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n", ":host.ngs-list-option-selected{background:var(--ngs-list-item-active-bg)}:host ngs-checkbox,:host ngs-radio-button{pointer-events:none;flex-shrink:0;margin-left:auto}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Checkbox, selector: "ngs-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["checkedChange", "disabledChange", "indeterminateChange", "change"], exportAs: ["ngsCheckbox"] }, { kind: "component", type: RadioButton, selector: "ngs-radio-button", inputs: ["id", "value", "name", "checked", "disabled"], outputs: ["checkedChange", "change"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: ListOption, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-list-option', exportAs: 'ngsListOption', imports: [
                        Checkbox,
                        RadioButton
                    ], host: {
                        'class': 'ngs-list-option ngs-list-item',
                        '[class.ngs-list-item-disabled]': 'disabled()',
                        '[class.ngs-list-option-selected]': 'selected()',
                        '[attr.aria-selected]': 'selected()',
                        '[attr.aria-disabled]': 'disabled()',
                        'role': 'option',
                        '[class.ngs-list-item-with-avatar]': '_avatars().length > 0',
                        '[class.ngs-list-item-with-icon]': '_icons().length > 0',
                        '[class.ngs-list-item-with-meta]': '_meta().length > 0',
                        '(click)': '_toggle()',
                    }, standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content select=\"[ngsListItemAvatar],[ngsListItemIcon]\" />\n\n<span class=\"ngs-list-item-content\">\n  <div class=\"ngs-list-item-title\">\n    <ng-content select=\"[ngsListItemTitle]\" />\n  </div>\n  <div class=\"ngs-list-item-line\">\n    <ng-content select=\"[ngsListItemLine],[ngsLine]\" />\n  </div>\n  <span class=\"ngs-list-item-unscoped-content\">\n    <ng-content />\n  </span>\n</span>\n\n<ng-content select=\"[ngsListItemMeta]\" />\n\n@if (_selectionList.multiple()) {\n  <ngs-checkbox [checked]=\"selected()\" [disabled]=\"disabled()\" />\n} @else {\n  <ngs-radio-button [checked]=\"selected()\" [disabled]=\"disabled()\" />\n}\n", styles: [":host{display:flex;align-items:center;padding:var(--ngs-list-item-padding);min-height:var(--ngs-list-item-min-height);cursor:pointer;position:relative;overflow:hidden;box-sizing:border-box;text-decoration:none;gap:var(--ngs-list-item-gap);border-radius:var(--ngs-list-item-radius);color:var(--nav-item-color);font-size:var(--ngs-list-item-font-size)}:host:not(.is-active):hover{color:var(--nav-item-hover-color);background:var(--ngs-list-item-hover-bg)}:host.is-active{background:var(--ngs-list-item-active-bg);color:var(--ngs-list-item-active-color)}:host.ngs-list-item-disabled{pointer-events:none;opacity:var(--ngs-list-item-disabled-opacity)}:host .ngs-list-item-content{display:flex;flex-direction:column;flex:1;overflow:hidden}:host .ngs-list-item-title{font-size:var(--ngs-list-item-title-font-size);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-title:empty{display:none}:host .ngs-list-item-line{font-size:var(--ngs-list-item-line-font-size);color:var(--ngs-list-item-line-color);margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}:host .ngs-list-item-line:empty{display:none}:host .ngs-list-item-avatar{flex-shrink:0}:host .ngs-list-item-meta{flex-shrink:0;margin-left:auto}:host .ngs-subheader{display:block;padding:16px;font-size:14px;font-weight:500;color:var(--ngs-list-item-line-color)}:host[data-lines=\"2\"]{--ngs-list-item-min-height: 72px}:host[data-lines=\"3\"]{--ngs-list-item-min-height: 88px}:host.ngs-list-item-with-avatar{--ngs-list-item-min-height: 56px}:host.ngs-list-item-with-icon{--ngs-list-item-min-height: 48px}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n", ":host.ngs-list-option-selected{background:var(--ngs-list-item-active-bg)}:host ngs-checkbox,:host ngs-radio-button{pointer-events:none;flex-shrink:0;margin-left:auto}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { _avatars: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemAvatar), { ...{ descendants: true }, isSignal: true }] }], _icons: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemIcon), { ...{ descendants: true }, isSignal: true }] }], _meta: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => ListItemMeta), { ...{ descendants: true }, isSignal: true }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: false }] }, { type: i0.Output, args: ["selectedChange"] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], selectedChange: [{ type: i0.Output, args: ["selectedChange"] }] } });

class Subheader {
    _elementRef = inject(ElementRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Subheader, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.4", type: Subheader, isStandalone: true, selector: "[ngsSubheader]", host: { classAttribute: "ngs-subheader" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Subheader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngsSubheader]',
                    standalone: true,
                    host: {
                        'class': 'ngs-subheader',
                    },
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ActionList, List, ListItem, ListItemAvatar, ListItemIcon, ListItemLine, ListItemMeta, ListItemTitle, ListOption, NavList, SelectionList, Subheader };
//# sourceMappingURL=ngstarter-components-list.mjs.map
