import * as i0 from '@angular/core';
import { inject, input, booleanAttribute, signal, computed, ChangeDetectionStrategy, Component } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { codeToHtml } from 'shiki';
import { Button } from '@ngstarter/components/button';
import { Icon } from '@ngstarter/components/icon';

const removeDiffPrefix = (node) => {
    if (!node.children || node.children.length === 0)
        return;
    const firstChild = node.children[0];
    if (firstChild.type === 'element' && firstChild.children && firstChild.children.length > 0) {
        const textNode = firstChild.children[0];
        if (textNode.type === 'text' && (textNode.value.startsWith('+') || textNode.value.startsWith('-'))) {
            textNode.value = textNode.value.slice(1);
            if (textNode.value === '' && firstChild.children.length === 1) {
                node.children.shift();
            }
        }
    }
    else if (firstChild.type === 'text' && (firstChild.value.startsWith('+') || firstChild.value.startsWith('-'))) {
        firstChild.value = firstChild.value.slice(1);
        if (firstChild.value === '') {
            node.children.shift();
        }
    }
};
const diffTransformer = {
    line(node, line) {
        if (this.options.lang === 'diff' || this.options.diff) {
            const lineTokens = this.tokens[line - 1];
            const text = lineTokens.map(token => token.content).join('');
            if (text.startsWith('+')) {
                this.addClassToHast(node, 'diff add');
                removeDiffPrefix(node);
            }
            else if (text.startsWith('-')) {
                this.addClassToHast(node, 'diff remove');
                removeDiffPrefix(node);
            }
        }
    }
};
class CodeHighlighter {
    sanitizer = inject(DomSanitizer);
    code = input.required(...(ngDevMode ? [{ debugName: "code" }] : /* istanbul ignore next */ []));
    language = input('none', ...(ngDevMode ? [{ debugName: "language" }] : /* istanbul ignore next */ []));
    theme = input('github-light', ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    title = input(null, ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    appearance = input('bordered', ...(ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []));
    diff = input(false, ...(ngDevMode ? [{ debugName: "diff" }] : /* istanbul ignore next */ []));
    highlightLines = input([], ...(ngDevMode ? [{ debugName: "highlightLines" }] : /* istanbul ignore next */ []));
    showLanguage = input(false, { ...(ngDevMode ? { debugName: "showLanguage" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    showCopyButton = input(false, { ...(ngDevMode ? { debugName: "showCopyButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    content = signal(null, ...(ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []));
    isLoading = signal(false, ...(ngDevMode ? [{ debugName: "isLoading" }] : /* istanbul ignore next */ []));
    displayedLanguage = computed(() => {
        const lang = this.language();
        if (!lang || lang === 'none')
            return '';
        const langMap = {
            '1c': '1C',
            'abap': 'ABAP',
            'actionscript-3': 'ActionScript 3',
            'ada': 'Ada',
            'apache': 'Apache',
            'apex': 'Apex',
            'apl': 'APL',
            'applescript': 'AppleScript',
            'ara': 'Ara',
            'asm': 'Assembly',
            'astro': 'Astro',
            'awk': 'AWK',
            'ballerina': 'Ballerina',
            'bash': 'Bash',
            'sh': 'Bash',
            'batch': 'Batch',
            'berry': 'Berry',
            'bibtex': 'BibTeX',
            'bicep': 'Bicep',
            'blade': 'Blade',
            'c': 'C',
            'cadence': 'Cadence',
            'clarity': 'Clarity',
            'clojure': 'Clojure',
            'clj': 'Clojure',
            'cmake': 'CMake',
            'cobol': 'COBOL',
            'codeql': 'CodeQL',
            'coffee': 'CoffeeScript',
            'cpp': 'C++',
            'csharp': 'C#',
            'cs': 'C#',
            'css': 'CSS',
            'cue': 'CUE',
            'cypher': 'Cypher',
            'd': 'D',
            'dart': 'Dart',
            'dax': 'DAX',
            'diff': 'Diff',
            'docker': 'Docker',
            'dockerfile': 'Dockerfile',
            'dream-maker': 'Dream Maker',
            'elixir': 'Elixir',
            'elm': 'Elm',
            'erb': 'ERB',
            'erlang': 'Erlang',
            'fish': 'Fish',
            'fsharp': 'F#',
            'fs': 'F#',
            'gdresource': 'GDResource',
            'gdscript': 'GDScript',
            'gdshader': 'GDShader',
            'gherkin': 'Gherkin',
            'git-commit': 'Git Commit',
            'git-rebase': 'Git Rebase',
            'glimmer-js': 'Glimmer JS',
            'gljs': 'Glimmer JS',
            'glsl': 'GLSL',
            'gnuplot': 'Gnuplot',
            'go': 'Go',
            'graphql': 'GraphQL',
            'groovy': 'Groovy',
            'hack': 'Hack',
            'haml': 'Haml',
            'handlebars': 'Handlebars',
            'hbs': 'Handlebars',
            'haskell': 'Haskell',
            'hs': 'Haskell',
            'hcl': 'HCL',
            'hjson': 'Hjson',
            'hlsl': 'HLSL',
            'html': 'HTML',
            'http': 'HTTP',
            'imba': 'Imba',
            'ini': 'INI',
            'java': 'Java',
            'javascript': 'JavaScript',
            'js': 'JavaScript',
            'jinja-html': 'Jinja HTML',
            'jjson': 'JJSON',
            'json': 'JSON',
            'json5': 'JSON5',
            'jsonc': 'JSONC',
            'jsonnet': 'Jsonnet',
            'jssm': 'JSSM',
            'jsx': 'JSX',
            'julia': 'Julia',
            'kotlin': 'Kotlin',
            'kt': 'Kotlin',
            'kts': 'Kotlin',
            'kusto': 'Kusto',
            'latex': 'LaTeX',
            'lat': 'LaTeX',
            'tex': 'LaTeX',
            'lean': 'Lean',
            'less': 'Less',
            'liquid': 'Liquid',
            'lisp': 'Lisp',
            'logo': 'Logo',
            'lua': 'Lua',
            'make': 'Make',
            'makefile': 'Makefile',
            'markdown': 'Markdown',
            'md': 'Markdown',
            'marko': 'Marko',
            'matlab': 'MATLAB',
            'mdx': 'MDX',
            'mermaid': 'Mermaid',
            'mipsasm': 'MIPS Assembly',
            'mips': 'MIPS Assembly',
            'mojolicious': 'Mojolicious',
            'move': 'Move',
            'narrat': 'Narrat',
            'nextflow': 'Nextflow',
            'nginx': 'Nginx',
            'nim': 'Nim',
            'nix': 'Nix',
            'objective-c': 'Objective-C',
            'objc': 'Objective-C',
            'objective-cpp': 'Objective-C++',
            'ocaml': 'OCaml',
            'pascal': 'Pascal',
            'perl': 'Perl',
            'pl': 'Perl',
            'php': 'PHP',
            'plsql': 'PL/SQL',
            'postcss': 'PostCSS',
            'powerquery': 'PowerQuery',
            'powershell': 'PowerShell',
            'ps1': 'PowerShell',
            'prisma': 'Prisma',
            'prolog': 'Prolog',
            'proto': 'Protocol Buffers',
            'pug': 'Pug',
            'jade': 'Pug',
            'puppet': 'Puppet',
            'purescript': 'PureScript',
            'python': 'Python',
            'py': 'Python',
            'r': 'R',
            'raku': 'Raku',
            'razor': 'Razor',
            'reg': 'Registry',
            'rel': 'Rel',
            'riscv': 'RISC-V',
            'rst': 'reStructuredText',
            'ruby': 'Ruby',
            'rb': 'Ruby',
            'rust': 'Rust',
            'rs': 'Rust',
            'sas': 'SAS',
            'sass': 'Sass',
            'scala': 'Scala',
            'scheme': 'Scheme',
            'scss': 'SCSS',
            'shaderlab': 'ShaderLab',
            'shader': 'ShaderLab',
            'shell': 'Shell',
            'shellscript': 'Shell',
            'smalltalk': 'Smalltalk',
            'solidity': 'Solidity',
            'sparql': 'SPARQL',
            'sql': 'SQL',
            'ssh-config': 'SSH Config',
            'stata': 'Stata',
            'stylus': 'Stylus',
            'styl': 'Stylus',
            'svelte': 'Svelte',
            'swift': 'Swift',
            'system-verilog': 'SystemVerilog',
            'tasl': 'Tasl',
            'tcl': 'Tcl',
            'terraform': 'Terraform',
            'tf': 'Terraform',
            'toml': 'TOML',
            'tsx': 'TSX',
            'turtle': 'Turtle',
            'twig': 'Twig',
            'typescript': 'TypeScript',
            'ts': 'TypeScript',
            'v': 'V',
            'vb': 'Visual Basic',
            'verilog': 'Verilog',
            'vhdl': 'VHDL',
            'viml': 'VimL',
            'vim': 'VimL',
            'vue': 'Vue',
            'vyper': 'Vyper',
            'wasm': 'WebAssembly',
            'wenyan': 'Wenyan',
            'wgsl': 'WGSL',
            'wolfram': 'Wolfram',
            'xml': 'XML',
            'xsl': 'XSL',
            'yaml': 'YAML',
            'yml': 'YAML',
            'zenscript': 'ZenScript',
            'zig': 'Zig',
            'zsh': 'Zsh',
        };
        return langMap[lang.toLowerCase()] || lang;
    }, ...(ngDevMode ? [{ debugName: "displayedLanguage" }] : /* istanbul ignore next */ []));
    getHighlightTransformer() {
        const highlights = this.highlightLines();
        if (!highlights || (Array.isArray(highlights) && highlights.length === 0)) {
            return {};
        }
        const isHighlighted = (line) => {
            if (Array.isArray(highlights[0])) {
                return highlights.some(([start, end]) => line >= start && line <= end);
            }
            else {
                const [start, end] = highlights;
                return line >= start && line <= end;
            }
        };
        return {
            line(node, line) {
                if (isHighlighted(line)) {
                    this.addClassToHast(node, 'highlighted');
                }
            }
        };
    }
    async ngOnChanges(changes) {
        if (!this.code()) {
            this.content.set(null);
            return;
        }
        this.isLoading.set(true);
        try {
            const highlighted = await codeToHtml(this.code(), {
                lang: this.language(),
                theme: this.theme(),
                transformers: [diffTransformer, this.getHighlightTransformer()],
                diff: this.diff()
            });
            this.content.set(this.sanitizer.bypassSecurityTrustHtml(highlighted));
        }
        catch (e) {
            // Fallback: raw code escaped inside pre
            const escaped = this.code()
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            const fallback = `<pre class="shiki"><code>${escaped}</code></pre>`;
            this.content.set(this.sanitizer.bypassSecurityTrustHtml(fallback));
            console.error('CodeHighlighter error:', e);
        }
        finally {
            this.isLoading.set(false);
        }
    }
    copied = signal(false, ...(ngDevMode ? [{ debugName: "copied" }] : /* istanbul ignore next */ []));
    copyTimeout;
    copyCode() {
        if (this.code()) {
            navigator.clipboard.writeText(this.code());
            this.copied.set(true);
            if (this.copyTimeout) {
                clearTimeout(this.copyTimeout);
            }
            this.copyTimeout = setTimeout(() => {
                this.copied.set(false);
                this.copyTimeout = undefined;
            }, 2000);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CodeHighlighter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: CodeHighlighter, isStandalone: true, selector: "ngs-code-highlighter", inputs: { code: { classPropertyName: "code", publicName: "code", isSignal: true, isRequired: true, transformFunction: null }, language: { classPropertyName: "language", publicName: "language", isSignal: true, isRequired: false, transformFunction: null }, theme: { classPropertyName: "theme", publicName: "theme", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, appearance: { classPropertyName: "appearance", publicName: "appearance", isSignal: true, isRequired: false, transformFunction: null }, diff: { classPropertyName: "diff", publicName: "diff", isSignal: true, isRequired: false, transformFunction: null }, highlightLines: { classPropertyName: "highlightLines", publicName: "highlightLines", isSignal: true, isRequired: false, transformFunction: null }, showLanguage: { classPropertyName: "showLanguage", publicName: "showLanguage", isSignal: true, isRequired: false, transformFunction: null }, showCopyButton: { classPropertyName: "showCopyButton", publicName: "showCopyButton", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.appearance-bordered": "appearance() === \"bordered\"", "class.appearance-none": "appearance() === \"none\"" }, classAttribute: "ngs-code-highlighter not-prose" }, exportAs: ["ngsCodeHighlighter"], usesOnChanges: true, ngImport: i0, template: "<figure>\n  @if (title()) {\n    <figcaption>\n      @if (title()) {\n        <span class=\"title\">{{ title() }}</span>\n      }\n    </figcaption>\n  }\n\n  <div class=\"content relative\">\n    @if (showLanguage()) {\n      <div class=\"languageName\">{{ displayedLanguage() }}</div>\n    }\n\n    @if (showCopyButton()) {\n      <span class=\"absolute top-2 right-2\">\n        <button\n          ngsIconButton\n          (click)=\"copyCode()\"\n        >\n          <ngs-icon\n            [name]=\"copied() ? 'fluent:checkmark-24-regular' : 'fluent:copy-24-regular'\"\n            [class.text-green-500]=\"copied()\"\n          />\n        </button>\n      </span>\n    }\n\n    <div>\n      @if (content()) {\n        <div [innerHTML]=\"content()\"></div>\n      } @else {\n        <div class=\"loading\">Loading\u2026</div>\n      }\n    </div>\n  </div>\n</figure>\n", styles: [":host{--ngs-code-highlighter-bg: var(--color-background);--ngs-code-highlighter-radius: 1rem;--ngs-code-highlighter-padding: calc(var(--spacing, .25rem) * 5);--ngs-code-highlighter-border: 1px solid var(--color-border);--ngs-code-highlighter-title-padding: calc(var(--spacing, .25rem) * 2) calc(var(--spacing, .25rem) * 3) calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-code-highlighter-title-color: var(--color-neutral-500);display:block;margin:calc(var(--spacing, .25rem) * 5) 0;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace}:host figcaption{font-size:.75rem;font-weight:500;padding:var(--ngs-code-highlighter-title-padding);background:var(--ngs-code-highlighter-bg);color:var(--ngs-code-highlighter-title-color);position:relative;z-index:1}:host figcaption:after{content:\"\";position:absolute;left:0;right:0;bottom:-1px;height:1px;background:var(--ngs-code-highlighter-bg)}:host .languageName{font-size:.875rem;font-weight:600;padding:0 calc(var(--spacing, .25rem) * 6);width:max-content;margin-bottom:calc(var(--spacing, .25rem) * 4);margin-top:calc(calc(var(--spacing, .25rem) * 1) * -1);position:relative}:host ::ng-deep pre{line-height:1.75;font-size:.875rem;position:relative;padding:0}:host ::ng-deep pre code{display:grid}:host ::ng-deep pre .line{padding-left:calc(var(--spacing, .25rem) * 6);padding-right:var(--ngs-code-highlighter-padding);min-height:1.75em}:host ::ng-deep pre .line.diff.remove{background-color:color-mix(in srgb,oklch(63.7% .237 25.331),transparent 85%);display:inline-block;width:100%}:host ::ng-deep pre .line.diff.remove:before{content:\"-\";color:#fb2c36;position:absolute;left:calc(var(--spacing, .25rem) * 2)}:host ::ng-deep pre .line.diff.add{background-color:color-mix(in srgb,oklch(72.3% .219 149.579),transparent 85%);display:inline-block;width:100%}:host ::ng-deep pre .line.diff.add:before{content:\"+\";color:#00c65a;color:oklch(72.3% .219 149.579);position:absolute;left:calc(var(--spacing, .25rem) * 2)}:host ::ng-deep pre .line.highlighted{background-color:var(--color-primary);display:inline-block;width:100%}@supports (color: color-mix(in lab,red,red)){:host ::ng-deep pre .line.highlighted{background-color:color-mix(in srgb,var(--color-primary),transparent 92%)}}:host ::ng-deep code{white-space:pre}:host .content{overflow:auto;background:var(--ngs-code-highlighter-bg);padding:var(--ngs-code-highlighter-padding) 0}:host .content button{color:inherit}:host .content button ngs-icon.text-green-500{color:#00a447!important;color:oklch(62.7% .194 149.214)!important}:host.appearance-bordered figcaption{border:var(--ngs-code-highlighter-border);border-bottom:none;border-top-left-radius:.75rem;border-top-right-radius:.75rem;width:max-content}:host.appearance-bordered .content{border:var(--ngs-code-highlighter-border);border-radius:var(--ngs-code-highlighter-radius);z-index:0}:host.appearance-bordered:has(figcaption) .content{border-top-left-radius:0}:host.appearance-none .content{border:none;padding:0;background-color:transparent!important;border-radius:0}:host.appearance-none ::ng-deep pre{padding:0}:host.loading{opacity:.6}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: CodeHighlighter, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-code-highlighter', standalone: true, imports: [Button, Icon], exportAs: 'ngsCodeHighlighter', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-code-highlighter not-prose',
                        '[class.appearance-bordered]': 'appearance() === "bordered"',
                        '[class.appearance-none]': 'appearance() === "none"',
                    }, template: "<figure>\n  @if (title()) {\n    <figcaption>\n      @if (title()) {\n        <span class=\"title\">{{ title() }}</span>\n      }\n    </figcaption>\n  }\n\n  <div class=\"content relative\">\n    @if (showLanguage()) {\n      <div class=\"languageName\">{{ displayedLanguage() }}</div>\n    }\n\n    @if (showCopyButton()) {\n      <span class=\"absolute top-2 right-2\">\n        <button\n          ngsIconButton\n          (click)=\"copyCode()\"\n        >\n          <ngs-icon\n            [name]=\"copied() ? 'fluent:checkmark-24-regular' : 'fluent:copy-24-regular'\"\n            [class.text-green-500]=\"copied()\"\n          />\n        </button>\n      </span>\n    }\n\n    <div>\n      @if (content()) {\n        <div [innerHTML]=\"content()\"></div>\n      } @else {\n        <div class=\"loading\">Loading\u2026</div>\n      }\n    </div>\n  </div>\n</figure>\n", styles: [":host{--ngs-code-highlighter-bg: var(--color-background);--ngs-code-highlighter-radius: 1rem;--ngs-code-highlighter-padding: calc(var(--spacing, .25rem) * 5);--ngs-code-highlighter-border: 1px solid var(--color-border);--ngs-code-highlighter-title-padding: calc(var(--spacing, .25rem) * 2) calc(var(--spacing, .25rem) * 3) calc(var(--spacing, .25rem) * 1) calc(var(--spacing, .25rem) * 3);--ngs-code-highlighter-title-color: var(--color-neutral-500);display:block;margin:calc(var(--spacing, .25rem) * 5) 0;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace}:host figcaption{font-size:.75rem;font-weight:500;padding:var(--ngs-code-highlighter-title-padding);background:var(--ngs-code-highlighter-bg);color:var(--ngs-code-highlighter-title-color);position:relative;z-index:1}:host figcaption:after{content:\"\";position:absolute;left:0;right:0;bottom:-1px;height:1px;background:var(--ngs-code-highlighter-bg)}:host .languageName{font-size:.875rem;font-weight:600;padding:0 calc(var(--spacing, .25rem) * 6);width:max-content;margin-bottom:calc(var(--spacing, .25rem) * 4);margin-top:calc(calc(var(--spacing, .25rem) * 1) * -1);position:relative}:host ::ng-deep pre{line-height:1.75;font-size:.875rem;position:relative;padding:0}:host ::ng-deep pre code{display:grid}:host ::ng-deep pre .line{padding-left:calc(var(--spacing, .25rem) * 6);padding-right:var(--ngs-code-highlighter-padding);min-height:1.75em}:host ::ng-deep pre .line.diff.remove{background-color:color-mix(in srgb,oklch(63.7% .237 25.331),transparent 85%);display:inline-block;width:100%}:host ::ng-deep pre .line.diff.remove:before{content:\"-\";color:#fb2c36;position:absolute;left:calc(var(--spacing, .25rem) * 2)}:host ::ng-deep pre .line.diff.add{background-color:color-mix(in srgb,oklch(72.3% .219 149.579),transparent 85%);display:inline-block;width:100%}:host ::ng-deep pre .line.diff.add:before{content:\"+\";color:#00c65a;color:oklch(72.3% .219 149.579);position:absolute;left:calc(var(--spacing, .25rem) * 2)}:host ::ng-deep pre .line.highlighted{background-color:var(--color-primary);display:inline-block;width:100%}@supports (color: color-mix(in lab,red,red)){:host ::ng-deep pre .line.highlighted{background-color:color-mix(in srgb,var(--color-primary),transparent 92%)}}:host ::ng-deep code{white-space:pre}:host .content{overflow:auto;background:var(--ngs-code-highlighter-bg);padding:var(--ngs-code-highlighter-padding) 0}:host .content button{color:inherit}:host .content button ngs-icon.text-green-500{color:#00a447!important;color:oklch(62.7% .194 149.214)!important}:host.appearance-bordered figcaption{border:var(--ngs-code-highlighter-border);border-bottom:none;border-top-left-radius:.75rem;border-top-right-radius:.75rem;width:max-content}:host.appearance-bordered .content{border:var(--ngs-code-highlighter-border);border-radius:var(--ngs-code-highlighter-radius);z-index:0}:host.appearance-bordered:has(figcaption) .content{border-top-left-radius:0}:host.appearance-none .content{border:none;padding:0;background-color:transparent!important;border-radius:0}:host.appearance-none ::ng-deep pre{padding:0}:host.loading{opacity:.6}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], propDecorators: { code: [{ type: i0.Input, args: [{ isSignal: true, alias: "code", required: true }] }], language: [{ type: i0.Input, args: [{ isSignal: true, alias: "language", required: false }] }], theme: [{ type: i0.Input, args: [{ isSignal: true, alias: "theme", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], appearance: [{ type: i0.Input, args: [{ isSignal: true, alias: "appearance", required: false }] }], diff: [{ type: i0.Input, args: [{ isSignal: true, alias: "diff", required: false }] }], highlightLines: [{ type: i0.Input, args: [{ isSignal: true, alias: "highlightLines", required: false }] }], showLanguage: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLanguage", required: false }] }], showCopyButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCopyButton", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { CodeHighlighter };
//# sourceMappingURL=ngstarter-components-code-highlighter.mjs.map
