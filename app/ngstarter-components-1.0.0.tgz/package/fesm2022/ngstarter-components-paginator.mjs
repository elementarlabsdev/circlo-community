import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, ChangeDetectorRef, input, numberAttribute, booleanAttribute, output, effect, untracked, afterNextRender, ChangeDetectionStrategy, Component } from '@angular/core';
import { Subject } from 'rxjs';
import { Tooltip } from '@ngstarter/components/tooltip';
import { Icon } from '@ngstarter/components/icon';
import { Option, Select } from '@ngstarter/components/select';
import { FormField } from '@ngstarter/components/form-field';
import { Button } from '@ngstarter/components/button';

/**
 * To modify the labels and text displayed, create a new instance of PaginatorIntl and
 * include it in a custom provider
 */
class PaginatorIntl {
    /**
     * Stream to emit from when labels are changed. Use this to notify components when the labels have
     * changed after initialization.
     */
    changes = new Subject();
    /** A label for the page size selector. */
    itemsPerPageLabel = 'Items per page:';
    /** A label for the button that increments the current page. */
    nextPageLabel = 'Next page';
    /** A label for the button that decrements the current page. */
    previousPageLabel = 'Previous page';
    /** A label for the button that moves to the first page. */
    firstPageLabel = 'First page';
    /** A label for the button that moves to the last page. */
    lastPageLabel = 'Last page';
    /** A label for the range of items within the current page and the length of the whole list. */
    getRangeLabel = (page, pageSize, length) => {
        length = Math.max(length || 0, 0);
        if (length === 0 || pageSize === 0) {
            return `0 ${this.ofLabel || 'of'} ${length}`;
        }
        const startIndex = (page || 0) * (pageSize || 0);
        // If the start index exceeds the list length, do not try and fix the end index to the end.
        const endIndex = startIndex < length ? Math.min(startIndex + (pageSize || 0), length) : startIndex + (pageSize || 0);
        return `${startIndex + 1} – ${endIndex} ${this.ofLabel || 'of'} ${length}`;
    };
    /** Label for the 'of' terminology in the range display. */
    ofLabel = 'of';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PaginatorIntl, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PaginatorIntl, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: PaginatorIntl, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Change event object that is emitted when the user selects a
 * different page size or navigates to another page.
 */
class PageEvent {
    /** The current page index. */
    pageIndex;
    /**
     * Index of the page that was selected previously.
     */
    previousPageIndex;
    /** The current page size. */
    pageSize;
    /** The current total number of items being paged. */
    length;
}
/** Injection token that can be used to provide the default options for the paginator module. */
const PAGINATOR_DEFAULT_OPTIONS = new InjectionToken('PAGINATOR_DEFAULT_OPTIONS');
/** The default page size if there is no page size and there are no provided page size options. */
const DEFAULT_PAGE_SIZE = 50;

class Paginator {
    _changeDetectorRef = inject(ChangeDetectorRef);
    _intl = inject(PaginatorIntl);
    _intlChanges;
    /** The zero-based page index of the displayed list of items. Defaulted to 0. */
    pageIndexInput = input(undefined, { ...(ngDevMode ? { debugName: "pageIndexInput" } : /* istanbul ignore next */ {}), transform: numberAttribute, alias: 'pageIndex' });
    get pageIndex() {
        return this._pageIndex;
    }
    set pageIndex(value) {
        this._pageIndex = Math.max(value || 0, 0);
        this._changeDetectorRef.markForCheck();
    }
    _pageIndex = 0;
    lengthInput = input(undefined, { ...(ngDevMode ? { debugName: "lengthInput" } : /* istanbul ignore next */ {}), transform: numberAttribute, alias: 'length' });
    get length() {
        return this._length;
    }
    set length(value) {
        this._length = value || 0;
        this._changeDetectorRef.markForCheck();
    }
    _length = 0;
    /** Number of items to display on a page. By default set to 50. */
    pageSizeInput = input(undefined, { ...(ngDevMode ? { debugName: "pageSizeInput" } : /* istanbul ignore next */ {}), transform: numberAttribute, alias: 'pageSize' });
    get pageSize() {
        return this._pageSize;
    }
    set pageSize(value) {
        this._pageSize = Math.max(value || 0, 0);
        this._updateDisplayedPageSizeOptions();
    }
    _pageSize;
    /** The set of provided page size options to display to the user. */
    pageSizeOptionsInput = input(undefined, { ...(ngDevMode ? { debugName: "pageSizeOptionsInput" } : /* istanbul ignore next */ {}), alias: 'pageSizeOptions' });
    get pageSizeOptions() {
        return this._pageSizeOptions;
    }
    set pageSizeOptions(value) {
        this._pageSizeOptions = (value || []).map((p) => numberAttribute(p, 0));
        this._updateDisplayedPageSizeOptions();
    }
    _pageSizeOptions = [];
    /** Whether to hide the page size selection UI from the user. */
    hidePageSize = input(false, { ...(ngDevMode ? { debugName: "hidePageSize" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether to show the first/last buttons UI to the user. */
    showFirstLastButtons = input(false, { ...(ngDevMode ? { debugName: "showFirstLastButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Whether the paginator is disabled. */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Event emitted when the paginator changes the page size or page index. */
    page = output();
    _initialized = new Subject();
    initialized = this._initialized.asObservable();
    _displayedPageSizeOptions;
    _isInitialized = false;
    constructor() {
        const defaults = inject(PAGINATOR_DEFAULT_OPTIONS, { optional: true });
        if (defaults) {
            if (defaults.pageSize != null) {
                this._pageSize = defaults.pageSize;
            }
            if (defaults.pageSizeOptions != null) {
                this._pageSizeOptions = defaults.pageSizeOptions;
            }
        }
        if (this._intl && this._intl.changes) {
            this._intlChanges = this._intl.changes.subscribe(() => {
                this._changeDetectorRef.markForCheck();
            });
        }
        effect(() => {
            const pageIndex = this.pageIndexInput();
            if (pageIndex !== undefined) {
                untracked(() => this.pageIndex = pageIndex);
            }
        });
        effect(() => {
            const pageSize = this.pageSizeInput();
            if (pageSize !== undefined) {
                untracked(() => this.pageSize = pageSize);
            }
        });
        effect(() => {
            const length = this.lengthInput();
            if (length !== undefined) {
                untracked(() => this.length = length);
            }
        });
        effect(() => {
            const pageSizeOptions = this.pageSizeOptionsInput();
            if (pageSizeOptions !== undefined) {
                untracked(() => this.pageSizeOptions = pageSizeOptions);
            }
        });
        afterNextRender(() => {
            this._initialized.next();
            this._initialized.complete();
        });
    }
    ngOnInit() {
        this._isInitialized = true;
        this._updateDisplayedPageSizeOptions();
    }
    ngOnDestroy() {
        this._intlChanges?.unsubscribe();
    }
    /** Advances to the next page if it exists. */
    nextPage() {
        if (this.hasNextPage()) {
            const previousPageIndex = this.pageIndex;
            this._pageIndex++;
            this._emitPageEvent(previousPageIndex);
        }
    }
    /** Move back to the previous page if it exists. */
    previousPage() {
        if (this.hasPreviousPage()) {
            const previousPageIndex = this.pageIndex;
            this._pageIndex--;
            this._emitPageEvent(previousPageIndex);
        }
    }
    /** Move to the first page if not already there. */
    firstPage() {
        if (this.hasPreviousPage()) {
            const previousPageIndex = this.pageIndex;
            this._pageIndex = 0;
            this._emitPageEvent(previousPageIndex);
        }
    }
    /** Move to the last page if not already there. */
    lastPage() {
        if (this.hasNextPage()) {
            const previousPageIndex = this.pageIndex;
            this._pageIndex = this.getNumberOfPages() - 1;
            this._emitPageEvent(previousPageIndex);
        }
    }
    /** Whether there is a previous page. */
    hasPreviousPage() {
        return this.pageIndex >= 1 && this.pageSize !== 0;
    }
    /** Whether there is a next page. */
    hasNextPage() {
        const maxPageIndex = this.getNumberOfPages() - 1;
        return this.pageIndex < maxPageIndex && this.pageSize !== 0;
    }
    /** Calculate the number of pages */
    getNumberOfPages() {
        if (!this.pageSize) {
            return 0;
        }
        return Math.ceil(this.length / this.pageSize);
    }
    /**
     * Changes the page size so that the first item displayed on the page will still be
     * displayed using the new page size.
     *
     * For example, if the page size is 10 and on the second page (items indexed 10-19) then
     * switching so that the page size is 5 will set the third page as the current page so
     * that the 10th item will still be displayed.
     */
    _changePageSize(pageSize) {
        // Current page needs to be updated to reflect the new page size. Navigate to the page
        // containing the previous page's first item.
        const startIndex = this.pageIndex * this.pageSize;
        const previousPageIndex = this.pageIndex;
        this._pageSize = pageSize;
        this._pageIndex = Math.floor(startIndex / pageSize) || 0;
        this._emitPageEvent(previousPageIndex);
    }
    /** Checks whether the buttons for going forwards should be disabled. */
    _nextButtonsDisabled() {
        return this.disabled() || !this.hasNextPage();
    }
    /** Checks whether the buttons for going backwards should be disabled. */
    _previousButtonsDisabled() {
        return this.disabled() || !this.hasPreviousPage();
    }
    /**
     * Updates the list of page size options to display to the user. Includes making sure that
     * the page size is an option and that the list is sorted.
     */
    _updateDisplayedPageSizeOptions() {
        if (!this._isInitialized) {
            return;
        }
        // If no page size is provided, use the first page size option or the default page size.
        if (!this.pageSize) {
            this._pageSize =
                this.pageSizeOptions.length !== 0 ? this.pageSizeOptions[0] : DEFAULT_PAGE_SIZE;
        }
        this._displayedPageSizeOptions = this.pageSizeOptions.slice();
        if (this._displayedPageSizeOptions.indexOf(this.pageSize) === -1) {
            this._displayedPageSizeOptions.push(this.pageSize);
        }
        // Sort the numbers using a number-specific sort function.
        this._displayedPageSizeOptions.sort((a, b) => a - b);
        this._changeDetectorRef.markForCheck();
    }
    /** Emits a page event and clears the session-cached page index if applicable. */
    _emitPageEvent(previousPageIndex) {
        this.page.emit({
            previousPageIndex,
            pageIndex: this._pageIndex,
            pageSize: this._pageSize,
            length: this.length,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Paginator, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.4", type: Paginator, isStandalone: true, selector: "ngs-paginator", inputs: { pageIndexInput: { classPropertyName: "pageIndexInput", publicName: "pageIndex", isSignal: true, isRequired: false, transformFunction: null }, lengthInput: { classPropertyName: "lengthInput", publicName: "length", isSignal: true, isRequired: false, transformFunction: null }, pageSizeInput: { classPropertyName: "pageSizeInput", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptionsInput: { classPropertyName: "pageSizeOptionsInput", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, hidePageSize: { classPropertyName: "hidePageSize", publicName: "hidePageSize", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastButtons: { classPropertyName: "showFirstLastButtons", publicName: "showFirstLastButtons", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { page: "page" }, host: { attributes: { "role": "group" }, classAttribute: "ngs-paginator" }, exportAs: ["ngsPaginator"], ngImport: i0, template: "<div class=\"ngs-paginator-container\">\n  @if (!hidePageSize()) {\n    <div class=\"ngs-paginator-page-size\">\n      <div class=\"ngs-paginator-page-size-label\">\n        {{_intl.itemsPerPageLabel || 'Items per page:'}}\n      </div>\n\n      <ngs-form-field\n        subscriptHiddenIfEmpty\n        class=\"ngs-paginator-page-size-select\">\n        <ngs-select\n          hideCheckIcon\n          [value]=\"pageSize\"\n          [disabled]=\"disabled()\"\n          (selectionChange)=\"_changePageSize($event.value)\">\n          @for (pageSizeOption of _displayedPageSizeOptions; track pageSizeOption) {\n            <ngs-option [value]=\"pageSizeOption\">\n              {{pageSizeOption}}\n            </ngs-option>\n          }\n        </ngs-select>\n      </ngs-form-field>\n    </div>\n  }\n\n  <div class=\"ngs-paginator-range-actions\">\n    <div class=\"ngs-paginator-range-label\" aria-live=\"polite\">\n      {{_intl.getRangeLabel(pageIndex, pageSize, length)}}\n    </div>\n\n    <div class=\"ngs-paginator-navigation\">\n      @if (showFirstLastButtons()) {\n        <button ngsIconButton\n                type=\"button\"\n                class=\"ngs-paginator-navigation-first\"\n                (click)=\"firstPage()\"\n                [ngsTooltip]=\"_intl.firstPageLabel || 'First page'\"\n                [disabled]=\"_previousButtonsDisabled()\">\n          <ngs-icon name=\"fluent:arrow-previous-24-regular\" />\n        </button>\n      }\n\n      <button ngsIconButton\n              type=\"button\"\n              class=\"ngs-paginator-navigation-previous\"\n              (click)=\"previousPage()\"\n              [ngsTooltip]=\"_intl.previousPageLabel || 'Previous page'\"\n              [disabled]=\"_previousButtonsDisabled()\">\n        <ngs-icon name=\"fluent:chevron-left-24-regular\" />\n      </button>\n\n      <button ngsIconButton\n              type=\"button\"\n              class=\"ngs-paginator-navigation-next\"\n              (click)=\"nextPage()\"\n              [ngsTooltip]=\"_intl.nextPageLabel || 'Next page'\"\n              [disabled]=\"_nextButtonsDisabled()\">\n        <ngs-icon name=\"fluent:chevron-right-24-regular\" />\n      </button>\n\n      @if (showFirstLastButtons()) {\n        <button ngsIconButton\n                type=\"button\"\n                class=\"ngs-paginator-navigation-last\"\n                (click)=\"lastPage()\"\n                [ngsTooltip]=\"_intl.lastPageLabel || 'Last page'\"\n                [disabled]=\"_nextButtonsDisabled()\">\n          <ngs-icon name=\"fluent:arrow-next-24-regular\" />\n        </button>\n      }\n    </div>\n  </div>\n</div>\n", styles: [":host{--ngs-paginator-container-background: transparent;--ngs-paginator-container-text-color: var(--color-on-surface);--ngs-paginator-container-text-font: var(--font-sans);--ngs-paginator-container-text-line-height: inherit;--ngs-paginator-container-text-size: .875rem;--ngs-paginator-container-text-tracking: normal;--ngs-paginator-container-text-weight: 400;--ngs-paginator-page-size-margin-right: 8px;--ngs-paginator-items-per-page-label-margin: 0 4px;--ngs-paginator-range-label-margin: 0 32px 0 24px;display:block}:host .ngs-paginator-container{display:flex;align-items:center;justify-content:flex-end;padding:0 8px;flex-wrap:wrap-reverse;min-height:40px;background:var(--ngs-paginator-container-background-color);color:var(--ngs-paginator-container-text-color);font-family:var(--ngs-paginator-container-text-font);line-height:var(--ngs-paginator-container-text-line-height);font-size:var(--ngs-paginator-container-text-size);letter-spacing:var(--ngs-paginator-container-text-tracking);font-weight:var(--ngs-paginator-container-text-weight)}:host .ngs-paginator-page-size{display:flex;align-items:center;margin-right:var(--ngs-paginator-page-size-margin-right)}:host .ngs-paginator-page-size-label{margin:var(--ngs-paginator-items-per-page-label-margin)}:host .ngs-paginator-page-size-select{margin:0 4px;width:78px;--ngs-form-field-infix-padding-top: 0 !important;--ngs-form-field-infix-padding-bottom: 0 !important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-form-field-container{padding:0 6px 0 12px!important;height:calc(var(--spacing, .25rem) * 10)!important;min-height:calc(var(--spacing, .25rem) * 10)!important;box-sizing:border-box!important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-form-field-infix{padding:0!important;height:calc(var(--spacing, .25rem) * 10)!important;min-height:calc(var(--spacing, .25rem) * 10)!important;box-sizing:border-box!important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-select{height:calc(var(--spacing, .25rem) * 10)!important;min-height:calc(var(--spacing, .25rem) * 10)!important;min-width:0!important;--ngs-select-min-width: 0 !important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-select-arrow-wrapper{height:calc(var(--spacing, .25rem) * 10)!important;padding-inline-end:2px}:host .ngs-paginator-range-actions{display:flex;align-items:center}:host .ngs-paginator-range-label{margin:var(--ngs-paginator-range-label-margin)}:host .ngs-paginator-navigation{display:flex;align-items:center}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"], dependencies: [{ kind: "component", type: Button, selector: "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", inputs: ["ngsButton", "ngsIconButton", "loading", "disabled", "disabledInteractive", "disableRipple", "reverse", "fullWidth", "hideTextOnMobile"], exportAs: ["ngsButton"] }, { kind: "directive", type: Tooltip, selector: "[ngsTooltip]", inputs: ["ngsTooltip", "ngsTooltipPosition", "ngsTooltipClass", "ngsTooltipShowDelay", "ngsTooltipHideDelay", "ngsTooltipOffset", "ngsTooltipPositionAtOrigin", "ngsTooltipDisabled"], exportAs: ["ngsTooltip"] }, { kind: "component", type: Icon, selector: "ngs-icon", inputs: ["name"], exportAs: ["ngsIcon"] }, { kind: "component", type: Option, selector: "ngs-option", inputs: ["value", "disabled", "selected"], outputs: ["onSelectionChange"], exportAs: ["ngsOption"] }, { kind: "component", type: Select, selector: "ngs-select", inputs: ["id", "placeholder", "disabled", "required", "multiple", "hideCheckIcon", "ariaLabel", "tabIndex", "aria-describedby", "value"], outputs: ["selectionChange", "opened", "closed", "valueChange"], exportAs: ["ngsSelect"] }, { kind: "component", type: FormField, selector: "ngs-form-field", inputs: ["subscriptHiddenIfEmpty"], exportAs: ["ngsFormField"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.4", ngImport: i0, type: Paginator, decorators: [{
            type: Component,
            args: [{ selector: 'ngs-paginator', exportAs: 'ngsPaginator', imports: [Button, Tooltip, Icon, Option, Select, FormField], changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        'class': 'ngs-paginator',
                        'role': 'group',
                    }, template: "<div class=\"ngs-paginator-container\">\n  @if (!hidePageSize()) {\n    <div class=\"ngs-paginator-page-size\">\n      <div class=\"ngs-paginator-page-size-label\">\n        {{_intl.itemsPerPageLabel || 'Items per page:'}}\n      </div>\n\n      <ngs-form-field\n        subscriptHiddenIfEmpty\n        class=\"ngs-paginator-page-size-select\">\n        <ngs-select\n          hideCheckIcon\n          [value]=\"pageSize\"\n          [disabled]=\"disabled()\"\n          (selectionChange)=\"_changePageSize($event.value)\">\n          @for (pageSizeOption of _displayedPageSizeOptions; track pageSizeOption) {\n            <ngs-option [value]=\"pageSizeOption\">\n              {{pageSizeOption}}\n            </ngs-option>\n          }\n        </ngs-select>\n      </ngs-form-field>\n    </div>\n  }\n\n  <div class=\"ngs-paginator-range-actions\">\n    <div class=\"ngs-paginator-range-label\" aria-live=\"polite\">\n      {{_intl.getRangeLabel(pageIndex, pageSize, length)}}\n    </div>\n\n    <div class=\"ngs-paginator-navigation\">\n      @if (showFirstLastButtons()) {\n        <button ngsIconButton\n                type=\"button\"\n                class=\"ngs-paginator-navigation-first\"\n                (click)=\"firstPage()\"\n                [ngsTooltip]=\"_intl.firstPageLabel || 'First page'\"\n                [disabled]=\"_previousButtonsDisabled()\">\n          <ngs-icon name=\"fluent:arrow-previous-24-regular\" />\n        </button>\n      }\n\n      <button ngsIconButton\n              type=\"button\"\n              class=\"ngs-paginator-navigation-previous\"\n              (click)=\"previousPage()\"\n              [ngsTooltip]=\"_intl.previousPageLabel || 'Previous page'\"\n              [disabled]=\"_previousButtonsDisabled()\">\n        <ngs-icon name=\"fluent:chevron-left-24-regular\" />\n      </button>\n\n      <button ngsIconButton\n              type=\"button\"\n              class=\"ngs-paginator-navigation-next\"\n              (click)=\"nextPage()\"\n              [ngsTooltip]=\"_intl.nextPageLabel || 'Next page'\"\n              [disabled]=\"_nextButtonsDisabled()\">\n        <ngs-icon name=\"fluent:chevron-right-24-regular\" />\n      </button>\n\n      @if (showFirstLastButtons()) {\n        <button ngsIconButton\n                type=\"button\"\n                class=\"ngs-paginator-navigation-last\"\n                (click)=\"lastPage()\"\n                [ngsTooltip]=\"_intl.lastPageLabel || 'Last page'\"\n                [disabled]=\"_nextButtonsDisabled()\">\n          <ngs-icon name=\"fluent:arrow-next-24-regular\" />\n        </button>\n      }\n    </div>\n  </div>\n</div>\n", styles: [":host{--ngs-paginator-container-background: transparent;--ngs-paginator-container-text-color: var(--color-on-surface);--ngs-paginator-container-text-font: var(--font-sans);--ngs-paginator-container-text-line-height: inherit;--ngs-paginator-container-text-size: .875rem;--ngs-paginator-container-text-tracking: normal;--ngs-paginator-container-text-weight: 400;--ngs-paginator-page-size-margin-right: 8px;--ngs-paginator-items-per-page-label-margin: 0 4px;--ngs-paginator-range-label-margin: 0 32px 0 24px;display:block}:host .ngs-paginator-container{display:flex;align-items:center;justify-content:flex-end;padding:0 8px;flex-wrap:wrap-reverse;min-height:40px;background:var(--ngs-paginator-container-background-color);color:var(--ngs-paginator-container-text-color);font-family:var(--ngs-paginator-container-text-font);line-height:var(--ngs-paginator-container-text-line-height);font-size:var(--ngs-paginator-container-text-size);letter-spacing:var(--ngs-paginator-container-text-tracking);font-weight:var(--ngs-paginator-container-text-weight)}:host .ngs-paginator-page-size{display:flex;align-items:center;margin-right:var(--ngs-paginator-page-size-margin-right)}:host .ngs-paginator-page-size-label{margin:var(--ngs-paginator-items-per-page-label-margin)}:host .ngs-paginator-page-size-select{margin:0 4px;width:78px;--ngs-form-field-infix-padding-top: 0 !important;--ngs-form-field-infix-padding-bottom: 0 !important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-form-field-container{padding:0 6px 0 12px!important;height:calc(var(--spacing, .25rem) * 10)!important;min-height:calc(var(--spacing, .25rem) * 10)!important;box-sizing:border-box!important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-form-field-infix{padding:0!important;height:calc(var(--spacing, .25rem) * 10)!important;min-height:calc(var(--spacing, .25rem) * 10)!important;box-sizing:border-box!important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-select{height:calc(var(--spacing, .25rem) * 10)!important;min-height:calc(var(--spacing, .25rem) * 10)!important;min-width:0!important;--ngs-select-min-width: 0 !important}:host .ngs-paginator-page-size-select ::ng-deep .ngs-select-arrow-wrapper{height:calc(var(--spacing, .25rem) * 10)!important;padding-inline-end:2px}:host .ngs-paginator-range-actions{display:flex;align-items:center}:host .ngs-paginator-range-label{margin:var(--ngs-paginator-range-label-margin)}:host .ngs-paginator-navigation{display:flex;align-items:center}\n/*! tailwindcss v4.2.2 | MIT License | https://tailwindcss.com */\n"] }]
        }], ctorParameters: () => [], propDecorators: { pageIndexInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageIndex", required: false }] }], lengthInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "length", required: false }] }], pageSizeInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }], pageSizeOptionsInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], hidePageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "hidePageSize", required: false }] }], showFirstLastButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastButtons", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], page: [{ type: i0.Output, args: ["page"] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_PAGE_SIZE, PAGINATOR_DEFAULT_OPTIONS, PageEvent, Paginator, PaginatorIntl };
//# sourceMappingURL=ngstarter-components-paginator.mjs.map
