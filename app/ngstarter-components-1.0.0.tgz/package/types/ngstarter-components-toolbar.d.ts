import * as i0 from '@angular/core';
import { ElementRef, TemplateRef, AfterViewInit, OnDestroy } from '@angular/core';
import { DialogRef } from '@ngstarter/components/dialog';

declare class ToolbarItem {
    readonly elementRef: ElementRef<any>;
    readonly hidden: i0.ModelSignal<boolean>;
    readonly template: i0.Signal<TemplateRef<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarItem, "ngs-toolbar-item", never, { "hidden": { "alias": "hidden"; "required": false; "isSignal": true; }; }, { "hidden": "hiddenChange"; }, never, ["*"], true, never>;
}

declare class ToolbarSpacer {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSpacer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarSpacer, "ngs-toolbar-spacer", never, {}, {}, never, never, true, never>;
}

declare class ToolbarRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarRow, "ngs-toolbar-row", never, {}, {}, never, ["*"], true, never>;
}

declare class Toolbar implements AfterViewInit, OnDestroy {
    private _elementRef;
    private _zone;
    private _platformId;
    private _injector;
    private _dialog;
    readonly items: i0.Signal<readonly ToolbarItem[]>;
    readonly spacers: i0.Signal<readonly ToolbarSpacer[]>;
    readonly _rows: i0.Signal<readonly ToolbarRow[]>;
    protected readonly _overflowItems: i0.WritableSignal<ToolbarItem[]>;
    protected _dialogRef: DialogRef<any> | null;
    private _resizeObserver?;
    private _itemWidths;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    protected _openOverflowDialog(template: TemplateRef<any>): void;
    protected _closeOverflowDialog(): void;
    private _updateOverflow;
    static ɵfac: i0.ɵɵFactoryDeclaration<Toolbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Toolbar, "ngs-toolbar", ["ngsToolbar"], {}, {}, ["items", "spacers", "_rows"], ["*"], true, never>;
}

declare class ToolbarTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarTitle, "ngs-toolbar-title", never, {}, {}, never, ["*"], true, never>;
}

export { Toolbar, ToolbarItem, ToolbarRow, ToolbarSpacer, ToolbarTitle };
