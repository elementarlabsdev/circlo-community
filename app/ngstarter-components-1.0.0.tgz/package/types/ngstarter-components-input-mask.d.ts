import * as i0 from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class CreditCardNumberMaskDirective {
    private readonly ngControl;
    private readonly hostElement;
    readonly placeholder: i0.InputSignal<string>;
    onInput(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreditCardNumberMaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CreditCardNumberMaskDirective, "[ngsCreditCardNumberMask]", ["ngsCreditCardNumberMask"], { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CreditCardExpiryDateMaskDirective implements ControlValueAccessor {
    private readonly elementRef;
    readonly placeholder: i0.InputSignal<string>;
    onChange: (_: any) => void;
    onTouched: () => void;
    writeValue(value: string | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    protected onInput(event: Event): void;
    onBlur(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreditCardExpiryDateMaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CreditCardExpiryDateMaskDirective, "[ngsCreditCardExpiryDateMask]", ["ngsCreditCardExpiryDateMask"], { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CreditCardCvvMaskDirective {
    private readonly ngControl;
    private readonly hostElement;
    readonly placeholder: i0.InputSignal<string>;
    onInput(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreditCardCvvMaskDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CreditCardCvvMaskDirective, "[ngsCreditCardCvvMask]", ["ngsCreditCardCvvMask"], { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { CreditCardCvvMaskDirective, CreditCardExpiryDateMaskDirective, CreditCardNumberMaskDirective };
