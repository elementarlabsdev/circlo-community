import * as i0 from '@angular/core';
import { AfterContentInit, OnDestroy, ChangeDetectorRef } from '@angular/core';

declare class ExpansionPanel {
    private _cdr;
    readonly accordion: Accordion | null;
    disabled: i0.InputSignalWithTransform<boolean, unknown>;
    expanded: i0.ModelSignal<boolean>;
    hideToggle: i0.InputSignalWithTransform<boolean, unknown>;
    readonly opened: i0.OutputEmitterRef<void>;
    readonly closed: i0.OutputEmitterRef<void>;
    readonly expandedChange: i0.OutputEmitterRef<boolean>;
    readonly id: string;
    readonly headerId: string;
    toggle(): void;
    open(): void;
    close(): void;
    private _emitExpansionChange;
    _getHideToggle(): boolean;
    _getExpandedState(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpansionPanel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpansionPanel, "ngs-expansion-panel", ["ngsExpansionPanel"], { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "hideToggle": { "alias": "hideToggle"; "required": false; "isSignal": true; }; }, { "expanded": "expandedChange"; "opened": "opened"; "closed": "closed"; "expandedChange": "expandedChange"; }, never, ["ngs-expansion-panel-header", "*", "ngs-action-row"], true, never>;
}

declare class Accordion implements AfterContentInit, OnDestroy {
    private readonly _destroyed;
    readonly _cdr: ChangeDetectorRef;
    /** Whether the accordion should allow multiple expanded panels at a time. */
    multi: i0.InputSignalWithTransform<boolean, unknown>;
    /** Whether the expansion indicator should be hidden. */
    hideToggle: i0.InputSignalWithTransform<boolean, unknown>;
    readonly _panels: i0.Signal<readonly ExpansionPanel[]>;
    private readonly _panels$;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    openAll(): void;
    closeAll(): void;
    private _closeAllExcept;
    static ɵfac: i0.ɵɵFactoryDeclaration<Accordion, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Accordion, "ngs-accordion", ["ngsAccordion"], { "multi": { "alias": "multi"; "required": false; "isSignal": true; }; "hideToggle": { "alias": "hideToggle"; "required": false; "isSignal": true; }; }, {}, ["_panels"], ["*"], true, never>;
}

declare class ExpansionPanelHeader {
    readonly panel: ExpansionPanel;
    private _cdr;
    hideToggle: i0.InputSignalWithTransform<boolean, unknown>;
    _toggle(): void;
    _getExpandedState(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpansionPanelHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpansionPanelHeader, "ngs-expansion-panel-header", never, { "hideToggle": { "alias": "hideToggle"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-panel-title", "ngs-panel-description", "*"], true, never>;
}

declare class ExpansionPanelTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpansionPanelTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpansionPanelTitle, "ngs-expansion-panel-title", ["ngsExpansionPanelTitle"], {}, {}, never, ["*"], true, never>;
}

declare class ExpansionPanelDescription {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpansionPanelDescription, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExpansionPanelDescription, "ngs-expansion-panel-description", ["ngsExpansionPanelDescription"], {}, {}, never, ["*"], true, never>;
}

declare class ActionRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionRow, "ngs-action-row", never, {}, {}, never, ["*"], true, never>;
}

export { Accordion, ActionRow, ExpansionPanel, ExpansionPanelDescription, ExpansionPanelHeader, ExpansionPanelTitle };
