import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef, EventEmitter, OnDestroy, Signal, InjectionToken } from '@angular/core';
import { BooleanInput } from '@angular/cdk/coercion';
import { ControlValueAccessor, Validator, AbstractControl, ValidationErrors } from '@angular/forms';
import { Subject } from 'rxjs';

declare class Timepicker {
    private _overlay;
    private _viewContainerRef;
    private _localeId;
    private _config;
    readonly _template: _angular_core.Signal<TemplateRef<any>>;
    readonly _panel: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    readonly opened: EventEmitter<void>;
    readonly closed: EventEmitter<void>;
    private _overlayRef;
    private _input;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    interval: _angular_core.InputSignalWithTransform<number, string | number>;
    protected _timeOptions: _angular_core.Signal<{
        label: string;
        value: string;
    }[]>;
    private _toTimeString;
    constructor();
    _registerInput(input: any): void;
    open(): void;
    close(): void;
    _isSelected(value: string): boolean;
    private _scrollToSelected;
    _selectValue(value: string): void;
    isOpen(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Timepicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Timepicker, "ngs-timepicker", ["ngsTimepicker"], { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "interval": { "alias": "interval"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

declare class TimepickerToggleIcon {
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimepickerToggleIcon, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TimepickerToggleIcon, "[ngsTimepickerToggleIcon]", never, {}, {}, never, never, true, never>;
}

declare class TimepickerToggle implements OnDestroy {
    private _stateChanges;
    customIcons: _angular_core.Signal<readonly TimepickerToggleIcon[]>;
    timepicker: _angular_core.InputSignal<Timepicker | null>;
    disabled: _angular_core.InputSignalWithTransform<boolean, BooleanInput>;
    ngOnDestroy(): void;
    _open(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimepickerToggle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimepickerToggle, "ngs-timepicker-toggle", ["ngsTimepickerToggle"], { "timepicker": { "alias": "for"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, ["customIcons"], ["[ngsTimepickerToggleIcon]"], true, never>;
}

declare class TimepickerInput<D = any> implements ControlValueAccessor, OnDestroy, Validator {
    private _elementRef;
    private _formField;
    private _localeId;
    private _disabledByCva;
    protected _disabledInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: Signal<boolean>;
    readonly max: _angular_core.InputSignalWithTransform<D | null, unknown>;
    readonly min: _angular_core.InputSignalWithTransform<D | null, unknown>;
    readonly openOnClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ngsTimepicker: _angular_core.InputSignal<Timepicker>;
    private _timepicker;
    private _onChange;
    private _onTouched;
    private _validatorOnChange;
    private _modelValue;
    private _destroyed;
    private _timepickerDestroyed;
    private _isTimepickerOpen;
    private _lastExternalDate;
    constructor();
    ngOnDestroy(): void;
    private _registerTimepicker;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    registerOnValidatorChange(fn: () => void): void;
    validate(control: AbstractControl): ValidationErrors | null;
    private _doValidate;
    private _updateNativeValidity;
    setDisabledState(isDisabled: boolean): void;
    _onInput(value: string): void;
    _onBlur(): void;
    private _toTimeString;
    _onFocus(): void;
    _onClick(): void;
    _setValue(value: string): void;
    private _mergeTimeIntoDate;
    private _formatValue;
    _parseValue(value: any): string;
    get value(): string;
    getConnectedOverlayOrigin(): ElementRef;
    getOverlayWidth(): string | number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimepickerInput<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TimepickerInput<any>, "input[ngsTimepicker]", never, { "_disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "openOnClick": { "alias": "openOnClick"; "required": false; "isSignal": true; }; "ngsTimepicker": { "alias": "ngsTimepicker"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TimepickerIntl {
    readonly changes: Subject<void>;
    openTimepickerLabel: string;
    closeTimepickerLabel: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimepickerIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TimepickerIntl>;
}

interface TimepickerConfig {
    interval?: number | string;
}
declare const TIMEPICKER_CONFIG: InjectionToken<TimepickerConfig>;

export { TIMEPICKER_CONFIG, Timepicker, TimepickerInput, TimepickerIntl, TimepickerToggle, TimepickerToggleIcon };
export type { TimepickerConfig };
