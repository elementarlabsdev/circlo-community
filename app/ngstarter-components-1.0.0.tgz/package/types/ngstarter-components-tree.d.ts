import * as i0 from '@angular/core';
import { ViewContainerRef, OnInit, OnDestroy } from '@angular/core';
import { CdkTree, CdkTreeNodeOutlet, CdkNestedTreeNode, CdkTreeNode, CdkTreeNodePadding, CdkTreeNodeToggle, CdkTreeNodeDef } from '@angular/cdk/tree';

declare class TreeNodeOutlet implements CdkTreeNodeOutlet {
    viewContainer: ViewContainerRef;
    _node: {} | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeNodeOutlet, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeNodeOutlet, "[ngsTreeNodeOutlet]", never, {}, {}, never, never, true, never>;
}
declare class Tree<T, K = T> extends CdkTree<T, K> {
    readonly _nodeOutlet: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<Tree<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Tree<any, any>, "ngs-tree", ["ngsTree"], {}, {}, never, never, true, never>;
}

declare class TreeNode<T, K = T> extends CdkTreeNode<T, K> implements OnInit, OnDestroy {
    tabIndexInputBinding: i0.InputSignalWithTransform<number, any>;
    disabled: i0.InputSignalWithTransform<boolean, unknown>;
    defaultTabIndex: number;
    constructor();
    _getTabindexAttribute(): any;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeNode<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeNode<any, any>, "ngs-tree-node", ["ngsTreeNode"], { "tabIndexInputBinding": { "alias": "tabIndex"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "activation": "activation"; "expandedChange": "expandedChange"; }, never, never, true, never>;
}
declare class NestedTreeNode<T, K = T> extends CdkNestedTreeNode<T, K> implements OnInit, OnDestroy {
    node: i0.InputSignal<T>;
    disabled: i0.InputSignalWithTransform<boolean, unknown>;
    tabIndexInput: i0.InputSignalWithTransform<number, any>;
    constructor();
    get tabIndex(): number;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NestedTreeNode<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NestedTreeNode<any, any>, "ngs-nested-tree-node", ["ngsNestedTreeNode"], { "node": { "alias": "ngsNestedTreeNode"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "tabIndexInput": { "alias": "tabIndex"; "required": false; "isSignal": true; }; }, { "activation": "activation"; "expandedChange": "expandedChange"; }, never, never, true, never>;
}

declare class TreeNodePadding<T, K = T> extends CdkTreeNodePadding<T, K> {
    levelInput: i0.InputSignalWithTransform<number, any>;
    indentInput: i0.InputSignal<string | number>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeNodePadding<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeNodePadding<any, any>, "[ngsTreeNodePadding]", never, { "levelInput": { "alias": "ngsTreeNodePadding"; "required": false; "isSignal": true; }; "indentInput": { "alias": "ngsTreeNodePaddingIndent"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TreeNodeToggle<T, K = T> extends CdkTreeNodeToggle<T, K> {
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeNodeToggle<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeNodeToggle<any, any>, "[ngsTreeNodeToggle]", never, { "recursive": { "alias": "ngsTreeNodeToggleRecursive"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TreeNodeDef<T> extends CdkTreeNodeDef<T> {
    data: i0.InputSignal<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeNodeDef<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TreeNodeDef<any>, "[ngsTreeNodeDef]", never, { "when": { "alias": "ngsTreeNodeDefWhen"; "required": false; }; "data": { "alias": "ngsTreeNode"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { NestedTreeNode, Tree, TreeNode, TreeNodeDef, TreeNodeOutlet, TreeNodePadding, TreeNodeToggle };
