import * as _angular_core from '@angular/core';
import { OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';

declare class Icon implements OnInit, OnChanges {
    private _sanitizer;
    protected _iconHtml: _angular_core.WritableSignal<SafeHtml | null>;
    name: _angular_core.InputSignal<string>;
    private loaded;
    ngOnInit(): Promise<void>;
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    private _loadIcon;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Icon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Icon, "ngs-icon", ["ngsIcon"], { "name": { "alias": "name"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { Icon };
