import * as i0 from '@angular/core';

declare class Kbd {
    static ɵfac: i0.ɵɵFactoryDeclaration<Kbd, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Kbd, "ngs-kbd", ["ngsKbd"], {}, {}, never, ["*"], true, never>;
}

declare class KbdGroup {
    static ɵfac: i0.ɵɵFactoryDeclaration<KbdGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KbdGroup, "ngs-kbd-group", ["ngsKbdGroup"], {}, {}, never, ["ngs-kbd"], true, never>;
}

export { Kbd, KbdGroup };
