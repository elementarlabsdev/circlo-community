import * as _angular_core from '@angular/core';
import { OnDestroy, TemplateRef, Type, OnInit, ElementRef, InjectionToken, Provider } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { FormFieldControl } from '@ngstarter/components/form-field';

declare class DatepickerActions {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerActions, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DatepickerActions, "ngs-datepicker-actions", never, {}, {}, never, ["*"], true, never>;
}

declare class DateRange<D> {
    /** The start date of the range. */
    readonly start: D | null;
    /** The end date of the range. */
    readonly end: D | null;
    constructor(
    /** The start date of the range. */
    start: D | null, 
    /** The end date of the range. */
    end: D | null);
}

interface DatepickerPreset<D> {
    label: string;
    value: D | DateRange<D> | null;
}

declare class Datepicker<D> implements OnDestroy {
    private _overlay;
    private _viewContainerRef;
    readonly _portalTemplate: _angular_core.Signal<TemplateRef<any>>;
    readonly actions: _angular_core.Signal<DatepickerActions | undefined>;
    startAt: _angular_core.InputSignal<D | null>;
    calendarHeaderComponent: _angular_core.InputSignal<Type<any> | null>;
    quickPresets: _angular_core.InputSignal<DatepickerPreset<D>[]>;
    showQuickPresets: _angular_core.InputSignal<boolean>;
    _datepickerInput: any;
    _selected: _angular_core.WritableSignal<D | null>;
    _isAbove: _angular_core.WritableSignal<boolean>;
    private _overlayRef;
    ngOnDestroy(): void;
    _registerInput(input: any): void;
    open(): void;
    close(): void;
    _select(date: D): void;
    _selectPreset(preset: DatepickerPreset<D>): void;
    apply(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Datepicker<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Datepicker<any>, "ngs-datepicker", ["ngsDatepicker"], { "startAt": { "alias": "startAt"; "required": false; "isSignal": true; }; "calendarHeaderComponent": { "alias": "calendarHeaderComponent"; "required": false; "isSignal": true; }; "quickPresets": { "alias": "quickPresets"; "required": false; "isSignal": true; }; "showQuickPresets": { "alias": "showQuickPresets"; "required": false; "isSignal": true; }; }, {}, ["actions"], ["ngs-datepicker-actions"], true, never>;
}

declare class DatepickerApply {
    _datepicker: any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerApply, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DatepickerApply, "[ngsDatepickerApply]", never, {}, {}, never, never, true, never>;
}
declare class DatepickerCancel {
    _datepicker: any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerCancel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DatepickerCancel, "[ngsDatepickerCancel]", never, {}, {}, never, never, true, never>;
}

declare class DateRangePicker<D> implements OnDestroy {
    private _overlay;
    private _viewContainerRef;
    private _dateAdapter;
    readonly startAt: _angular_core.InputSignal<D | null>;
    readonly calendarHeaderComponent: _angular_core.InputSignal<Type<any> | null>;
    readonly quickPresets: _angular_core.InputSignal<DatepickerPreset<D>[] | null>;
    readonly showQuickPresets: _angular_core.InputSignal<boolean>;
    readonly _portalTemplate: _angular_core.Signal<TemplateRef<any>>;
    readonly actions: _angular_core.Signal<DatepickerActions | undefined>;
    _datepickerInput: any;
    _selectedRange: _angular_core.WritableSignal<DateRange<D>>;
    _isAbove: _angular_core.WritableSignal<boolean>;
    readonly _effectivePresets: _angular_core.Signal<DatepickerPreset<D>[]>;
    private _overlayRef;
    ngOnDestroy(): void;
    _registerInput(input: any): void;
    open(): void;
    close(): void;
    _select(date: D): void;
    _selectPreset(preset: DatepickerPreset<D>): void;
    private _updateSelectedRange;
    apply(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateRangePicker<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateRangePicker<any>, "ngs-date-range-picker", ["ngsDateRangePicker"], { "startAt": { "alias": "startAt"; "required": false; "isSignal": true; }; "calendarHeaderComponent": { "alias": "calendarHeaderComponent"; "required": false; "isSignal": true; }; "quickPresets": { "alias": "quickPresets"; "required": false; "isSignal": true; }; "showQuickPresets": { "alias": "showQuickPresets"; "required": false; "isSignal": true; }; }, {}, ["actions"], ["ngs-datepicker-actions"], true, never>;
}

declare class DatepickerInput<D> implements ControlValueAccessor, OnDestroy, OnInit {
    private _elementRef;
    private _formField;
    private _dateAdapter;
    readonly ngsDatepicker: _angular_core.InputSignal<Datepicker<D>>;
    _value: D | null;
    _onChange: (value: any) => void;
    _onTouched: () => void;
    readonly _valueChange: Subject<D | null>;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    writeValue(value: D | null): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    _onInput(value: string): void;
    private _formatValue;
    getConnectedOverlayOrigin(): ElementRef;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerInput<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DatepickerInput<any>, "input[ngsDatepicker]", never, { "ngsDatepicker": { "alias": "ngsDatepicker"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class StartDate<D> {
    private _elementRef;
    private _dateAdapter;
    _rangeInput: DateRangeInput<D>;
    _onInput(value: string): void;
    _formatValue(value: D | null): void;
    _onFocus(): void;
    _onBlur(): void;
    isEmpty(): boolean;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StartDate<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<StartDate<any>, "input[ngsStartDate]", never, {}, {}, never, never, true, never>;
}
declare class EndDate<D> {
    private _elementRef;
    private _dateAdapter;
    _rangeInput: DateRangeInput<D>;
    _onInput(value: string): void;
    _formatValue(value: D | null): void;
    _onFocus(): void;
    _onBlur(): void;
    isEmpty(): boolean;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EndDate<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<EndDate<any>, "input[ngsEndDate]", never, {}, {}, never, never, true, never>;
}
declare class DateRangeInput<D> implements OnDestroy, OnInit, FormFieldControl<DateRange<D>> {
    private _elementRef;
    private _formField;
    readonly rangePicker: _angular_core.InputSignal<DateRangePicker<D>>;
    readonly separator: _angular_core.InputSignal<string>;
    readonly ngControl: NgControl | null;
    _startInput: _angular_core.Signal<StartDate<any> | undefined>;
    _endInput: _angular_core.Signal<EndDate<any> | undefined>;
    _value: DateRange<D> | null;
    get value(): DateRange<D> | null;
    private _focused;
    get focused(): boolean;
    private _empty;
    get empty(): boolean;
    private _shouldLabelFloat;
    get shouldLabelFloat(): boolean;
    readonly stateChanges: Subject<void>;
    private _inputStateChanges;
    id: string;
    placeholder: string;
    required: boolean;
    disabled: boolean;
    errorState: boolean;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    _startUpdated(date: D | null): void;
    _endUpdated(date: D | null): void;
    _rangeUpdated(range: DateRange<D>): void;
    _handleFocus(): void;
    _handleBlur(): void;
    _inputUpdated(): void;
    getConnectedOverlayOrigin(): ElementRef;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateRangeInput<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateRangeInput<any>, "ngs-date-range-input", never, { "rangePicker": { "alias": "rangePicker"; "required": true; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; }, {}, ["_startInput", "_endInput"], ["input[ngsStartDate]", "input[ngsEndDate]"], true, never>;
}

declare class DatepickerToggleIcon {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerToggleIcon, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DatepickerToggleIcon, "[ngsDatepickerToggleIcon]", never, {}, {}, never, never, true, never>;
}

declare class DatepickerToggle<D> {
    private _intl;
    private _formField;
    readonly for: _angular_core.InputSignal<Datepicker<D> | DateRangePicker<D>>;
    readonly customIcon: _angular_core.Signal<DatepickerToggleIcon | undefined>;
    _open(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerToggle<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DatepickerToggle<any>, "ngs-datepicker-toggle", ["ngsDatepickerToggle"], { "for": { "alias": "for"; "required": true; "isSignal": true; }; }, {}, ["customIcon"], ["[ngsDatepickerToggleIcon]"], true, never>;
}

declare class Calendar<D> {
    private _dateAdapter;
    private _intl;
    readonly startAt: _angular_core.InputSignal<D | null>;
    readonly selected: _angular_core.InputSignal<D | DateRange<D> | null>;
    readonly minDate: _angular_core.InputSignal<D | null>;
    readonly maxDate: _angular_core.InputSignal<D | null>;
    readonly headerComponent: _angular_core.InputSignal<Type<any> | null>;
    readonly selectedChange: _angular_core.OutputEmitterRef<D>;
    readonly yearSelected: _angular_core.OutputEmitterRef<D>;
    readonly monthSelected: _angular_core.OutputEmitterRef<D>;
    activeDate: _angular_core.WritableSignal<D>;
    constructor();
    currentView: _angular_core.WritableSignal<"month" | "year" | "multi-year">;
    readonly _selectedDate: _angular_core.Signal<D | null>;
    readonly periodButtonText: _angular_core.Signal<string>;
    prevPage(): void;
    nextPage(): void;
    toggleView(): void;
    _monthSelectedInYearView(date: D): void;
    _yearSelectedInMultiYearView(date: D): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Calendar<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Calendar<any>, "ngs-calendar", ["ngsCalendar"], { "startAt": { "alias": "startAt"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "headerComponent": { "alias": "headerComponent"; "required": false; "isSignal": true; }; }, { "selectedChange": "selectedChange"; "yearSelected": "yearSelected"; "monthSelected": "monthSelected"; }, never, never, true, never>;
}

declare class MonthView<D> {
    private _dateAdapter;
    readonly activeDate: _angular_core.InputSignal<D>;
    readonly selected: _angular_core.InputSignal<D | DateRange<D> | null>;
    readonly minDate: _angular_core.InputSignal<D | null>;
    readonly maxDate: _angular_core.InputSignal<D | null>;
    readonly selectedChange: _angular_core.OutputEmitterRef<D>;
    readonly hoveredDate: _angular_core.WritableSignal<D | null>;
    readonly weekdays: _angular_core.Signal<string[]>;
    readonly weeks: _angular_core.Signal<{
        date: D | null;
        label: string;
        selected: boolean;
        current: boolean;
        inRange: boolean;
        rangeStart: boolean;
        rangeEnd: boolean;
    }[][]>;
    selectDate(date: D | null): void;
    handleHover(date: D | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MonthView<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MonthView<any>, "ngs-month-view", never, { "activeDate": { "alias": "activeDate"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; }, { "selectedChange": "selectedChange"; }, never, never, true, never>;
}

declare class YearView<D> {
    private _dateAdapter;
    readonly activeDate: _angular_core.InputSignal<D>;
    readonly selected: _angular_core.InputSignal<D | null>;
    readonly monthSelected: _angular_core.OutputEmitterRef<D>;
    readonly months: _angular_core.Signal<{
        index: number;
        label: string;
        selected: boolean;
        current: boolean;
    }[][]>;
    selectMonth(month: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<YearView<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<YearView<any>, "ngs-year-view", never, { "activeDate": { "alias": "activeDate"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "monthSelected": "monthSelected"; }, never, never, true, never>;
}

declare class MultiYearView<D> {
    private _dateAdapter;
    readonly activeDate: _angular_core.InputSignal<D>;
    readonly selected: _angular_core.InputSignal<D | null>;
    readonly yearSelected: _angular_core.OutputEmitterRef<D>;
    readonly years: _angular_core.Signal<{
        value: number;
        label: string;
        selected: boolean;
        current: boolean;
    }[][]>;
    selectYear(year: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiYearView<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MultiYearView<any>, "ngs-multi-year-view", never, { "activeDate": { "alias": "activeDate"; "required": true; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "yearSelected": "yearSelected"; }, never, never, true, never>;
}

/** Injection token for the DateAdapter's locale. */
declare const MAT_DATE_LOCALE: InjectionToken<string>;
/** Injection token for the DateAdapter's formats. */
declare const MAT_DATE_FORMATS: InjectionToken<any>;
declare abstract class DateAdapter<D> {
    protected _localeChanges: Subject<void>;
    readonly localeChanges: Subject<void>;
    abstract getYear(date: D): number;
    abstract getMonth(date: D): number;
    abstract getDate(date: D): number;
    abstract getDayOfWeek(date: D): number;
    abstract getMonthNames(style: 'long' | 'short' | 'narrow'): string[];
    abstract getDateNames(): string[];
    abstract getDayOfWeekNames(style: 'long' | 'short' | 'narrow'): string[];
    abstract getYearName(date: D): string;
    abstract getFirstDayOfWeek(): number;
    abstract getNumDaysInMonth(date: D): number;
    abstract clone(date: D): D;
    abstract createDate(year: number, month: number, date: number): D;
    abstract today(): D;
    abstract parse(value: any, parseFormat: any): D | null;
    abstract format(date: D, displayFormat: any): string;
    abstract addCalendarYears(date: D, years: number): D;
    abstract addCalendarMonths(date: D, months: number): D;
    abstract addCalendarDays(date: D, days: number): D;
    abstract toIso8601(date: D): string;
    abstract isDateInstance(obj: any): obj is D;
    abstract isValid(date: D): boolean;
    abstract invalid(): D;
    setLocale(locale: string): void;
    protected locale: string;
    compareDate(first: D, second: D): number;
    sameDate(first: D | null, second: D | null): boolean;
    clampDate(date: D, min?: D | null, max?: D | null): D;
}

declare class NativeDateAdapter extends DateAdapter<Date> {
    getYear(date: Date): number;
    getMonth(date: Date): number;
    getDate(date: Date): number;
    getDayOfWeek(date: Date): number;
    getMonthNames(style: 'long' | 'short' | 'narrow'): string[];
    getDateNames(): string[];
    getDayOfWeekNames(style: 'long' | 'short' | 'narrow'): string[];
    getYearName(date: Date): string;
    getFirstDayOfWeek(): number;
    getNumDaysInMonth(date: Date): number;
    clone(date: Date): Date;
    createDate(year: number, month: number, date: number): Date;
    today(): Date;
    parse(value: any): Date | null;
    format(date: Date, displayFormat: Object): string;
    addCalendarYears(date: Date, years: number): Date;
    addCalendarMonths(date: Date, months: number): Date;
    addCalendarDays(date: Date, days: number): Date;
    toIso8601(date: Date): string;
    isDateInstance(obj: any): obj is Date;
    isValid(date: Date): boolean;
    invalid(): Date;
    private _2digit;
    private _stripDirectionMarkers;
    private _createDateWithOverflow;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NativeDateAdapter, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<NativeDateAdapter>;
}

declare const MAT_NATIVE_DATE_FORMATS: {
    parse: {
        dateInput: null;
    };
    display: {
        dateInput: {
            month: string;
            year: string;
            day: string;
        };
        monthYearLabel: {
            month: string;
            year: string;
        };
        dateA11yLabel: {
            month: string;
            year: string;
            day: string;
        };
        monthYearA11yLabel: {
            month: string;
            year: string;
        };
    };
};
declare function provideNativeDateAdapter(): Provider[];

declare class DatepickerIntl {
    readonly changes: Subject<void>;
    calendarLabel: string;
    openCalendarLabel: string;
    prevMonthLabel: string;
    nextMonthLabel: string;
    prevYearLabel: string;
    nextYearLabel: string;
    prevMultiYearLabel: string;
    nextMultiYearLabel: string;
    switchToMonthViewLabel: string;
    switchToMultiYearViewLabel: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DatepickerIntl>;
}

export { Calendar, DateAdapter, DateRange, DateRangeInput, DateRangePicker, Datepicker, DatepickerActions, DatepickerApply, DatepickerCancel, DatepickerInput, DatepickerIntl, DatepickerToggle, DatepickerToggleIcon, EndDate, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MAT_NATIVE_DATE_FORMATS, MonthView, MultiYearView, NativeDateAdapter, StartDate, YearView, provideNativeDateAdapter };
export type { DatepickerPreset };
