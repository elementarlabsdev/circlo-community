import * as i0 from '@angular/core';
import { QueryList, ElementRef } from '@angular/core';
import { CdkTable, CdkHeaderRowDef, CdkColumnDef, CdkCell, CdkCellDef, CdkFooterCell, CdkFooterCellDef, CdkFooterRow, CdkFooterRowDef, CdkHeaderCell, CdkHeaderCellDef, CdkHeaderRow, CdkNoDataRow, CdkRow, CdkRowDef, CdkTextColumn } from '@angular/cdk/table';
import { DataSource } from '@angular/cdk/collections';
import { Subscription, BehaviorSubject } from 'rxjs';
import { SortDirective } from '@ngstarter/components/sort';
import { Paginator } from '@ngstarter/components/paginator';

declare class Table<T> extends CdkTable<T> {
    hideHeader: i0.InputSignalWithTransform<boolean, unknown>;
    hideBody: i0.InputSignalWithTransform<boolean, unknown>;
    hideFooter: i0.InputSignalWithTransform<boolean, unknown>;
    private readonly destroyRef;
    /**
     * Whether the table has any sticky header rows.
     * This is used to apply the 'ngs-table-sticky-header' class.
     */
    private readonly _hasStickyHeader;
    readonly hasStickyHeader: i0.Signal<boolean>;
    headerRowDefsQuery: QueryList<CdkHeaderRowDef>;
    columnDefsQuery: QueryList<CdkColumnDef>;
    /**
     * Whether the table has any sticky columns.
     */
    private readonly _hasStickyColumns;
    readonly hasStickyColumns: i0.Signal<boolean>;
    private _updateStickyStates;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    protected stickyCssClass: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<Table<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Table<any>, "ngs-table, table[ngs-table]", ["ngsTable"], { "hideHeader": { "alias": "hideHeader"; "required": false; "isSignal": true; }; "hideBody": { "alias": "hideBody"; "required": false; "isSignal": true; }; "hideFooter": { "alias": "hideFooter"; "required": false; "isSignal": true; }; }, {}, ["headerRowDefsQuery", "columnDefsQuery"], never, true, never>;
}

/** Cell template container that adds the right classes and role. */
declare class Cell extends CdkCell {
    constructor(elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<Cell, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<Cell, "ngs-cell, [ngs-cell], td[ngs-cell]", never, {}, {}, never, never, true, never>;
}

/** Cell definition for the ngs-table. */
declare class CellDef extends CdkCellDef {
    static ɵfac: i0.ɵɵFactoryDeclaration<CellDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CellDef, "[ngsCellDef]", never, {}, {}, never, never, true, never>;
}

/**
 * Column definition for the ngs-table.
 * Defines a set of cells available for a table column.
 */
declare class ColumnDef extends CdkColumnDef {
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ColumnDef, "[ngsColumnDef]", never, { "name": { "alias": "ngsColumnDef"; "required": false; }; }, {}, never, never, true, never>;
}

/** Footer cell template container that adds the right classes and role. */
declare class FooterCell extends CdkFooterCell {
    constructor(elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterCell, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FooterCell, "ngs-footer-cell, [ngs-footer-cell], td[ngs-footer-cell]", never, {}, {}, never, never, true, never>;
}

/** Footer cell definition for the ngs-table. */
declare class FooterCellDef extends CdkFooterCellDef {
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterCellDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FooterCellDef, "[ngsFooterCellDef]", never, {}, {}, never, never, true, never>;
}

/** Footer template container that adds the right classes and role. */
declare class FooterRow extends CdkFooterRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FooterRow, "ngs-footer-row, [ngs-footer-row], tr[ngs-footer-row]", never, {}, {}, never, never, true, never>;
}

/** Footer row definition for the ngs-table. */
declare class FooterRowDef extends CdkFooterRowDef {
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterRowDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FooterRowDef, "[ngsFooterRowDef]", never, { "columns": { "alias": "ngsFooterRowDef"; "required": false; }; "sticky": { "alias": "ngsFooterRowDefSticky"; "required": false; }; }, {}, never, never, true, never>;
}

/** Header cell template container that adds the right classes and role. */
declare class HeaderCell extends CdkHeaderCell {
    constructor(elementRef: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderCell, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HeaderCell, "ngs-header-cell, [ngs-header-cell], th[ngs-header-cell]", never, {}, {}, never, never, true, never>;
}

/** Header cell definition for the ngs-table. */
declare class HeaderCellDef extends CdkHeaderCellDef {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderCellDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HeaderCellDef, "[ngsHeaderCellDef]", never, {}, {}, never, never, true, never>;
}

/** Header template container that adds the right classes and role. */
declare class HeaderRow extends CdkHeaderRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderRow, "ngs-header-row, [ngs-header-row], tr[ngs-header-row]", never, {}, {}, never, never, true, never>;
}

/** Header row definition for the ngs-table. */
declare class HeaderRowDef extends CdkHeaderRowDef {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderRowDef, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HeaderRowDef, "[ngsHeaderRowDef]", never, { "columns": { "alias": "ngsHeaderRowDef"; "required": false; }; "sticky": { "alias": "ngsHeaderRowDefSticky"; "required": false; }; }, {}, never, never, true, never>;
}

/** Row that can be used to display a message when no data is shown in the table. */
declare class NoDataRow extends CdkNoDataRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<NoDataRow, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NoDataRow, "ng-template[ngsNoDataRow]", never, {}, {}, never, never, true, never>;
}

/** Data row template container that adds the right classes and role. */
declare class Row extends CdkRow {
    static ɵfac: i0.ɵɵFactoryDeclaration<Row, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Row, "ngs-row, [ngs-row], tr[ngs-row]", never, {}, {}, never, never, true, never>;
}

/** Data row definition for the ngs-table. */
declare class RowDef<T> extends CdkRowDef<T> {
    static ɵfac: i0.ɵɵFactoryDeclaration<RowDef<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RowDef<any>, "[ngsRowDef]", never, { "columns": { "alias": "ngsRowDefColumns"; "required": false; }; "when": { "alias": "ngsRowDefWhen"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Column that simply shows text content for the header and row cells. Assumes that the table
 * is using the native table implementation (`<table>`).
 *
 * By default, the name of this column will be the same as the data property that it should show.
 * The header can be overridden by setting the `headerText` input.
 *
 * Example usage:
 * <table ngs-table [dataSource]="dataSource">
 *   <ngs-text-column name="userName"></ngs-text-column>
 *   <tr ngs-header-row *ngsHeaderRowDef="['userName']"></tr>
 *   <tr ngs-row *ngsRowDef="['userName']"></tr>
 * </table>
 */
declare class TextColumn<T> extends CdkTextColumn<T> {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextColumn<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextColumn<any>, "ngs-text-column", never, {}, {}, never, never, true, never>;
}

declare class TableDataSource<T> extends DataSource<T> {
    /** Stream that emits when a new data array is set on the data source. */
    private readonly _data;
    /** Stream emitting render data to the table (depends on ordered data changes). */
    private readonly _renderData;
    /** Stream that emits when a new filter string is set on the data source. */
    private readonly _filter;
    /** Used to react to internal changes of the paginator that the table needs to be notified about. */
    private readonly _internalPageChanges;
    /**
     * Subscription to the changes that should trigger an update to the table's rendered data, such
     * as filtering, sorting, pagination, or base data changes.
     */
    _renderChangesSubscription: Subscription;
    /**
     * Cache for quick filter strings. Maps each data object to its concatenated string representation
     * used for filtering.
     */
    private _quickFilterCache;
    /**
     * The filtered set of data that has been matched by the filter string, or all the data if there
     * is no filter. Useful for knowing the set of data the table represents.
     * For example, a 'scrolled' paginator can use this to know the total number of items when
     * pagination has been applied.
     */
    filteredData: T[];
    /**
     * The sorted set of data that has been ordered by the sort state, or all the filtered data if there
     * is no sort. Useful for knowing the set of data the table represents.
     */
    sortedData: T[];
    /** Array of data that should be rendered by the table, where each object represents one row. */
    get data(): T[];
    set data(data: T[]);
    /**
     * Filter term that should be used to filter out objects from the data array. To `TableDataSource`'s
     * default implementation, this string checks for stringification matches anywhere in the object.
     */
    get filter(): string;
    set filter(filter: string);
    /**
     * Instance of the MatSort directive used by the table to control its sorting. Sort changes
     * emitted by the MatSort will trigger an update to the table's rendered data.
     */
    get sort(): SortDirective | null;
    set sort(sort: SortDirective | null);
    private _sort;
    /**
     * Instance of the Paginator component used by the table to control what page of the data is
     * displayed. Page changes emitted by the Paginator will trigger an update to the
     * table's rendered data.
     */
    get paginator(): Paginator | null;
    set paginator(paginator: Paginator | null);
    private _paginator;
    /**
     * Data accessor function that is used for accessing data properties for sorting through
     * the default sortData function.
     * This default function assumes that the data objects are flat and can be accessed directly by
     * the column name.
     */
    sortingDataAccessor: (data: T, sortHeaderId: string) => string | number;
    /**
     * Gets a sorted copy of the data array based on the state of the MatSort. Called
     * after changes are made to the filtered data or when sort changes are emitted from MatSort.
     * By default, the function retrieves the active sort and its direction and compares data
     * objects by retrieving data using the sortingDataAccessor. May be overridden for a
     * custom implementation of data ordering.
     * @param data The array of data that should be sorted.
     * @param sort The connected MatSort that holds the current sort state.
     */
    sortData: (data: T[], sort: SortDirective) => T[];
    /**
     * Checks if a data object matches the data source's filter string. By default, each data object
     * is converted to a string of its properties and returns true if the filter has at least one
     * occurrence in that string. By default, the filter string has its whitespace trimmed and the match
     * is case-insensitive. May be overridden for a custom implementation of filter matching.
     * @param data Data object used to check against the filter.
     * @param filter Filter string that has been set on the data source.
     * @returns Whether the filter matches the data.
     */
    filterPredicate: (data: T, filter: string) => boolean;
    /**
     * Gets a string representation of the data object used for quick filtering.
     * Caches the result to improve performance.
     * @param data
     * @private
     */
    private _getQuickFilterString;
    constructor(initialData?: T[]);
    /**
     * Subscribe to changes that should trigger an update to the table's rendered data.
     */
    _updateChangeSubscription(): void;
    private _observeOutput;
    /**
     * Returns a filtered data array where each filter object contains the filter string within
     * the result of the filterPredicate function. If no filter is set, returns the entire data
     * array without changes.
     */
    _filterData(data: T[]): T[];
    /**
     * Returns a sorted copy of the data if MatSort has a sort applied, otherwise just returns the
     * data array entirely.
     */
    _orderData(data: T[]): T[];
    /**
     * Returns a paged splice of the provided data array based on the provided Paginator's page
     * index and length. If there is no paginator provided, returns the data array as is.
     */
    _pageData(data: T[]): T[];
    /**
     * Updates the paginator to reflect the length of the filtered data, and makes sure that the page
     * index does not exceed the amount of pages in the new data set.
     */
    _updatePaginator(filteredDataLength: number): void;
    /**
     * Used by the CdkTable. Called when it connects to the data source.
     * @docs-private
     */
    connect(): BehaviorSubject<T[]>;
    /**
     * Used by the CdkTable. Called when it disconnects from the data source.
     * @docs-private
     */
    disconnect(): void;
}

declare class NativeTable {
    static ɵfac: i0.ɵɵFactoryDeclaration<NativeTable, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NativeTable, "table[ngs-native-table]", ["ngsNativeTable"], {}, {}, never, ["*"], true, never>;
}

export { Cell, CellDef, ColumnDef, FooterCell, FooterCellDef, FooterRow, FooterRowDef, HeaderCell, HeaderCellDef, HeaderRow, HeaderRowDef, NativeTable, NoDataRow, Row, RowDef, Table, TableDataSource, TextColumn };
