import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { Ripple } from '@ngstarter/components/core';

type ButtonVariant = 'filled' | 'outlined' | 'text' | 'tonal' | '';
declare class Button {
    readonly elementRef: ElementRef<any>;
    readonly _ripple: Ripple | null;
    readonly ngsButton: _angular_core.InputSignal<ButtonVariant>;
    readonly ngsIconButton: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabledInteractive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disableRipple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly reverse: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly hideTextOnMobile: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor();
    /** Whether the button is an icon button. */
    get isIconButton(): boolean;
    _haltDisabledEvents(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Button, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Button, "    button[ngsButton], button[ngsIconButton],    a[ngsButton], a[ngsIconButton]  ", ["ngsButton"], { "ngsButton": { "alias": "ngsButton"; "required": false; "isSignal": true; }; "ngsIconButton": { "alias": "ngsIconButton"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disabledInteractive": { "alias": "disabledInteractive"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; "reverse": { "alias": "reverse"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "hideTextOnMobile": { "alias": "hideTextOnMobile"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-icon", "*"], true, never>;
}

export { Button };
export type { ButtonVariant };
