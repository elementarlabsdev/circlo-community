import * as _angular_core from '@angular/core';
import { OnInit, ElementRef } from '@angular/core';

declare class ResizableContainer implements OnInit {
    private _renderer;
    private _elementRef;
    private _cdr;
    private _ngZone;
    private _destroyRef;
    private _document;
    private _resizing;
    private _maxWidth;
    private _clientX;
    readonly handlerRef: _angular_core.Signal<ElementRef<any>>;
    minWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    ngOnInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ResizableContainer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ResizableContainer, "ngs-resizable-container", ["ngsResizableContainer"], { "minWidth": { "alias": "minWidth"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { ResizableContainer };
