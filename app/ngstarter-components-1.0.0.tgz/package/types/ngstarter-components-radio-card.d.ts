import * as i0 from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class RadioCardGroup implements ControlValueAccessor {
    readonly value: i0.WritableSignal<any>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    private onTouched;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    selectValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioCardGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioCardGroup, "ngs-radio-card-group", ["ngsRadioCardGroup"], {}, {}, never, ["*"], true, never>;
}

declare class RadioCard {
    value: i0.InputSignal<any>;
    protected parentGroup: RadioCardGroup;
    readonly isSelected: i0.Signal<boolean>;
    selectCard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioCard, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioCard, "ngs-radio-card", ["ngsRadioCard"], { "value": { "alias": "value"; "required": true; "isSignal": true; }; }, {}, never, ["ngs-radio-card-title", "*"], true, never>;
}

declare class RadioCardTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioCardTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioCardTitle, "ngs-radio-card-title", never, {}, {}, never, ["*"], true, never>;
}

declare class RadioCardContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioCardContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioCardContent, "ngs-radio-card-content", never, {}, {}, never, ["*"], true, never>;
}

export { RadioCard, RadioCardContent, RadioCardGroup, RadioCardTitle };
