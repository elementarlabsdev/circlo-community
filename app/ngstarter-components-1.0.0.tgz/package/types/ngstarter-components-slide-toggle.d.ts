import * as _angular_core from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class SlideToggleChange {
    source: SlideToggle;
    checked: boolean;
    constructor(source: SlideToggle, checked: boolean);
}
declare class SlideToggle implements ControlValueAccessor {
    private _uniqueId;
    id: _angular_core.InputSignal<string>;
    name: _angular_core.InputSignal<string | null>;
    labelPosition: _angular_core.InputSignal<"before" | "after">;
    ariaLabel: _angular_core.InputSignal<string | null>;
    ariaLabelledby: _angular_core.InputSignal<string | null>;
    ariaDescribedby: _angular_core.InputSignal<string | null>;
    required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.ModelSignal<boolean>;
    disableRipple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    tabIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    hideIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    color: _angular_core.InputSignal<string | undefined>;
    checked: _angular_core.ModelSignal<boolean>;
    change: _angular_core.OutputEmitterRef<SlideToggleChange>;
    toggleChange: _angular_core.OutputEmitterRef<void>;
    private _onChange;
    private _onTouched;
    constructor();
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    toggle(): void;
    _onInputClick(event: Event): void;
    private _emitChangeEvent;
    _onInputBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SlideToggle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SlideToggle, "ngs-slide-toggle", ["ngsSlideToggle"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; "tabIndex": { "alias": "tabIndex"; "required": false; "isSignal": true; }; "hideIcon": { "alias": "hideIcon"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "checked": "checkedChange"; "change": "change"; "toggleChange": "toggleChange"; }, never, ["*"], true, never>;
}

export { SlideToggle, SlideToggleChange };
