import * as _angular_core from '@angular/core';
import { InjectionToken, TemplateRef, OnInit, AfterViewInit, Injector, EnvironmentProviders } from '@angular/core';
import { TableDataSource, Table } from '@ngstarter/components/table';
import { CheckboxChange } from '@ngstarter/components/checkbox';
import { SelectionModel } from '@angular/cdk/collections';
import { Paginator, PageEvent } from '@ngstarter/components/paginator';
import { Sort, SortDirective, SortDirection } from '@ngstarter/components/sort';

interface DataViewInterface {
    api: DataViewAPI;
}
interface DataViewAPI {
    search(value: string): void;
    selectAll(): void;
    unselectAll(): void;
    refresh(): void;
    getSnapshot(): DataViewState[];
}
interface DataViewColumnDef {
    name: string;
    field: string;
    cellRenderer?: string;
    visible?: boolean;
    width?: string;
    flex?: number;
    type?: string;
    valueGetter?: (value: any) => any;
    pinned?: boolean;
    pinAlign?: DataViewPinAlign;
    sortable?: boolean;
    resizable?: boolean;
    withColumnSettings?: boolean;
    minWidth?: string | number;
    maxWidth?: string | number;
    params?: {
        [prop: string]: any;
    };
}
interface DataViewRowSelectionEvent<T> {
    checkboxChange: CheckboxChange;
    row: T;
    checked: boolean;
}
interface DataViewCellRendererDef {
    cellRenderer: string;
    component: () => Promise<any>;
}
interface DataViewCellRenderer {
    element: any;
    columnDef: any;
    fieldData: any;
}
interface DataViewActionBarAPI {
    setForceVisible: (visible: boolean) => void;
}
type DataViewRowModelType = 'clientSide' | 'serverSide';
interface DataViewGetRowsParams {
    startRow: number;
    endRow: number;
    page: number;
    pageSize: number;
    sortModel: {
        colId: string;
        sort: 'asc' | 'desc' | '';
    }[];
    filterModel: string;
    successCallback(rowsThisBlock: any[], lastRow?: number): void;
    failCallback(): void;
}
interface DataViewDatasource {
    getItems(params: DataViewGetRowsParams): void;
}
type DataViewPinAlign = 'start' | 'end' | undefined;
interface DataViewState {
    field: string;
    visible?: boolean;
    width?: string;
    pinned?: boolean;
    pinAlign?: DataViewPinAlign;
}
declare const DATA_VIEW: InjectionToken<DataViewInterface>;

declare class DataViewEmptyFilterResultsDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewEmptyFilterResultsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DataViewEmptyFilterResultsDirective, "[ngsDataViewEmptyFilterResults]", ["ngsDataViewEmptyFilterResults"], {}, {}, never, never, true, never>;
}

declare class DataViewActionBarDirective {
    readonly templateRef: TemplateRef<any>;
    readonly width: _angular_core.InputSignalWithTransform<number, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewActionBarDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DataViewActionBarDirective, "[ngsDataViewActionBar]", never, { "width": { "alias": "ngsDataViewActionBarWidth"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class DataViewActionBar {
    forceVisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    width: _angular_core.InputSignalWithTransform<number, unknown>;
    protected _forceVisible: boolean;
    get api(): DataViewActionBarAPI;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewActionBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DataViewActionBar, "ngs-data-view-action-bar", ["ngsDataViewActionBar"], { "forceVisible": { "alias": "forceVisible"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class DataView<T> implements OnInit, AfterViewInit, DataViewInterface {
    private _cdr;
    private _destroyRef;
    private _platformId;
    private _ngZone;
    private _doc;
    private _config;
    private _elRef;
    private _dialog;
    private _isDestroyed;
    private _requestId;
    private _lastRequestKey;
    private _refreshTrigger;
    private _serverSideRowCount;
    private _manualOrder;
    private _manualVisibility;
    private _hasDataOnServer;
    private _internalLoading;
    protected _isFiltering: _angular_core.WritableSignal<boolean>;
    protected _isSorting: _angular_core.WritableSignal<boolean>;
    private _emptyDataRef;
    protected _emptyFilterResults: _angular_core.Signal<DataViewEmptyFilterResultsDirective | undefined>;
    protected _actionBarRef: _angular_core.Signal<DataViewActionBarDirective | undefined>;
    protected _actionBarComp: _angular_core.Signal<DataViewActionBar | undefined>;
    private _table;
    private _ngsSort;
    private _internalPaginator;
    paginator: _angular_core.InputSignal<Paginator | null>;
    private _dataSource;
    private _headerCenter;
    private _headerCenterInner;
    private _bodyLeftContent;
    private _scrollbarArea;
    private _bodyCenterContent;
    private _bodyRightContent;
    columnDefs: _angular_core.InputSignal<DataViewColumnDef[]>;
    defaultColDef: _angular_core.InputSignal<Partial<DataViewColumnDef>>;
    data: _angular_core.InputSignal<T[]>;
    datasource: _angular_core.InputSignal<DataViewDatasource | null>;
    rowHeight: _angular_core.InputSignalWithTransform<number, any>;
    headerHeight: _angular_core.InputSignalWithTransform<number, any>;
    bufferRows: _angular_core.InputSignalWithTransform<number, any>;
    withSelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    highlightHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    rowModelType: _angular_core.InputSignal<DataViewRowModelType>;
    autoHeight: _angular_core.InputSignalWithTransform<boolean, unknown>;
    stickyHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    withPagination: _angular_core.InputSignalWithTransform<boolean, unknown>;
    bodyScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    pageSizeOptions: _angular_core.InputSignal<number[]>;
    showFirstLastButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    paginatorAriaLabel: _angular_core.InputSignal<string>;
    pageSize: _angular_core.ModelSignal<number>;
    pageIndex: _angular_core.ModelSignal<number>;
    snapshot: _angular_core.InputSignal<DataViewState[] | null>;
    withColumnSettings: _angular_core.InputSignalWithTransform<boolean, unknown>;
    embedded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    rowSelection: _angular_core.InputSignal<"single" | "multiple">;
    selectionWidth: _angular_core.InputSignalWithTransform<number, any>;
    minColumnWidth: _angular_core.InputSignalWithTransform<number, any>;
    private _lastScrollTop;
    private _lastScrollLeft;
    private _scrollTop;
    private _viewportHeight;
    private _viewportWidth;
    protected loaded: _angular_core.WritableSignal<boolean>;
    protected isBrowser: _angular_core.WritableSignal<boolean>;
    protected hoveredRowIndex: _angular_core.WritableSignal<number | null>;
    private _initialViewState;
    private _manualWidths;
    private _manualPinned;
    private _isResizing;
    private _resizeLineLeft;
    private _resizeStartX;
    private _resizeStartWidth;
    private _resizeColField;
    protected isResizing(): boolean;
    protected resizeLineLeft(): number;
    private _normalizeWidth;
    protected normalizedColumns: _angular_core.Signal<{
        visible: boolean;
        width: string | undefined;
        flex: number | undefined;
        pinned: boolean | undefined;
        pinAlign: DataViewPinAlign;
        name: string;
        field: string;
        cellRenderer?: string;
        type?: string;
        valueGetter?: (value: any) => any;
        sortable?: boolean;
        resizable?: boolean;
        withColumnSettings?: boolean;
        minWidth?: string | number;
        maxWidth?: string | number;
        params?: {
            [prop: string]: any;
        };
    }[]>;
    protected isSortingEnabled: _angular_core.Signal<boolean>;
    protected pinnedLeftColumns: _angular_core.Signal<{
        visible: boolean;
        width: string | undefined;
        flex: number | undefined;
        pinned: boolean | undefined;
        pinAlign: DataViewPinAlign;
        name: string;
        field: string;
        cellRenderer?: string;
        type?: string;
        valueGetter?: (value: any) => any;
        sortable?: boolean;
        resizable?: boolean;
        withColumnSettings?: boolean;
        minWidth?: string | number;
        maxWidth?: string | number;
        params?: {
            [prop: string]: any;
        };
    }[]>;
    protected pinnedRightColumns: _angular_core.Signal<{
        visible: boolean;
        width: string | undefined;
        flex: number | undefined;
        pinned: boolean | undefined;
        pinAlign: DataViewPinAlign;
        name: string;
        field: string;
        cellRenderer?: string;
        type?: string;
        valueGetter?: (value: any) => any;
        sortable?: boolean;
        resizable?: boolean;
        withColumnSettings?: boolean;
        minWidth?: string | number;
        maxWidth?: string | number;
        params?: {
            [prop: string]: any;
        };
    }[]>;
    protected centerColumns: _angular_core.Signal<{
        visible: boolean;
        width: string | undefined;
        flex: number | undefined;
        pinned: boolean | undefined;
        pinAlign: DataViewPinAlign;
        name: string;
        field: string;
        cellRenderer?: string;
        type?: string;
        valueGetter?: (value: any) => any;
        sortable?: boolean;
        resizable?: boolean;
        withColumnSettings?: boolean;
        minWidth?: string | number;
        maxWidth?: string | number;
        params?: {
            [prop: string]: any;
        };
    }[]>;
    protected leftPinnedWidth: _angular_core.Signal<number>;
    protected leftPinnedWidthStyles: _angular_core.Signal<{
        'width.px': number;
        'min-width.px': number;
    }>;
    protected rightPinnedWidth: _angular_core.Signal<number>;
    protected rightPinnedWidthStyles: _angular_core.Signal<{
        'width.px': number;
        'min-width.px': number;
    }>;
    protected centerWidth: _angular_core.Signal<any>;
    protected onColumnResizeStart(event: MouseEvent, col: any): void;
    protected effectiveDataLength: _angular_core.Signal<number>;
    protected effectivePaginatorLength: _angular_core.Signal<number>;
    protected totalHeight: _angular_core.Signal<number>;
    protected visibleRange: _angular_core.Signal<{
        start: number;
        end: number;
    }>;
    protected visibleRows: _angular_core.Signal<{
        item: T;
        index: number;
        top: number;
        isLast: boolean;
    }[]>;
    displayedColumns: _angular_core.Signal<string[]>;
    protected isSelectionSticky: _angular_core.Signal<boolean>;
    protected hasHorizontalScroll: _angular_core.Signal<boolean>;
    protected dataSource: _angular_core.Signal<TableDataSource<T>>;
    private _syncEffect;
    private _loadDataEffect;
    private _dsRenderTick;
    private _connectEffect;
    cellRenderers: _angular_core.InputSignal<DataViewCellRendererDef[]>;
    loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    hoverRows: _angular_core.InputSignalWithTransform<boolean, unknown>;
    search: _angular_core.InputSignal<string>;
    private _debouncedSearch;
    private _debounceSearchEffect;
    emptyIcon: _angular_core.InputSignal<string>;
    emptyText: _angular_core.InputSignal<string>;
    emptyFilterResultsIcon: _angular_core.InputSignal<string>;
    emptyFilterResultsText: _angular_core.InputSignal<string>;
    protected interpolatedEmptyFilterResultsText: _angular_core.Signal<string>;
    protected _isLoading: _angular_core.Signal<boolean>;
    protected injector: Injector;
    protected selection: SelectionModel<T>;
    protected cellRenderersMap: Map<string, any>;
    protected loadingCellRenderers: _angular_core.WritableSignal<boolean>;
    readonly rowSelectionChanged: _angular_core.OutputEmitterRef<DataViewRowSelectionEvent<T>>;
    readonly selectionChanged: _angular_core.OutputEmitterRef<T[]>;
    readonly allRowsSelectionChanged: _angular_core.OutputEmitterRef<boolean>;
    readonly sortChange: _angular_core.OutputEmitterRef<Sort>;
    readonly loadEnd: _angular_core.OutputEmitterRef<void>;
    readonly refreshEnd: _angular_core.OutputEmitterRef<void>;
    get api(): DataViewAPI;
    refresh(): void;
    get noFilteredResults(): boolean;
    protected get isNoResults(): boolean;
    protected get isNoData(): boolean;
    get actionBarTemplateRef(): TemplateRef<any> | undefined;
    protected actionBarWidth: _angular_core.Signal<number>;
    protected get emptyTemplateRef(): TemplateRef<any>;
    protected get emptyFilterResultsTemplateRef(): TemplateRef<any>;
    protected get hasFilterValue(): boolean;
    getNestedValue(item: any, path: string): any;
    constructor();
    ngOnDestroy(): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private _syncScrolls;
    private _scheduleVirtualUpdate;
    private _syncTransforms;
    private _syncHoverState;
    get table(): Table<T>;
    get ngsSort(): SortDirective;
    hasCellRenderer(cellRenderer: string): boolean;
    getCellRenderer(cellRenderer: string): any;
    isAllSelected(): boolean;
    toggleAllRows(): void;
    rowSelectionToggle(event: CheckboxChange, row: T): void;
    onPageChange(event: PageEvent): void;
    protected sortColumn(col: DataViewColumnDef, direction: SortDirection): void;
    getSnapshot(): DataViewState[];
    applyState(state: DataViewState[]): void;
    protected pinColumn(col: any, align: DataViewPinAlign | null): void;
    protected autosizeColumn(col: DataViewColumnDef): void;
    protected autosizeAllColumns(): void;
    private _calculateColumnAutosize;
    protected resetColumns(): void;
    protected openColumnSettingsDialog(): void;
    protected onSortChange(event: Sort): void;
    private _selectAll;
    private _unselectAll;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataView<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DataView<any>, "ngs-data-view", ["ngsDataView"], { "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "columnDefs": { "alias": "columnDefs"; "required": false; "isSignal": true; }; "defaultColDef": { "alias": "defaultColDef"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "datasource": { "alias": "datasource"; "required": false; "isSignal": true; }; "rowHeight": { "alias": "rowHeight"; "required": false; "isSignal": true; }; "headerHeight": { "alias": "headerHeight"; "required": false; "isSignal": true; }; "bufferRows": { "alias": "bufferRows"; "required": false; "isSignal": true; }; "withSelection": { "alias": "withSelection"; "required": false; "isSignal": true; }; "highlightHeader": { "alias": "highlightHeader"; "required": false; "isSignal": true; }; "rowModelType": { "alias": "rowModelType"; "required": false; "isSignal": true; }; "autoHeight": { "alias": "autoHeight"; "required": false; "isSignal": true; }; "stickyHeader": { "alias": "stickyHeader"; "required": false; "isSignal": true; }; "withPagination": { "alias": "withPagination"; "required": false; "isSignal": true; }; "bodyScroll": { "alias": "bodyScroll"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "showFirstLastButtons": { "alias": "showFirstLastButtons"; "required": false; "isSignal": true; }; "paginatorAriaLabel": { "alias": "paginatorAriaLabel"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "pageIndex": { "alias": "pageIndex"; "required": false; "isSignal": true; }; "snapshot": { "alias": "snapshot"; "required": false; "isSignal": true; }; "withColumnSettings": { "alias": "withColumnSettings"; "required": false; "isSignal": true; }; "embedded": { "alias": "embedded"; "required": false; "isSignal": true; }; "rowSelection": { "alias": "rowSelection"; "required": false; "isSignal": true; }; "selectionWidth": { "alias": "selectionWidth"; "required": false; "isSignal": true; }; "minColumnWidth": { "alias": "minColumnWidth"; "required": false; "isSignal": true; }; "cellRenderers": { "alias": "cellRenderers"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "hoverRows": { "alias": "hoverRows"; "required": false; "isSignal": true; }; "search": { "alias": "search"; "required": false; "isSignal": true; }; "emptyIcon": { "alias": "emptyIcon"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; "emptyFilterResultsIcon": { "alias": "emptyFilterResultsIcon"; "required": false; "isSignal": true; }; "emptyFilterResultsText": { "alias": "emptyFilterResultsText"; "required": false; "isSignal": true; }; }, { "pageSize": "pageSizeChange"; "pageIndex": "pageIndexChange"; "rowSelectionChanged": "rowSelectionChanged"; "selectionChanged": "selectionChanged"; "allRowsSelectionChanged": "allRowsSelectionChanged"; "sortChange": "sortChange"; "loadEnd": "loadEnd"; "refreshEnd": "refreshEnd"; }, ["_emptyDataRef", "_emptyFilterResults", "_actionBarRef", "_actionBarComp"], never, true, never>;
}

declare class DataViewEmptyDataDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewEmptyDataDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DataViewEmptyDataDirective, "[ngsDataViewEmptyData]", ["ngsDataViewEmptyData"], {}, {}, never, never, true, never>;
}

declare function cellRenderer<T>(cellRenderer: string, component: any): DataViewCellRendererDef;

interface DataViewConfig {
    embedded?: boolean;
    rowHeight?: number;
    headerHeight?: number;
    bufferRows?: number;
    pageSizeOptions?: number[];
    pageSize?: number;
    rowSelection?: 'single' | 'multiple';
    selectionWidth?: number;
    stickyHeader?: boolean;
    withPagination?: boolean;
    showFirstLastButtons?: boolean;
    minColumnWidth?: number;
    defaultColDef?: Partial<DataViewColumnDef>;
    autoHeight?: boolean;
}
declare const DATA_VIEW_CONFIG: InjectionToken<DataViewConfig>;
declare function provideDataView(config: DataViewConfig): EnvironmentProviders;

export { DATA_VIEW, DATA_VIEW_CONFIG, DataView, DataViewActionBar, DataViewActionBarDirective, DataViewEmptyDataDirective, DataViewEmptyFilterResultsDirective, cellRenderer, provideDataView };
export type { DataViewAPI, DataViewActionBarAPI, DataViewCellRenderer, DataViewCellRendererDef, DataViewColumnDef, DataViewConfig, DataViewDatasource, DataViewGetRowsParams, DataViewInterface, DataViewPinAlign, DataViewRowModelType, DataViewRowSelectionEvent, DataViewState };
