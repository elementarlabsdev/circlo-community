import * as _angular_core from '@angular/core';
import { OnChanges, SimpleChanges } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';

declare class CodeHighlighter implements OnChanges {
    private sanitizer;
    code: _angular_core.InputSignal<string>;
    language: _angular_core.InputSignal<string>;
    theme: _angular_core.InputSignal<string>;
    title: _angular_core.InputSignal<string | null>;
    appearance: _angular_core.InputSignal<"none" | "bordered">;
    diff: _angular_core.InputSignal<boolean>;
    highlightLines: _angular_core.InputSignal<number[] | number[][]>;
    showLanguage: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showCopyButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly content: _angular_core.WritableSignal<SafeHtml | null>;
    readonly isLoading: _angular_core.WritableSignal<boolean>;
    readonly displayedLanguage: _angular_core.Signal<string>;
    private getHighlightTransformer;
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    copied: _angular_core.WritableSignal<boolean>;
    private copyTimeout?;
    copyCode(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CodeHighlighter, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CodeHighlighter, "ngs-code-highlighter", ["ngsCodeHighlighter"], { "code": { "alias": "code"; "required": true; "isSignal": true; }; "language": { "alias": "language"; "required": false; "isSignal": true; }; "theme": { "alias": "theme"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "diff": { "alias": "diff"; "required": false; "isSignal": true; }; "highlightLines": { "alias": "highlightLines"; "required": false; "isSignal": true; }; "showLanguage": { "alias": "showLanguage"; "required": false; "isSignal": true; }; "showCopyButton": { "alias": "showCopyButton"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { CodeHighlighter };
