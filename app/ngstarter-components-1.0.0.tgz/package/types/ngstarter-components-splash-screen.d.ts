import * as _angular_core from '@angular/core';
import * as _ngrx_signals from '@ngrx/signals';

declare class SplashScreen {
    private _store;
    private _renderer;
    private _elementRef;
    private _router;
    animationDuration: _angular_core.InputSignalWithTransform<number, unknown>;
    hideDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    constructor();
    ngOnInit(): void;
    private _show;
    private _hide;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplashScreen, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SplashScreen, "ngs-splash-screen", ["ngsSplashScreen"], { "animationDuration": { "alias": "animationDuration"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-logo", "*"], true, never>;
}

interface SplashScreenState {
    visible: boolean;
}
declare const SplashScreenStore: _angular_core.Type<{
    visible: _angular_core.Signal<boolean>;
    show: () => void;
    hide: () => void;
} & _ngrx_signals.StateSource<{
    visible: boolean;
}>>;

export { SplashScreen, SplashScreenStore };
export type { SplashScreenState };
