import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';

type SidenavMode = 'over' | 'push' | 'side';
type SidenavPosition = 'start' | 'end';
declare class Sidenav {
    private _platformId;
    private _breakpointObserver;
    private _destroyRef;
    private _ngZone;
    _elementRef: ElementRef<any>;
    readonly isHovered: _angular_core.WritableSignal<boolean>;
    protected _isSettled: _angular_core.WritableSignal<boolean>;
    private _isBreakpointMatched;
    private _previousOpened;
    /** Indicates whether the sidenav is in mobile (adaptive) mode. */
    isMobile: _angular_core.Signal<boolean>;
    effectiveMode: _angular_core.Signal<SidenavMode>;
    constructor();
    adaptive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    adaptiveBreakpoint: _angular_core.InputSignal<string>;
    opened: _angular_core.ModelSignal<boolean>;
    fixedWidth: _angular_core.InputSignal<string | number | null>;
    mode: _angular_core.InputSignal<SidenavMode>;
    position: _angular_core.InputSignal<SidenavPosition>;
    collapsed: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disableClose: _angular_core.InputSignalWithTransform<boolean, unknown>;
    open(): Promise<void>;
    close(): Promise<void>;
    toggle(isOpen?: boolean): Promise<void>;
    _getWidth(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Sidenav, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Sidenav, "ngs-sidenav", ["ngsSidenav"], { "adaptive": { "alias": "adaptive"; "required": false; "isSignal": true; }; "adaptiveBreakpoint": { "alias": "adaptiveBreakpoint"; "required": false; "isSignal": true; }; "opened": { "alias": "opened"; "required": false; "isSignal": true; }; "fixedWidth": { "alias": "fixedWidth"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; "disableClose": { "alias": "disableClose"; "required": false; "isSignal": true; }; }, { "opened": "openedChange"; }, never, ["*"], true, never>;
}

type AutoFocusTarget = 'dialog' | 'first-tabbable' | 'first-heading';
declare class SidenavContainer {
    private _ngZone;
    private _document;
    private _platformId;
    protected _isSettled: _angular_core.WritableSignal<boolean>;
    _sidenavs: _angular_core.Signal<readonly Sidenav[]>;
    readonly backdropClick: _angular_core.OutputEmitterRef<void>;
    hasBackdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    autoFocus: _angular_core.InputSignal<string | boolean>;
    autosize: _angular_core.InputSignalWithTransform<boolean, unknown>;
    fixedWidth: _angular_core.InputSignal<string | number | null>;
    constructor();
    private _focusSidenav;
    _isShowingBackdrop(): boolean;
    _onBackdropClicked(): void;
    _getContentMarginLeft(): string;
    _getContentMarginRight(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidenavContainer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidenavContainer, "ngs-sidenav-container", ["ngsSidenavContainer"], { "hasBackdrop": { "alias": "hasBackdrop"; "required": false; "isSignal": true; }; "autoFocus": { "alias": "autoFocus"; "required": false; "isSignal": true; }; "autosize": { "alias": "autosize"; "required": false; "isSignal": true; }; "fixedWidth": { "alias": "fixedWidth"; "required": false; "isSignal": true; }; }, { "backdropClick": "backdropClick"; }, ["_sidenavs"], ["ngs-sidenav", "ngs-sidenav-content", "*"], true, never>;
}

declare class SidenavContent {
    private _ngZone;
    protected _container: SidenavContainer;
    protected _isSettled: _angular_core.WritableSignal<boolean>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidenavContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidenavContent, "ngs-sidenav-content", ["ngsSidenavContent"], {}, {}, never, ["*"], true, never>;
}

declare class SidenavCollapsed {
    private _templateRef;
    private _viewContainerRef;
    private _sidenav;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidenavCollapsed, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SidenavCollapsed, "[ngsSidenavCollapsed]", ["ngsSidenavCollapsed"], {}, {}, never, never, true, never>;
}

declare class SidenavExpanded {
    private _templateRef;
    private _viewContainerRef;
    private _sidenav;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidenavExpanded, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SidenavExpanded, "[ngsSidenavExpanded]", ["ngsSidenavExpanded"], {}, {}, never, never, true, never>;
}

export { Sidenav, SidenavCollapsed, SidenavContainer, SidenavContent, SidenavExpanded };
export type { AutoFocusTarget, SidenavMode, SidenavPosition };
