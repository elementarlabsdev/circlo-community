import * as _angular_core from '@angular/core';
import { OnInit, AfterContentInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type ButtonToggleAppearance = 'standard' | 'legacy';
declare class ButtonToggleGroup implements ControlValueAccessor, AfterContentInit {
    readonly _buttonToggles: _angular_core.Signal<readonly any[]>;
    appearance: _angular_core.InputSignal<ButtonToggleAppearance>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    hideSelectionIndicator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    vertical: _angular_core.InputSignalWithTransform<boolean, unknown>;
    value: _angular_core.ModelSignal<any>;
    readonly change: _angular_core.OutputEmitterRef<any>;
    _onChange: (value: any) => void;
    _onTouched: () => void;
    constructor();
    ngAfterContentInit(): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    _emitChangeEvent(value: any): void;
    private _updateSelectedButtonsFromValue;
    private _isSelected;
    _onButtonClick(toggle: ButtonToggle): void;
    private _updateValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonToggleGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonToggleGroup, "ngs-button-toggle-group", ["ngsButtonToggleGroup"], { "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "hideSelectionIndicator": { "alias": "hideSelectionIndicator"; "required": false; "isSignal": true; }; "vertical": { "alias": "vertical"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "change": "change"; }, ["_buttonToggles"], ["*"], true, never>;
}
declare class ButtonToggle implements OnInit {
    private _id;
    id: _angular_core.InputSignal<string>;
    value: _angular_core.InputSignal<any>;
    name: _angular_core.InputSignal<string | undefined>;
    checked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private _internalChecked;
    get isChecked(): boolean;
    _setChecked(value: boolean): void;
    readonly change: _angular_core.OutputEmitterRef<any>;
    buttonToggleGroup: any;
    private _changeDetectorRef;
    get isDisabled(): boolean;
    get _shouldShowSelectionIndicator(): boolean;
    ngOnInit(): void;
    _onButtonClick(): void;
    _markForCheck(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonToggle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonToggle, "ngs-button-toggle", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "change": "change"; }, never, ["*"], true, never>;
}

export { ButtonToggle, ButtonToggleGroup };
export type { ButtonToggleAppearance };
