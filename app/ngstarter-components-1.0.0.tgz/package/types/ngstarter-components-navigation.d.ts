import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef, AfterContentInit, OnChanges, SimpleChanges, InjectionToken } from '@angular/core';
import * as i1 from '@ngstarter/components/core';

declare class NavigationItemIconDirective {
    readonly templateRef: TemplateRef<any> | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationItemIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NavigationItemIconDirective, "[ngsNavigationItemIcon]", ["ngsNavigationItemIcon"], {}, {}, never, never, true, never>;
}

declare class NavigationItem {
    private store;
    private _navigation;
    private _elementRef;
    private parentGroup;
    protected readonly iconRef: _angular_core.Signal<NavigationItemIconDirective | undefined>;
    readonly active: _angular_core.Signal<boolean>;
    get api(): {
        isActive: () => boolean;
    };
    readonly key: _angular_core.InputSignal<any>;
    readonly forceActive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly badgeTextOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected click(event: MouseEvent): void;
    get _hostElement(): ElementRef;
    protected get iconRefTemplate(): TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationItem, "ngs-navigation-item,[ngs-navigation-item]", ["ngsNavigationItem"], { "key": { "alias": "key"; "required": false; "isSignal": true; }; "forceActive": { "alias": "forceActive"; "required": false; "isSignal": true; }; "badgeTextOnly": { "alias": "badgeTextOnly"; "required": false; "isSignal": true; }; }, {}, ["iconRef"], ["[ngsNavigationItemIcon]", "*", "[ngsNavigationItemBadge]"], true, never>;
}

declare class NavigationItemDefDirective {
    template: TemplateRef<any>;
    when: _angular_core.InputSignal<string | ((item: any) => boolean) | undefined>;
    constructor(template: TemplateRef<any>);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationItemDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NavigationItemDefDirective, "[ngsNavigationItemDef]", never, { "when": { "alias": "ngsNavigationItemDef"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class Navigation implements AfterContentInit, OnChanges {
    private store;
    private _elementRef;
    private _renderer;
    private location;
    private router;
    private destroyRef;
    readonly _items: _angular_core.Signal<readonly NavigationItem[]>;
    readonly _defs: _angular_core.Signal<readonly NavigationItemDefDirective[]>;
    activeKey: _angular_core.InputSignal<any>;
    dataSource: _angular_core.InputSignal<any[] | undefined>;
    itemTypeProperty: _angular_core.InputSignal<string>;
    appearance: _angular_core.InputSignal<unknown>;
    activateByRoute: _angular_core.InputSignalWithTransform<boolean, unknown>;
    autoScrollToActiveItem: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly itemClicked: _angular_core.OutputEmitterRef<NavigationItem>;
    constructor();
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private _hasScroll;
    private _isScrolledIntoView;
    private findActiveItemByRoute;
    getTemplate(item: any): TemplateRef<any> | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Navigation, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Navigation, "ngs-navigation", ["ngsNavigation"], { "activeKey": { "alias": "activeKey"; "required": false; "isSignal": true; }; "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "itemTypeProperty": { "alias": "itemTypeProperty"; "required": false; "isSignal": true; }; "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "activateByRoute": { "alias": "activateByRoute"; "required": false; "isSignal": true; }; "autoScrollToActiveItem": { "alias": "autoScrollToActiveItem"; "required": false; "isSignal": true; }; }, { "itemClicked": "itemClicked"; }, ["_items", "_defs"], ["*"], true, never>;
}

declare class NavigationHeading {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationHeading, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationHeading, "ngs-navigation-heading", ["ngsNavigationHeading"], {}, {}, never, ["*"], true, never>;
}

declare class NavigationDivider {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationDivider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationDivider, "ngs-navigation-divider", ["ngsNavigationDivider"], {}, {}, never, never, true, never>;
}

declare class NavigationGroup {
    readonly key: _angular_core.WritableSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationGroup, "ngs-navigation-group", ["ngsNavigationGroup"], {}, {}, never, ["ngs-navigation-group-toggle", "ngs-navigation-group-menu"], true, never>;
}

declare class NavigationGroupMenu implements AfterContentInit {
    private store;
    private _group;
    readonly active: _angular_core.Signal<boolean>;
    readonly _items: _angular_core.Signal<readonly NavigationItem[]>;
    readonly _defs: _angular_core.Signal<readonly NavigationItemDefDirective[]>;
    dataSource: _angular_core.InputSignal<any[] | undefined>;
    itemTypeProperty: _angular_core.InputSignal<string>;
    readonly hasActiveItemInGroup: _angular_core.Signal<boolean>;
    ngAfterContentInit(): void;
    getTemplate(item: any): TemplateRef<any> | null;
    private _detectGroupIsActive;
    private _isActive;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationGroupMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationGroupMenu, "ngs-navigation-group-menu", ["ngsNavigationGroupMenu"], { "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "itemTypeProperty": { "alias": "itemTypeProperty"; "required": false; "isSignal": true; }; }, {}, ["_items", "_defs"], ["*"], true, never>;
}

declare class NavigationGroupToggleIconDirective {
    readonly templateRef: TemplateRef<any> | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationGroupToggleIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NavigationGroupToggleIconDirective, "[ngsNavigationGroupToggleIcon]", ["ngsNavigationGroupToggleIcon"], {}, {}, never, never, true, never>;
}

declare class NavigationGroupToggle {
    private store;
    private _group;
    readonly iconRef: _angular_core.Signal<NavigationGroupToggleIconDirective | undefined>;
    readonly active: _angular_core.Signal<boolean>;
    readonly badgeTextOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected toggle(event: MouseEvent): void;
    protected get iconRefTemplate(): TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationGroupToggle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationGroupToggle, "ngs-navigation-group-toggle", ["ngsNavigationGroupToggle"], { "badgeTextOnly": { "alias": "badgeTextOnly"; "required": false; "isSignal": true; }; }, {}, ["iconRef"], ["[ngsNavigationItemIcon]", "*", "[ngsNavigationItemBadge]", "[ngsNavigationGroupToggleIcon]"], true, [{ directive: typeof i1.Ripple; inputs: {}; outputs: {}; }]>;
}

declare class NavigationItemBadgeDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationItemBadgeDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NavigationItemBadgeDirective, "[ngsNavigationItemBadge]", ["ngsNavigationItemBadge"], {}, {}, never, never, true, never>;
}

interface NavigationItemData {
    key: any;
    type: 'heading' | 'group' | 'link' | 'item' | 'divider' | string;
    name?: string;
    icon?: string;
    children?: NavigationItemData[];
    link?: string;
    [prop: string]: any;
    badge?: string | number;
}
declare const NAVIGATION: InjectionToken<unknown>;
declare const NAVIGATION_GROUP: InjectionToken<unknown>;

export { NAVIGATION, NAVIGATION_GROUP, Navigation, NavigationDivider, NavigationGroup, NavigationGroupMenu, NavigationGroupToggle, NavigationGroupToggleIconDirective, NavigationHeading, NavigationItem, NavigationItemBadgeDirective, NavigationItemDefDirective, NavigationItemIconDirective };
export type { NavigationItemData };
