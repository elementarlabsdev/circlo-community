import * as i0 from '@angular/core';
import { Type, InjectionToken, OnInit, OnDestroy, Signal } from '@angular/core';
import { FormGroup, ValidationErrors, ValidatorFn, FormBuilder, FormControl } from '@angular/forms';

type ComponentImporter = () => Promise<Type<any>>;
declare class ComponentRegistryService {
    private globalRegistry;
    private componentMap;
    constructor();
    private registerDefaultComponents;
    getImporter(typeName: string): ComponentImporter | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentRegistryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComponentRegistryService>;
}

declare const FORM_RENDERER_FIELD_REGISTRY: InjectionToken<{
    [fieldName: string]: ComponentImporter;
}>;
interface ValidatorConfig {
    type: string;
    value?: any;
    message: string;
}
interface BaseComponentConfig {
    name: string;
    type: string;
}
interface FormFieldConfig extends BaseComponentConfig {
    kind: 'field';
    value?: any;
    validators?: ValidatorConfig[];
    label?: string;
    placeholder?: string;
    inputType?: 'text' | 'number' | 'email' | 'password';
    readonly?: boolean;
    disabled?: boolean;
    inline?: boolean;
    visibleWhen?: (formGroup: FormGroup) => boolean;
    payload?: {
        [key: string]: any;
    };
    hint?: string;
}
interface ContentConfig extends BaseComponentConfig {
    kind: 'content';
    content?: {
        [key: string]: any;
    };
}
type ComponentConfig = FormFieldConfig | ContentConfig | any;
interface ComponentNode {
    name: string;
    colspan?: number;
}
interface GridNode {
    columns: number;
    gap?: string;
    children: LayoutNode[];
}
type LayoutNode = ComponentNode | GridNode;
type CrossValidatorFn = (formGroup: FormGroup) => ValidationErrors | null;
interface FormConfig {
    elements: ComponentConfig[];
    layout: LayoutNode;
    crossValidators?: CrossValidatorFn[];
}

type ValidatorFactory = (config: ValidatorConfig) => ValidatorFn;
declare class ValidatorRegistryService {
    private validatorMap;
    constructor();
    private registerDefaultValidators;
    registerValidator(name: string, factory: ValidatorFactory): void;
    getValidator(config: ValidatorConfig): ValidatorFn;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidatorRegistryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidatorRegistryService>;
}

declare class FormGeneratorService {
    private fb;
    private validatorRegistry;
    constructor(fb: FormBuilder, validatorRegistry: ValidatorRegistryService);
    createFormGroup(config: FormConfig, initialValue?: Record<string, any>): FormGroup;
    private mapValidators;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormGeneratorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormGeneratorService>;
}

declare class FormRenderer implements OnInit, OnDestroy {
    #private;
    private formGenerator;
    private validatorRegistry;
    private destroyRef;
    readonly config: i0.InputSignal<FormConfig>;
    readonly initialValue: i0.InputSignal<Record<string, any> | undefined>;
    readonly formSubmit: i0.OutputEmitterRef<any>;
    readonly valueChanges: i0.OutputEmitterRef<any>;
    readonly initialized: i0.OutputEmitterRef<void>;
    private elementsMap;
    protected formGroup: Signal<FormGroup>;
    private valueChangesSub?;
    constructor(formGenerator: FormGeneratorService, validatorRegistry: ValidatorRegistryService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    submit(): void;
    get form(): FormGroup<any>;
    get value(): any;
    get isValid(): boolean;
    get isInvalid(): boolean;
    protected isFieldVisible(name: string): boolean;
    protected getComponentConfig(name: string): ComponentConfig | undefined;
    protected getControl(name: string): FormControl | null;
    protected isGridNode(node: LayoutNode): node is GridNode;
    protected onSubmit(): void;
    private mapValidators;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRenderer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormRenderer, "ngs-form-renderer", ["ngsFormRenderer"], { "config": { "alias": "config"; "required": true; "isSignal": true; }; "initialValue": { "alias": "initialValue"; "required": false; "isSignal": true; }; }, { "formSubmit": "formSubmit"; "valueChanges": "valueChanges"; "initialized": "initialized"; }, never, ["*"], true, never>;
}

export { ComponentRegistryService, FORM_RENDERER_FIELD_REGISTRY, FormRenderer, ValidatorRegistryService };
export type { ComponentConfig, ComponentImporter, ComponentNode, ContentConfig, CrossValidatorFn, FormConfig, FormFieldConfig, GridNode, LayoutNode, ValidatorConfig };
