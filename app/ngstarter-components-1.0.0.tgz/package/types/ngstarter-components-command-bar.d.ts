import * as i0 from '@angular/core';
import * as i1 from '@ngstarter/components/core';

type CommandBarPosition = 'top' | 'bottom';

declare class CommandBar {
    private _elementRef;
    private _renderer;
    open: i0.InputSignalWithTransform<boolean, unknown>;
    position: i0.InputSignal<CommandBarPosition>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CommandBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommandBar, "ngs-command-bar", ["ngsCommandBar"], { "open": { "alias": "open"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; }, {}, never, ["*", "ngs-command-bar-command,[ngs-command-bar-command],ngs-command-bar-divider"], true, never>;
}

declare class CommandBarDivider {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommandBarDivider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommandBarDivider, "ngs-command-bar-divider", ["ngsCommandBarDivider"], {}, {}, never, never, true, never>;
}

declare class CommandBarCommand {
    shortcut: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommandBarCommand, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommandBarCommand, "ngs-command-bar-command,[ngs-command-bar-command]", ["ngsCommandBarCommand"], { "shortcut": { "alias": "shortcut"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Ripple; inputs: {}; outputs: {}; }]>;
}

export { CommandBar, CommandBarCommand, CommandBarDivider };
export type { CommandBarPosition };
