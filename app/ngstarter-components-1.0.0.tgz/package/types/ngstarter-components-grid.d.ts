import * as _angular_core from '@angular/core';
import { InjectionToken, InputSignal, OnInit } from '@angular/core';

interface GridItemAware {
    id: InputSignal<any>;
    content?: InputSignal<any>;
}
interface GridItemConfig {
    type: string;
    skeleton?: any;
    plain?: boolean;
    component: () => Promise<any>;
}
interface GridItem {
    id: any;
    type?: string;
    columns: number;
    children?: GridItem[];
    skeletonHeight?: string;
    height?: string;
    content?: any;
}
declare const GRID: InjectionToken<unknown>;

declare class Grid implements OnInit {
    protected _skeletonMap: Map<string, any>;
    protected _componentsMap: Map<string, any>;
    readonly configs: _angular_core.InputSignal<GridItemConfig[]>;
    readonly items: _angular_core.InputSignal<GridItem[]>;
    readonly plain: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly waitWhenAllItemsLoaded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected _allLoaded: _angular_core.WritableSignal<boolean>;
    protected _loadedItemsCount: _angular_core.WritableSignal<number>;
    ngOnInit(): void;
    markItemAsLoaded(id: any): void;
    protected getItemConfig(type: string): GridItemConfig;
    protected getSkeletonComponent(type: string): any;
    protected getItemComponent(type: string): any;
    protected getItemInputs(gridItem: GridItem): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Grid, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Grid, "ngs-grid", ["ngsGrid"], { "configs": { "alias": "configs"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "plain": { "alias": "plain"; "required": false; "isSignal": true; }; "waitWhenAllItemsLoaded": { "alias": "waitWhenAllItemsLoaded"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { GRID, Grid };
export type { GridItem, GridItemAware, GridItemConfig };
