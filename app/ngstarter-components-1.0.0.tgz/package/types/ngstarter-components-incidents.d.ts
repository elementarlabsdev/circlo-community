import * as i0 from '@angular/core';
import * as _ngrx_signals from '@ngrx/signals';
import * as _ngstarter_components_incidents from '@ngstarter/components/incidents';

declare class Incidents {
    isVisible: boolean;
    toggleVisibility(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Incidents, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Incidents, "ngs-incidents", ["ngsIncidents"], {}, {}, never, ["ngs-incidents-bar", "ngs-incidents-list"], true, never>;
}

declare class IncidentsBar {
    private _parent;
    _handleClick(_event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentsBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentsBar, "ngs-incidents-bar", ["ngsIncidentsBar"], {}, {}, never, ["ngs-incidents-title", "ngs-incidents-description", "[ngsIncidentsToggleIcon]"], true, never>;
}

declare class IncidentsList {
    private _parent;
    fixed: i0.InputSignalWithTransform<boolean, unknown>;
    _handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentsList, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentsList, "ngs-incidents-list", ["ngs-incidents-list"], { "fixed": { "alias": "fixed"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-incident"], true, never>;
}

declare class Incident$1 {
    private _incidentsStore;
    incidentId: i0.InputSignal<string>;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Incident$1, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Incident$1, "ngs-incident,[ngs-incident]", ["ngsIncident"], { "incidentId": { "alias": "incidentId"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsIncidentIcon]", "ngs-incident-title", "ngs-incident-details", "[ngsIncidentButton]", "[ngsIncidentClose]"], true, never>;
}

declare class IncidentTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentTitle, "ngs-incident-title", ["ngsIncidentTitle"], {}, {}, never, ["*"], true, never>;
}

declare class IncidentDetails {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentDetails, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentDetails, "ngs-incident-details", ["ngsIncidentDetails"], {}, {}, never, ["*"], true, never>;
}

declare class IncidentButtonDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IncidentButtonDirective, "[ngsIncidentButton]", ["ngsIncidentButton"], {}, {}, never, never, true, never>;
}

declare class IncidentsTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentsTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentsTitle, "ngs-incidents-title", ["ngsIncidentTitle"], {}, {}, never, ["*"], true, never>;
}

declare class IncidentsDescription {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentsDescription, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentsDescription, "ngs-incidents-description", ["ngsIncidentsDescription"], {}, {}, never, ["*"], true, never>;
}

interface Incident {
    id: any;
    title: string;
    details?: string;
}

declare class IncidentsContainer {
    protected _incidentsStore: {
        incidents: i0.Signal<Incident[]>;
        title: i0.Signal<string>;
        description: i0.Signal<string>;
        show: (state: _ngstarter_components_incidents.IncidentsState) => void;
        hide: () => void;
    } & _ngrx_signals.StateSource<{
        incidents: Incident[];
        title: string;
        description: string;
    }>;
    hasIncidents: i0.Signal<boolean>;
    title: i0.Signal<string>;
    description: i0.Signal<string>;
    incidents: i0.Signal<Incident[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentsContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IncidentsContainer, "ngs-incidents-container,ngs-incidents-global", ["ngsIncidentsGlobal"], {}, {}, never, never, true, never>;
}

declare class IncidentsToggleIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentsToggleIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IncidentsToggleIconDirective, "[ngsIncidentsToggleIcon]", ["ngsIncidentsToggleIcon"], {}, {}, never, never, true, never>;
}

declare class IncidentIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IncidentIconDirective, "[ngsIncidentIcon]", ["ngsIncidentIcon"], {}, {}, never, never, true, never>;
}

declare class IncidentCloseDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<IncidentCloseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IncidentCloseDirective, "[ngsIncidentClose]", ["ngsIncidentClose"], {}, {}, never, never, true, never>;
}

interface IncidentsState {
    incidents: Incident[];
    title: string;
    description: string;
}
declare const IncidentsStore: i0.Type<{
    incidents: i0.Signal<Incident[]>;
    title: i0.Signal<string>;
    description: i0.Signal<string>;
    show: (state: IncidentsState) => void;
    hide: () => void;
} & _ngrx_signals.StateSource<{
    incidents: Incident[];
    title: string;
    description: string;
}>>;

export { Incident$1 as Incident, IncidentButtonDirective, IncidentCloseDirective, IncidentDetails, IncidentIconDirective, IncidentTitle, Incidents, IncidentsBar, IncidentsContainer, IncidentsDescription, IncidentsList, IncidentsStore, IncidentsTitle, IncidentsToggleIconDirective };
export type { IncidentsState };
