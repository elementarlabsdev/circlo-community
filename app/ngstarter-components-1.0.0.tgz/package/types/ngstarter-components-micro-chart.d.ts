import * as _angular_core from '@angular/core';
import { Renderer2, ViewContainerRef, Injector, TemplateRef, OnDestroy, AfterViewChecked, OnChanges, SimpleChanges } from '@angular/core';
import { OverlayPosition } from '@ngstarter/components/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { OverlayRef, Overlay, OverlayConfig, FlexibleConnectedPositionStrategy, ConnectedPosition } from '@angular/cdk/overlay';

type MchartLineCurveType = 'linear' | 'catmullRom' | 'curveBumpX' | 'curveStep';

declare abstract class BaseChartTooltip {
    protected _tooltipOrigin: HTMLElement;
    protected _tooltipPortal: TemplatePortal;
    protected _overlayRef: OverlayRef;
    protected _renderer: Renderer2;
    protected _overlay: Overlay;
    protected _viewContainerRef: ViewContainerRef;
    protected _injector: Injector;
    protected _document: Document;
    abstract getTooltipTemplateRef(): TemplateRef<any> | undefined;
    abstract getTooltipPosition(): OverlayPosition;
    protected _createTooltipOrigin(): void;
    protected _showTooltip(data: object): void;
    protected _hideTooltip(): void;
    protected _setTooltipPositionByEvent(e: MouseEvent): void;
    protected _setTooltipVisible(): void;
    protected _setTooltipInVisible(): void;
    protected _getContentPortal(data: object): TemplatePortal<any>;
    protected _getOverlayConfig(): OverlayConfig;
    protected _getOverlayPositionStrategy(): FlexibleConnectedPositionStrategy;
    protected _getOverlayPositions(): ConnectedPosition[];
}

declare class MchartLine extends BaseChartTooltip implements OnDestroy, AfterViewChecked {
    private _initialized;
    private _host;
    private _svg;
    private _dimensions;
    private _hostWidth;
    private _hostHeight;
    private _innerWidth;
    private _innerHeight;
    private _yScale;
    private _xScale;
    private _curveMap;
    private _resizeObserver;
    private _tooltipDot;
    private _area;
    private _line;
    private _platformId;
    private _destroyRef;
    private _elementRef;
    data: _angular_core.InputSignal<number[]>;
    labels: _angular_core.InputSignal<any[]>;
    strokeWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    showArea: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showMarkers: _angular_core.InputSignalWithTransform<boolean, unknown>;
    responsive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    fillAreaGradient: _angular_core.InputSignalWithTransform<boolean, unknown>;
    curve: _angular_core.InputSignal<MchartLineCurveType>;
    xAccessor: _angular_core.InputSignal<(d: any, i: number) => number>;
    yAccessor: _angular_core.InputSignal<(d: any) => any>;
    compact: _angular_core.InputSignalWithTransform<boolean, unknown>;
    markerDotSize: _angular_core.InputSignalWithTransform<number, unknown>;
    tooltip: _angular_core.InputSignal<TemplateRef<unknown> | undefined>;
    tooltipPosition: _angular_core.InputSignal<OverlayPosition>;
    private _currentTooltipPosition;
    get gradientId(): string;
    private _gradientId;
    constructor();
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    getTooltipPosition(): OverlayPosition;
    getTooltipTemplateRef(): TemplateRef<any> | undefined;
    private _render;
    private _setupContainers;
    private _setupData;
    private _setupResizeObserver;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MchartLine, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MchartLine, "ngs-mchart-line", ["ngsMchartLine"], { "data": { "alias": "data"; "required": false; "isSignal": true; }; "labels": { "alias": "labels"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "showArea": { "alias": "showArea"; "required": false; "isSignal": true; }; "showMarkers": { "alias": "showMarkers"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "fillAreaGradient": { "alias": "fillAreaGradient"; "required": false; "isSignal": true; }; "curve": { "alias": "curve"; "required": false; "isSignal": true; }; "xAccessor": { "alias": "xAccessor"; "required": false; "isSignal": true; }; "yAccessor": { "alias": "yAccessor"; "required": false; "isSignal": true; }; "compact": { "alias": "compact"; "required": false; "isSignal": true; }; "markerDotSize": { "alias": "markerDotSize"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class MchartBar extends BaseChartTooltip implements OnDestroy, AfterViewChecked {
    private _initialized;
    private _host;
    private _svg;
    private _hlContainer;
    private _dataContainer;
    private _dimensions;
    private _innerWidth;
    private _innerHeight;
    private _hostWidth;
    private _hostHeight;
    private _xScale;
    private _yScale;
    private _resizeObserver;
    private _platformId;
    private _elementRef;
    private _destroyRef;
    data: _angular_core.InputSignal<number[]>;
    labels: _angular_core.InputSignal<string[]>;
    gap: _angular_core.InputSignalWithTransform<number, unknown>;
    radius: _angular_core.InputSignalWithTransform<number, unknown>;
    highlight: _angular_core.InputSignalWithTransform<boolean, unknown>;
    responsive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    fillGradient: _angular_core.InputSignalWithTransform<boolean, unknown>;
    xAccessor: _angular_core.InputSignal<(d: any, i: number) => number>;
    yAccessor: _angular_core.InputSignal<(d: any) => any>;
    tooltip: _angular_core.InputSignal<TemplateRef<any> | undefined>;
    tooltipPosition: _angular_core.InputSignal<OverlayPosition>;
    private _currentTooltipPosition;
    get gradientId(): string;
    private _gradientId;
    constructor();
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    getTooltipPosition(): OverlayPosition;
    getTooltipTemplateRef(): TemplateRef<any> | undefined;
    private _render;
    private _init;
    private _setupAxisScale;
    private _setupData;
    private _setupResizeObserver;
    private _initTooltip;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MchartBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MchartBar, "ngs-mchart-bar", ["ngsMchartBar"], { "data": { "alias": "data"; "required": false; "isSignal": true; }; "labels": { "alias": "labels"; "required": false; "isSignal": true; }; "gap": { "alias": "gap"; "required": false; "isSignal": true; }; "radius": { "alias": "radius"; "required": false; "isSignal": true; }; "highlight": { "alias": "highlight"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "fillGradient": { "alias": "fillGradient"; "required": false; "isSignal": true; }; "xAccessor": { "alias": "xAccessor"; "required": false; "isSignal": true; }; "yAccessor": { "alias": "yAccessor"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class MchartPie extends BaseChartTooltip implements AfterViewChecked, OnChanges, OnDestroy {
    private _initialized;
    private _host;
    private _svg;
    private _dataContainer;
    private _legendContainer;
    private _dimensions;
    private _innerWidth;
    private _innerHeight;
    private _hostWidth;
    private _hostHeight;
    private _resizeObserver;
    private _platformId;
    private _elementRef;
    private _radius;
    private _arcGenerator;
    private _pieGenerator;
    private _colorsGenerator;
    private _arcTweenGenerator;
    private _pieData;
    data: _angular_core.InputSignal<number[]>;
    labels: _angular_core.InputSignal<string[] | number[]>;
    valueAccessor: _angular_core.InputSignal<(d: any) => any>;
    dataItemStrokeWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    legendContainerWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    showDataAnimation: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showValueOnSlices: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showLegend: _angular_core.InputSignalWithTransform<boolean, unknown>;
    legendOffset: _angular_core.InputSignalWithTransform<number, unknown>;
    legendItemHeight: _angular_core.InputSignalWithTransform<number, unknown>;
    legendItemSymbolSize: _angular_core.InputSignalWithTransform<number, unknown>;
    legendItemFontSize: _angular_core.InputSignalWithTransform<number, unknown>;
    legendItemSymbolBorderRadius: _angular_core.InputSignalWithTransform<number, unknown>;
    valueFontSize: _angular_core.InputSignalWithTransform<number, unknown>;
    tooltip: _angular_core.InputSignal<TemplateRef<unknown> | undefined>;
    tooltipPosition: _angular_core.InputSignal<OverlayPosition>;
    getTooltipPosition(): OverlayPosition;
    getTooltipTemplateRef(): TemplateRef<any> | undefined;
    ngAfterViewChecked(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private _render;
    private _initDimensions;
    private _initContainers;
    private _setGenerators;
    private _setLegend;
    private _draw;
    private _setupResizeObserver;
    private _initTooltip;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MchartPie, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MchartPie, "ngs-mchart-pie", ["ngsMchartPie"], { "data": { "alias": "data"; "required": false; "isSignal": true; }; "labels": { "alias": "labels"; "required": false; "isSignal": true; }; "valueAccessor": { "alias": "valueAccessor"; "required": false; "isSignal": true; }; "dataItemStrokeWidth": { "alias": "dataItemStrokeWidth"; "required": false; "isSignal": true; }; "legendContainerWidth": { "alias": "legendContainerWidth"; "required": false; "isSignal": true; }; "showDataAnimation": { "alias": "showDataAnimation"; "required": false; "isSignal": true; }; "showValueOnSlices": { "alias": "showValueOnSlices"; "required": false; "isSignal": true; }; "showLegend": { "alias": "showLegend"; "required": false; "isSignal": true; }; "legendOffset": { "alias": "legendOffset"; "required": false; "isSignal": true; }; "legendItemHeight": { "alias": "legendItemHeight"; "required": false; "isSignal": true; }; "legendItemSymbolSize": { "alias": "legendItemSymbolSize"; "required": false; "isSignal": true; }; "legendItemFontSize": { "alias": "legendItemFontSize"; "required": false; "isSignal": true; }; "legendItemSymbolBorderRadius": { "alias": "legendItemSymbolBorderRadius"; "required": false; "isSignal": true; }; "valueFontSize": { "alias": "valueFontSize"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class MchartTooltip {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MchartTooltip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MchartTooltip, "ngs-mchart-tooltip", ["ngsMchartTooltip"], {}, {}, never, ["ngs-mchart-tooltip-title", "ngs-mchart-tooltip-body", "*"], true, never>;
}

declare class MchartTooltipTitle {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MchartTooltipTitle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MchartTooltipTitle, "ngs-mchart-tooltip-title", ["ngsMchartTooltipTitle"], {}, {}, never, ["*"], true, never>;
}

declare class MchartTooltipBody {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MchartTooltipBody, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MchartTooltipBody, "ngs-mchart-tooltip-body", ["ngsMchartTooltipBody"], {}, {}, never, ["*"], true, never>;
}

export { MchartBar, MchartLine, MchartPie, MchartTooltip, MchartTooltipBody, MchartTooltipTitle };
