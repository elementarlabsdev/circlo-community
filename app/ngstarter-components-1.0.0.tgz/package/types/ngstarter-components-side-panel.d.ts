import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import { TooltipPosition } from '@ngstarter/components/tooltip';

type PanelPosition = 'left' | 'right';
interface SidePanelTabConfig {
    tabId: string;
    label: string;
    icon?: string | TemplateRef<any>;
    content: TemplateRef<any>;
}

declare class SidePanel {
    position: _angular_core.InputSignal<PanelPosition>;
    isPositionRight: _angular_core.Signal<boolean>;
    tooltipPosition: _angular_core.Signal<TooltipPosition>;
    private projectedTabsQuery;
    protected internalTabs: _angular_core.WritableSignal<SidePanelTabConfig[]>;
    activeTabId: _angular_core.WritableSignal<string | null>;
    isOpen: _angular_core.WritableSignal<boolean>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    selectedTabContent: _angular_core.Signal<TemplateRef<any> | null>;
    constructor();
    toggleTab(tabId: string): void;
    close(): void;
    protected isTemplateRef(value: any): value is TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidePanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidePanel, "ngs-side-panel", ["ngsSidePanel"], { "position": { "alias": "position"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, ["projectedTabsQuery"], never, true, never>;
}

declare class SidePanelTab {
    tabId: _angular_core.InputSignal<string>;
    label: _angular_core.InputSignal<string>;
    icon: _angular_core.InputSignal<string | TemplateRef<any> | undefined>;
    readonly content: _angular_core.Signal<TemplateRef<any>>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidePanelTab, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidePanelTab, "ngs-side-panel-tab", ["ngsSidePanelTab"], { "tabId": { "alias": "tabId"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { SidePanel, SidePanelTab };
export type { PanelPosition, SidePanelTabConfig };
