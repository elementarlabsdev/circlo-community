import * as i0 from '@angular/core';
import { InjectionToken, OnInit, OnDestroy } from '@angular/core';
import { Editor } from '@tiptap/core';
import * as i1 from '@ngstarter/components/upload';
import { UploadFileSelectedEvent } from '@ngstarter/components/upload';

interface CommentEditorInterface {
    api: CommentEditorAPI;
}
interface CommentEditorAPI {
    isCommandDisabled: (command: string) => boolean | null;
    isActive: (command: string) => boolean | null;
    runCommand: (command: string) => void;
    editor: () => Editor;
    isToolbarActive: () => boolean;
    toggleToolbar: () => void;
    isEditorActivated: () => boolean;
}
declare const COMMENT_EDITOR: InjectionToken<unknown>;
declare const COMMENT_EDITOR_BUBBLE_MENU: InjectionToken<unknown>;

declare class CommentEditor implements OnInit, OnDestroy {
    private _platformId;
    private _document;
    private _cdr;
    private _injector;
    private _content;
    private _bubbleMenu;
    private _imageBubbleMenu;
    protected _value: string;
    protected editor: Editor;
    protected showToolbar: boolean;
    protected fullView: boolean;
    contentMaxHeight: i0.InputSignal<number | undefined>;
    buttonCancelLabel: i0.InputSignal<string>;
    buttonSendLabel: i0.InputSignal<string>;
    placeholder: i0.InputSignal<string>;
    toolbarAlwaysVisible: i0.InputSignalWithTransform<boolean, unknown>;
    fullViewMode: i0.InputSignalWithTransform<boolean, unknown>;
    cancelButtonAlwaysVisible: i0.InputSignalWithTransform<boolean, unknown>;
    imageUploadFn: i0.InputSignal<((file: Blob) => Promise<string>) | undefined>;
    readonly sent: i0.OutputEmitterRef<string>;
    readonly canceled: i0.OutputEmitterRef<void>;
    ngOnInit(): void;
    get api(): CommentEditorAPI;
    isCommandDisabled(command: string): boolean | null;
    ngOnDestroy(): void;
    send(event: MouseEvent): void;
    activateFullView(): void;
    toggleToolbar(): void;
    cancel(event: MouseEvent): void;
    private _runCommand;
    private _init;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditor, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommentEditor, "ngs-comment-editor", ["ngsCommentEditor"], { "contentMaxHeight": { "alias": "contentMaxHeight"; "required": false; "isSignal": true; }; "buttonCancelLabel": { "alias": "buttonCancelLabel"; "required": false; "isSignal": true; }; "buttonSendLabel": { "alias": "buttonSendLabel"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "toolbarAlwaysVisible": { "alias": "toolbarAlwaysVisible"; "required": false; "isSignal": true; }; "fullViewMode": { "alias": "fullViewMode"; "required": false; "isSignal": true; }; "cancelButtonAlwaysVisible": { "alias": "cancelButtonAlwaysVisible"; "required": false; "isSignal": true; }; "imageUploadFn": { "alias": "imageUploadFn"; "required": false; "isSignal": true; }; }, { "sent": "sent"; "canceled": "canceled"; }, never, ["ngs-comment-editor-toolbar", "ngs-comment-editor-footer-bar", "ngs-comment-editor-bubble-menu"], true, never>;
}

declare class CommentEditorDivider {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorDivider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommentEditorDivider, "ngs-comment-editor-divider", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorToolbar {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorToolbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommentEditorToolbar, "ngs-comment-editor-toolbar", ["ngsCommentEditorToolbar"], {}, {}, never, ["[ngsCommentEditorCommand],ngs-comment-editor-divider"], true, never>;
}

declare class CommentEditorBubbleMenu {
    protected commentEditor: CommentEditorInterface;
    getLinkUrl(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorBubbleMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommentEditorBubbleMenu, "ngs-comment-editor-bubble-menu", ["ngsCommentEditorBubbleMenu"], {}, {}, never, ["[ngsCommentEditorCommandEditLink],[ngsCommentEditorCommandUnsetLink]", "[ngsCommentEditorCommand],ngs-comment-editor-divider"], true, never>;
}

declare class CommentEditorFooterBar {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorFooterBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CommentEditorFooterBar, "ngs-comment-editor-footer-bar", ["ngsCommentEditorFooterBar"], {}, {}, never, ["[ngsCommentEditorCommand],ngs-comment-editor-divider"], true, never>;
}

declare class CommentEditorCommandDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandDirective, "[ngsCommentEditorCommand]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandBoldDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandBoldDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandBoldDirective, "[ngsCommentEditorCommandBold]", ["ngsCommentEditorCommandBold"], {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandItalicDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandItalicDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandItalicDirective, "[ngsCommentEditorCommandItalic]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandStrikeDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandStrikeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandStrikeDirective, "[ngsCommentEditorCommandStrike]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandBulletListDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandBulletListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandBulletListDirective, "[ngsCommentEditorCommandBulletList]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandOrderedListDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandOrderedListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandOrderedListDirective, "[ngsCommentEditorCommandOrderedList]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandBlockquoteDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandBlockquoteDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandBlockquoteDirective, "[ngsCommentEditorCommandBlockquote]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandCodeBlockDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandCodeBlockDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandCodeBlockDirective, "[ngsCommentEditorCommandCodeBlock]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandImageDirective {
    protected commentEditor: CommentEditorInterface;
    protected onImageSelected(event: UploadFileSelectedEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandImageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandImageDirective, "[ngsCommentEditorCommandImage]", never, {}, {}, never, never, true, [{ directive: typeof i1.UploadTriggerDirective; inputs: {}; outputs: { "fileSelected": "fileSelected"; }; }]>;
}

declare class CommentEditorCommandYoutubeDirective {
    protected commentEditor: CommentEditorInterface;
    private _dialog;
    private _destroyRef;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandYoutubeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandYoutubeDirective, "[ngsCommentEditorCommandYoutube]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandLinkDirective {
    private _destroyRef;
    private _dialog;
    protected commentEditor: CommentEditorInterface;
    protected setLinkActive: boolean;
    protected onClick(): void;
    private _setLink;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandLinkDirective, "[ngsCommentEditorCommandLink]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandCodeDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandCodeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandCodeDirective, "[ngsCommentEditorCommandCode]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandEditLinkDirective {
    private _destroyRef;
    private _dialog;
    protected commentEditor: CommentEditorInterface;
    protected setLinkActive: boolean;
    protected onClick(): void;
    private _setLink;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandEditLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandEditLinkDirective, "[ngsCommentEditorCommandEditLink]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandUnsetLinkDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandUnsetLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandUnsetLinkDirective, "[ngsCommentEditorCommandUnsetLink]", never, {}, {}, never, never, true, never>;
}

declare class CommentEditorCommandToggleToolbarDirective {
    protected commentEditor: CommentEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommentEditorCommandToggleToolbarDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CommentEditorCommandToggleToolbarDirective, "[ngsCommentEditorCommandToggleToolbar]", never, {}, {}, never, never, true, never>;
}

export { COMMENT_EDITOR, COMMENT_EDITOR_BUBBLE_MENU, CommentEditor, CommentEditorBubbleMenu, CommentEditorCommandBlockquoteDirective, CommentEditorCommandBoldDirective, CommentEditorCommandBulletListDirective, CommentEditorCommandCodeBlockDirective, CommentEditorCommandCodeDirective, CommentEditorCommandDirective, CommentEditorCommandEditLinkDirective, CommentEditorCommandImageDirective, CommentEditorCommandItalicDirective, CommentEditorCommandLinkDirective, CommentEditorCommandOrderedListDirective, CommentEditorCommandStrikeDirective, CommentEditorCommandToggleToolbarDirective, CommentEditorCommandUnsetLinkDirective, CommentEditorCommandYoutubeDirective, CommentEditorDivider, CommentEditorFooterBar, CommentEditorToolbar };
export type { CommentEditorAPI, CommentEditorInterface };
