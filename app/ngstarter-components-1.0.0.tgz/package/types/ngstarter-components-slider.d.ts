import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class SliderThumb implements ControlValueAccessor, OnInit, OnDestroy {
    private _elementRef;
    readonly _slider: Slider;
    readonly valueChange: _angular_core.OutputEmitterRef<number>;
    valueInput: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    private _value;
    getId(): string;
    get value(): number;
    set value(v: number);
    private _clampValue;
    constructor();
    private _onChangeFn;
    private _onTouchedFn;
    ngOnInit(): void;
    get min(): number;
    get max(): number;
    get step(): number;
    ngOnDestroy(): void;
    _updateValueFromUser(value: number): void;
    _onInput(event: Event): void;
    _onChange(event: Event): void;
    _onBlur(): void;
    _onFocus(): void;
    focus(): void;
    private _isUserInteraction;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    private _updateHostValue;
    get percentage(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderThumb, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SliderThumb, "input[ngsSliderThumb]", ["ngsSliderThumb"], { "valueInput": { "alias": "value"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class Slider {
    private elementRef;
    readonly _cdr: ChangeDetectorRef;
    private readonly _dir;
    private readonly _destroyRef;
    private readonly _document;
    private readonly _platformId;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    discrete: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showTickMarks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    min: _angular_core.InputSignalWithTransform<number, unknown>;
    max: _angular_core.InputSignalWithTransform<number, unknown>;
    step: _angular_core.InputSignalWithTransform<number, unknown>;
    displayWith: _angular_core.InputSignal<(value: number) => string>;
    _allThumbs: _angular_core.Signal<readonly SliderThumb[]>;
    _trackLeft: _angular_core.Signal<number>;
    _trackRight: _angular_core.Signal<number>;
    _activeThumb: _angular_core.WritableSignal<SliderThumb | null>;
    _isDragging: _angular_core.WritableSignal<boolean>;
    _tickMarks: _angular_core.Signal<any[]>;
    _isRtl: boolean;
    constructor();
    private _initializeEvents;
    _onValueChange(thumb: SliderThumb): void;
    private _findClosestThumb;
    _onPointerDown(event: MouseEvent | TouchEvent): void;
    _onPointerMove(event: MouseEvent | TouchEvent): void;
    private _calculatePercentage;
    private _calculateValueFromPercentage;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Slider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Slider, "ngs-slider", ["ngsSlider"], { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "discrete": { "alias": "discrete"; "required": false; "isSignal": true; }; "showTickMarks": { "alias": "showTickMarks"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "displayWith": { "alias": "displayWith"; "required": false; "isSignal": true; }; }, {}, ["_allThumbs"], ["*"], true, never>;
}

declare class SliderStartThumb extends SliderThumb {
    getId(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderStartThumb, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SliderStartThumb, "input[ngsSliderStartThumb]", never, {}, {}, never, never, true, never>;
}

declare class SliderEndThumb extends SliderThumb {
    getId(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderEndThumb, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SliderEndThumb, "input[ngsSliderEndThumb]", never, {}, {}, never, never, true, never>;
}

export { Slider, SliderEndThumb, SliderStartThumb, SliderThumb };
