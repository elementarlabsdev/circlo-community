import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';

type SpinnerMode = 'determinate' | 'indeterminate';
declare class ProgressSpinner {
    readonly color: _angular_core.InputSignal<string>;
    readonly mode: _angular_core.InputSignal<SpinnerMode>;
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly diameter: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly strokeWidth: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly _elementRef: ElementRef<any>;
    readonly _actualStrokeWidth: _angular_core.Signal<number>;
    _circleRadius(): number;
    _viewBox(): string;
    _strokeCircumference(): number;
    _strokeDashOffset(): number | null;
    _circleStrokeWidth(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressSpinner, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressSpinner, "ngs-progress-spinner", ["ngsProgressSpinner"], { "color": { "alias": "color"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "diameter": { "alias": "diameter"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class ProgressSpinnerModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressSpinnerModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ProgressSpinnerModule, never, [typeof ProgressSpinner], [typeof ProgressSpinner]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ProgressSpinnerModule>;
}

export { ProgressSpinner, ProgressSpinnerModule };
export type { SpinnerMode };
