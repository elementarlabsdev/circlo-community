import * as _angular_core from '@angular/core';
import { AfterContentInit, OnInit, ChangeDetectorRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class RadioGroup implements ControlValueAccessor, AfterContentInit {
    readonly _radios: _angular_core.Signal<readonly any[]>;
    disabled: _angular_core.ModelSignal<boolean>;
    name: _angular_core.InputSignal<string | undefined>;
    value: _angular_core.ModelSignal<any>;
    readonly change: _angular_core.OutputEmitterRef<any>;
    constructor();
    _onChange: (value: any) => void;
    _onTouched: () => void;
    ngAfterContentInit(): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    _emitChangeEvent(value: any): void;
    private _updateSelectedRadioFromValue;
    private _markRadiosForCheck;
    _onRadioClick(radio: RadioButton): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadioGroup, "ngs-radio-group", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "value": "valueChange"; "change": "change"; }, ["_radios"], ["*"], true, never>;
}

declare class RadioButton implements OnInit {
    radioGroup: RadioGroup;
    private _changeDetectorRef;
    id: _angular_core.InputSignal<string>;
    value: _angular_core.InputSignal<any>;
    name: _angular_core.InputSignal<string | undefined>;
    checked: _angular_core.ModelSignal<boolean>;
    disabledInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.Signal<boolean>;
    readonly change: _angular_core.OutputEmitterRef<any>;
    constructor(radioGroup: RadioGroup, _changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    _onInputClick(event: Event): void;
    _markForCheck(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioButton, [{ optional: true; }, null]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadioButton, "ngs-radio-button", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "change": "change"; }, never, ["*"], true, never>;
}

export { RadioButton, RadioGroup };
