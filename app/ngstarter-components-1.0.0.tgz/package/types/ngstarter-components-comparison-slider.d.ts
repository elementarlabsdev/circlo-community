import * as i0 from '@angular/core';
import { AfterViewInit, OnDestroy } from '@angular/core';

declare class ComparisonSlider implements AfterViewInit, OnDestroy {
    private resizeObserver;
    private platformId;
    private ngZone;
    private destroyRef;
    private sliderContainerRef;
    private handleRef;
    initialPosition: i0.InputSignal<number>;
    sliderPosition: i0.WritableSignal<number>;
    isDragging: i0.WritableSignal<boolean>;
    private containerRect;
    handleLeftStyle: i0.Signal<string>;
    afterImageClipStyle: i0.Signal<string>;
    private isBrowser;
    constructor();
    ngAfterViewInit(): void;
    private initDragStreams;
    ngOnDestroy(): void;
    private updateContainerRect;
    private updateSliderPosition;
    protected onContextMenu(event: MouseEvent): void;
    protected onDragStart(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComparisonSlider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ComparisonSlider, "ngs-comparison-slider", ["ngsComparisonSlider"], { "initialPosition": { "alias": "initialPosition"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsComparisonSliderBeforeImage]", "[ngsComparisonSliderAfterImage]"], true, never>;
}

declare class ComparisonSliderAfterImageDirective {
    protected onDragStart(event: DragEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComparisonSliderAfterImageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ComparisonSliderAfterImageDirective, "[ngsComparisonSliderAfterImage]", never, {}, {}, never, never, true, never>;
}

declare class ComparisonSliderBeforeImageDirective {
    protected onDragStart(event: DragEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComparisonSliderBeforeImageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ComparisonSliderBeforeImageDirective, "[ngsComparisonSliderBeforeImage]", never, {}, {}, never, never, true, never>;
}

export { ComparisonSlider, ComparisonSliderAfterImageDirective, ComparisonSliderBeforeImageDirective };
