import * as _angular_core from '@angular/core';
import { OutputEmitterRef, InjectionToken, OnInit, OnChanges, OnDestroy } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, Subject } from 'rxjs';
import * as _ngstarter_components_sort from '@ngstarter/components/sort';

type SortDirection = 'asc' | 'desc' | '';

interface Sort {
    readonly active: string;
    readonly direction: SortDirection;
}
interface EmrSort {
    readonly active: string | (() => string);
    readonly direction: SortDirection | (() => SortDirection);
    readonly sortChange: Observable<Sort> | OutputEmitterRef<Sort>;
    readonly initialized?: Observable<void>;
}
declare const SORT: InjectionToken<EmrSort>;

declare class SortDirective implements OnInit, OnChanges, OnDestroy, EmrSort {
    active: _angular_core.ModelSignal<string>;
    start: _angular_core.InputSignal<SortDirection>;
    direction: _angular_core.ModelSignal<SortDirection>;
    disableClear: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    disabled: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    readonly sortChange: _angular_core.OutputEmitterRef<Sort>;
    readonly _stateChanges: Subject<void>;
    private readonly _initialized;
    readonly initialized: rxjs.Observable<void>;
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    sort(id: string): void;
    getNextSortDirection(id: string): SortDirection;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SortDirective, "[ngsSort]", ["ngsSort"], { "active": { "alias": "ngsSortActive"; "required": false; "isSignal": true; }; "start": { "alias": "ngsSortStart"; "required": false; "isSignal": true; }; "direction": { "alias": "ngsSortDirection"; "required": false; "isSignal": true; }; "disableClear": { "alias": "ngsSortDisableClear"; "required": false; "isSignal": true; }; "disabled": { "alias": "ngsSortDisabled"; "required": false; "isSignal": true; }; }, { "active": "ngsSortActiveChange"; "direction": "ngsSortDirectionChange"; "sortChange": "ngsSortChange"; }, never, never, true, never>;
}

declare class SortHeader implements OnInit, OnDestroy {
    private _rerenderSubscription;
    private _cdr;
    id: _angular_core.InputSignal<string>;
    sortActionDescription: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignalWithTransform<boolean, string | boolean>;
    _sort: _ngstarter_components_sort.EmrSort | null;
    ngOnInit(): void;
    ngOnDestroy(): void;
    _handleClick(): void;
    _getNextSortDirection(): string;
    _isSorted(): boolean;
    _isDisabled(): boolean;
    _isSortDisabled(): boolean;
    _getArrowState(): _ngstarter_components_sort.SortDirection | "void";
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SortHeader, "[ngs-sort-header]", ["ngsSortHeader"], { "id": { "alias": "ngs-sort-header"; "required": false; "isSignal": true; }; "sortActionDescription": { "alias": "sortActionDescription"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SortModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SortModule, never, [typeof SortDirective, typeof SortHeader], [typeof SortDirective, typeof SortHeader]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SortModule>;
}

export { SORT, SortDirective, SortHeader, SortModule };
export type { EmrSort, Sort, SortDirection };
