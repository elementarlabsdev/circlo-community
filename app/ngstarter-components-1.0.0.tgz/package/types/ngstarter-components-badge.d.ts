import * as _angular_core from '@angular/core';
import { OnInit, OnChanges, OnDestroy } from '@angular/core';

declare class BadgeContent {
    content: any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BadgeContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BadgeContent, "ngs-badge-content", never, {}, {}, never, never, true, never>;
}

type BadgePosition = 'above after' | 'above before' | 'below after' | 'below before' | 'before' | 'after' | 'above' | 'below';
type BadgeSize = 'small' | 'medium' | 'large';
declare class Badge implements OnInit, OnChanges, OnDestroy {
    private readonly _elementRef;
    private readonly _applicationRef;
    private readonly _environmentInjector;
    private readonly _injector;
    private readonly renderer;
    readonly content: _angular_core.InputSignal<any>;
    readonly color: _angular_core.InputSignal<string>;
    readonly overlap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly position: _angular_core.InputSignal<BadgePosition>;
    readonly size: _angular_core.InputSignal<BadgeSize>;
    readonly hidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly description: _angular_core.InputSignal<string>;
    readonly isAbove: _angular_core.Signal<boolean>;
    readonly isAfter: _angular_core.Signal<boolean>;
    private _componentRef;
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private _updateBadge;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Badge, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Badge, "[ngsBadge]", never, { "content": { "alias": "ngsBadge"; "required": false; "isSignal": true; }; "color": { "alias": "ngsBadgeColor"; "required": false; "isSignal": true; }; "overlap": { "alias": "ngsBadgeOverlap"; "required": false; "isSignal": true; }; "disabled": { "alias": "ngsBadgeDisabled"; "required": false; "isSignal": true; }; "position": { "alias": "ngsBadgePosition"; "required": false; "isSignal": true; }; "size": { "alias": "ngsBadgeSize"; "required": false; "isSignal": true; }; "hidden": { "alias": "ngsBadgeHidden"; "required": false; "isSignal": true; }; "description": { "alias": "ngsBadgeDescription"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { Badge, BadgeContent };
export type { BadgePosition, BadgeSize };
