import * as _angular_core from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { FormFieldControl } from '@ngstarter/components/form-field';
import { Select, SelectChange } from '@ngstarter/components/select';
import { Subject } from 'rxjs';

type DateFormat = {
    value: string;
    name: string;
};
declare class DateFormatSelect implements FormFieldControl<string>, ControlValueAccessor, OnDestroy, OnInit {
    private static nextId;
    readonly matSelect: _angular_core.Signal<Select>;
    readonly dateFormats: _angular_core.InputSignal<DateFormat[]>;
    private readonly _value;
    private readonly _focused;
    readonly _describedBy: _angular_core.WritableSignal<string>;
    readonly stateChanges: Subject<void>;
    readonly id: string;
    readonly controlType = "date-format-input";
    readonly autofilled = false;
    get focused(): boolean;
    get empty(): boolean;
    get shouldLabelFloat(): boolean;
    get errorState(): boolean;
    get value(): string | null;
    set value(val: string | null);
    readonly ngControl: NgControl | null;
    readonly placeholderInput: _angular_core.InputSignal<string>;
    get placeholder(): string;
    private readonly _destroy$;
    constructor();
    ngOnInit(): void;
    private _required;
    get required(): boolean;
    set required(value: boolean | string);
    private _disabled;
    get disabled(): boolean;
    set disabled(value: boolean | string);
    ngOnDestroy(): void;
    onFocus(): void;
    onBlur(): void;
    onSelectionChange(event: SelectChange): void;
    setDescribedByIds(ids: string[]): void;
    onContainerClick(): void;
    private onChange;
    private onTouched;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: unknown) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateFormatSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateFormatSelect, "ngs-date-format-select", ["ngsDateFormatSelect"], { "dateFormats": { "alias": "dateFormats"; "required": false; "isSignal": true; }; "placeholderInput": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { DateFormatSelect };
export type { DateFormat };
