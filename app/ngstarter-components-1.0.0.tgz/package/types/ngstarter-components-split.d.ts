import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef, InjectionToken, AfterViewInit, EnvironmentProviders } from '@angular/core';
import { Observable } from 'rxjs';

declare class SplitPane implements OnDestroy {
    private ngZone;
    private renderer;
    private split;
    elRef: ElementRef<any>;
    /**
     * Order of the area. Used to maintain the order of areas when toggling their visibility.
     * Toggling area visibility without specifying an `order` leads to weird behavior.
     */
    orderIn: _angular_core.InputSignalWithTransform<number | null, string | number | null>;
    /**
     * Size of the area in selected unit (percent/pixel).
     * - Percent: All areas sizes should equal to `100`, If not, all areas will have the same size.
     * - Pixel: An area with wildcard size (`size="*"`) is mandatory (only one) and
     *   can't have `visible="false"` or `minSize`/`maxSize`/`lockSize` properties.
     */
    sizeIn: _angular_core.InputSignalWithTransform<number | null, string | number | null>;
    /** Minimum pixel or percent size, should be equal to or smaller than provided `size`. */
    minSizeIn: _angular_core.InputSignalWithTransform<number | null, string | number | null>;
    /** Maximum pixel or percent size, should be equal to or larger than provided `size`. */
    maxSizeIn: _angular_core.InputSignalWithTransform<number | null, string | number | null>;
    /** Lock area size, same as `minSize`=`maxSize`=`size`. */
    lockSizeIn: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Hide area visually but still present in the DOM, use `ngIf` to completely remove it. */
    visibleIn: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Show handle (three dots) on the gutter adjacent to this pane. */
    withHandleIn: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private orderSig;
    private sizeSig;
    private minSizeSig;
    private maxSizeSig;
    private lockSizeSig;
    private visibleSig;
    private withHandleSig;
    private transitionListener;
    private readonly lockListeners;
    constructor();
    getOrder(): number | null;
    getSize(): number | null;
    setSize(v: number | null): void;
    getMinSize(): number | null;
    getMaxSize(): number | null;
    isLocked(): boolean;
    isVisible(): boolean;
    hasHandle(): boolean;
    setStyleOrder(value: number): void;
    setStyleFlex(grow: number, shrink: number, basis: string, isMin: boolean, isMax: boolean): void;
    lockEvents(): void;
    unlockEvents(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitPane, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SplitPane, "ngs-split-pane, [ngs-split-pane]", ["ngsSplitPane"], { "orderIn": { "alias": "order"; "required": false; "isSignal": true; }; "sizeIn": { "alias": "size"; "required": false; "isSignal": true; }; "minSizeIn": { "alias": "minSize"; "required": false; "isSignal": true; }; "maxSizeIn": { "alias": "maxSize"; "required": false; "isSignal": true; }; "lockSizeIn": { "alias": "lockSize"; "required": false; "isSignal": true; }; "visibleIn": { "alias": "visible"; "required": false; "isSignal": true; }; "withHandleIn": { "alias": "withHandle"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface SplitPoint {
    x: number;
    y: number;
}
interface SplitArea {
    component: SplitPane;
    order: number;
    size: number | null;
    minSize: number | null;
    maxSize: number | null;
}
interface SplitSnapshot {
    gutterNum: number;
    allAreasSizePixel: number;
    allInvolvedAreasSizePercent: number;
    lastSteppedOffset: number;
    areasBeforeGutter: SplitAreaSnapshot[];
    areasAfterGutter: SplitAreaSnapshot[];
}
interface SplitAreaSnapshot {
    area: SplitArea;
    sizePixelAtStart: number;
    sizePercentAtStart: number;
}
interface SplitSideAbsorptionCapacity {
    remain: number;
    list: SplitAreaAbsorptionCapacity[];
}
interface SplitAreaAbsorptionCapacity {
    areaSnapshot: SplitAreaSnapshot;
    pixelAbsorb: number;
    percentAfterAbsorption: number;
    pixelRemain: number;
}
interface SplitOutputData {
    gutterNum: number;
    sizes: SplitOutputAreaSizes;
}
type SplitOutputAreaSizes = (number | '*')[];
interface SplitDefaultOptions {
    dir?: 'ltr' | 'rtl';
    direction?: 'horizontal' | 'vertical';
    unit?: 'percent' | 'pixel';
    gutterDblClickDuration?: number;
    gutterSize?: number;
    gutterStep?: number;
    restrictMove?: boolean;
    useTransition?: boolean;
}

declare function getPointFromEvent(event: MouseEvent | TouchEvent): SplitPoint | null;
declare function getElementPixelSize(elRef: ElementRef, direction: 'horizontal' | 'vertical'): number;
declare function getInputPositiveNumber<T>(v: any, defaultValue: T): number | T;
declare function isUserSizesValid(unit: 'percent' | 'pixel', sizes: number[]): boolean | number | void;
declare function getAreaMinSize(a: SplitArea): number;
declare function getAreaMaxSize(a: SplitArea): null | number;
declare function getGutterSideAbsorptionCapacity(unit: 'percent' | 'pixel', sideAreas: SplitAreaSnapshot[], pixels: number, allAreasSizePixel: number): SplitSideAbsorptionCapacity;
declare function getAreaAbsorptionCapacity(unit: 'percent' | 'pixel', areaSnapshot: SplitAreaSnapshot, pixels: number, allAreasSizePixel: number): SplitAreaAbsorptionCapacity | void;
declare function getAreaAbsorptionCapacityPercent(areaSnapshot: SplitAreaSnapshot, pixels: number, allAreasSizePixel: number): SplitAreaAbsorptionCapacity | void;
declare function getAreaAbsorptionCapacityPixel(areaSnapshot: SplitAreaSnapshot, pixels: number, containerSizePixel: number): SplitAreaAbsorptionCapacity | void;
declare function updateAreaSize(unit: 'percent' | 'pixel', item: SplitAreaAbsorptionCapacity): void;

/** Injection token that can be used to specify default split options. */
declare const SPLIT_DEFAULT_OPTIONS: InjectionToken<SplitDefaultOptions>;
/**
 * Configures the default options for the split component.
 * @param options The default options to use.
 * @returns The environment providers.
 */
declare function provideSplit(options: SplitDefaultOptions): EnvironmentProviders;
declare class Split implements AfterViewInit, OnDestroy {
    shouldShowHandle(gutterIndex: number): boolean;
    private ngZone;
    private elRef;
    private cdRef;
    private renderer;
    private isInit;
    protected _defaultOptions: SplitDefaultOptions | null;
    /** The split direction. */
    direction: _angular_core.InputSignal<"horizontal" | "vertical">;
    /** The unit you want to specify area sizes. */
    unit: _angular_core.InputSignal<"percent" | "pixel">;
    /** Gutters's size (dragging elements) in pixels. */
    gutterSize: _angular_core.InputSignalWithTransform<number, string | number>;
    /** Gutter step while moving in pixels. */
    gutterStep: _angular_core.InputSignalWithTransform<number, string | number>;
    /** Set to true if you want to limit gutter move to adjacent areas only. */
    restrictMove: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Add transition when toggling visibility using `visible` or `size` changes. */
    useTransition: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Disable the dragging feature (remove cursor/image on gutters).
     * `gutterClick`/`gutterDblClick` still emits.
     */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Indicates the directionality of the areas. */
    dir: _angular_core.InputSignal<"ltr" | "rtl">;
    /**
     * Milliseconds to detect a double click on a gutter. Set it around 300-500ms if
     * you want to use `gutterDblClick` event.
     */
    gutterDblClickDuration: _angular_core.InputSignalWithTransform<number, string | number>;
    /** Event emitted when drag starts. */
    dragStart: _angular_core.OutputEmitterRef<SplitOutputData>;
    /** Event emitted when drag ends. */
    dragEnd: _angular_core.OutputEmitterRef<SplitOutputData>;
    /** Event emitted when user clicks on a gutter. */
    gutterClick: _angular_core.OutputEmitterRef<SplitOutputData>;
    /** Event emitted when user double clicks on a gutter. */
    gutterDblClick: _angular_core.OutputEmitterRef<SplitOutputData>;
    /** Event emitted when transition ends (debounced). */
    transitionEnd: _angular_core.OutputEmitterRef<SplitOutputAreaSizes>;
    private transitionEndSubject;
    private dragProgressSubject;
    dragProgress$: Observable<SplitOutputData>;
    private isDragging;
    private dragListeners;
    private snapshot;
    private startPoint;
    private endPoint;
    readonly displayedAreas: SplitArea[];
    private readonly hidedAreas;
    private gutterEls;
    protected isDraggingSignal: _angular_core.Signal<boolean>;
    readonly isDraggingPublic: _angular_core.Signal<boolean>;
    protected isInitSignal: _angular_core.Signal<boolean>;
    constructor();
    ngAfterViewInit(): void;
    private getNbGutters;
    addArea(component: SplitPane): void;
    removeArea(component: SplitPane): void;
    updateArea(component: SplitPane, resetOrders: boolean, resetSizes: boolean): void;
    updateAreaInternal(component: SplitPane): void;
    showArea(component: SplitPane): void;
    hideArea(comp: SplitPane): void;
    getVisibleAreaSizes(): SplitOutputAreaSizes;
    setVisibleAreaSizes(sizes: SplitOutputAreaSizes): boolean;
    private build;
    private refreshStyleSizes;
    _clickTimeout: number | null;
    clickGutter(event: MouseEvent | TouchEvent, gutterNum: number): void;
    startDragging(event: MouseEvent | TouchEvent, gutterOrder: number, gutterNum: number): void;
    private dragEvent;
    private stopDragging;
    notify(type: 'start' | 'progress' | 'end' | 'click' | 'dblclick' | 'transitionEnd', gutterNum: number): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Split, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Split, "ngs-split", ["ngsSplit"], { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "unit": { "alias": "unit"; "required": false; "isSignal": true; }; "gutterSize": { "alias": "gutterSize"; "required": false; "isSignal": true; }; "gutterStep": { "alias": "gutterStep"; "required": false; "isSignal": true; }; "restrictMove": { "alias": "restrictMove"; "required": false; "isSignal": true; }; "useTransition": { "alias": "useTransition"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "dir": { "alias": "dir"; "required": false; "isSignal": true; }; "gutterDblClickDuration": { "alias": "gutterDblClickDuration"; "required": false; "isSignal": true; }; }, { "dragStart": "dragStart"; "dragEnd": "dragEnd"; "gutterClick": "gutterClick"; "gutterDblClick": "gutterDblClick"; "transitionEnd": "transitionEnd"; }, never, ["*"], true, never>;
}

export { SPLIT_DEFAULT_OPTIONS, Split, SplitPane, getAreaAbsorptionCapacity, getAreaAbsorptionCapacityPercent, getAreaAbsorptionCapacityPixel, getAreaMaxSize, getAreaMinSize, getElementPixelSize, getGutterSideAbsorptionCapacity, getInputPositiveNumber, getPointFromEvent, isUserSizesValid, provideSplit, updateAreaSize };
export type { SplitArea, SplitAreaAbsorptionCapacity, SplitAreaSnapshot, SplitDefaultOptions, SplitOutputAreaSizes, SplitOutputData, SplitPoint, SplitSideAbsorptionCapacity, SplitSnapshot };
