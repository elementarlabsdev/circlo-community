import * as i0 from '@angular/core';
import { InjectionToken, OnInit, EventEmitter } from '@angular/core';
import * as i1 from '@angular/cdk/scrolling';
import { CdkScrollable } from '@angular/cdk/scrolling';
import * as _ngrx_signals from '@ngrx/signals';

declare class Layout {
    layoutId: i0.InputSignal<string>;
    root: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Layout, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Layout, "ngs-layout", ["ngsLayout"], { "layoutId": { "alias": "layoutId"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-layout-topbar", "ngs-layout-header", "ngs-layout-sidebar", "*", "ngs-layout-aside", "ngs-layout-footer"], true, never>;
}

declare class LayoutHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutHeader, "ngs-layout-header", ["ngsLayoutHeader"], {}, {}, never, ["*"], true, never>;
}

declare const LAYOUT: InjectionToken<unknown>;
interface LayoutSidebarVisibilityChange {
    layoutId: string;
    shown: boolean;
}
interface LayoutContentInterface {
    scrollContainer(): HTMLElement;
    scrollable?: CdkScrollable;
}
declare const LAYOUT_CONTENT: InjectionToken<LayoutContentInterface>;

declare class LayoutContent implements OnInit, LayoutContentInterface {
    private _router;
    private _elementRef;
    private _platformId;
    readonly scrollable: CdkScrollable;
    autoscrollToTop: i0.InputSignalWithTransform<boolean, unknown>;
    scrollContainer(): HTMLElement;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutContent, "ngs-layout-content", ["ngsLayoutContent"], { "autoscrollToTop": { "alias": "autoscrollToTop"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.CdkScrollable; inputs: {}; outputs: {}; }]>;
}

declare class LayoutFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutFooter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutFooter, "ngs-layout-footer", ["ngsLayoutFooter"], {}, {}, never, ["*"], true, never>;
}

declare class LayoutTopbar {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutTopbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutTopbar, "ngs-layout-topbar", ["ngsLayoutTopbar"], {}, {}, never, ["*"], true, never>;
}

declare class LayoutSidebar {
    private _parent;
    private _layoutSidebarStore;
    protected _isShown: i0.Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutSidebar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutSidebar, "ngs-layout-sidebar", ["ngsLayoutSidebar"], {}, {}, never, ["*"], true, never>;
}

declare class LayoutAside {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutAside, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutAside, "ngs-layout-aside", ["ngsLayoutAside"], {}, {}, never, ["*"], true, never>;
}

declare class LayoutApiService {
    private _layoutSidebarStore;
    readonly sidebarVisibility: EventEmitter<LayoutSidebarVisibilityChange>;
    hideSidebar(layoutId: string): void;
    showSidebar(layoutId: string): void;
    toggleSidebar(layoutId: string): void;
    isSidebarShown(layoutId: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LayoutApiService>;
}

declare const LayoutSidebarStore: i0.Type<{
    showSidebarVisibility: (layoutId: string, isShown: boolean) => void;
} & _ngrx_signals.StateSource<{
    [x: string]: boolean;
}>>;

export { LAYOUT, LAYOUT_CONTENT, Layout, LayoutApiService, LayoutAside, LayoutContent, LayoutFooter, LayoutHeader, LayoutSidebar, LayoutSidebarStore, LayoutTopbar };
export type { LayoutContentInterface, LayoutSidebarVisibilityChange };
