import * as i0 from '@angular/core';

declare class Logo {
    static ɵfac: i0.ɵɵFactoryDeclaration<Logo, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Logo, "ngs-logo,[ngs-logo]", ["ngsLogo"], {}, {}, never, ["ngs-logo-shape", "ngs-logo-text", "ngs-logo-description", "*"], true, never>;
}

declare class LogoShape {
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoShape, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoShape, "ngs-logo-shape", never, {}, {}, never, ["img"], true, never>;
}

type LogoTextSize = 'small' | 'default' | 'large';

declare class LogoText {
    readonly size: i0.InputSignal<LogoTextSize>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoText, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoText, "ngs-logo-text", ["ngsLogoText"], { "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class LogoDescription {
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoDescription, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoDescription, "ngs-logo-description", never, {}, {}, never, ["*"], true, never>;
}

export { Logo, LogoDescription, LogoShape, LogoText };
