import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import { CdkStep, CdkStepper, StepperOrientation, CdkStepperNext, CdkStepperPrevious } from '@angular/cdk/stepper';

declare class StepLabel {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<StepLabel, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StepLabel, "[ngsStepLabel]", never, {}, {}, never, never, true, never>;
}

declare class Step extends CdkStep {
    stepLabel: StepLabel;
    constructor(stepper: Stepper);
    static ɵfac: i0.ɵɵFactoryDeclaration<Step, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Step, "ngs-step", ["ngsStep"], {}, {}, ["stepLabel"], ["*"], true, never>;
}

declare class Stepper extends CdkStepper {
    headerPosition: i0.InputSignal<"top" | "bottom">;
    labelPosition: i0.InputSignal<"top" | "bottom">;
    private _stepperOrientation;
    get orientation(): StepperOrientation;
    set orientation(value: StepperOrientation);
    readonly stepItems: i0.Signal<readonly Step[]>;
    readonly _stepLabels: i0.Signal<readonly StepLabel[]>;
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Stepper, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Stepper, "ngs-stepper", ["ngsStepper"], { "headerPosition": { "alias": "headerPosition"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; }, {}, ["stepItems", "_stepLabels"], never, true, never>;
}

declare class StepperNext extends CdkStepperNext {
    type: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StepperNext, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StepperNext, "button[ngsStepperNext]", never, {}, {}, never, never, true, never>;
}

declare class StepperPrevious extends CdkStepperPrevious {
    type: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StepperPrevious, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StepperPrevious, "button[ngsStepperPrevious]", never, {}, {}, never, never, true, never>;
}

export { Step, StepLabel, Stepper, StepperNext, StepperPrevious };
