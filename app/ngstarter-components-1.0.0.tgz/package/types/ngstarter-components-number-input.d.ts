import * as _angular_core from '@angular/core';
import { TemplateRef, OnDestroy, DoCheck } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { FormFieldControl } from '@ngstarter/components/form-field';
import { Subject } from 'rxjs';

declare class DecreaseControlDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DecreaseControlDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DecreaseControlDirective, "[ngsDecreaseControl]", ["ngsDecreaseControl"], {}, {}, never, never, true, never>;
}

declare class IncreaseControlDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IncreaseControlDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<IncreaseControlDirective, "[ngsIncreaseControl]", ["ngsIncreaseControl"], {}, {}, never, never, true, never>;
}

declare class NumberInput implements FormFieldControl<any>, ControlValueAccessor, OnDestroy, DoCheck {
    ngControl: NgControl;
    private _parentForm;
    private _parentFormGroup;
    private _elementRef;
    readonly disableAutomaticLabeling: boolean;
    private _input;
    readonly _decreaseControlRef: _angular_core.Signal<DecreaseControlDirective | undefined>;
    readonly _increaseControlRef: _angular_core.Signal<IncreaseControlDirective | undefined>;
    min: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    max: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    step: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabledInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get disabled(): boolean;
    private _disabled;
    requiredInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get required(): boolean;
    private _required;
    readonly valueChange: _angular_core.OutputEmitterRef<number | undefined>;
    static nextId: number;
    private _value;
    controlType?: string | undefined;
    autofilled?: boolean | undefined;
    userAriaDescribedBy?: string | undefined;
    stateChanges: Subject<void>;
    focused: boolean;
    private _focused;
    touched: boolean;
    errorState: boolean;
    private _errorState;
    id: string;
    private _id;
    shouldLabelFloat: boolean;
    private _shouldLabelFloat;
    empty: boolean;
    private _empty;
    _placeholder: _angular_core.InputSignal<string>;
    get placeholder(): string;
    constructor(ngControl: NgControl);
    setDescribedByIds(ids: string[]): void;
    onFocusIn(event: FocusEvent): void;
    onFocusOut(event: FocusEvent): void;
    set value(value: number | undefined);
    get value(): number | undefined;
    ngOnDestroy(): void;
    protected get _decreaseControlTemplateRef(): TemplateRef<any>;
    protected get _increaseControlTemplateRef(): TemplateRef<any>;
    onChange: any;
    onTouched: any;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    decrease(event: MouseEvent, input: HTMLInputElement): void;
    increase(event: MouseEvent, input: HTMLInputElement): void;
    isDecreaseDisabled(): boolean;
    isIncreaseDisabled(): boolean;
    inputChange(event: any): void;
    private _emitEvent;
    ngDoCheck(): void;
    focus(): void;
    onContainerClick(event: MouseEvent): void;
    private updateErrorState;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NumberInput, [{ optional: true; self: true; }]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NumberInput, "ngs-number-input", ["ngsNumberInput"], { "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "requiredInput": { "alias": "required"; "required": false; "isSignal": true; }; "_placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, ["_decreaseControlRef", "_increaseControlRef"], never, true, never>;
}

declare class NumberInputPrefixDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NumberInputPrefixDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NumberInputPrefixDirective, "[ngsNumberInputPrefix]", ["ngsNumberInputPrefix"], {}, {}, never, never, true, never>;
}

declare class NumberInputSuffixDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NumberInputSuffixDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<NumberInputSuffixDirective, "[ngsNumberInputSuffix]", ["ngsNumberInputSuffix"], {}, {}, never, never, true, never>;
}

export { DecreaseControlDirective, IncreaseControlDirective, NumberInput, NumberInputPrefixDirective, NumberInputSuffixDirective };
