import * as _angular_core from '@angular/core';
import { ElementRef, AfterContentInit, DoCheck } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { FormFieldControl } from '@ngstarter/components/form-field';

declare class Chip {
    readonly _elementRef: ElementRef<any>;
    protected _editing: boolean;
    appearance: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    value: _angular_core.InputSignal<any>;
    readonly destroyed: _angular_core.OutputEmitterRef<{
        chip: Chip;
    }>;
    readonly removed: _angular_core.OutputEmitterRef<{
        chip: Chip;
    }>;
    remove(): void;
    ngOnDestroy(): void;
    _handleKeydown(event: KeyboardEvent): void;
    _handleBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Chip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Chip, "ngs-chip", never, { "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "destroyed": "destroyed"; "removed": "removed"; }, never, ["ngs-chip-avatar, [ngsChipAvatar]", "*", "[ngsChipTrailingAction]", "ngs-chip-remove, [ngsChipRemove], [ngsChipTrailingAction], [ngsChipEdit]"], true, never>;
}

interface ChipEditedEvent {
    /** The chip row that was edited. */
    chip: ChipRow;
    /** The value of the chip row after it was edited. */
    value: string;
}
declare class ChipRow extends Chip {
    private _changeDetectorRef;
    private readonly _editInput;
    alreadyEdited: _angular_core.WritableSignal<boolean>;
    editable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly edited: _angular_core.OutputEmitterRef<ChipEditedEvent>;
    /**
     * Allows for use of the template-bound $event object
     */
    _handleKeydown(event: KeyboardEvent): void;
    _handleBlur(): void;
    _handleClick(event: MouseEvent): void;
    _startEditing(): void;
    private _stopEditing;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipRow, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipRow, "ngs-chip-row", never, { "editable": { "alias": "editable"; "required": false; "isSignal": true; }; }, { "edited": "edited"; }, never, ["ngs-chip-avatar, [ngsChipAvatar]", "*", "[ngsChipTrailingAction]", "ngs-chip-remove, [ngsChipRemove], [ngsChipTrailingAction], [ngsChipEdit]"], true, never>;
}

declare class ChipGrid implements ControlValueAccessor, AfterContentInit, FormFieldControl<any[]> {
    readonly ngControl: NgControl | null;
    readonly _elementRef: ElementRef<any>;
    _id: _angular_core.InputSignal<string>;
    get id(): string;
    _placeholder: _angular_core.InputSignal<string | undefined>;
    get placeholder(): string | undefined;
    _required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get required(): boolean;
    private _disabled;
    _disabledInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    isDisabled: _angular_core.Signal<boolean>;
    get disabled(): boolean;
    readonly _chips: _angular_core.Signal<readonly ChipRow[]>;
    private readonly _chips$;
    readonly valueChange: _angular_core.OutputEmitterRef<any>;
    private _value;
    readonly stateChanges: _angular_core.WritableSignal<void>;
    private _focused;
    get focused(): boolean;
    private _errorState;
    get errorState(): boolean;
    private _chipsLength;
    get chipsLength(): number;
    private _empty;
    get empty(): boolean;
    private _shouldLabelFloat;
    get shouldLabelFloat(): boolean;
    private _isInputFocused;
    private _isInputEmpty;
    private _chipInput;
    onChange: (value: any) => void;
    onTouched: () => void;
    constructor();
    get value(): any[];
    set value(value: any[]);
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    ngAfterContentInit(): void;
    _setFocused(focused: boolean): void;
    _setInputFocused(focused: boolean): void;
    _setInputEmpty(empty: boolean): void;
    _registerInput(input: any): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipGrid, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipGrid, "ngs-chip-grid", never, { "_id": { "alias": "id"; "required": false; "isSignal": true; }; "_placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "_required": { "alias": "required"; "required": false; "isSignal": true; }; "_disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, ["_chips"], ["*"], true, never>;
}

declare class ChipOption extends Chip {
    selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private _internalSelected;
    constructor();
    get isSelected(): boolean;
    _setSelected(value: boolean): void;
    readonly selectionChange: _angular_core.OutputEmitterRef<{
        source: ChipOption;
        selected: boolean;
    }>;
    toggleSelected(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipOption, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipOption, "ngs-chip-option", never, { "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; }, never, ["ngs-chip-avatar, [ngsChipAvatar]", "*", "[ngsChipTrailingAction]", "ngs-chip-remove, [ngsChipRemove], [ngsChipTrailingAction], [ngsChipEdit]"], true, never>;
}

declare class ChipListbox implements ControlValueAccessor, AfterContentInit {
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly _chips: _angular_core.Signal<readonly ChipOption[]>;
    private readonly _chips$;
    private _value;
    onChange: (value: any) => void;
    onTouched: () => void;
    get value(): any;
    set value(value: any);
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    ngAfterContentInit(): void;
    private _onSelectionChange;
    private _updateChips;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipListbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipListbox, "ngs-chip-listbox", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, ["_chips"], ["*"], true, never>;
}

declare class ChipSet {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipSet, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChipSet, "ngs-chip-set", never, {}, {}, never, ["*"], true, never>;
}

declare class ChipAvatar {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipAvatar, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ChipAvatar, "ngs-chip-avatar, [ngsChipAvatar]", never, {}, {}, never, never, true, never>;
}

declare class ChipEdit {
    protected _parentChip: ChipRow;
    _handleClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipEdit, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ChipEdit, "ngs-chip-edit, [ngsChipEdit]", never, {}, {}, never, never, true, never>;
}

declare class ChipRemove {
    protected _parentChip: Chip;
    _handleClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipRemove, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ChipRemove, "ngs-chip-remove, [ngsChipRemove]", never, {}, {}, never, never, true, never>;
}

interface ChipInputEvent {
    readonly chipInput: ChipInput;
    readonly value: string;
    readonly input: HTMLInputElement;
}
declare class ChipInput implements DoCheck {
    private _elementRef;
    set chipGrid(value: ChipGrid);
    get chipGrid(): ChipGrid;
    private _chipGrid;
    chipGridInput: _angular_core.InputSignal<ChipGrid | undefined>;
    chipInputSeparatorKeyCodes: _angular_core.InputSignal<ReadonlySet<number> | readonly number[] | undefined>;
    chipInputAddOnBlur: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly chipInputTokenEnd: _angular_core.OutputEmitterRef<any>;
    protected readonly _value: _angular_core.WritableSignal<string>;
    protected readonly _focused: _angular_core.WritableSignal<boolean>;
    constructor();
    ngDoCheck(): void;
    _onInput(): void;
    _onKeydown(event: any): void;
    _onBlur(): void;
    _onFocus(): void;
    clear(): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipInput, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ChipInput, "input[ngsChipInputFor]", never, { "chipGridInput": { "alias": "ngsChipInputFor"; "required": false; "isSignal": true; }; "chipInputSeparatorKeyCodes": { "alias": "ngsChipInputSeparatorKeyCodes"; "required": false; "isSignal": true; }; "chipInputAddOnBlur": { "alias": "ngsChipInputAddOnBlur"; "required": false; "isSignal": true; }; }, { "chipInputTokenEnd": "chipInputTokenEnd"; }, never, never, true, never>;
}

export { Chip, ChipAvatar, ChipEdit, ChipGrid, ChipInput, ChipListbox, ChipOption, ChipRemove, ChipRow, ChipSet };
export type { ChipEditedEvent, ChipInputEvent };
