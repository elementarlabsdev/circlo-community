import * as i0 from '@angular/core';

declare class Skeleton {
    roundedFull: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Skeleton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Skeleton, "ngs-skeleton", ["ngsSkeleton"], { "roundedFull": { "alias": "roundedFull"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { Skeleton };
