import * as _angular_core from '@angular/core';
import { TemplateRef, InjectionToken, AfterViewInit, OnDestroy, ElementRef, OnInit } from '@angular/core';
import * as _ngstarter_components_tabs from '@ngstarter/components/tabs';
import * as _angular_cdk_portal from '@angular/cdk/portal';
import { TemplatePortal } from '@angular/cdk/portal';
import * as i1 from '@ngstarter/components/core';

declare class Tab {
    templateLabel: _angular_core.Signal<_ngstarter_components_tabs.TabLabel | undefined>;
    explicitContent: _angular_core.Signal<_ngstarter_components_tabs.TabContent | undefined>;
    implicitContent: _angular_core.Signal<TemplateRef<any> | undefined>;
    label: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string>;
    ariaLabelledby: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private _contentPortal;
    _prepareContent(viewContainerRef: any): TemplatePortal<any> | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tab, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tab, "ngs-tab", ["ngsTab"], { "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, ["templateLabel", "explicitContent"], ["*"], true, never>;
}

declare const TAB_LABEL: InjectionToken<TabLabel>;
declare class TabLabel {
    template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabLabel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TabLabel, "[ngsTabLabel], [ngs-tab-label]", never, {}, {}, never, never, true, never>;
}
declare const TAB_CONTENT: InjectionToken<TabContent>;
declare class TabContent {
    template: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TabContent, "[ngsTabContent], [ngs-tab-content]", never, {}, {}, never, never, true, never>;
}

interface TabChangeEvent {
    index: number;
    tab: Tab;
}
declare class TabGroup implements AfterViewInit, OnDestroy {
    private _viewContainerRef;
    private _cdr;
    private _platformId;
    private _tabsSubscription;
    private _resizeSubscription;
    private _resizeObserver;
    _tabs: _angular_core.Signal<readonly Tab[]>;
    _tabLabels: _angular_core.Signal<readonly ElementRef<any>[]>;
    _tabListContainer: _angular_core.Signal<ElementRef<any> | undefined>;
    _tabList: _angular_core.Signal<ElementRef<any> | undefined>;
    _showPaginationControls: _angular_core.WritableSignal<boolean>;
    _disableScrollBefore: _angular_core.WritableSignal<boolean>;
    _disableScrollAfter: _angular_core.WritableSignal<boolean>;
    selectedIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    headerPosition: _angular_core.InputSignal<"above" | "below">;
    preserveContent: _angular_core.InputSignalWithTransform<boolean, unknown>;
    stretchTabs: _angular_core.InputSignalWithTransform<boolean, unknown>;
    alignTabs: _angular_core.InputSignal<"start" | "center" | "end">;
    disableRipple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    animationDuration: _angular_core.InputSignalWithTransform<string, string | number>;
    enterAnimation: _angular_core.InputSignal<string>;
    leaveAnimation: _angular_core.InputSignal<string>;
    selectedIndexChange: _angular_core.OutputEmitterRef<number>;
    selectedTabChange: _angular_core.OutputEmitterRef<TabChangeEvent>;
    focusChange: _angular_core.OutputEmitterRef<TabChangeEvent>;
    _isActive: {
        [key: number]: boolean;
    };
    protected _selectedIndex: number;
    private _prevIndex;
    private _isInitialized;
    constructor();
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    protected _clampIndex(): void;
    _updatePagination(): void;
    _updateScrollButtonsState(): void;
    private _scrollToTab;
    _scrollBefore(): void;
    _scrollAfter(): void;
    _handleScroll(): void;
    _onTabHeaderClick(index: number): void;
    _getTabContent(tab: Tab): _angular_cdk_portal.TemplatePortal<any> | null;
    _getEnterAnimation(index: number): string;
    _getLeaveAnimation(index: number): string;
    _onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabGroup, "ngs-tab-group", never, { "selectedIndex": { "alias": "selectedIndex"; "required": false; "isSignal": true; }; "headerPosition": { "alias": "headerPosition"; "required": false; "isSignal": true; }; "preserveContent": { "alias": "preserveContent"; "required": false; "isSignal": true; }; "stretchTabs": { "alias": "ngs-stretch-tabs"; "required": false; "isSignal": true; }; "alignTabs": { "alias": "ngs-align-tabs"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; "animationDuration": { "alias": "animationDuration"; "required": false; "isSignal": true; }; "enterAnimation": { "alias": "animate.enter"; "required": false; "isSignal": true; }; "leaveAnimation": { "alias": "animate.leave"; "required": false; "isSignal": true; }; }, { "selectedIndexChange": "selectedIndexChange"; "selectedTabChange": "selectedTabChange"; "focusChange": "focusChange"; }, ["_tabs"], never, true, never>;
}

declare class TabLink {
    private _el;
    private _parent;
    private _routerLink;
    readonly active: _angular_core.Signal<boolean>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    rippleDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get ngsRippleDisabled(): boolean;
    _ariaControls(): string | null;
    _onClick(event: MouseEvent): void;
    focus(): void;
    get elementRef(): ElementRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabLink, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabLink, "a[ngs-tab-link]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "rippleDisabled": { "alias": "ngsRippleDisabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Ripple; inputs: { "ngsRippleDisabled": "ngsRippleDisabled"; }; outputs: {}; }]>;
}

declare class TabNavPanel {
    id: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabNavPanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabNavPanel, "ngs-tab-nav-panel", ["ngsTabNavPanel"], {}, {}, never, ["*"], true, never>;
}

declare class TabNavBar implements AfterViewInit, OnDestroy, OnInit {
    private _cdr;
    private platformId;
    private currentUrl;
    private _router;
    private _destroyRef;
    _links: _angular_core.Signal<readonly TabLink[]>;
    _tabListContainer: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    _tabList: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    _showPaginationControls: _angular_core.WritableSignal<boolean>;
    _disableScrollBefore: _angular_core.WritableSignal<boolean>;
    _disableScrollAfter: _angular_core.WritableSignal<boolean>;
    tabPanel: _angular_core.InputSignal<TabNavPanel | null>;
    disableRipple: _angular_core.InputSignal<boolean>;
    activator: _angular_core.InputSignal<((link: TabLink) => boolean) | undefined>;
    readonly isActiveFn: _angular_core.Signal<(link: TabLink) => boolean>;
    private _resizeObserver;
    private _resizeSubscription;
    private defaultIsActive;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    _handleScroll(): void;
    _scrollBefore(): void;
    _scrollAfter(): void;
    private _updatePagination;
    private _updateScrollButtonsState;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabNavBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabNavBar, "ngs-tab-nav-bar, [ngs-tab-nav-bar]", ["ngsTabNavBar"], { "tabPanel": { "alias": "tabPanel"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; "activator": { "alias": "activator"; "required": false; "isSignal": true; }; }, {}, ["_links"], ["a[ngs-tab-link]"], true, never>;
}

export { TAB_CONTENT, TAB_LABEL, Tab, TabContent, TabGroup, TabLabel, TabLink, TabNavBar, TabNavPanel };
export type { TabChangeEvent };
