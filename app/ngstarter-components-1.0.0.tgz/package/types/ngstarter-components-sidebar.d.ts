import * as i0 from '@angular/core';
import { ElementRef, AfterContentInit, TemplateRef, SimpleChanges, OnInit, InjectionToken } from '@angular/core';
import * as i1 from '@ngstarter/components/core';

declare class Sidebar {
    static ɵfac: i0.ɵɵFactoryDeclaration<Sidebar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Sidebar, "ngs-sidebar", ["ngsSidebar"], {}, {}, never, ["ngs-sidebar-header", "ngs-sidebar-body", "ngs-sidebar-footer"], true, never>;
}

declare class SidebarHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarHeader, "ngs-sidebar-header", ["ngsSidebarHeader"], {}, {}, never, ["*"], true, never>;
}

declare class SidebarBody {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarBody, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarBody, "ngs-sidebar-body", ["ngsSidebarBody"], {}, {}, never, ["*"], true, never>;
}

declare class SidebarNavItemInterface {
    active: boolean;
}
declare class SidebarNavItem implements SidebarNavItemInterface {
    private _navigation;
    private _elementRef;
    private _navStore;
    get api(): {
        isActive: () => boolean;
    };
    key: i0.InputSignal<any>;
    forceActive: i0.InputSignalWithTransform<boolean, unknown>;
    click(event: MouseEvent): void;
    get active(): boolean;
    get _hostElement(): ElementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarNavItem, "ngs-sidebar-nav-item,[ngs-sidebar-nav-item]", ["ngs-sidebar-nav-item"], { "key": { "alias": "key"; "required": false; "isSignal": true; }; "forceActive": { "alias": "forceActive"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsSidebarNavItemIcon]", "*", "[ngsSidebarNavItemBadge]"], true, never>;
}

declare class SidebarNavGroup implements AfterContentInit {
    private _toggle;
    private _menu;
    readonly _groupId: string;
    ngAfterContentInit(): void;
    hasActiveItem(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarNavGroup, "ngs-sidebar-nav-group", never, {}, {}, ["_toggle", "_menu"], ["*"], true, never>;
}

declare class SidebarNavItemDefDirective {
    template: TemplateRef<any>;
    when: i0.InputSignal<string | ((item: any) => boolean) | undefined>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavItemDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarNavItemDefDirective, "[ngsSidebarNavItemDef]", never, { "when": { "alias": "ngsSidebarNavItemDef"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SidebarNav implements AfterContentInit {
    private _elementRef;
    private _navStore;
    readonly _items: i0.Signal<readonly SidebarNavItem[]>;
    readonly _groups: i0.Signal<readonly SidebarNavGroup[]>;
    readonly _defs: i0.Signal<readonly SidebarNavItemDefDirective[]>;
    activeKey: i0.InputSignal<unknown>;
    dataSource: i0.InputSignal<any[] | undefined>;
    itemTypeProperty: i0.InputSignal<string>;
    autoScrollToActiveItem: i0.InputSignalWithTransform<boolean, unknown>;
    readonly itemClicked: i0.OutputEmitterRef<any>;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentInit(): void;
    private _hasScroll;
    private _isScrolledIntoView;
    getTemplate(item: any): TemplateRef<any> | null;
    private _scrollToActiveItem;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNav, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarNav, "ngs-sidebar-nav", ["ngsSidebarNav"], { "activeKey": { "alias": "activeKey"; "required": false; "isSignal": true; }; "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "itemTypeProperty": { "alias": "itemTypeProperty"; "required": false; "isSignal": true; }; "autoScrollToActiveItem": { "alias": "autoScrollToActiveItem"; "required": false; "isSignal": true; }; }, { "itemClicked": "itemClicked"; }, ["_items", "_groups", "_defs"], ["*"], true, never>;
}

declare class SidebarFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarFooter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarFooter, "ngs-sidebar-footer", ["ngsSidebarFooter"], {}, {}, never, ["*"], true, never>;
}

declare class SidebarNavHeading {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavHeading, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarNavHeading, "ngs-sidebar-nav-heading", ["ngsSidebarNavHeading"], {}, {}, never, ["*"], true, never>;
}

declare class SidebarNavGroupToggle {
    private _navStore;
    readonly for: i0.WritableSignal<any>;
    get active(): boolean;
    toggle(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavGroupToggle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarNavGroupToggle, "ngs-sidebar-nav-group-toggle", ["ngsSidebarNavGroupToggle"], {}, {}, never, ["[ngsSidebarNavItemIcon]", "*", "[ngsSidebarNavItemBadge]", "[ngsSidebarNavGroupToggleIcon]"], true, [{ directive: typeof i1.Ripple; inputs: {}; outputs: {}; }]>;
}

declare class SidebarNavGroupMenu implements AfterContentInit, OnInit {
    readonly navigation: SidebarNav;
    private _group;
    private _navStore;
    readonly _items: i0.Signal<readonly SidebarNavItem[]>;
    readonly _defs: i0.Signal<readonly SidebarNavItemDefDirective[]>;
    key: i0.WritableSignal<any>;
    dataSource: i0.InputSignal<any[] | undefined>;
    itemTypeProperty: i0.InputSignal<string>;
    get active(): boolean;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    hasActiveItem(): boolean;
    getTemplate(item: any): TemplateRef<any> | null;
    private _checkIfActive;
    private _isActive;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavGroupMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarNavGroupMenu, "ngs-sidebar-nav-group-menu", ["ngsSidebarNavGroupMenu"], { "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "itemTypeProperty": { "alias": "itemTypeProperty"; "required": false; "isSignal": true; }; }, {}, ["_items", "_defs"], ["*"], true, never>;
}

declare class SidebarDivider {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarDivider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidebarDivider, "ngs-sidebar-divider", never, {}, {}, never, never, true, never>;
}

declare class SidebarNavItemIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavItemIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarNavItemIconDirective, "[ngsSidebarNavItemIcon]", never, {}, {}, never, never, true, never>;
}

declare class SidebarNavItemBadgeDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavItemBadgeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarNavItemBadgeDirective, "[ngsSidebarNavItemBadge]", never, {}, {}, never, never, true, never>;
}

declare class SidebarNavGroupToggleIconDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarNavGroupToggleIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SidebarNavGroupToggleIconDirective, "[ngsSidebarNavGroupToggleIcon]", never, {}, {}, never, never, true, never>;
}

declare const SIDEBAR_NAVIGATION: InjectionToken<unknown>;
declare const SIDEBAR_NAVIGATION_GROUP: InjectionToken<unknown>;

export { SIDEBAR_NAVIGATION, SIDEBAR_NAVIGATION_GROUP, Sidebar, SidebarBody, SidebarDivider, SidebarFooter, SidebarHeader, SidebarNav, SidebarNavGroup, SidebarNavGroupMenu, SidebarNavGroupToggle, SidebarNavGroupToggleIconDirective, SidebarNavHeading, SidebarNavItem, SidebarNavItemBadgeDirective, SidebarNavItemDefDirective, SidebarNavItemIconDirective, SidebarNavItemInterface };
