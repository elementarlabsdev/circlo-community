import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';

declare class Gauge implements OnInit {
    value: i0.InputSignalWithTransform<number, unknown>;
    strokeWidth: i0.InputSignalWithTransform<number, unknown>;
    radius: i0.InputSignalWithTransform<number, unknown>;
    protected strokeDasharray: string;
    protected initialOffset: number;
    protected strokeDashoffset: number;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Gauge, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Gauge, "ngs-gauge", ["ngsGauge"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "radius": { "alias": "radius"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-gauge-value"], true, never>;
}

declare class GaugeValue {
    static ɵfac: i0.ɵɵFactoryDeclaration<GaugeValue, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GaugeValue, "ngs-gauge-value", ["ngsGaugeValue"], {}, {}, never, ["*"], true, never>;
}

export { Gauge, GaugeValue };
