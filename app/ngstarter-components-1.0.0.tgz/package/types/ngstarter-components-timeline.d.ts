import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';

declare class Timeline {
    static ɵfac: i0.ɵɵFactoryDeclaration<Timeline, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Timeline, "ngs-timeline", ["ngsTimeline"], {}, {}, never, ["*"], true, never>;
}

declare class TimelineHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineHeader, "ngs-timeline-header", ["ngsTimelineHeader"], {}, {}, never, ["*"], true, never>;
}

declare class TimelineItemIndicatorDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineItemIndicatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TimelineItemIndicatorDirective, "[ngsTimelineItemIndicator]", ["ngsTimelineItemIndicator"], {}, {}, never, never, true, never>;
}

declare class TimelineItem {
    readonly indicatorRef: i0.Signal<TimelineItemIndicatorDirective | undefined>;
    get indicatorTemplateRef(): TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineItem, "ngs-timeline-item", ["ngsTimelineItem"], {}, {}, ["indicatorRef"], ["ngs-timeline-timestamp", "ngs-timeline-title", "ngs-timeline-subtitle", "ngs-timeline-description", "ngs-timeline-attributes", "ngs-timeline-content"], true, never>;
}

declare class TimelineAttributes {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineAttributes, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineAttributes, "ngs-timeline-attributes", ["ngsTimelineAttributes"], {}, {}, never, ["*"], true, never>;
}

declare class TimelineDescription {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineDescription, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineDescription, "ngs-timeline-description", ["ngsTimelineDescription"], {}, {}, never, ["*"], true, never>;
}

declare class TimelineTimestamp {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineTimestamp, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineTimestamp, "ngs-timeline-timestamp", ["ngsTimelineTimestamp"], {}, {}, never, ["*"], true, never>;
}

declare class TimelineTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineTitle, "ngs-timeline-title", ["ngsTimelineTitle"], {}, {}, never, ["*"], true, never>;
}

declare class TimelineSubtitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineSubtitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineSubtitle, "ngs-timeline-subtitle", never, {}, {}, never, ["*"], true, never>;
}

declare class TimelineContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimelineContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimelineContent, "ngs-timeline-content", never, {}, {}, never, ["*"], true, never>;
}

export { Timeline, TimelineAttributes, TimelineContent, TimelineDescription, TimelineHeader, TimelineItem, TimelineItemIndicatorDirective, TimelineSubtitle, TimelineTimestamp, TimelineTitle };
