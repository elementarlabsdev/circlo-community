import * as i0 from '@angular/core';
import { InjectionToken, ElementRef } from '@angular/core';

declare class Label {
    static ɵfac: i0.ɵɵFactoryDeclaration<Label, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Label, "ngs-label", never, {}, {}, never, ["*"], true, never>;
}

declare abstract class FormFieldControl<T> {
    abstract value: T | null;
    abstract readonly stateChanges: any;
    abstract readonly id: string;
    abstract readonly placeholder: string | undefined;
    abstract readonly ngControl: any;
    abstract readonly focused: boolean;
    abstract readonly empty: boolean;
    abstract readonly shouldLabelFloat: boolean;
    abstract readonly required: boolean;
    abstract readonly disabled: boolean;
    abstract readonly errorState: boolean;
    abstract focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldControl<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormFieldControl<any>>;
}

declare class Hint {
    align: i0.InputSignal<"start" | "end">;
    static ɵfac: i0.ɵɵFactoryDeclaration<Hint, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Hint, "ngs-hint", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class Error {
    static ɵfac: i0.ɵɵFactoryDeclaration<Error, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Error, "ngs-error", never, {}, {}, never, ["*"], true, never>;
}

declare class Prefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<Prefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<Prefix, "[ngsPrefix]", never, {}, {}, never, never, true, never>;
}
declare class TextPrefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextPrefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextPrefix, "[ngsTextPrefix]", never, {}, {}, never, never, true, never>;
}
declare class IconPrefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconPrefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IconPrefix, "[ngsIconPrefix]", never, {}, {}, never, never, true, never>;
}
declare class IconButtonPrefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconButtonPrefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IconButtonPrefix, "[ngsIconButtonPrefix]", never, {}, {}, never, never, true, never>;
}
declare class Suffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<Suffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<Suffix, "[ngsSuffix]", never, {}, {}, never, never, true, never>;
}
declare class TextSuffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextSuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextSuffix, "[ngsTextSuffix]", never, {}, {}, never, never, true, never>;
}
declare class IconSuffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconSuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IconSuffix, "[ngsIconSuffix]", never, {}, {}, never, never, true, never>;
}
declare class IconButtonSuffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconButtonSuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<IconButtonSuffix, "[ngsIconButtonSuffix]", never, {}, {}, never, never, true, never>;
}

declare const FORM_FIELD: InjectionToken<any>;

declare class FormField {
    subscriptHiddenIfEmpty: i0.InputSignalWithTransform<boolean, unknown>;
    elementRef: ElementRef<any>;
    wrapper: i0.Signal<ElementRef<any>>;
    container: i0.Signal<ElementRef<any>>;
    control: i0.Signal<FormFieldControl<any> | undefined>;
    labelChild: i0.Signal<Label | undefined>;
    prefixChildren: i0.Signal<readonly Prefix[]>;
    iconPrefixChildren: i0.Signal<readonly IconPrefix[]>;
    iconButtonPrefixChildren: i0.Signal<readonly IconButtonPrefix[]>;
    textPrefixChildren: i0.Signal<readonly TextPrefix[]>;
    suffixChildren: i0.Signal<readonly Suffix[]>;
    iconSuffixChildren: i0.Signal<readonly IconSuffix[]>;
    iconButtonSuffixChildren: i0.Signal<readonly IconButtonSuffix[]>;
    textSuffixChildren: i0.Signal<readonly TextSuffix[]>;
    hintChildren: i0.Signal<readonly Hint[]>;
    errorChildren: i0.Signal<readonly Error[]>;
    isRequired: i0.Signal<boolean>;
    shouldLabelFloat(): boolean;
    protected _onClick(event: MouseEvent): void;
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormField, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormField, "ngs-form-field", ["ngsFormField"], { "subscriptHiddenIfEmpty": { "alias": "subscriptHiddenIfEmpty"; "required": false; "isSignal": true; }; }, {}, ["control", "labelChild", "prefixChildren", "iconPrefixChildren", "iconButtonPrefixChildren", "textPrefixChildren", "suffixChildren", "iconSuffixChildren", "iconButtonSuffixChildren", "textSuffixChildren", "hintChildren", "errorChildren"], ["[ngsPrefix]", "[ngsIconPrefix]", "[ngsIconButtonPrefix]", "[ngsTextPrefix]", "ngs-label", "*", "[ngsTextSuffix]", "[ngsIconButtonSuffix]", "[ngsIconSuffix]", "[ngsSuffix]", "ngs-error", "ngs-hint"], true, never>;
}

interface FormFieldDefaultOptions {
    appearance?: 'fill' | 'outline';
    color?: string;
    hideRequiredMarker?: boolean;
    floatLabel?: 'always' | 'auto';
    subscriptHiddenIfEmpty?: boolean;
}
declare const FORM_FIELD_DEFAULT_OPTIONS: InjectionToken<FormFieldDefaultOptions>;

export { Error, FORM_FIELD, FORM_FIELD_DEFAULT_OPTIONS, FormField, FormFieldControl, Hint, IconButtonPrefix, IconButtonSuffix, IconPrefix, IconSuffix, Label, Prefix, Suffix, TextPrefix, TextSuffix };
export type { FormFieldDefaultOptions };
