import * as _angular_core from '@angular/core';
import { TemplateRef, OnInit } from '@angular/core';
import { CdkDragDrop, CdkDragStart, CdkDragMove, CdkDragEnd } from '@angular/cdk/drag-drop';

interface KanbanColumn<T extends KanbanItem> {
    id: any;
    name: string;
    color: string;
    items: T[];
}
interface KanbanItem {
    name: string;
    position: number;
}
interface KanbanItemSortedEvent {
    previousIndex: number;
    currentIndex: number;
}
interface KanbanItemTransferredEvent<T> {
    previousContainerData: T[];
    currentContainerData: T[];
    previousIndex: number;
    currentIndex: number;
}

declare class KanbanItemDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KanbanItemDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<KanbanItemDefDirective, "[ngsKanbanItemDef]", never, {}, {}, never, never, true, never>;
}

declare class KanbanBoard<T extends KanbanColumn<K>, K extends KanbanItem> implements OnInit {
    protected _itemTplDef: _angular_core.Signal<KanbanItemDefDirective>;
    private _headerContainer;
    private _scrollContainer;
    private _renderer;
    private _destroyRef;
    columns: _angular_core.InputSignal<T[]>;
    colors: _angular_core.InputSignal<string[]>;
    protected _hasVerticalScroll: _angular_core.WritableSignal<boolean>;
    readonly columnEdit: _angular_core.OutputEmitterRef<T>;
    readonly columnDelete: _angular_core.OutputEmitterRef<{
        column: T;
        index: number;
    }>;
    readonly itemAdd: _angular_core.OutputEmitterRef<void>;
    readonly itemClick: _angular_core.OutputEmitterRef<K>;
    readonly itemDropped: _angular_core.OutputEmitterRef<CdkDragDrop<K[], K[], any>>;
    readonly itemSorted: _angular_core.OutputEmitterRef<KanbanItemSortedEvent>;
    readonly itemTransferred: _angular_core.OutputEmitterRef<KanbanItemTransferredEvent<K>>;
    private _startContainerXOffset;
    private _itemXOffset;
    private _itemWidth;
    protected isDraggingActive: boolean;
    private _autoScrollStarted;
    ngOnInit(): void;
    onDropped(event: CdkDragDrop<K[]>): void;
    onScroll(event: Event): void;
    onDragStarted(event: CdkDragStart, element: HTMLElement): void;
    onDragMoved(event: CdkDragMove<K>): void;
    onDragEnded(event: CdkDragEnd): void;
    protected itemMousedown(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KanbanBoard<any, any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<KanbanBoard<any, any>, "ngs-kanban-board", ["ngsKanbanBoard"], { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "colors": { "alias": "colors"; "required": false; "isSignal": true; }; }, { "columnEdit": "columnEdit"; "columnDelete": "columnDelete"; "itemAdd": "itemAdd"; "itemClick": "itemClick"; "itemDropped": "itemDropped"; "itemSorted": "itemSorted"; "itemTransferred": "itemTransferred"; }, ["_itemTplDef"], never, true, never>;
}

export { KanbanBoard, KanbanItemDefDirective };
export type { KanbanColumn, KanbanItem, KanbanItemSortedEvent, KanbanItemTransferredEvent };
