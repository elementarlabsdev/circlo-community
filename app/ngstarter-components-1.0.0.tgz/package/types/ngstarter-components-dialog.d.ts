import * as i0 from '@angular/core';
import { InjectionToken, OnInit, EventEmitter, TemplateRef } from '@angular/core';
import { Observable } from 'rxjs';
import { CdkDialogContainer } from '@angular/cdk/dialog';
import { ComponentType } from '@angular/cdk/portal';

declare class DialogConfig<D = any> {
    data?: D | null;
    width?: string;
    height?: string;
    minWidth?: string | number;
    minHeight?: string | number;
    maxWidth?: string | number;
    maxHeight?: string | number;
    hasBackdrop?: boolean;
    backdropClass?: string | string[];
    panelClass?: string | string[];
    disableClose?: boolean;
    autoFocus?: boolean | string;
    restoreFocus?: boolean;
    ariaDescribedBy?: string | null;
    ariaLabelledBy?: string | null;
    ariaLabel?: string | null;
    role?: 'dialog' | 'alertdialog';
    closeOnNavigation?: boolean;
}
declare const DIALOG_DATA: InjectionToken<any>;
declare const DIALOG_DEFAULT_OPTIONS: InjectionToken<DialogConfig<any>>;

declare class DialogContainer extends CdkDialogContainer implements OnInit {
    private readonly _cdr;
    readonly _portalOutlet: any;
    /** State of the dialog animation. */
    _animationState: 'void' | 'enter' | 'exit';
    /** Emits when an animation state changes. */
    _animationStateChanged: EventEmitter<any>;
    ngOnInit(): void;
    private _formatValue;
    _onTransitionEnd(event: TransitionEvent): void;
    /** Starts the dialog enter animation. */
    _startEnterAnimation(): void;
    /** Starts the dialog exit animation. */
    _startExitAnimation(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogContainer, "ngs-dialog-container", never, {}, {}, never, never, true, never>;
}

declare class DialogRef<T, R = any> {
    private readonly _afterClosed;
    private readonly _afterOpened;
    private readonly _backdropClick;
    private readonly _keydownEvents;
    componentInstance: T | null;
    disableClose: boolean | undefined;
    /** @internal */
    _cdkRef: any;
    /** @internal */
    _container: DialogContainer | undefined;
    private _isClosing;
    close(dialogResult?: R): void;
    private _finishClose;
    afterClosed(): Observable<R | undefined>;
    afterOpened(): Observable<void>;
    backdropClick(): Observable<MouseEvent>;
    keydownEvents(): Observable<KeyboardEvent>;
    __fireAfterOpened(): void;
    __fireBackdropClick(event: MouseEvent): void;
    __fireKeydownEvent(event: KeyboardEvent): void;
}

declare class Dialog {
    private readonly _cdkDialog;
    private readonly _injector;
    private readonly _defaultOptions;
    open<T, D = any, R = any>(componentOrTemplateRef: ComponentType<T> | TemplateRef<T>, config?: DialogConfig<D>): DialogRef<T, R>;
    close<T, R>(dialogRef: DialogRef<T, R>, result?: R): void;
    closeAll(): void;
    private _buildPanelClass;
    private _buildBackdropClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<Dialog, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Dialog>;
}

declare class DialogTitle implements OnInit {
    private _dialogRef;
    id: i0.InputSignal<string>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogTitle, "ngs-dialog-title, [ngs-dialog-title], [ngsDialogTitle]", ["ngsDialogTitle"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class DialogContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogContent, "ngs-dialog-content,[ngs-dialog-content],[ngsDialogContent]", never, {}, {}, never, ["*"], true, never>;
}

declare class DialogActions {
    align: i0.InputSignal<"start" | "center" | "end">;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogActions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogActions, "ngs-dialog-actions, [ngs-dialog-actions], [ngsDialogActions]", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class DialogClose {
    dialogResult: i0.InputSignal<any>;
    _dialogResult: i0.InputSignal<any>;
    ariaLabel: i0.InputSignal<string | null>;
    type: i0.InputSignal<"submit" | "button" | "reset">;
    private _dialogRef;
    private _dialog;
    protected _onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogClose, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DialogClose, "[ngs-dialog-close], [ngsDialogClose]", ["ngsDialogClose"], { "dialogResult": { "alias": "ngs-dialog-close"; "required": false; "isSignal": true; }; "_dialogResult": { "alias": "ngsDialogClose"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { DIALOG_DATA, DIALOG_DEFAULT_OPTIONS, Dialog, DialogActions, DialogClose, DialogConfig, DialogContainer, DialogContent, DialogRef, DialogTitle };
