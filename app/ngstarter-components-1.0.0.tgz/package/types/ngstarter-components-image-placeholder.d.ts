import * as i0 from '@angular/core';

declare class ImagePlaceholder {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImagePlaceholder, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImagePlaceholder, "ngs-image-placeholder", ["ngsImagePlaceholder"], {}, {}, never, never, true, never>;
}

export { ImagePlaceholder };
