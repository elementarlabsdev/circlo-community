import * as _angular_core from '@angular/core';
import { AfterViewInit, OnDestroy } from '@angular/core';

type ProgressBarMode = 'determinate' | 'indeterminate' | 'buffer' | 'query';
declare class ProgressBar implements AfterViewInit, OnDestroy {
    private readonly _elementRef;
    private readonly _ngZone;
    private readonly _renderer;
    readonly color: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly bufferValue: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly mode: _angular_core.InputSignal<ProgressBarMode>;
    readonly animationEnd: _angular_core.OutputEmitterRef<{
        value: number;
    }>;
    private _cleanupTransitionEnd?;
    readonly isIndeterminate: _angular_core.Signal<boolean>;
    readonly primaryBarTransform: _angular_core.Signal<string>;
    readonly bufferBarTransform: _angular_core.Signal<string>;
    /** @deprecated use bufferBarTransform instead */
    readonly bufferBarFlexBasis: _angular_core.Signal<string>;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private _transitionendHandler;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressBar, "ngs-progress-bar", ["ngsProgressBar"], { "color": { "alias": "color"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "bufferValue": { "alias": "bufferValue"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; }, { "animationEnd": "animationEnd"; }, never, never, true, never>;
}

export { ProgressBar };
export type { ProgressBarMode };
