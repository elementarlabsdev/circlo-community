import * as i0 from '@angular/core';
import { AfterContentInit, OnChanges, OnDestroy, TemplateRef, SimpleChanges } from '@angular/core';

declare class Marquee implements AfterContentInit, OnChanges, OnDestroy {
    private _elementRef;
    private _platformId;
    private _intersectionObserver?;
    reverse: i0.InputSignalWithTransform<boolean, unknown>;
    pauseOnHover: i0.InputSignalWithTransform<boolean, unknown>;
    protected isInView: boolean;
    readonly template: i0.Signal<TemplateRef<any>>;
    protected get nativeElement(): HTMLElement;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Marquee, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Marquee, "ngs-marquee", ["ngsMarquee"], { "reverse": { "alias": "reverse"; "required": false; "isSignal": true; }; "pauseOnHover": { "alias": "pauseOnHover"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class MarqueeItemDirective {
    private _elementRef;
    get nativeElement(): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarqueeItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MarqueeItemDirective, "[ngsMarqueeItem]", never, {}, {}, never, never, true, never>;
}

export { Marquee, MarqueeItemDirective };
