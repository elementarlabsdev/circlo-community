import * as _angular_core from '@angular/core';
import { InjectionToken, TemplateRef, Provider, OnDestroy, ViewContainerRef, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import * as _angular_platform_browser from '@angular/platform-browser';
import * as _ngstarter_components_guided_tour from '@ngstarter/components/guided-tour';
import { ConnectedPosition } from '@angular/cdk/overlay';

interface TourConfig {
    /**
     * Default padding for the highlighted element.
     * @default 4
     */
    padding?: number;
    /**
     * Whether to close the tour when clicking on the backdrop.
     * @default false
     */
    closeOnBackdropClick?: boolean;
    /**
     * Whether to enable keyboard navigation (arrows and Esc).
     * @default true
     */
    keyboardNavigation?: boolean;
    /**
     * Default text for the "Next" button.
     */
    nextBtnText?: string;
    /**
     * Default text for the "Prev" button.
     */
    prevBtnText?: string;
    /**
     * Default text for the "Finish" button.
     */
    finishBtnText?: string;
    /**
     * Default text for the "Skip" button.
     */
    skipBtnText?: string;
}
declare const TOUR_CONFIG: InjectionToken<TourConfig>;
declare function provideTourConfig(config: TourConfig): Provider;
type TourStepPosition = 'below-start' | 'below-center' | 'below-end' | 'above-start' | 'above-center' | 'above-end' | 'before-start' | 'before-center' | 'before-end' | 'after-start' | 'after-center' | 'after-end';
interface TourStepConfig {
    /**
     * Unique identifier for the tour step anchor or a function that returns an element or selector.
     */
    anchorId: string | (() => HTMLElement | string);
    /**
     * Title of the tour step.
     */
    title?: string;
    /**
     * Content of the tour step.
     */
    content?: string;
    /**
     * HTML content of the tour step.
     */
    htmlContent?: string;
    /**
     * Template for the tour step.
     */
    template?: TemplateRef<any>;
    /**
     * Context for the template.
     */
    templateContext?: any;
    /**
     * Custom data for the tour step.
     */
    data?: any;
    /**
     * Whether to show a backdrop and highlight the anchor element.
     */
    withBackdrop?: boolean;
    /**
     * Whether to disable interaction with the highlighted element.
     */
    disableInteraction?: boolean;
    /**
     * Padding for the highlighted element.
     * If not provided, the default from TourConfig will be used.
     */
    padding?: number;
    /**
     * Route to navigate to before showing the step.
     */
    route?: string;
    /**
     * CSS selector to wait for before showing the step.
     */
    waitFor?: string;
    /**
     * Callback before showing the step.
     */
    onShow?: () => void | Promise<void>;
    /**
     * Callback before hiding the step.
     */
    onHide?: () => void | Promise<void>;
    /**
     * Callback when "Next" is clicked.
     */
    onNext?: () => void | Promise<void>;
    /**
     * Callback when "Prev" is clicked.
     */
    onPrev?: () => void | Promise<void>;
    /**
     * Whether to hide the arrow pointing to the anchor.
     */
    hideArrow?: boolean;
    /**
     * Whether to close the tour when clicking on the backdrop.
     * If not provided, the default from TourConfig will be used.
     */
    closeOnBackdropClick?: boolean;
    /**
     * Text for the "Next" button.
     */
    nextBtnText?: string;
    /**
     * Text for the "Prev" button.
     */
    prevBtnText?: string;
    /**
     * Text for the "Finish" button.
     */
    finishBtnText?: string;
    /**
     * Text for the "Skip" button.
     */
    skipBtnText?: string;
    /**
     * Explicit position for the tour step.
     * If not provided, the best position will be chosen automatically.
     */
    position?: TourStepPosition;
}
declare enum TourState {
    OFF = 0,
    ON = 1,
    PAUSED = 2
}
declare const TOUR_STEP_COMPONENT: InjectionToken<any>;

declare class TourService implements OnDestroy {
    private readonly overlay;
    private readonly config;
    private readonly document;
    private readonly router;
    private backdropOverlayRef;
    private backdropComponentRef;
    private readonly _steps;
    private readonly _currentStepIndex;
    private readonly _state;
    private readonly _anchors;
    private stepOverlayRef;
    private stepComponentRef;
    private readonly customStepComponent;
    constructor();
    ngOnDestroy(): void;
    private readonly handleKeyDown;
    readonly steps: _angular_core.Signal<TourStepConfig[]>;
    readonly currentStepIndex: _angular_core.Signal<number>;
    readonly state: _angular_core.Signal<TourState>;
    readonly currentStep: _angular_core.Signal<TourStepConfig | null>;
    readonly stepShow$: Subject<TourStepConfig>;
    readonly stepHide$: Subject<TourStepConfig>;
    readonly start$: Subject<void>;
    readonly end$: Subject<void>;
    registerAnchor(id: string, anchor: any): void;
    unregisterAnchor(id: string): void;
    start(steps: TourStepConfig[]): void;
    end(): Promise<void>;
    next(): Promise<void>;
    prev(): Promise<void>;
    goToStep(index: number): Promise<void>;
    private waitForElement;
    showBackdrop(rect: DOMRect, borderRadius: string, viewContainerRef?: ViewContainerRef, anchorElement?: HTMLElement, padding?: number, disableInteraction?: boolean): void;
    hideBackdrop(animate: boolean): Promise<void>;
    private _showStep;
    private showStepForElement;
    private _getOffset;
    private _hideStep;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TourService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TourService>;
}

declare class TourAnchorDirective implements OnInit, OnDestroy {
    anchorId: _angular_core.InputSignal<string>;
    private readonly elementRef;
    private readonly tourService;
    private readonly overlay;
    private readonly viewContainerRef;
    private readonly customStepComponent;
    private readonly config;
    private overlayRef;
    private componentRef;
    ngOnInit(): void;
    ngOnDestroy(): void;
    showStep(step: TourStepConfig): void;
    hideStep(): Promise<void>;
    private _getOffset;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TourAnchorDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TourAnchorDirective, "[ngsTourAnchor]", never, { "anchorId": { "alias": "ngsTourAnchor"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TourStep {
    readonly tourService: TourService;
    private _sanitizer;
    step: _angular_core.InputSignal<TourStepConfig>;
    isFirst: _angular_core.InputSignal<boolean>;
    isLast: _angular_core.InputSignal<boolean>;
    position: _angular_core.InputSignal<ConnectedPosition | null>;
    animateEnterClass: _angular_core.InputSignal<boolean>;
    animateLeaveClass: _angular_core.InputSignal<boolean>;
    readonly config: _ngstarter_components_guided_tour.TourConfig | null;
    protected readonly htmlContent: _angular_core.Signal<_angular_platform_browser.SafeHtml | null>;
    getArrowClasses(pos: ConnectedPosition | null): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TourStep, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TourStep, "ngs-tour-step", never, { "step": { "alias": "step"; "required": true; "isSignal": true; }; "isFirst": { "alias": "isFirst"; "required": false; "isSignal": true; }; "isLast": { "alias": "isLast"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "animateEnterClass": { "alias": "animateEnterClass"; "required": false; "isSignal": true; }; "animateLeaveClass": { "alias": "animateLeaveClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { TOUR_CONFIG, TOUR_STEP_COMPONENT, TourAnchorDirective, TourService, TourState, TourStep, provideTourConfig };
export type { TourConfig, TourStepConfig, TourStepPosition };
