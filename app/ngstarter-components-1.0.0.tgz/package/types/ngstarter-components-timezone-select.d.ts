import * as _angular_core from '@angular/core';
import { OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { FormFieldControl } from '@ngstarter/components/form-field';
import { Subject } from 'rxjs';

interface LocalizedTimezone {
    id: string;
    name: string;
    shortName?: string;
    offsetName?: string;
}
interface TimezoneGroup {
    name: string;
    timezones: LocalizedTimezone[];
}

declare class TimezoneSelect implements OnInit, FormFieldControl<any>, ControlValueAccessor {
    protected localeId: string;
    protected renderer: Renderer2;
    private readonly _focusMonitor;
    private readonly _elementRef;
    private readonly _formField;
    ngControl: NgControl | null;
    private searchInput;
    private selectRef;
    protected timezoneGroups: _angular_core.WritableSignal<TimezoneGroup[]>;
    readonly touched: _angular_core.WritableSignal<boolean>;
    readonly stateChanges: Subject<void>;
    readonly controlType = "ngs-timezone-select";
    readonly id: string;
    readonly _userAriaDescribedBy: _angular_core.InputSignal<string>;
    readonly locale: _angular_core.InputSignal<string>;
    readonly _placeholder: _angular_core.InputSignal<string>;
    readonly _required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly _disabledByInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly _value: _angular_core.ModelSignal<string | null>;
    protected searchTerm: _angular_core.ModelSignal<string>;
    private readonly _focused;
    private readonly _disabledByCva;
    private readonly _disabled;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    onChange: (_: any) => void;
    onTouched: () => void;
    get focused(): boolean;
    get empty(): boolean;
    get shouldLabelFloat(): boolean;
    get userAriaDescribedBy(): string;
    get placeholder(): string;
    get required(): boolean;
    get disabled(): boolean;
    get value(): string | null;
    get errorState(): boolean;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    onFocusIn(): void;
    onFocusOut(event: any): void;
    onContainerClick(event: MouseEvent): void;
    setDescribedByIds(ids: string[]): void;
    writeValue(timezone: string | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    protected onSelectOpened(): void;
    clearSearch(event: MouseEvent): void;
    protected onSelectClosed(): void;
    private _updateValue;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimezoneSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimezoneSelect, "ngs-timezone-select", ["ngsTimezoneSelect"], { "_userAriaDescribedBy": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "_placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "_required": { "alias": "required"; "required": false; "isSignal": true; }; "_disabledByInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "_value": { "alias": "value"; "required": false; "isSignal": true; }; "searchTerm": { "alias": "searchTerm"; "required": false; "isSignal": true; }; }, { "_value": "valueChange"; "searchTerm": "searchTermChange"; "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

export { TimezoneSelect };
