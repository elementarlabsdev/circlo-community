import * as _angular_core from '@angular/core';

declare class ActionRequired {
    actionText: _angular_core.InputSignal<string | undefined>;
    iconName: _angular_core.InputSignal<string | undefined>;
    description: _angular_core.InputSignal<string>;
    buttonText: _angular_core.InputSignal<string>;
    readonly buttonClicked: _angular_core.OutputEmitterRef<void>;
    protected getIconName(iconName: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ActionRequired, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ActionRequired, "ngs-action-required", ["ngsActionRequired"], { "actionText": { "alias": "actionText"; "required": false; "isSignal": true; }; "iconName": { "alias": "iconName"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": true; "isSignal": true; }; "buttonText": { "alias": "buttonText"; "required": true; "isSignal": true; }; }, { "buttonClicked": "buttonClicked"; }, never, never, true, never>;
}

export { ActionRequired };
