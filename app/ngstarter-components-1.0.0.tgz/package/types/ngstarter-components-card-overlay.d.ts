import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';

declare class CardOverlay {
    withTranslate: i0.InputSignalWithTransform<boolean, unknown>;
    withBlur: i0.InputSignalWithTransform<boolean, unknown>;
    disabled: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardOverlay, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardOverlay, "ngs-card-overlay", ["ngsCardOverlay"], { "withTranslate": { "alias": "withTranslate"; "required": false; "isSignal": true; }; "withBlur": { "alias": "withBlur"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class CardOverlayContainerDirective implements OnInit {
    private _elementRef;
    private _renderer;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardOverlayContainerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardOverlayContainerDirective, "[ngsCardOverlayContainer]", ["ngsCardOverlayContainer"], {}, {}, never, never, true, never>;
}

export { CardOverlay, CardOverlayContainerDirective };
