import * as _angular_core from '@angular/core';
import { OnInit, OnChanges, AfterContentChecked, SimpleChanges } from '@angular/core';
import { AbstractControl, ControlValueAccessor, UntypedFormControl, ValidatorFn } from '@angular/forms';

declare enum Criteria {
    at_least_eight_chars = "minChar",
    at_least_one_lower_case_char = "lowerCase",
    at_least_one_upper_case_char = "upperCase",
    at_least_one_digit_char = "digit",
    at_least_one_special_char = " specialChar",
    at_custom_chars = "customChars"
}

declare class PasswordStrengthValidator {
    isUndefinedOrEmpty(control: AbstractControl): any | undefined;
    validate(criteria: string, regex: RegExp): (control: AbstractControl) => ({
        [p: string]: any;
    } | undefined);
    confirm(password: string): (control: AbstractControl) => ({
        [p: string]: any;
    } | undefined);
}

declare class PasswordStrength implements OnInit, OnChanges, AfterContentChecked, ControlValueAccessor {
    password: _angular_core.InputSignal<any>;
    externalError: _angular_core.InputSignalWithTransform<boolean, unknown>;
    enableLengthRule: _angular_core.InputSignalWithTransform<boolean, unknown>;
    enableLowerCaseLetterRule: _angular_core.InputSignalWithTransform<boolean, unknown>;
    enableUpperCaseLetterRule: _angular_core.InputSignalWithTransform<boolean, unknown>;
    enableDigitRule: _angular_core.InputSignalWithTransform<boolean, unknown>;
    enableSpecialCharRule: _angular_core.InputSignalWithTransform<boolean, unknown>;
    min: _angular_core.InputSignalWithTransform<number, unknown>;
    max: _angular_core.InputSignalWithTransform<number, unknown>;
    customValidator: _angular_core.InputSignal<any>;
    warnThreshold: _angular_core.InputSignalWithTransform<number, unknown>;
    accentThreshold: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly strengthChanged: _angular_core.OutputEmitterRef<number>;
    criteriaMap: Map<Criteria, RegExp>;
    containAtLeastMinChars: boolean;
    containAtLeastOneLowerCaseLetter: boolean;
    containAtLeastOneUpperCaseLetter: boolean;
    containAtLeastOneDigit: boolean;
    containAtLeastOneSpecialChar: boolean;
    containAtCustomChars: boolean;
    passwordFormControl: UntypedFormControl;
    passwordConfirmationFormControl: UntypedFormControl;
    validatorsArray: ValidatorFn[];
    Validators: ValidatorFn | null;
    passwordStrengthValidator: PasswordStrengthValidator;
    private _strength;
    get strength(): number;
    get isLow(): boolean;
    get isWeak(): boolean;
    get isMedium(): boolean;
    get isStrong(): boolean;
    get isVeryStrong(): boolean;
    propagateChange: (_: any) => void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setRulesAndValidators(): void;
    calculatePasswordStrength(): void;
    reset(): void;
    writeValue(obj: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    private _containAtLeastMinChars;
    private _containAtLeastOneLowerCaseLetter;
    private _containAtLeastOneUpperCaseLetter;
    private _containAtLeastOneDigit;
    private _containAtLeastOneSpecialChar;
    private _containCustomChars;
    ngAfterContentChecked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordStrength, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PasswordStrength, "ngs-password-strength", ["ngsPasswordStrength"], { "password": { "alias": "password"; "required": true; "isSignal": true; }; "externalError": { "alias": "externalError"; "required": false; "isSignal": true; }; "enableLengthRule": { "alias": "enableLengthRule"; "required": false; "isSignal": true; }; "enableLowerCaseLetterRule": { "alias": "enableLowerCaseLetterRule"; "required": false; "isSignal": true; }; "enableUpperCaseLetterRule": { "alias": "enableUpperCaseLetterRule"; "required": false; "isSignal": true; }; "enableDigitRule": { "alias": "enableDigitRule"; "required": false; "isSignal": true; }; "enableSpecialCharRule": { "alias": "enableSpecialCharRule"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "customValidator": { "alias": "customValidator"; "required": false; "isSignal": true; }; "warnThreshold": { "alias": "warnThreshold"; "required": false; "isSignal": true; }; "accentThreshold": { "alias": "accentThreshold"; "required": false; "isSignal": true; }; }, { "strengthChanged": "strengthChanged"; }, never, never, true, never>;
}

declare class PassToggleVisibility {
    visible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    tabindex: _angular_core.InputSignal<string>;
    protected _visible: boolean;
    get type(): "password" | "text";
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PassToggleVisibility, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PassToggleVisibility, "ngs-pass-toggle-visibility", ["ngsPassToggleVisibility"], { "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class PasswordStrengthInfo {
    passwordComponent: _angular_core.InputSignal<PasswordStrength>;
    enableScoreInfo: _angular_core.InputSignalWithTransform<boolean, unknown>;
    lowerCaseCriteriaMessage: _angular_core.InputSignal<string>;
    upperCaseCriteriaMessage: _angular_core.InputSignal<string>;
    digitsCriteriaMessage: _angular_core.InputSignal<string>;
    specialCharsCriteriaMessage: _angular_core.InputSignal<string>;
    customCharsCriteriaMessage: _angular_core.InputSignal<string>;
    minCharsCriteriaMessage: _angular_core.InputSignal<string>;
    ngsIconDone: _angular_core.InputSignal<string>;
    ngsIconError: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordStrengthInfo, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PasswordStrengthInfo, "ngs-password-strength-info", ["ngsPasswordStrengthInfo"], { "passwordComponent": { "alias": "passwordComponent"; "required": true; "isSignal": true; }; "enableScoreInfo": { "alias": "enableScoreInfo"; "required": false; "isSignal": true; }; "lowerCaseCriteriaMessage": { "alias": "lowerCaseCriteriaMessage"; "required": false; "isSignal": true; }; "upperCaseCriteriaMessage": { "alias": "upperCaseCriteriaMessage"; "required": false; "isSignal": true; }; "digitsCriteriaMessage": { "alias": "digitsCriteriaMessage"; "required": false; "isSignal": true; }; "specialCharsCriteriaMessage": { "alias": "specialCharsCriteriaMessage"; "required": false; "isSignal": true; }; "customCharsCriteriaMessage": { "alias": "customCharsCriteriaMessage"; "required": false; "isSignal": true; }; "minCharsCriteriaMessage": { "alias": "minCharsCriteriaMessage"; "required": false; "isSignal": true; }; "ngsIconDone": { "alias": "ngsIconDone"; "required": false; "isSignal": true; }; "ngsIconError": { "alias": "ngsIconError"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const RegExpValidator: {
    lowerCase: RegExp;
    upperCase: RegExp;
    digit: RegExp;
    specialChar: RegExp;
};

export { PassToggleVisibility, PasswordStrength, PasswordStrengthInfo, PasswordStrengthValidator, RegExpValidator };
