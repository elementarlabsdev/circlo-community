import * as _angular_core from '@angular/core';
import { OnInit, OnChanges, SimpleChanges, OnDestroy, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { BooleanInput } from '@angular/cdk/coercion';
import { TinyColor } from '@ctrl/tinycolor';

type ColorPickerPosition = 'below-start' | 'below-center' | 'below-end' | 'above-start' | 'above-center' | 'above-end' | 'before-start' | 'before-center' | 'before-end' | 'after-start' | 'after-center' | 'after-end' | string;
type ColorPickerResultFormat = 'hex' | 'rgb' | 'hsl' | 'hsv';

declare class ColorPicker implements OnInit, OnChanges, ControlValueAccessor {
    private cdr;
    color: _angular_core.InputSignal<string>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    asDropdown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showOpacity: _angular_core.InputSignalWithTransform<boolean, unknown>;
    resultFormat: _angular_core.InputSignal<ColorPickerResultFormat>;
    readonly colorChange: _angular_core.OutputEmitterRef<string>;
    readonly rawColorChange: _angular_core.OutputEmitterRef<TinyColor>;
    private tmpColor;
    protected hexColor: string;
    protected _color: _angular_core.WritableSignal<TinyColor>;
    protected _colorFromHue: _angular_core.WritableSignal<TinyColor | null | undefined>;
    protected _disabled: _angular_core.WritableSignal<boolean>;
    protected alpha: _angular_core.WritableSignal<number>;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onChange: any;
    onTouched: any;
    writeValue(color: string): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: BooleanInput): void;
    protected copyToClipboard(event: MouseEvent, hexInput: HTMLInputElement): Promise<void>;
    protected onSaturationColorChange(tinyColor: TinyColor): void;
    protected _handleContextMenu(event: Event): void;
    protected onAlphaChange(alpha: number): void;
    protected onHueColorChange(color: TinyColor): void;
    protected onHexColorChange(color: string): void;
    protected onHexColorBlur(): void;
    protected _setHexColor(tinyColor: TinyColor): void;
    private _setColor;
    private emitEvent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColorPicker, "ngs-color-picker", ["ngsColorPicker"], { "color": { "alias": "color"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "asDropdown": { "alias": "asDropdown"; "required": false; "isSignal": true; }; "showOpacity": { "alias": "showOpacity"; "required": false; "isSignal": true; }; "resultFormat": { "alias": "resultFormat"; "required": false; "isSignal": true; }; }, { "colorChange": "colorChange"; "rawColorChange": "rawColorChange"; }, never, never, true, never>;
}

declare class ColorPickerThumbnail {
    private _elementRef;
    color: _angular_core.InputSignal<string>;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPickerThumbnail, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColorPickerThumbnail, "ngs-color-picker-thumbnail,[ngs-color-picker-thumbnail]", ["ngsColorPickerThumbnail"], { "color": { "alias": "color"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class ColorPickerTriggerForDirective implements OnDestroy {
    private _overlay;
    private _elementRef;
    private _directionality;
    private _viewContainerRef;
    private _injector;
    private _destroyRef;
    colorPickerTemplateRef: _angular_core.InputSignal<TemplateRef<any>>;
    position: _angular_core.InputSignal<string>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    private _portal;
    private _overlayRef;
    private _destroy$;
    constructor();
    ngOnDestroy(): void;
    get api(): {
        isOpen: () => boolean;
        open: () => void;
        close: () => void;
    };
    protected _handleClick(event: MouseEvent): void;
    private _isOpen;
    private _open;
    private _close;
    private _destroyOverlay;
    private _subscribeToOutsideClicks;
    private _getPopoverContentPortal;
    private _getOverlayConfig;
    private _getOverlayPositionStrategy;
    private _getOverlayPositions;
    private _setType;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPickerTriggerForDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ColorPickerTriggerForDirective, "[ngsColorPickerTriggerFor]", ["ngsColorPickerTriggerFor"], { "colorPickerTemplateRef": { "alias": "ngsColorPickerTriggerFor"; "required": true; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

export { ColorPicker, ColorPickerThumbnail, ColorPickerTriggerForDirective };
export type { ColorPickerPosition, ColorPickerResultFormat };
