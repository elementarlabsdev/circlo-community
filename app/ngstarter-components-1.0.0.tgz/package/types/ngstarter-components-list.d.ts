import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';
import * as i1 from '@ngstarter/components/core';
import { SelectionModel } from '@angular/cdk/collections';

declare class List {
    disabled: i0.InputSignalWithTransform<boolean, unknown>;
    disableRipple: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<List, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<List, "ngs-list", ["ngsList"], { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ActionList extends List {
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionList, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionList, "ngs-action-list", ["ngsActionList"], {}, {}, never, ["*"], true, never>;
}

declare class NavList extends List {
    static ɵfac: i0.ɵɵFactoryDeclaration<NavList, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavList, "ngs-nav-list", ["ngsNavList"], {}, {}, never, ["*"], true, never>;
}

declare class ListItemAvatar {
    private readonly _elementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListItemAvatar, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ListItemAvatar, "[ngsListItemAvatar]", never, {}, {}, never, never, true, never>;
}

declare class ListItemIcon {
    private readonly _elementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListItemIcon, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ListItemIcon, "[ngsListItemIcon]", never, {}, {}, never, never, true, never>;
}

declare class ListItemTitle {
    private readonly _elementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListItemTitle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ListItemTitle, "[ngsListItemTitle]", never, {}, {}, never, never, true, never>;
}

declare class ListItemLine {
    private readonly _elementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListItemLine, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ListItemLine, "[ngsListItemLine], [ngsLine]", never, {}, {}, never, never, true, never>;
}

declare class ListItemMeta {
    private readonly _elementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListItemMeta, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ListItemMeta, "[ngsListItemMeta]", never, {}, {}, never, never, true, never>;
}

declare class ListItem {
    private _list;
    disabled: i0.InputSignalWithTransform<boolean, unknown>;
    lines: i0.InputSignalWithTransform<number | null, any>;
    readonly _avatars: i0.Signal<readonly ListItemAvatar[]>;
    readonly _icons: i0.Signal<readonly ListItemIcon[]>;
    readonly _titles: i0.Signal<readonly ListItemTitle[]>;
    readonly _lines: i0.Signal<readonly ListItemLine[]>;
    readonly _meta: i0.Signal<readonly ListItemMeta[]>;
    get disableRipple(): boolean | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListItem, "ngs-list-item, a[ngs-list-item], button[ngs-list-item]", ["ngsListItem"], { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "lines": { "alias": "lines"; "required": false; "isSignal": true; }; }, {}, ["_avatars", "_icons", "_titles", "_lines", "_meta"], ["[ngsListItemAvatar],[ngsListItemIcon]", "[ngsListItemTitle]", "[ngsListItemLine],[ngsLine]", "*", "[ngsListItemMeta]"], true, [{ directive: typeof i1.Ripple; inputs: { "ngsRippleDisabled": "disableRipple"; }; outputs: {}; }]>;
}

declare class SelectionList extends List implements OnInit {
    multiple: i0.InputSignalWithTransform<boolean, unknown>;
    readonly selectionChange: i0.OutputEmitterRef<any>;
    readonly options: i0.Signal<readonly any[]>;
    selectedOptions: SelectionModel<ListOption>;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectionList, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectionList, "ngs-selection-list", ["ngsSelectionList"], { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; }, ["options"], ["*"], true, never>;
}

declare class ListOption extends ListItem {
    protected _selectionList: SelectionList;
    private _changeDetectorRef;
    readonly _avatars: i0.Signal<readonly ListItemAvatar[]>;
    readonly _icons: i0.Signal<readonly ListItemIcon[]>;
    readonly _meta: i0.Signal<readonly ListItemMeta[]>;
    selected: i0.ModelSignal<boolean>;
    value: i0.InputSignal<any>;
    readonly selectedChange: i0.OutputEmitterRef<boolean>;
    _toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListOption, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListOption, "ngs-list-option", ["ngsListOption"], { "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "selected": "selectedChange"; "selectedChange": "selectedChange"; }, ["_avatars", "_icons", "_meta"], ["[ngsListItemAvatar],[ngsListItemIcon]", "[ngsListItemTitle]", "[ngsListItemLine],[ngsLine]", "*", "[ngsListItemMeta]"], true, never>;
}

declare class Subheader {
    private readonly _elementRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<Subheader, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<Subheader, "[ngsSubheader]", never, {}, {}, never, never, true, never>;
}

export { ActionList, List, ListItem, ListItemAvatar, ListItemIcon, ListItemLine, ListItemMeta, ListItemTitle, ListOption, NavList, SelectionList, Subheader };
