import * as _angular_core from '@angular/core';
import { AfterViewInit, AfterContentChecked, OnDestroy } from '@angular/core';

declare class InlineTextEdit implements AfterViewInit, AfterContentChecked, OnDestroy {
    private platformId;
    private document;
    enabled: _angular_core.InputSignal<boolean>;
    placeholder: _angular_core.InputSignal<string>;
    delay: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly contentChanged: _angular_core.OutputEmitterRef<string>;
    isEditing: _angular_core.WritableSignal<boolean>;
    isFocused: _angular_core.WritableSignal<boolean>;
    private previousValue;
    private minHeightSet;
    private elementRef;
    private renderer;
    private emitTimeoutId;
    constructor();
    ngAfterViewInit(): void;
    get isContentEditable(): boolean;
    ngAfterContentChecked(): void;
    ngOnDestroy(): void;
    private setInitialMinHeight;
    onFocus(): void;
    onBlur(): void;
    onEnter(event: Event): void;
    onEscape(): void;
    onPaste(event: ClipboardEvent): void;
    onInput(): void;
    private finishEdit;
    private cancelEdit;
    private placeCaretAtEnd;
    private emitWithDelay;
    private clearPendingEmission;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InlineTextEdit, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InlineTextEdit, "ngs-inline-text-edit,[ngs-inline-text-edit]", never, { "enabled": { "alias": "enabled"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "delay": { "alias": "delay"; "required": false; "isSignal": true; }; }, { "contentChanged": "contentChanged"; }, never, ["*"], true, never>;
}

export { InlineTextEdit };
