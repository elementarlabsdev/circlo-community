import * as _angular_core from '@angular/core';
import { OnChanges, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { BooleanInput } from '@angular/cdk/coercion';

declare class ColorSwitcher implements ControlValueAccessor, OnChanges {
    private _cdr;
    protected _disabled: boolean;
    protected _selectedColor: string;
    colors: _angular_core.InputSignal<string[]>;
    selectedColor: _angular_core.InputSignal<string | undefined>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly colorChange: _angular_core.OutputEmitterRef<string>;
    _onChange: any;
    _onTouched: any;
    ngOnChanges(changes: SimpleChanges): void;
    selectColor(color: string): void;
    writeValue(_selectedColor: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: BooleanInput): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorSwitcher, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColorSwitcher, "ngs-color-switcher", ["ngsColorSwitcher"], { "colors": { "alias": "colors"; "required": false; "isSignal": true; }; "selectedColor": { "alias": "selectedColor"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "colorChange": "colorChange"; }, never, never, true, never>;
}

export { ColorSwitcher };
