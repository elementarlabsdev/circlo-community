import * as _angular_core from '@angular/core';
import * as _ngrx_signals from '@ngrx/signals';

type AnnouncementVariant = 'neutral' | 'negative' | 'warning' | 'positive' | 'informative' | string;
interface AnnouncementData {
    title?: string;
    iconName?: string;
    variant: AnnouncementVariant;
    message: string;
    linkTo?: AnnouncementLinkTo;
}
interface AnnouncementLinkTo {
    url: string;
    text?: string;
    target?: string;
}

declare class Announcement {
    private _elementRef;
    private _renderer;
    title: _angular_core.InputSignal<string>;
    variant: _angular_core.InputSignal<string>;
    iconName: _angular_core.InputSignal<string>;
    closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    linkTo: _angular_core.InputSignal<AnnouncementLinkTo | null | undefined>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    constructor();
    protected close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Announcement, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Announcement, "ngs-announcement", ["ngsAnnouncement"], { "title": { "alias": "title"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "iconName": { "alias": "iconName"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "linkTo": { "alias": "linkTo"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, ["*"], true, never>;
}

declare class AnnouncementGlobal {
    private _announcementStore;
    announcement: _angular_core.Signal<AnnouncementData>;
    readonly announcementClose: _angular_core.OutputEmitterRef<void>;
    onClose(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AnnouncementGlobal, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AnnouncementGlobal, "ngs-announcement-global", ["ngsAnnouncementGlobal"], {}, { "announcementClose": "announcementClose"; }, never, never, true, never>;
}

declare class AnnouncementTitle {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AnnouncementTitle, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AnnouncementTitle, "[ngsAnnouncementTitle]", never, {}, {}, never, never, true, never>;
}

interface AnnouncementState {
    announcement: AnnouncementData | null;
}
declare const AnnouncementStore: _angular_core.Type<{
    announcement: _angular_core.Signal<AnnouncementData | null>;
    show: (announcement: AnnouncementData) => void;
    hide: () => void;
} & _ngrx_signals.StateSource<{
    announcement: AnnouncementData | null;
}>>;

export { Announcement, AnnouncementGlobal, AnnouncementStore, AnnouncementTitle };
export type { AnnouncementData, AnnouncementLinkTo, AnnouncementState, AnnouncementVariant };
