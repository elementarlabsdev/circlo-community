import * as _angular_core from '@angular/core';

interface ThumbnailMakerApi {
    getDataUrl: () => string;
    toBlob: (callback: BlobCallback) => void;
    getCanvas: () => HTMLCanvasElement;
    increase: () => void;
    decrease: () => void;
}

declare class ThumbnailMaker {
    private _content;
    private _dragImage;
    private _thumbnailSize;
    src: _angular_core.InputSignal<string>;
    helperText: _angular_core.InputSignal<string>;
    get api(): ThumbnailMakerApi;
    protected scale: number;
    protected min: number;
    protected max: number;
    protected loading: boolean;
    protected alreadyDragged: boolean;
    protected get isEqualsToMinScale(): boolean;
    protected get isEqualsToMaxScale(): boolean;
    protected onLoad(event: Event): void;
    protected onDragStart(event: Event): void;
    protected onScaleChange($event: number): void;
    protected increase(): void;
    protected decrease(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThumbnailMaker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ThumbnailMaker, "ngs-thumbnail-maker", ["ngsThumbnailMaker"], { "src": { "alias": "src"; "required": true; "isSignal": true; }; "helperText": { "alias": "helperText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { ThumbnailMaker };
export type { ThumbnailMakerApi };
