import * as _angular_core from '@angular/core';
import { OnDestroy, OnInit, TemplateRef, Signal, AfterContentInit } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { ControlValueAccessor } from '@angular/forms';
import { SelectionModel } from '@angular/cdk/collections';
import { Option } from '@ngstarter/components/select';

/** Reason why the menu was closed. */
type MenuCloseReason = 'click' | 'keydown' | 'tab' | 'backdrop' | 'mouse';

declare class MenuTrigger implements OnDestroy {
    private _overlay;
    private _elementRef;
    private _viewContainerRef;
    private _injector;
    private _parentMenu;
    private _menu;
    readonly menu: _angular_core.InputSignal<Menu | null>;
    readonly menuData: _angular_core.InputSignal<any>;
    readonly menuDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly xPosition: _angular_core.InputSignal<"before" | "after">;
    readonly yPosition: _angular_core.InputSignal<"above" | "below">;
    readonly menuOpened: _angular_core.OutputEmitterRef<void>;
    readonly menuClosed: _angular_core.OutputEmitterRef<MenuCloseReason>;
    readonly restoreFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private _overlayRef;
    private _portal;
    private _closingSubscription;
    private _hoverSubscription;
    private _childMenuClosedSubscription;
    private _closeTimeoutId;
    private _previouslyFocusedElement;
    readonly menuOpen: _angular_core.WritableSignal<boolean>;
    ngOnDestroy(): void;
    _handleMouseLeave(): void;
    _clearCloseTimeout(): void;
    _handleClick(event: MouseEvent): void;
    toggleMenu(): void;
    openMenu(): void;
    closeMenu(reason: MenuCloseReason, force?: boolean): void;
    private _setIsMenuOpen;
    private _getPanelClasses;
    private _createOverlay;
    private _getOverlayConfig;
    private _getPositions;
    private _menuClosingActions;
    _handleMouseEnter(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<MenuTrigger, "[ngsMenuTriggerFor]", ["ngsMenuTrigger"], { "menu": { "alias": "ngsMenuTriggerFor"; "required": false; "isSignal": true; }; "menuData": { "alias": "ngsMenuTriggerData"; "required": false; "isSignal": true; }; "menuDisabled": { "alias": "ngsMenuDisabled"; "required": false; "isSignal": true; }; "xPosition": { "alias": "xPosition"; "required": false; "isSignal": true; }; "yPosition": { "alias": "yPosition"; "required": false; "isSignal": true; }; "restoreFocus": { "alias": "ngsMenuTriggerRestoreFocus"; "required": false; "isSignal": true; }; }, { "menuOpened": "menuOpened"; "menuClosed": "menuClosed"; }, never, never, true, never>;
}

declare class MenuItem implements OnInit {
    private _injector;
    protected _menuTrigger: MenuTrigger | null;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly role: _angular_core.InputSignal<"menuitem" | "menuitem-radio" | "menuitem-checkbox">;
    selected: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly _triggered: _angular_core.OutputEmitterRef<void>;
    private _elementRef;
    private _menu;
    get label(): string;
    focus(): void;
    ngOnInit(): void;
    _handleClick(event: MouseEvent): void;
    _handleMouseEnter(): void;
    protected readonly _isHighlighted: _angular_core.WritableSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuItem, "ngs-menu-item, [ngs-menu-item]", ["ngsMenuItem"], { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "_triggered": "_triggered"; }, never, ["ngs-icon", "*"], true, never>;
}

declare class MenuContent {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<MenuContent, "[ngsMenuContent]", never, {}, {}, never, never, true, never>;
}

declare class Menu implements OnDestroy {
    readonly role: _angular_core.InputSignal<"menu" | "menubar">;
    readonly classList: _angular_core.InputSignal<string>;
    readonly xPosition: _angular_core.InputSignal<"before" | "after">;
    readonly yPosition: _angular_core.InputSignal<"above" | "below">;
    protected readonly _panelClasses: _angular_core.WritableSignal<string[]>;
    readonly closed: _angular_core.OutputEmitterRef<MenuCloseReason>;
    readonly _childMenuClosed: Subject<void>;
    readonly templateRef: _angular_core.Signal<TemplateRef<any>>;
    readonly content: _angular_core.Signal<MenuContent | undefined>;
    readonly items: _angular_core.Signal<readonly MenuItem[]>;
    protected readonly _isNested: _angular_core.WritableSignal<boolean>;
    protected readonly _context: _angular_core.WritableSignal<any>;
    private _parentMenu;
    private _parentMenuTrigger;
    private _itemSubscription;
    private _openedTrigger;
    constructor();
    ngOnDestroy(): void;
    /**
     * Закрывает меню.
     * @param reason Причина закрытия.
     */
    close(reason: MenuCloseReason): void;
    _setPanelClasses(classes: string[]): void;
    _setContext(context: any): void;
    _triggerOpened(trigger: any): void;
    _triggerClosed(trigger: any): void;
    hasOpenChild(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Menu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Menu, "ngs-menu", ["ngsMenu"], { "role": { "alias": "role"; "required": false; "isSignal": true; }; "classList": { "alias": "classList"; "required": false; "isSignal": true; }; "xPosition": { "alias": "xPosition"; "required": false; "isSignal": true; }; "yPosition": { "alias": "yPosition"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, ["content", "items"], ["[ngs-menu-header]", "*", "[ngs-menu-footer]"], true, never>;
}

declare class MenuDivider {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuDivider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuDivider, "ngs-menu-divider", never, {}, {}, never, never, true, never>;
}

declare class MenuHeading {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuHeading, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuHeading, "ngs-menu-heading", never, {}, {}, never, ["*"], true, never>;
}

declare class ContextMenuTrigger implements OnDestroy {
    private _overlay;
    private _elementRef;
    private _viewContainerRef;
    private _ngZone;
    readonly menu: _angular_core.InputSignal<Menu | null>;
    readonly menuData: _angular_core.InputSignal<any>;
    readonly menuOpened: _angular_core.OutputEmitterRef<void>;
    readonly menuClosed: _angular_core.OutputEmitterRef<MenuCloseReason>;
    private _overlayRef;
    private _portal;
    private _closingSubscription;
    readonly menuOpen: _angular_core.WritableSignal<boolean>;
    ngOnDestroy(): void;
    openMenu(x: number, y: number): void;
    closeMenu(reason: MenuCloseReason): void;
    private _setIsMenuOpen;
    private _createOverlay;
    private _getOverlayConfig;
    private _getPositionStrategy;
    private _menuClosingActions;
    _handleContextMenu(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContextMenuTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ContextMenuTrigger, "[ngsContextMenuTriggerFor]", ["ngsContextMenuTrigger"], { "menu": { "alias": "ngsContextMenuTriggerFor"; "required": false; "isSignal": true; }; "menuData": { "alias": "ngsContextMenuTriggerData"; "required": false; "isSignal": true; }; }, { "menuOpened": "menuOpened"; "menuClosed": "menuClosed"; }, never, never, true, never>;
}

declare class MenuHeader {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuHeader, "ngs-menu-header", never, {}, {}, never, ["*"], true, never>;
}

declare class MenuFooter {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuFooter, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuFooter, "ngs-menu-footer", never, {}, {}, never, ["*"], true, never>;
}

/**
 * Describes a parent component that manages a list of options.
 * Contains properties that the options can inherit.
 * @docs-private
 */
interface OptionParentComponent {
    disableRipple?: boolean | Signal<boolean>;
    multiple?: boolean | Signal<boolean>;
    inertGroups?: boolean;
    hideSingleSelectionIndicator?: boolean;
}

declare class MenuOptionGroupDirective implements OptionParentComponent, OnInit, ControlValueAccessor, AfterContentInit {
    private _changeDetectorRef;
    private _destroyRef;
    private _menu;
    disableRipple: boolean;
    inertGroups: boolean;
    hideSingleSelectionIndicator: boolean;
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly multipleSignal: Signal<boolean>;
    readonly hideCheckIcon: _angular_core.WritableSignal<boolean>;
    readonly _optionsContentChanges: _angular_core.WritableSignal<number>;
    _selectionModel: SelectionModel<any>;
    private _value;
    readonly options: Signal<readonly Option[]>;
    readonly ngsOptions: Signal<readonly any[]>;
    private _options$;
    private _ngsOptions$;
    private _initialized;
    readonly valueChange: _angular_core.OutputEmitterRef<any>;
    readonly optionSelectionChanges: Observable<any>;
    onChange: any;
    onTouched: any;
    ngOnInit(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    ngAfterContentInit(): void;
    private _selectOptionByValue;
    writeValue(newValue: any): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuOptionGroupDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<MenuOptionGroupDirective, "[ngsMenuOptionGroup]", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, ["options", "ngsOptions"], never, true, never>;
}

export { ContextMenuTrigger, Menu, MenuContent, MenuDivider, MenuFooter, MenuHeader, MenuHeading, MenuItem, MenuOptionGroupDirective, MenuTrigger };
export type { MenuCloseReason };
