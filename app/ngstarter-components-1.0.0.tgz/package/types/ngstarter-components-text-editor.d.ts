import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Editor } from '@tiptap/core';
import * as i1 from '@ngstarter/components/upload';
import { UploadFileSelectedEvent } from '@ngstarter/components/upload';

interface TextEditorInterface {
    api: TextEditorAPI;
}
interface TextEditorAPI {
    isCommandDisabled: (command: string, options?: any) => boolean | null;
    isActive: (command: string, options?: any) => boolean | null;
    runCommand: (command: string, options?: any) => void;
    editor: () => Editor;
}
declare const TEXT_EDITOR: InjectionToken<unknown>;
declare const TEXT_EDITOR_BUBBLE_MENU: InjectionToken<unknown>;

declare class TextEditor {
    private _document;
    private _cdr;
    private _injector;
    private _content;
    private _bubbleMenu;
    private _imageBubbleMenu;
    private _floatingMenu;
    protected _value: string;
    protected editor: Editor;
    content: i0.InputSignal<string>;
    extensions: i0.InputSignal<never[]>;
    contentMaxHeight: i0.InputSignal<number | undefined>;
    placeholder: i0.InputSignal<string>;
    imageUploadFn: i0.InputSignal<((file: Blob) => Promise<string>) | undefined>;
    readonly contentChange: i0.OutputEmitterRef<string>;
    get api(): TextEditorAPI;
    ngOnInit(): void;
    isCommandDisabled(command: string, options?: any): boolean | null;
    ngOnDestroy(): void;
    private _runCommand;
    private _init;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditor, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextEditor, "ngs-text-editor", ["ngsTextEditor"], { "content": { "alias": "content"; "required": false; "isSignal": true; }; "extensions": { "alias": "extensions"; "required": false; "isSignal": true; }; "contentMaxHeight": { "alias": "contentMaxHeight"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "imageUploadFn": { "alias": "imageUploadFn"; "required": false; "isSignal": true; }; }, { "contentChange": "contentChange"; }, never, ["ngs-text-editor-toolbar", "ngs-text-editor-bubble-menu", "ngs-text-editor-floating-menu"], true, never>;
}

declare class TextEditorToolbar {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorToolbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextEditorToolbar, "ngs-text-editor-toolbar", ["ngsTextEditorToolbar"], {}, {}, never, ["[ngsTextEditorCommand],ngs-text-editor-divider"], true, never>;
}

declare class TextEditorDivider {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorDivider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextEditorDivider, "ngs-text-editor-divider", ["ngsTextEditorDivider"], {}, {}, never, never, true, never>;
}

declare class TextEditorBubbleMenu {
    protected textEditor: TextEditorInterface;
    getLinkUrl(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorBubbleMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextEditorBubbleMenu, "ngs-text-editor-bubble-menu", ["emitTextEditorBubbleMenu"], {}, {}, never, ["[ngsTextEditorCommandEditLink],[ngsCommentEditorCommandUnsetLink]", "[ngsTextEditorCommand],ngs-text-editor-divider"], true, never>;
}

declare class TextEditorFloatingMenu {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorFloatingMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextEditorFloatingMenu, "ngs-text-editor-floating-menu", ["ngsTextEditorFloatingMenu"], {}, {}, never, ["[ngsTextEditorCommand],ngs-text-editor-divider"], true, never>;
}

declare class TextEditorCommandBlockquoteDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandBlockquoteDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandBlockquoteDirective, "[ngsTextEditorCommandBlockquote]", ["ngsTextEditorCommandBlockquote"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandBoldDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandBoldDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandBoldDirective, "[ngsTextEditorCommandBold]", ["ngsTextEditorCommandBold"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandBulletListDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandBulletListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandBulletListDirective, "[ngsTextEditorCommandBulletList]", ["ngsTextEditorCommandBulletList"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandCodeBlockDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandCodeBlockDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandCodeBlockDirective, "[ngsTextEditorCommandCodeBlock]", ["ngsTextEditorCommandCodeBlock"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandCodeDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandCodeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandCodeDirective, "[ngsTextEditorCommandCode]", ["ngsTextEditorCommandCode"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandEditLinkDirective {
    private _destroyRef;
    private _dialog;
    protected textEditor: TextEditorInterface;
    protected setLinkActive: boolean;
    protected onClick(): void;
    private _setLink;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandEditLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandEditLinkDirective, "[ngsTextEditorCommandEditLink]", ["ngsTextEditorCommandEditLink"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandImageDirective {
    protected textEditor: TextEditorInterface;
    protected onImageSelected(event: UploadFileSelectedEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandImageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandImageDirective, "[ngsTextEditorCommandImage]", ["ngsTextEditorCommandImage"], {}, {}, never, never, true, [{ directive: typeof i1.UploadTriggerDirective; inputs: {}; outputs: { "fileSelected": "fileSelected"; }; }]>;
}

declare class TextEditorCommandItalicDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandItalicDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandItalicDirective, "[ngsTextEditorCommandItalic]", ["ngsTextEditorCommandItalic"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandDirective, "[ngsTextEditorCommand]", ["ngsTextEditorCommand"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandYoutubeDirective {
    protected textEditor: TextEditorInterface;
    private _dialog;
    private _destroyRef;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandYoutubeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandYoutubeDirective, "[ngsTextEditorCommandYoutube]", ["ngsTextEditorCommandYoutube"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandUnsetLinkDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandUnsetLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandUnsetLinkDirective, "[ngsTextEditorCommandUnsetLink]", ["ngsTextEditorCommandUnsetLink"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandStrikeDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandStrikeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandStrikeDirective, "[ngsTextEditorCommandStrike]", ["ngsTextEditorCommandStrike"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandOrderedListDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandOrderedListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandOrderedListDirective, "[ngsTextEditorCommandOrderedList]", ["ngsTextEditorCommandOrderedList"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandLinkDirective {
    private _destroyRef;
    private _dialog;
    protected textEditor: TextEditorInterface;
    protected setLinkActive: boolean;
    protected onClick(): void;
    private _setLink;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandLinkDirective, "[ngsTextEditorCommandLink]", ["ngsTextEditorCommandLink"], {}, {}, never, never, true, never>;
}

declare class TextEditorCommandHeadingDirective {
    protected textEditor: TextEditorInterface;
    level: i0.InputSignalWithTransform<number, unknown>;
    protected get isActive(): boolean;
    protected get isDisabled(): boolean;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandHeadingDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandHeadingDirective, "[ngsTextEditorCommandHeading]", ["ngsTextEditorCommandHeading"], { "level": { "alias": "level"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TextEditorCommandHorizontalRuleDirective {
    protected textEditor: TextEditorInterface;
    protected onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextEditorCommandHorizontalRuleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextEditorCommandHorizontalRuleDirective, "[ngsTextEditorCommandHorizontalRule]", never, {}, {}, never, never, true, never>;
}

export { TEXT_EDITOR, TEXT_EDITOR_BUBBLE_MENU, TextEditor, TextEditorBubbleMenu, TextEditorCommandBlockquoteDirective, TextEditorCommandBoldDirective, TextEditorCommandBulletListDirective, TextEditorCommandCodeBlockDirective, TextEditorCommandCodeDirective, TextEditorCommandDirective, TextEditorCommandEditLinkDirective, TextEditorCommandHeadingDirective, TextEditorCommandHorizontalRuleDirective, TextEditorCommandImageDirective, TextEditorCommandItalicDirective, TextEditorCommandLinkDirective, TextEditorCommandOrderedListDirective, TextEditorCommandStrikeDirective, TextEditorCommandUnsetLinkDirective, TextEditorCommandYoutubeDirective, TextEditorDivider, TextEditorFloatingMenu, TextEditorToolbar };
export type { TextEditorAPI, TextEditorInterface };
