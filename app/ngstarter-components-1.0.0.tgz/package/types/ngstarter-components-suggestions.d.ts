import * as i0 from '@angular/core';
import * as i1 from '@ngstarter/components/core';

declare class Suggestions {
    static ɵfac: i0.ɵɵFactoryDeclaration<Suggestions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Suggestions, "ngs-suggestions", ["ngsSuggestions"], {}, {}, never, ["*"], true, never>;
}

declare class Suggestion {
    static ɵfac: i0.ɵɵFactoryDeclaration<Suggestion, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Suggestion, "ngs-suggestion,[ngs-suggestion]", ["ngsSuggestion"], {}, {}, never, ["[ngsSuggestionIcon]", "[ngsSuggestionThumb]", "*"], true, [{ directive: typeof i1.Ripple; inputs: {}; outputs: {}; }]>;
}

declare class SuggestionBlock {
    heading: i0.InputSignal<unknown>;
    showDivider: i0.InputSignalWithTransform<boolean, unknown>;
    inline: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuggestionBlock, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SuggestionBlock, "ngs-suggestion-block", ["ngsSuggestionBlock"], { "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "showDivider": { "alias": "showDivider"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SuggestionIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SuggestionIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuggestionIconDirective, "[ngsSuggestionIcon]", never, {}, {}, never, never, true, never>;
}

declare class SuggestionThumbDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SuggestionThumbDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SuggestionThumbDirective, "[ngsSuggestionThumb]", never, {}, {}, never, never, true, never>;
}

export { Suggestion, SuggestionBlock, SuggestionIconDirective, SuggestionThumbDirective, Suggestions };
