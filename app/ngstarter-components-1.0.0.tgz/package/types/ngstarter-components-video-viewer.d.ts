import * as _angular_core from '@angular/core';
import { EventEmitter, InjectionToken, TemplateRef } from '@angular/core';
import * as _ngstarter_components_video_viewer from '@ngstarter/components/video-viewer';

declare class VideoViewer {
    readonly videoViewerRef: _ngstarter_components_video_viewer.VideoViewerRef;
    readonly data: _ngstarter_components_video_viewer.VideoViewerOptions;
    hasTitle: _angular_core.Signal<boolean>;
    hasAside: _angular_core.Signal<boolean>;
    onBackdropClick(): void;
    onPreventClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoViewer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VideoViewer, "ngs-video-viewer", ["ngsVideoViewer"], {}, {}, never, never, true, never>;
}

declare class VideoViewerRef {
    readonly closed: EventEmitter<any>;
    close(): void;
}

type VideoViewerOrientation = 'landscape' | 'portrait' | 'square';
interface VideoViewerOptions {
    sourceUrl: string;
    title?: string | undefined;
    caption?: string | undefined;
    description?: string | undefined;
    titleTplRef?: TemplateRef<any> | undefined;
    captionTplRef?: TemplateRef<any> | undefined;
    descriptionTplRef?: TemplateRef<any> | undefined;
    payload?: any | null;
    orientation?: VideoViewerOrientation | undefined;
    autoPlay?: boolean;
    showPlayButton?: boolean;
    showSpeaker?: boolean;
    showFullscreen?: boolean;
    showDurationSlider?: boolean;
    muted?: boolean;
}
declare const VIDEO_VIEWER: InjectionToken<unknown>;
declare const VIDEO_VIEWER_REF: InjectionToken<VideoViewerRef>;
declare const VIDEO_VIEWER_DATA: InjectionToken<VideoViewerOptions>;

declare class VideoViewerDirective {
    private _overlay;
    private _injector;
    private _destroyRef;
    get api(): {
        open: (options: VideoViewerOptions) => VideoViewerRef;
    };
    private _open;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoViewerDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<VideoViewerDirective, "[ngsVideoViewer]", ["ngsVideoViewer"], {}, {}, never, never, true, never>;
}

declare class VideoViewerVideoDirective {
    private _videoViewer;
    private _titleTplRef;
    private _captionTplRef;
    private _descriptionTplRef;
    sourceUrl: _angular_core.InputSignal<string>;
    caption: _angular_core.InputSignal<string | undefined>;
    title: _angular_core.InputSignal<string | undefined>;
    description: _angular_core.InputSignal<string | undefined>;
    payload: _angular_core.InputSignal<any>;
    orientation: _angular_core.InputSignal<VideoViewerOrientation | undefined>;
    autoPlay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showPlayButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showSpeaker: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showFullscreen: _angular_core.InputSignalWithTransform<boolean, unknown>;
    showDurationSlider: _angular_core.InputSignalWithTransform<boolean, unknown>;
    muted: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected onClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoViewerVideoDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<VideoViewerVideoDirective, "[ngsVideoViewerVideo]", ["ngsVideoViewerVideo"], { "sourceUrl": { "alias": "sourceUrl"; "required": true; "isSignal": true; }; "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "payload": { "alias": "payload"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "autoPlay": { "alias": "autoPlay"; "required": false; "isSignal": true; }; "showPlayButton": { "alias": "showPlayButton"; "required": false; "isSignal": true; }; "showSpeaker": { "alias": "showSpeaker"; "required": false; "isSignal": true; }; "showFullscreen": { "alias": "showFullscreen"; "required": false; "isSignal": true; }; "showDurationSlider": { "alias": "showDurationSlider"; "required": false; "isSignal": true; }; "muted": { "alias": "muted"; "required": false; "isSignal": true; }; }, {}, ["_titleTplRef", "_captionTplRef", "_descriptionTplRef"], never, true, never>;
}

declare class VideoViewerVideoTitleDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoViewerVideoTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<VideoViewerVideoTitleDirective, "[ngsVideoViewerVideoTitle]", never, {}, {}, never, never, true, never>;
}

declare class VideoViewerVideoCaptionDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoViewerVideoCaptionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<VideoViewerVideoCaptionDirective, "[ngsVideoViewerVideoCaption]", never, {}, {}, never, never, true, never>;
}

declare class VideoViewerVideoDescriptionDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoViewerVideoDescriptionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<VideoViewerVideoDescriptionDirective, "[ngsVideoViewerVideoDescription]", never, {}, {}, never, never, true, never>;
}

export { VIDEO_VIEWER, VIDEO_VIEWER_DATA, VIDEO_VIEWER_REF, VideoViewer, VideoViewerDirective, VideoViewerRef, VideoViewerVideoCaptionDirective, VideoViewerVideoDescriptionDirective, VideoViewerVideoDirective, VideoViewerVideoTitleDirective };
export type { VideoViewerOptions, VideoViewerOrientation };
