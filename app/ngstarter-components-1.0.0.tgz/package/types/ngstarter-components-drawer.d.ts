import * as _angular_core from '@angular/core';
import { OnDestroy, Signal, TemplateRef, InjectionToken } from '@angular/core';

declare class Drawer implements OnDestroy {
    private overlay;
    private viewContainerRef;
    private destroyRef;
    readonly initialIsOpen: _angular_core.InputSignal<boolean | undefined>;
    readonly showBackdrop: _angular_core.InputSignal<boolean>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    private internalIsOpen;
    private overlayRef;
    protected portal: Signal<TemplateRef<any>>;
    protected _isOpen: Signal<boolean>;
    constructor();
    ngOnDestroy(): void;
    open(): void;
    close(): void;
    get isOpened(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Drawer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Drawer, "ngs-drawer", ["ngsDrawer"], { "initialIsOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; "showBackdrop": { "alias": "showBackdrop"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "opened": "opened"; }, never, ["*"], true, never>;
}

declare class DrawerIgnoreOutsideClickDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DrawerIgnoreOutsideClickDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DrawerIgnoreOutsideClickDirective, "[ngsDrawerIgnoreOutsideClick]", never, {}, {}, never, never, true, never>;
}

declare const DRAWER: InjectionToken<unknown>;

export { DRAWER, Drawer, DrawerIgnoreOutsideClickDirective };
