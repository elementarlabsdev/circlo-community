import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import * as i1 from '@angular/cdk/scrolling';
import { CdkScrollable } from '@angular/cdk/scrolling';

declare class PanelSidebar {
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelSidebar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelSidebar, "ngs-panel-sidebar", never, {}, {}, never, ["*"], true, never>;
}

declare class PanelAside {
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelAside, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelAside, "ngs-panel-aside", never, {}, {}, never, ["*"], true, never>;
}

declare class PanelHeader {
    autoHeight: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelHeader, "ngs-panel-header", ["ngsPanelHeader"], { "autoHeight": { "alias": "autoHeight"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class PanelSubheader {
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelSubheader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelSubheader, "ngs-panel-subheader", ["ngsPanelSubheader"], {}, {}, never, never, true, never>;
}

declare class PanelFooter {
    autoHeight: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelFooter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelFooter, "ngs-panel-footer", ["ngsPanelFooter"], { "autoHeight": { "alias": "autoHeight"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class Panel {
    header: i0.Signal<PanelHeader | undefined>;
    subheader: i0.Signal<PanelSubheader | undefined>;
    sidebar: i0.Signal<PanelSidebar | undefined>;
    aside: i0.Signal<PanelAside | undefined>;
    footer: i0.Signal<PanelFooter | undefined>;
    absolute: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Panel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Panel, "ngs-panel", ["ngsPanel"], { "absolute": { "alias": "absolute"; "required": false; "isSignal": true; }; }, {}, ["header", "subheader", "sidebar", "aside", "footer"], ["ngs-panel-header", "ngs-panel-subheader", "ngs-panel-sidebar", "ngs-panel-content", "ngs-panel-aside", "ngs-panel-footer"], true, never>;
}

interface PanelContentInterface {
    scrollContainer(): HTMLElement;
    scrollable?: CdkScrollable;
}
declare const PANEL_CONTENT: InjectionToken<PanelContentInterface>;

declare class PanelContent implements PanelContentInterface {
    private elementRef;
    readonly scrollable: CdkScrollable;
    scrollContainer(): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelContent, "ngs-panel-content", ["ngsPanelContent"], {}, {}, never, ["*"], true, [{ directive: typeof i1.CdkScrollable; inputs: {}; outputs: {}; }]>;
}

export { PANEL_CONTENT, Panel, PanelAside, PanelContent, PanelFooter, PanelHeader, PanelSidebar };
export type { PanelContentInterface };
