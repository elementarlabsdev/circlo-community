import { ComponentType } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { InjectionToken, ViewContainerRef, OnDestroy, TemplateRef, EventEmitter } from '@angular/core';
import { ScrollStrategy } from '@angular/cdk/overlay';
import * as rxjs from 'rxjs';
import { Subject } from 'rxjs';
import { DialogRef, CdkDialogContainer } from '@angular/cdk/dialog';

/** Injection token that can be used to access the data that was passed in to a bottom sheet. */
declare const BOTTOM_SHEET_DATA: InjectionToken<any>;
/**
 * Configuration used when opening a bottom sheet.
 */
declare class BottomSheetConfig<D = any> {
    /** The view container to place the overlay for the bottom sheet into. */
    viewContainerRef?: ViewContainerRef;
    /** Extra CSS classes to be added to the bottom sheet container. */
    panelClass?: string | string[];
    /** Text layout direction for the bottom sheet. */
    direction?: 'ltr' | 'rtl';
    /** Data being injected into the child component. */
    data?: D | null;
    /** Whether the bottom sheet has a backdrop. */
    hasBackdrop?: boolean;
    /** Custom class for the backdrop. */
    backdropClass?: string;
    /** Whether the user can use escape or clicking outside to close the bottom sheet. */
    disableClose?: boolean;
    /** Aria label to assign to the bottom sheet element. */
    ariaLabel?: string | null;
    /**
     * Whether this is a modal dialog. Used to set the `aria-modal` attribute.
     */
    ariaModal?: boolean;
    /**
     * Whether the bottom sheet should close when the user goes backwards/forwards in history.
     */
    closeOnNavigation?: boolean;
    /**
     * Where the bottom sheet should focus on open.
     */
    autoFocus?: string | boolean;
    /**
     * Whether the bottom sheet should restore focus to the
     * previously-focused element, after it's closed.
     */
    restoreFocus?: boolean;
    /** Scroll strategy to be used for the bottom sheet. */
    scrollStrategy?: ScrollStrategy;
    /** Height for the bottom sheet. */
    height?: string;
    /** Minimum height for the bottom sheet. If a number is provided, assumes pixel units. */
    minHeight?: string | number;
    /** Maximum height for the bottom sheet. If a number is provided, assumes pixel units. */
    maxHeight?: string | number;
}

/**
 * Reference to a bottom sheet dispatched from the BottomSheet service.
 */
declare class BottomSheetRef<T = any, R = any> {
    private _ref;
    containerInstance: any;
    /** @internal */
    _refInstance: T | null;
    /** @internal */
    _refRef: any;
    /** Instance of the component making up the content of the bottom sheet. */
    get instance(): T;
    /**
     * `ComponentRef` of the component opened into the bottom sheet. Will be
     * null when the bottom sheet is opened using a `TemplateRef`.
     */
    get componentRef(): any;
    /** Whether the user is allowed to close the bottom sheet. */
    disableClose: boolean | undefined;
    /** Subject for notifying the user that the bottom sheet has opened and appeared. */
    private readonly _afterOpened;
    /** Result to be passed down to the `afterDismissed` stream. */
    private _result;
    /** Handle to the timeout that's running as a fallback in case the exit animation doesn't fire. */
    private _closeFallbackTimeout;
    constructor(_ref: DialogRef<R, T>, config: BottomSheetConfig, containerInstance: any);
    /**
     * Dismisses the bottom sheet.
     * @param result Data to be passed back to the bottom sheet opener.
     */
    dismiss(result?: R): void;
    /** Gets an observable that is notified when the bottom sheet is finished closing. */
    afterDismissed(): rxjs.Observable<R | undefined>;
    /** Gets an observable that is notified when the bottom sheet has opened and appeared. */
    afterOpened(): Subject<void>;
    /**
     * Gets an observable that emits when the overlay's backdrop has been clicked.
     */
    backdropClick(): rxjs.Observable<MouseEvent>;
    /**
     * Gets an observable that emits when keydown events are targeted on the overlay.
     */
    keydownEvents(): rxjs.Observable<KeyboardEvent>;
}

/** Injection token that can be used to specify default bottom sheet options. */
declare const BOTTOM_SHEET_DEFAULT_OPTIONS: InjectionToken<BottomSheetConfig<any>>;
declare class BottomSheet implements OnDestroy {
    private _injector;
    private _overlay;
    private _dialog;
    private _parentBottomSheet;
    private _defaultOptions;
    private _bottomSheetRefAtThisLevel;
    /** Reference to the currently opened bottom sheet. */
    get _openedBottomSheetRef(): BottomSheetRef<any> | null;
    set _openedBottomSheetRef(value: BottomSheetRef<any> | null);
    open<T, D = any, R = any>(componentOrTemplateRef: ComponentType<T> | TemplateRef<T>, config?: BottomSheetConfig<D>): BottomSheetRef<T, R>;
    /**
     * Dismisses the currently-visible bottom sheet.
     * @param result Data to pass to the bottom sheet instance.
     */
    dismiss<R = any>(result?: R): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BottomSheet, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BottomSheet>;
}

/**
 * Internal component that wraps user-provided bottom sheet content.
 * @docs-private
 */
declare class BottomSheetContainer extends CdkDialogContainer implements OnDestroy {
    private _breakpointSubscription;
    /** The state of the bottom sheet animations. */
    _animationState: 'void' | 'visible' | 'hidden';
    /** Emits whenever the state of the animation changes. */
    _animationStateChanged: EventEmitter<any>;
    /** Whether the component has been destroyed. */
    private _destroyed;
    constructor();
    /** Begin animation of bottom sheet entrance into view. */
    enter(): void;
    /** Begin animation of the bottom sheet exiting from view. */
    exit(): void;
    ngOnDestroy(): void;
    _onTransitionEnd(event: TransitionEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BottomSheetContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BottomSheetContainer, "ngs-bottom-sheet-container", never, {}, {}, never, never, true, never>;
}

export { BOTTOM_SHEET_DATA, BOTTOM_SHEET_DEFAULT_OPTIONS, BottomSheet, BottomSheetConfig, BottomSheetContainer, BottomSheetRef };
