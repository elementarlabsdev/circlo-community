import * as _angular_core from '@angular/core';
import { AfterViewInit, OnDestroy, ElementRef } from '@angular/core';

declare class VideoPlayer implements AfterViewInit, OnDestroy {
    private readonly platformId;
    private readonly document;
    private readonly destroyRef;
    src: _angular_core.InputSignal<string | null>;
    payload: _angular_core.InputSignal<any>;
    autoPlay: _angular_core.InputSignal<boolean>;
    videoElement: _angular_core.Signal<ElementRef<HTMLVideoElement> | undefined>;
    loaded: _angular_core.WritableSignal<boolean>;
    isPlaying: _angular_core.WritableSignal<boolean>;
    hasStarted: _angular_core.WritableSignal<boolean>;
    currentTime: _angular_core.WritableSignal<number>;
    duration: _angular_core.WritableSignal<number>;
    volume: _angular_core.WritableSignal<number>;
    isMuted: _angular_core.WritableSignal<boolean>;
    isFullscreen: _angular_core.WritableSignal<boolean>;
    orientation: _angular_core.Signal<any>;
    private player;
    constructor();
    ngAfterViewInit(): void;
    private onLoadedData;
    private onTimeUpdate;
    private onLoadedMetadata;
    private onPlay;
    private onPause;
    private setupEvents;
    private onFullscreenChange;
    toggleFullscreen(): void;
    togglePlay(): void;
    seek(event: any): void;
    toggleMute(): void;
    private initPlayer;
    private updateSrc;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<VideoPlayer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<VideoPlayer, "ngs-video-player", ["ngsVideoPlayer"], { "src": { "alias": "src"; "required": false; "isSignal": true; }; "payload": { "alias": "payload"; "required": false; "isSignal": true; }; "autoPlay": { "alias": "autoPlay"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { VideoPlayer };
