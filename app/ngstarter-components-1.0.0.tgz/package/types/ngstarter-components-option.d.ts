import * as _angular_core from '@angular/core';
import { InjectionToken, Signal, ElementRef, OutputEmitterRef, WritableSignal, AfterViewInit, OnDestroy } from '@angular/core';
import { Highlightable } from '@angular/cdk/a11y';

declare abstract class _Option {
    abstract value: Signal<any>;
    abstract elementRef: ElementRef<HTMLElement>;
    abstract select(): void;
    abstract deselect(): void;
    abstract selected: boolean;
    abstract viewValue: string;
    abstract onSelectionChange: OutputEmitterRef<_Option>;
    abstract disabled: boolean;
}
declare abstract class _OptionParent {
    abstract multiple: Signal<boolean>;
    abstract hideCheckIcon?: Signal<boolean>;
    abstract _optionsContentChanges?: WritableSignal<number>;
}
declare const OPTION_PARENT: InjectionToken<_OptionParent>;
declare const OPTION: InjectionToken<_Option>;

declare class Option implements AfterViewInit, OnDestroy, _Option, Highlightable {
    elementRef: ElementRef<HTMLElement>;
    private _parent;
    private _cdr;
    value: _angular_core.InputSignal<any>;
    disabledSignal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    selectedInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get disabled(): boolean;
    readonly onSelectionChange: _angular_core.OutputEmitterRef<_Option>;
    private _selected;
    private _active;
    private _mutationObserver?;
    constructor(elementRef: ElementRef<HTMLElement>);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    get selected(): boolean;
    get multiple(): boolean;
    get hideCheckIcon(): boolean;
    get active(): boolean;
    select(): void;
    deselect(): void;
    setActiveStyles(): void;
    setInactiveStyles(): void;
    _onClick(event: MouseEvent): void;
    get viewValue(): string;
    getLabel?(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Option, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Option, "ngs-option", ["ngsOption"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabledSignal": { "alias": "disabled"; "required": false; "isSignal": true; }; "selectedInput": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "onSelectionChange": "onSelectionChange"; }, never, ["*"], true, never>;
}

declare class Optgroup {
    label: _angular_core.InputSignal<string | undefined>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    id: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Optgroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Optgroup, "ngs-optgroup", ["ngsOptgroup"], { "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-option"], true, never>;
}

export { OPTION, OPTION_PARENT, Optgroup, Option, _Option, _OptionParent };
