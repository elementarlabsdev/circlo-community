import * as _angular_core from '@angular/core';
import { OnInit, AfterViewInit, DoCheck, OnDestroy, ElementRef, PipeTransform } from '@angular/core';
import { NgControl, NgForm, FormGroupDirective, UntypedFormControl } from '@angular/forms';
import { ErrorStateMatcher } from '@ngstarter/components/core';
import { FormFieldControl } from '@ngstarter/components/form-field';
import { PhoneNumber, CountryCode } from 'libphonenumber-js';
import { Subject } from 'rxjs';

interface Country {
    name: string;
    shortCode: string;
    phoneCode: string;
}

type PhoneNumberFormat = 'default' | 'national' | 'international';

declare class PhoneInput implements OnInit, AfterViewInit, DoCheck, OnDestroy, FormFieldControl<any> {
    ngControl: NgControl;
    private _destroyRef;
    private _changeDetectorRef;
    private countryCodeData;
    private _focusMonitor;
    private _elementRef;
    private _errorStateMatcher;
    private _parentForm;
    static nextId: number;
    readonly menuSearchInput: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly focusable: _angular_core.Signal<ElementRef<any>>;
    focused: boolean;
    private _focused;
    errorState: boolean;
    private _errorState;
    id: string;
    private _id;
    placeholder: string;
    empty: boolean;
    shouldLabelFloat: boolean;
    private _shouldLabelFloat;
    private _empty;
    readonly countryChanged: _angular_core.OutputEmitterRef<Country>;
    stateChanges: Subject<void>;
    describedBy: string;
    phoneNumber?: string;
    allCountries: Country[];
    preferredCountriesInDropDown: Country[];
    selectedCountry: _angular_core.WritableSignal<Country | null>;
    numberInstance?: PhoneNumber;
    value: any;
    searchCriteria?: string;
    private _previousFormattedNumber?;
    onTouched: () => void;
    propagateChange: (_: any) => void;
    autocomplete: _angular_core.InputSignal<AutoFill>;
    errorStateMatcher: _angular_core.InputSignal<ErrorStateMatcher>;
    onlyCountries: _angular_core.InputSignal<string[]>;
    preferredCountries: _angular_core.InputSignal<string[]>;
    format: _angular_core.InputSignal<PhoneNumberFormat>;
    defaultSelectedCountryCode: _angular_core.InputSignal<string>;
    readonly _placeholder: _angular_core.InputSignal<string>;
    set required(value: boolean);
    get required(): boolean;
    private _required;
    phoneDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private _disabled;
    private _compositeDisabled;
    disabled: boolean;
    constructor(ngControl: NgControl, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, _defaultErrorStateMatcher: ErrorStateMatcher);
    ngOnInit(): void;
    ngDoCheck(): void;
    updateErrorState(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onPhoneNumberChange(): void;
    onCountrySelect(country: Country, el: any): void;
    getCountry(shortCode: CountryCode): Country;
    onInputKeyPress(event: any): void;
    protected fetchCountryData(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    setDescribedByIds(ids: string[]): void;
    focus(): void;
    onContainerClick(event: MouseEvent): void;
    reset(): void;
    private get formattedPhoneNumber();
    private formatAsYouTypeIfEnabled;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PhoneInput, [{ optional: true; self: true; }, { optional: true; }, { optional: true; }, null]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PhoneInput, "ngs-phone-input", ["ngsPhoneInput"], { "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "errorStateMatcher": { "alias": "errorStateMatcher"; "required": false; "isSignal": true; }; "onlyCountries": { "alias": "onlyCountries"; "required": false; "isSignal": true; }; "preferredCountries": { "alias": "preferredCountries"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; "defaultSelectedCountryCode": { "alias": "defaultSelectedCountryCode"; "required": false; "isSignal": true; }; "_placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; }; "phoneDisabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "countryChanged": "countryChanged"; }, never, never, true, never>;
    static ngAcceptInputType_required: unknown;
}

declare const phoneValidator: (control: UntypedFormControl) => {
    invalidPhone: boolean;
} | null;

declare class SearchPipe implements PipeTransform {
    transform(countries: Country[], searchCriteria?: string): Country[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SearchPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<SearchPipe, "search", true>;
}

export { PhoneInput, SearchPipe, phoneValidator };
