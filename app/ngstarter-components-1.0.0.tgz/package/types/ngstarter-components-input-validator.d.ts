import { ValidatorFn } from '@angular/forms';

declare function expiryDateValidator(): ValidatorFn;

export { expiryDateValidator };
