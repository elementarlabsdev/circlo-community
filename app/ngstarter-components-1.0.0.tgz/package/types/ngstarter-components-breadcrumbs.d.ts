import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as _ngrx_signals from '@ngrx/signals';

declare class Breadcrumbs<T> {
    itemRef: i0.Signal<TemplateRef<any>>;
    activeItemRef: i0.Signal<TemplateRef<any>>;
    separatorRef: i0.Signal<TemplateRef<any>>;
    dataSource: i0.InputSignal<T[]>;
    lastItemAsLink: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Breadcrumbs<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Breadcrumbs<any>, "ngs-breadcrumbs", ["ngsBreadcrumbs"], { "dataSource": { "alias": "dataSource"; "required": false; "isSignal": true; }; "lastItemAsLink": { "alias": "lastItemAsLink"; "required": false; "isSignal": true; }; }, {}, ["itemRef", "activeItemRef", "separatorRef"], ["*"], true, never>;
}

declare class BreadcrumbItem {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbItem, "ngs-breadcrumb-item,[ngs-breadcrumb-item]", ["ngsBreadcrumbItem"], {}, {}, never, ["[ngsBreadcrumbItemIcon]", "ngs-breadcrumb-title", "*"], true, never>;
}

declare class BreadcrumbSeparator {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbSeparator, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbSeparator, "ngs-breadcrumb-separator", ["ngsBreadcrumbSeparator"], {}, {}, never, ["*"], true, never>;
}

declare class BreadcrumbTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbTitle, "ngs-breadcrumb-title", ["ngsBreadcrumbTitle"], {}, {}, never, ["*"], true, never>;
}

interface Breadcrumb {
    id: any;
    name?: string;
    title?: string;
    type: 'link' | 'separator' | null | string;
    icon?: string;
    route?: string;
    [propName: string]: any;
}

declare class BreadcrumbItemIconDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemIconDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbItemIconDefDirective, "[ngsBreadcrumbItemIconDef]", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbItemNameDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemNameDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbItemNameDefDirective, "[ngsBreadcrumbItemNameDef]", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbItemTitleDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemTitleDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbItemTitleDefDirective, "[ngsBreadcrumbItemTitleDef]", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbsGlobal {
    private _breadcrumbsStore;
    protected itemIconDef: i0.Signal<BreadcrumbItemIconDefDirective | undefined>;
    protected itemNameDef: i0.Signal<BreadcrumbItemNameDefDirective | undefined>;
    protected itemTitleDef: i0.Signal<BreadcrumbItemTitleDefDirective | undefined>;
    breadcrumbs: i0.Signal<Breadcrumb[]>;
    lastItemAsLink: i0.InputSignalWithTransform<boolean, unknown>;
    separator: i0.InputSignal<string>;
    get iconTemplateRef(): TemplateRef<any>;
    get titleTemplateRef(): TemplateRef<any>;
    get nameTemplateRef(): TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbsGlobal, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbsGlobal, "ngs-breadcrumbs-global", ["ngsBreadcrumbsGlobal"], { "lastItemAsLink": { "alias": "lastItemAsLink"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; }, {}, ["itemIconDef", "itemNameDef", "itemTitleDef"], never, true, never>;
}

declare class BreadcrumbItemDefDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbItemDefDirective, "[ngsBreadcrumbItemDef]", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbSeparatorDefDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbSeparatorDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbSeparatorDefDirective, "[ngsBreadcrumbSeparatorDef]", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbActiveItemDefDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbActiveItemDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbActiveItemDefDirective, "[ngsBreadcrumbActiveItemDef]", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbItemIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbItemIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BreadcrumbItemIconDirective, "[ngsBreadcrumbItemIcon]", ["ngsBreadcrumbItemIcon"], {}, {}, never, never, true, never>;
}

interface BreadcrumbsState {
    breadcrumbs: Breadcrumb[];
}
declare const BreadcrumbsStore: i0.Type<{
    breadcrumbs: i0.Signal<Breadcrumb[]>;
    setBreadcrumbs: (breadcrumbs: Breadcrumb[]) => void;
} & _ngrx_signals.StateSource<{
    breadcrumbs: Breadcrumb[];
}>>;

export { BreadcrumbActiveItemDefDirective, BreadcrumbItem, BreadcrumbItemDefDirective, BreadcrumbItemIconDefDirective, BreadcrumbItemIconDirective, BreadcrumbItemNameDefDirective, BreadcrumbItemTitleDefDirective, BreadcrumbSeparator, BreadcrumbSeparatorDefDirective, BreadcrumbTitle, Breadcrumbs, BreadcrumbsGlobal, BreadcrumbsStore };
export type { BreadcrumbsState };
