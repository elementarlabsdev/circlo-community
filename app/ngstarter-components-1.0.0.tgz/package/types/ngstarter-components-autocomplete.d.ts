import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef, OnDestroy } from '@angular/core';
import { _OptionParent, Option } from '@ngstarter/components/option';
export { Option } from '@ngstarter/components/option';

interface AutocompleteActivatedEvent {
    source: Autocomplete;
    option: Option | null;
}
interface AutocompleteSelectedEvent {
    source: Autocomplete;
    option: Option;
}
declare class Autocomplete implements _OptionParent {
    readonly options: _angular_core.Signal<readonly Option[]>;
    multiple: _angular_core.WritableSignal<boolean>;
    readonly template: _angular_core.Signal<TemplateRef<any>>;
    readonly panel: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    id: string;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledby: _angular_core.InputSignal<string | undefined>;
    autoActiveFirstOption: _angular_core.InputSignalWithTransform<boolean, unknown>;
    autoSelectActiveOption: _angular_core.InputSignalWithTransform<boolean, unknown>;
    classList: _angular_core.InputSignal<string | string[] | undefined>;
    disableRipple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    displayWith: _angular_core.InputSignal<(value: any) => string | null>;
    hideSingleSelectionIndicator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    panelWidth: _angular_core.InputSignal<string | number | undefined>;
    requireSelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    closed: _angular_core.OutputEmitterRef<void>;
    opened: _angular_core.OutputEmitterRef<void>;
    optionActivated: _angular_core.OutputEmitterRef<AutocompleteActivatedEvent>;
    optionSelected: _angular_core.OutputEmitterRef<AutocompleteSelectedEvent>;
    _emitSelectEvent(option: Option): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Autocomplete, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Autocomplete, "ngs-autocomplete", ["ngsAutocomplete"], { "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "autoActiveFirstOption": { "alias": "autoActiveFirstOption"; "required": false; "isSignal": true; }; "autoSelectActiveOption": { "alias": "autoSelectActiveOption"; "required": false; "isSignal": true; }; "classList": { "alias": "class"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; "displayWith": { "alias": "displayWith"; "required": false; "isSignal": true; }; "hideSingleSelectionIndicator": { "alias": "hideSingleSelectionIndicator"; "required": false; "isSignal": true; }; "panelWidth": { "alias": "panelWidth"; "required": false; "isSignal": true; }; "requireSelection": { "alias": "requireSelection"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "opened": "opened"; "optionActivated": "optionActivated"; "optionSelected": "optionSelected"; }, ["options"], ["*"], true, never>;
}

declare class AutocompleteTrigger implements OnDestroy {
    private _elementRef;
    private _overlay;
    private _viewContainerRef;
    private _formField;
    private _chipInput;
    private _injector;
    autocomplete: _angular_core.InputSignal<Autocomplete>;
    private _overlayRef;
    private _portal;
    private _closingSubscription;
    private _keyManager;
    private _canOpenOnInput;
    private _resizeObserver;
    private _optionsSubscription;
    constructor();
    ngOnDestroy(): void;
    private _startResizeObserver;
    private _stopResizeObserver;
    _handleInput(): void;
    private _syncSelectedOption;
    _handleFocus(): void;
    _handleClick(): void;
    _handleKeydown(event: KeyboardEvent): void;
    get panelOpen(): boolean;
    openPanel(): void;
    private _setActiveItem;
    private _scrollToOption;
    closePanel(): void;
    updatePosition(): void;
    private _getConnectedElement;
    private _getPanelWidth;
    private _createOverlay;
    private _destroyOverlay;
    private _subscribeToClosingIndices;
    private _initKeyManager;
    private _setupSelectionListeners;
    private _updatePanelWidth;
    private _selectOption;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AutocompleteTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AutocompleteTrigger, "[ngsAutocomplete]", ["ngsAutocompleteTrigger"], { "autocomplete": { "alias": "ngsAutocomplete"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { Autocomplete, AutocompleteTrigger };
export type { AutocompleteActivatedEvent, AutocompleteSelectedEvent };
