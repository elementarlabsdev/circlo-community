import * as i0 from '@angular/core';
import { TemplateRef, Injector } from '@angular/core';
import { OverlayRef, Overlay } from '@angular/cdk/overlay';
import { Observable } from 'rxjs';

declare class ScreenLoader {
    opened: i0.InputSignalWithTransform<boolean, unknown>;
    message: i0.InputSignal<string | TemplateRef<any> | null>;
    protected isTemplateRef(value: any): value is TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScreenLoader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScreenLoader, "ngs-screen-loader", ["ngsScreenLoader"], { "opened": { "alias": "opened"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ScreenLoaderRef {
    private overlayRef;
    private readonly _afterOpened;
    private readonly _afterClosed;
    constructor(overlayRef: OverlayRef);
    close(): void;
    afterOpened(): Observable<void>;
    afterClosed(): Observable<void>;
    _notifyOpened(): void;
}

declare class ScreenLoaderService {
    private overlay;
    private injector;
    constructor(overlay: Overlay, injector: Injector);
    open(message: string | TemplateRef<any>): ScreenLoaderRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScreenLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScreenLoaderService>;
}

export { ScreenLoader, ScreenLoaderRef, ScreenLoaderService };
