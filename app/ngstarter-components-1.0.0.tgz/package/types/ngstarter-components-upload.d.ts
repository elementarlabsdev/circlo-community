import * as i0 from '@angular/core';
import { Renderer2, DestroyRef, TemplateRef } from '@angular/core';

type UploadFileState = 'uploading' | 'error' | 'uploaded' | string;
interface UploadFileSelectedEvent {
    event: any;
    multiple: boolean;
    fileList: FileList | null;
    files: File[];
}

declare class UploadArea {
    protected _renderer: Renderer2;
    accept: i0.InputSignal<string | undefined>;
    allowHover: i0.InputSignalWithTransform<boolean, unknown>;
    multiple: i0.InputSignalWithTransform<boolean, unknown>;
    readonly fileSelected: i0.OutputEmitterRef<UploadFileSelectedEvent>;
    protected isDropActive: i0.WritableSignal<boolean>;
    protected isDropInvalid: i0.WritableSignal<boolean>;
    get api(): {
        isDropActive: boolean;
    };
    protected handleDragOver(event: any): void;
    protected handleDragEnter(event: any): void;
    protected handleDragLeave(event: DragEvent): void;
    protected handleDragEnd(event: any): void;
    protected handleDrop(event: DragEvent): void;
    private isMimeTypeAllowed;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadArea, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UploadArea, "ngs-upload-area", ["ngsUploadArea"], { "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "allowHover": { "alias": "allowHover"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, { "fileSelected": "fileSelected"; }, never, ["[ngsUploadAreaIcon]", "*", "[ngsUploadAreaMainState]", "[ngsUploadAreaDropState]", "[ngsUploadAreaInvalidState]"], true, never>;
}

declare class FileList$1 {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileList$1, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileList$1, "ngs-file-list", ["ngsFileList"], {}, {}, never, ["*"], true, never>;
}

declare class File$1 {
    name: i0.InputSignal<unknown>;
    size: i0.InputSignal<unknown>;
    progress: i0.InputSignalWithTransform<number, unknown>;
    progressingMessage: i0.InputSignal<unknown>;
    errorMessage: i0.InputSignal<unknown>;
    remainingTime: i0.InputSignal<unknown>;
    state: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<File$1, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<File$1, "ngs-file", ["ngsFile"], { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "progress": { "alias": "progress"; "required": false; "isSignal": true; }; "progressingMessage": { "alias": "progressingMessage"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "remainingTime": { "alias": "remainingTime"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; }, {}, never, ["ngs-file-control,[ngs-file-control]"], true, never>;
}

declare class FileControl {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileControl, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileControl, "ngs-file-control,[ngs-file-control]", ["ngsFileControl"], {}, {}, never, ["*"], true, never>;
}

declare class FilesGrid {
    static ɵfac: i0.ɵɵFactoryDeclaration<FilesGrid, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilesGrid, "ngs-files-grid", ["ngsFilesGrid"], {}, {}, never, ["*"], true, never>;
}

declare class GridFile {
    name: i0.InputSignal<unknown>;
    size: i0.InputSignal<unknown>;
    progress: i0.InputSignalWithTransform<number, unknown>;
    progressingMessage: i0.InputSignal<unknown>;
    errorMessage: i0.InputSignal<unknown>;
    remainingTime: i0.InputSignal<unknown>;
    state: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridFile, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridFile, "ngs-grid-file", ["ngsGridFile"], { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "progress": { "alias": "progress"; "required": false; "isSignal": true; }; "progressingMessage": { "alias": "progressingMessage"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; "remainingTime": { "alias": "remainingTime"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsFileIcon]", "[ngsGridFileControl]"], true, never>;
}

declare class UploadContainer {
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UploadContainer, "ngs-upload-container", never, {}, {}, never, ["ngs-upload-area", "ngs-upload-allowed-types", "ngs-upload-max-file-size"], true, never>;
}

declare class UploadMaxFileSize {
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadMaxFileSize, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UploadMaxFileSize, "ngs-upload-max-file-size", never, {}, {}, never, ["*"], true, never>;
}

declare class UploadAllowedTypes {
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadAllowedTypes, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UploadAllowedTypes, "ngs-upload-allowed-types", never, {}, {}, never, ["*"], true, never>;
}

declare class UploadTriggerDirective {
    private _elementRef;
    protected _renderer: Renderer2;
    protected _destroyRef: DestroyRef;
    accept: i0.InputSignal<string | undefined>;
    multiple: i0.InputSignalWithTransform<boolean, unknown>;
    readonly fileSelected: i0.OutputEmitterRef<UploadFileSelectedEvent>;
    _handleClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UploadTriggerDirective, "[ngsUploadTrigger]", ["ngsUploadTrigger"], { "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, { "fileSelected": "fileSelected"; }, never, never, true, never>;
}

declare class UploadAreaIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadAreaIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UploadAreaIconDirective, "[ngsUploadAreaIcon]", never, {}, {}, never, never, true, never>;
}

declare class UploadAreaMainStateDirective {
    readonly templateRef: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadAreaMainStateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UploadAreaMainStateDirective, "[ngsUploadAreaMainState]", never, {}, {}, never, never, true, never>;
}

declare class UploadAreaDropStateDirective {
    readonly templateRef: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadAreaDropStateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UploadAreaDropStateDirective, "[ngsUploadAreaDropState]", never, {}, {}, never, never, true, never>;
}

declare class UploadAreaInvalidStateDirective {
    readonly templateRef: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadAreaInvalidStateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UploadAreaInvalidStateDirective, "[ngsUploadAreaInvalidState]", never, {}, {}, never, never, true, never>;
}

declare class FileIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FileIconDirective, "[ngsFileIcon]", never, {}, {}, never, never, true, never>;
}

declare class GridFileControlDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<GridFileControlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GridFileControlDirective, "[ngsGridFileControl]", never, {}, {}, never, never, true, never>;
}

export { File$1 as File, FileControl, FileIconDirective, FileList$1 as FileList, FilesGrid, GridFile, GridFileControlDirective, UploadAllowedTypes, UploadArea, UploadAreaDropStateDirective, UploadAreaIconDirective, UploadAreaInvalidStateDirective, UploadAreaMainStateDirective, UploadContainer, UploadMaxFileSize, UploadTriggerDirective };
export type { UploadFileSelectedEvent, UploadFileState };
