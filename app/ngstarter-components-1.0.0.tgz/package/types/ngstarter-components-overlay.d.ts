import { ConnectedPosition } from '@angular/cdk/overlay';

type OverlayPosition = 'below-start' | 'below-center' | 'below-end' | 'above-start' | 'above-center' | 'above-end' | 'before-start' | 'before-center' | 'before-end' | 'after-start' | 'after-center' | 'after-end';

declare class PositionManager {
    private _positions;
    private _positionPairs;
    build(position: OverlayPosition): ConnectedPosition[];
}

export { PositionManager };
export type { OverlayPosition };
