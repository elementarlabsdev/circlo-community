import * as i0 from '@angular/core';
import { AfterViewInit, OnChanges, SimpleChanges, OnDestroy, ElementRef, Renderer2, InjectionToken, OnInit, NgZone, PipeTransform } from '@angular/core';
import { ControlValueAccessor, AbstractControl, FormGroupDirective, NgForm } from '@angular/forms';
import { Platform } from '@angular/cdk/platform';
import { Observable, SchedulerLike } from 'rxjs';
import { TitleStrategy, RouterStateSnapshot } from '@angular/router';
import { Meta } from '@angular/platform-browser';
import * as _ngrx_signals from '@ngrx/signals';

declare class AutoFocusDirective implements AfterViewInit, OnChanges {
    private platformId;
    private elementRef;
    private autofocusable;
    enabled: i0.InputSignal<string | boolean>;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private _focus;
    private _moveCursorToEnd;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AutoFocusDirective, "[ngsAutoFocus]", ["ngsAutoFocus"], { "enabled": { "alias": "ngsAutoFocus"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FocusElementDirective implements AfterViewInit, OnDestroy {
    private _elementRef;
    private _focusMonitor;
    checkChildren: i0.InputSignalWithTransform<boolean, unknown>;
    readonly elementFocused: i0.OutputEmitterRef<void>;
    readonly elementBlurred: i0.OutputEmitterRef<void>;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private _emitFocusEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusElementDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusElementDirective, "[ngsFocusElement]", ["ngsFocusElement"], { "checkChildren": { "alias": "checkChildren"; "required": false; "isSignal": true; }; }, { "elementFocused": "elementFocused"; "elementBlurred": "elementBlurred"; }, never, never, true, never>;
}

declare class SoundEffectDirective {
    soundSrc: i0.InputSignal<string>;
    private _elementRef;
    private _destroyRef;
    constructor();
    private _init;
    static ɵfac: i0.ɵɵFactoryDeclaration<SoundEffectDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SoundEffectDirective, "[ngsSoundEffect]", never, { "soundSrc": { "alias": "soundSrc"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class DebounceTimeDirective implements ControlValueAccessor {
    private elementRef;
    private renderer;
    private debounceTimer?;
    readonly debounceTime: i0.InputSignalWithTransform<number, unknown>;
    private onChange;
    private onTouched;
    constructor(elementRef: ElementRef<HTMLInputElement>, renderer: Renderer2);
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState?(isDisabled: boolean): void;
    protected handleInput(event: Event): void;
    protected handleBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DebounceTimeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DebounceTimeDirective, "[ngsDebounceTime][ngModel]", never, { "debounceTime": { "alias": "debounceTime"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Possible states for a ripple element. */
declare enum RippleState {
    FADING_IN = 0,
    VISIBLE = 1,
    FADING_OUT = 2,
    HIDDEN = 3
}
interface RippleConfig {
    color?: string;
    centered?: boolean;
    radius?: number;
    persistent?: boolean;
    animation?: RippleAnimationConfig;
    terminateOnPointerUp?: boolean;
}
interface RippleAnimationConfig {
    enterDuration?: number;
    exitDuration?: number;
}
/**
 * Reference to a previously launched ripple element.
 */
declare class RippleRef {
    private _renderer;
    /** Reference to the ripple HTML element. */
    element: HTMLElement;
    /** Ripple configuration used for the ripple. */
    config: RippleConfig;
    _animationForciblyDisabledThroughCss: boolean;
    /** Current state of the ripple. */
    state: RippleState;
    constructor(_renderer: {
        fadeOutRipple(ref: RippleRef): void;
    }, 
    /** Reference to the ripple HTML element. */
    element: HTMLElement, 
    /** Ripple configuration used for the ripple. */
    config: RippleConfig, _animationForciblyDisabledThroughCss?: boolean);
    /** Fades out the ripple element. */
    fadeOut(): void;
}
/**
 * Default ripple animation configuration for ripples without an explicit
 * animation config specified.
 */
declare const defaultRippleAnimationConfig: {
    enterDuration: number;
    exitDuration: number;
};
/**
 * Helper service that performs DOM manipulations. Not intended to be used outside this module.
 */
declare class RippleRenderer implements EventListenerObject {
    private _target;
    private _ngZone;
    private _platform;
    /** Element where the ripples are being added to. */
    private _containerElement;
    /** Element which triggers the ripple elements on mouse events. */
    private _triggerElement;
    /** Whether the pointer is currently down or not. */
    private _isPointerDown;
    /** Map of currently active ripple references. */
    private _activeRipples;
    /** Latest non-persistent ripple that was triggered. */
    private _mostRecentTransientRipple;
    /** Time in milliseconds when the last touchstart event happened. */
    private _lastTouchStartEvent;
    /** Whether pointer-up event listeners have been registered. */
    private _pointerUpEventsRegistered;
    /** Cached dimensions of the ripple container. */
    private _containerRect;
    private static _eventManager;
    constructor(_target: {
        rippleConfig: RippleConfig;
        rippleDisabled: boolean;
    }, _ngZone: NgZone, elementOrElementRef: HTMLElement | ElementRef<HTMLElement>, _platform: Platform);
    /** Fades in a ripple at the given coordinates. */
    fadeInRipple(x: number, y: number, config?: RippleConfig): RippleRef;
    /** Fades out a ripple reference. */
    fadeOutRipple(rippleRef: RippleRef): void;
    /** Fades out all currently active ripples. */
    fadeOutAll(): void;
    /** Fades out all currently showing non-persistent ripples. */
    fadeOutAllNonPersistent(): void;
    /** Sets up the trigger event listeners */
    setupTriggerEvents(elementOrElementRef: HTMLElement | ElementRef<HTMLElement>): void;
    /** Handles all registered events. */
    handleEvent(event: Event): void;
    /** Method that will be called if the fade-in or fade-in transition completed. */
    private _finishRippleTransition;
    /** Starts the fade-out transition of the given ripple. */
    private _startFadeOutTransition;
    /** Destroys the given ripple. */
    private _destroyRipple;
    /** Function being called whenever the trigger is being pressed using mouse. */
    private _onMousedown;
    /** Function being called whenever the trigger is being pressed using touch. */
    private _onTouchStart;
    /** Function being called whenever the trigger is being released. */
    private _onPointerUp;
    private _getActiveRipples;
    /** Removes previously registered event listeners from the trigger element. */
    _removeTriggerEvents(): void;
}
interface RippleGlobalOptions {
    disabled?: boolean;
    animation?: RippleAnimationConfig;
    terminateOnPointerUp?: boolean;
}
declare const RIPPLE_GLOBAL_OPTIONS: InjectionToken<RippleGlobalOptions>;
declare class Ripple implements OnInit, OnDestroy {
    private _elementRef;
    private _ngZone;
    private _platform;
    private _globalOptions;
    color: i0.InputSignal<string | undefined>;
    unbounded: i0.InputSignalWithTransform<boolean, unknown>;
    centered: i0.ModelSignal<boolean>;
    radius: i0.InputSignalWithTransform<number, unknown>;
    animation: i0.InputSignal<RippleAnimationConfig | undefined>;
    disabled: i0.ModelSignal<boolean>;
    trigger: i0.ModelSignal<HTMLElement | undefined>;
    private _rippleRenderer;
    private _isInitialized;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Fades out all currently showing ripple elements. */
    fadeOutAll(): void;
    /** Fades out all currently showing non-persistent ripple elements. */
    fadeOutAllNonPersistent(): void;
    get rippleConfig(): RippleConfig;
    get rippleDisabled(): boolean;
    private _setupTriggerEventsIfEnabled;
    /** Launches a manual ripple at the specified coordinates or just by the ripple config. */
    launch(configOrX: number | RippleConfig, y?: number, config?: RippleConfig): RippleRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<Ripple, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<Ripple, "[ngsRipple]", ["ngsRipple"], { "color": { "alias": "ngsRippleColor"; "required": false; "isSignal": true; }; "unbounded": { "alias": "ngsRippleUnbounded"; "required": false; "isSignal": true; }; "centered": { "alias": "ngsRippleCentered"; "required": false; "isSignal": true; }; "radius": { "alias": "ngsRippleRadius"; "required": false; "isSignal": true; }; "animation": { "alias": "ngsRippleAnimation"; "required": false; "isSignal": true; }; "disabled": { "alias": "ngsRippleDisabled"; "required": false; "isSignal": true; }; "trigger": { "alias": "ngsRippleTrigger"; "required": false; "isSignal": true; }; }, { "centered": "ngsRippleCenteredChange"; "disabled": "ngsRippleDisabledChange"; "trigger": "ngsRippleTriggerChange"; }, never, never, true, never>;
}

declare class TextareaAutoSize implements AfterViewInit, OnDestroy {
    private readonly _textarea;
    private readonly _ngZone;
    private readonly _platform;
    minRows: i0.InputSignalWithTransform<number, unknown>;
    maxRows: i0.InputSignalWithTransform<number, unknown>;
    private _resizeObserver?;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    resize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaAutoSize, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaAutoSize, "textarea[ngsTextareaAutoSize]", ["ngsTextareaAutoSize"], { "minRows": { "alias": "minRows"; "required": false; "isSignal": true; }; "maxRows": { "alias": "maxRows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class InitialsPipe implements PipeTransform {
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<InitialsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<InitialsPipe, "initials", true>;
}

declare class FormatFileSizePipe implements PipeTransform {
    transform(bytes: number, decimalPoint?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatFileSizePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormatFileSizePipe, "formatFileSize", true>;
}

declare class OrderByPipe implements PipeTransform {
    transform(value: any, property: string, direction?: 'asc' | 'desc'): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderByPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OrderByPipe, "orderBy", true>;
}

declare class SafeHtmlPipe implements PipeTransform {
    private _domSanitizer;
    transform(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafeHtmlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafeHtmlPipe, "safeHtml", true>;
}

declare class SafeResourceUrlPipe implements PipeTransform {
    private _domSanitizer;
    transform(value: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafeResourceUrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafeResourceUrlPipe, "safeResourceUrl", true>;
}

declare class FilterByPropertyPipe implements PipeTransform {
    private getNestedValue;
    transform<T>(items: T[], propPath: string, value: any, strict?: boolean): T[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterByPropertyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FilterByPropertyPipe, "filterByProperty", true>;
}

declare class SearchByPropertyPipe implements PipeTransform {
    private getNestedValue;
    transform<T>(items: T[] | null, propPath: string, searchValue: string): T[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchByPropertyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SearchByPropertyPipe, "searchByProperty", true>;
}

declare class AnalyticsService {
    private _platformId;
    private _router;
    private _document;
    private _environmentService;
    trackPageViews(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnalyticsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnalyticsService>;
}

declare class InactivityTrackerService {
    private _destroyRef;
    private _document;
    private _interval;
    private _timeout;
    private _interactionEvents$;
    private _noInteraction;
    setupInactivityTimer(interval?: number): Observable<void>;
    reset(): void;
    private _setupTimer;
    static ɵfac: i0.ɵɵFactoryDeclaration<InactivityTrackerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InactivityTrackerService>;
}

declare class PageTitleStrategyService extends TitleStrategy {
    private _title;
    private _globalStore;
    updateTitle(routerState: RouterStateSnapshot): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageTitleStrategyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageTitleStrategyService>;
}

declare class ScreenLoaderService {
    private _globalStore;
    show(): void;
    hide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScreenLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScreenLoaderService>;
}

declare class SeoService {
    private readonly _router;
    private readonly _destroyRef;
    private readonly _document;
    private readonly _platformId;
    private _linkCanonical;
    private _title;
    private _meta;
    private _globalStore;
    get meta(): Meta;
    updateDescription(content?: string): void;
    updateOgUrl(content?: string): void;
    updateOgImage(content: string): void;
    trackCanonicalChanges(siteUrl: string): void;
    updateTitle(title: string): void;
    private getCanonicalUrl;
    private _createCanonicalTag;
    static ɵfac: i0.ɵɵFactoryDeclaration<SeoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SeoService>;
}

declare class ThemeManagerService {
    private _document;
    private _window;
    private _colorScheme;
    constructor();
    getColorScheme(): 'dark' | 'light';
    toggleColorScheme(): void;
    changeColorScheme(colorScheme: 'dark' | 'light'): void;
    private _getStoredColorScheme;
    private _setStoredColorScheme;
    getPreferredColorScheme(): 'dark' | 'light';
    setColorScheme(colorScheme: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeManagerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeManagerService>;
}

declare const ENVIRONMENT: InjectionToken<{
    [key: string]: any;
}>;
declare class EnvironmentService {
    private _environment;
    getValue(key: string, defaultValue?: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EnvironmentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EnvironmentService>;
}

declare class ResizeObserverService {
    private ngZone;
    constructor(ngZone: NgZone);
    observe(element: Element): Observable<ResizeObserverEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResizeObserverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ResizeObserverService>;
}

declare class MutationObserverService {
    private ngZone;
    constructor(ngZone: NgZone);
    observe(element: Node, options?: MutationObserverInit): Observable<MutationRecord[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MutationObserverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MutationObserverService>;
}

interface Autofocusable {
    focus(): void;
}
declare const AUTOFOCUSABLE: InjectionToken<Autofocusable>;

/** Provider for managing the error state of a form control. */
declare class ErrorStateMatcher {
    /**
     * Whether a control should be in an error state.
     * @param control The form control to check.
     * @param form The parent form that contains the control.
     * @returns Whether the control should be in an error state.
     */
    isErrorState(control: AbstractControl | null, form: FormGroupDirective | NgForm | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorStateMatcher, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorStateMatcher>;
}
/** Error state matcher that displays an error when a control is dirty and invalid. */
declare class ShowOnDirtyErrorStateMatcher implements ErrorStateMatcher {
    isErrorState(control: AbstractControl | null, form: FormGroupDirective | NgForm | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowOnDirtyErrorStateMatcher, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ShowOnDirtyErrorStateMatcher>;
}

interface GlobalState {
    screenLoading: boolean;
    sidebarHidden: boolean;
    pageTitle: string;
}
declare const GlobalStore: i0.Type<{
    screenLoading: i0.Signal<boolean>;
    sidebarHidden: i0.Signal<boolean>;
    pageTitle: i0.Signal<string>;
    setScreenLoading: (isLoading: boolean) => void;
    setPageTitle: (pageTitle: string) => void;
} & _ngrx_signals.StateSource<{
    screenLoading: boolean;
    sidebarHidden: boolean;
    pageTitle: string;
}>>;

declare function injectElement<T extends Element = HTMLElement>(): T;
declare function isElement(node?: Node | Element | EventTarget | null): node is Element;
declare function getActualTarget(event: Event): Node;

declare function px(value: number): string;
declare function arrayShallowEquals<T>(a: readonly T[], b: readonly T[]): boolean;

declare function zonefreeScheduler(): SchedulerLike;

declare function typedFromEvent<E extends Event>(target: EventTarget, event: string, options?: EventListenerOptions | boolean): Observable<E>;

export { AUTOFOCUSABLE, AnalyticsService, AutoFocusDirective, DebounceTimeDirective, ENVIRONMENT, EnvironmentService, ErrorStateMatcher, FilterByPropertyPipe, FocusElementDirective, FormatFileSizePipe, GlobalStore, InactivityTrackerService, InitialsPipe, MutationObserverService, OrderByPipe, PageTitleStrategyService, RIPPLE_GLOBAL_OPTIONS, ResizeObserverService, Ripple, RippleRef, RippleRenderer, RippleState, SafeHtmlPipe, SafeResourceUrlPipe, ScreenLoaderService, SearchByPropertyPipe, SeoService, ShowOnDirtyErrorStateMatcher, SoundEffectDirective, TextareaAutoSize, ThemeManagerService, arrayShallowEquals, defaultRippleAnimationConfig, getActualTarget, injectElement, isElement, px, typedFromEvent, zonefreeScheduler };
export type { Autofocusable, GlobalState, RippleAnimationConfig, RippleConfig, RippleGlobalOptions };
