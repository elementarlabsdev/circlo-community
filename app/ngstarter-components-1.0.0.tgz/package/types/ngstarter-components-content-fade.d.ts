import * as _angular_core from '@angular/core';
import { OnChanges, SimpleChanges } from '@angular/core';

type ContentFadePosition = 'both' | 'start' | 'end';

declare class ContentFade implements OnChanges {
    private _elementRef;
    color: _angular_core.InputSignal<unknown>;
    width: _angular_core.InputSignal<unknown>;
    position: _angular_core.InputSignal<ContentFadePosition>;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContentFade, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ContentFade, "ngs-content-fade", ["ngsContentFade"], { "color": { "alias": "color"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { ContentFade };
export type { ContentFadePosition };
