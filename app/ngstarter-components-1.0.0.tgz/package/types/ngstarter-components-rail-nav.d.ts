import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';

interface RailNavAPI {
    getActiveKey: () => any;
    activateItem: (key: any) => void;
    isActive: (key: any) => boolean;
}
interface RailNavComponent {
    api: RailNavAPI;
}

declare class RailNav implements OnInit {
    activeKey: i0.InputSignal<unknown>;
    private _activeKey;
    readonly api: RailNavAPI;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RailNav, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RailNav, "ngs-rail-nav", ["ngsRailNav"], { "activeKey": { "alias": "activeKey"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class RailNavItem {
    protected _railNav: RailNavComponent;
    key: i0.InputSignal<string>;
    get isActive(): boolean;
    click(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RailNavItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RailNavItem, "ngs-rail-nav-item,[ngs-rail-nav-item]", ["ngsRailNavItem"], { "key": { "alias": "key"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsRailNavItemIcon]", "*"], true, never>;
}

declare class RailNavItemIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<RailNavItemIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RailNavItemIconDirective, "[ngsRailNavItemIcon]", never, {}, {}, never, never, true, never>;
}

export { RailNav, RailNavItem, RailNavItemIconDirective };
