import * as rxjs from 'rxjs';
import { Subject } from 'rxjs';
import * as _angular_core from '@angular/core';
import { InjectionToken, OnInit, OnDestroy } from '@angular/core';

/**
 * To modify the labels and text displayed, create a new instance of PaginatorIntl and
 * include it in a custom provider
 */
declare class PaginatorIntl {
    /**
     * Stream to emit from when labels are changed. Use this to notify components when the labels have
     * changed after initialization.
     */
    readonly changes: Subject<void>;
    /** A label for the page size selector. */
    itemsPerPageLabel: string;
    /** A label for the button that increments the current page. */
    nextPageLabel: string;
    /** A label for the button that decrements the current page. */
    previousPageLabel: string;
    /** A label for the button that moves to the first page. */
    firstPageLabel: string;
    /** A label for the button that moves to the last page. */
    lastPageLabel: string;
    /** A label for the range of items within the current page and the length of the whole list. */
    getRangeLabel: (page: number, pageSize: number, length: number) => string;
    /** Label for the 'of' terminology in the range display. */
    ofLabel: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginatorIntl, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PaginatorIntl>;
}

/**
 * Change event object that is emitted when the user selects a
 * different page size or navigates to another page.
 */
declare class PageEvent {
    /** The current page index. */
    pageIndex: number;
    /**
     * Index of the page that was selected previously.
     */
    previousPageIndex?: number;
    /** The current page size. */
    pageSize: number;
    /** The current total number of items being paged. */
    length: number;
}
/** Injection token that can be used to provide the default options for the paginator module. */
declare const PAGINATOR_DEFAULT_OPTIONS: InjectionToken<PaginatorDefaultOptions>;
/**
 * Object that can be used to configure the default options for the paginator module.
 */
interface PaginatorDefaultOptions {
    /** Number of items to display on a page. By default set to 50. */
    pageSize?: number;
    /** The set of provided page size options to display to the user. */
    pageSizeOptions?: number[];
    /** Whether to hide the page size selection UI from the user. */
    hidePageSize?: boolean;
    /** Whether to show the first/last buttons UI to the user. */
    showFirstLastButtons?: boolean;
}
/** The default page size if there is no page size and there are no provided page size options. */
declare const DEFAULT_PAGE_SIZE = 50;

declare class Paginator implements OnInit, OnDestroy {
    private _changeDetectorRef;
    _intl: PaginatorIntl;
    private _intlChanges;
    /** The zero-based page index of the displayed list of items. Defaulted to 0. */
    pageIndexInput: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    get pageIndex(): number;
    set pageIndex(value: number);
    private _pageIndex;
    lengthInput: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    get length(): number;
    set length(value: number);
    private _length;
    /** Number of items to display on a page. By default set to 50. */
    pageSizeInput: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    get pageSize(): number;
    set pageSize(value: number);
    private _pageSize;
    /** The set of provided page size options to display to the user. */
    pageSizeOptionsInput: _angular_core.InputSignal<number[] | undefined>;
    get pageSizeOptions(): number[];
    set pageSizeOptions(value: number[]);
    private _pageSizeOptions;
    /** Whether to hide the page size selection UI from the user. */
    hidePageSize: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Whether to show the first/last buttons UI to the user. */
    showFirstLastButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Whether the paginator is disabled. */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Event emitted when the paginator changes the page size or page index. */
    readonly page: _angular_core.OutputEmitterRef<PageEvent>;
    _initialized: Subject<void>;
    initialized: rxjs.Observable<void>;
    _displayedPageSizeOptions: number[];
    private _isInitialized;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** Advances to the next page if it exists. */
    nextPage(): void;
    /** Move back to the previous page if it exists. */
    previousPage(): void;
    /** Move to the first page if not already there. */
    firstPage(): void;
    /** Move to the last page if not already there. */
    lastPage(): void;
    /** Whether there is a previous page. */
    hasPreviousPage(): boolean;
    /** Whether there is a next page. */
    hasNextPage(): boolean;
    /** Calculate the number of pages */
    getNumberOfPages(): number;
    /**
     * Changes the page size so that the first item displayed on the page will still be
     * displayed using the new page size.
     *
     * For example, if the page size is 10 and on the second page (items indexed 10-19) then
     * switching so that the page size is 5 will set the third page as the current page so
     * that the 10th item will still be displayed.
     */
    _changePageSize(pageSize: number): void;
    /** Checks whether the buttons for going forwards should be disabled. */
    _nextButtonsDisabled(): boolean;
    /** Checks whether the buttons for going backwards should be disabled. */
    _previousButtonsDisabled(): boolean;
    /**
     * Updates the list of page size options to display to the user. Includes making sure that
     * the page size is an option and that the list is sorted.
     */
    private _updateDisplayedPageSizeOptions;
    /** Emits a page event and clears the session-cached page index if applicable. */
    private _emitPageEvent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Paginator, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Paginator, "ngs-paginator", ["ngsPaginator"], { "pageIndexInput": { "alias": "pageIndex"; "required": false; "isSignal": true; }; "lengthInput": { "alias": "length"; "required": false; "isSignal": true; }; "pageSizeInput": { "alias": "pageSize"; "required": false; "isSignal": true; }; "pageSizeOptionsInput": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "hidePageSize": { "alias": "hidePageSize"; "required": false; "isSignal": true; }; "showFirstLastButtons": { "alias": "showFirstLastButtons"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "page": "page"; }, never, never, true, never>;
}

export { DEFAULT_PAGE_SIZE, PAGINATOR_DEFAULT_OPTIONS, PageEvent, Paginator, PaginatorIntl };
export type { PaginatorDefaultOptions };
