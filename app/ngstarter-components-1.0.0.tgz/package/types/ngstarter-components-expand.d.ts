import * as _angular_core from '@angular/core';

declare class Expand {
    private _elementRef;
    expanded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    color: _angular_core.InputSignal<string>;
    expandLabel: _angular_core.InputSignal<string>;
    collapseLabel: _angular_core.InputSignal<string>;
    showButtonIfExpanded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    height: _angular_core.InputSignal<string>;
    readonly expandedChange: _angular_core.OutputEmitterRef<boolean>;
    protected _expanded: boolean;
    constructor();
    get api(): {
        expand: () => void;
        collapse: () => void;
        toggle: () => void;
    };
    private _toggle;
    private _expand;
    private _collapse;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Expand, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Expand, "ngs-expand", ["ngsExpand"], { "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "expandLabel": { "alias": "expandLabel"; "required": false; "isSignal": true; }; "collapseLabel": { "alias": "collapseLabel"; "required": false; "isSignal": true; }; "showButtonIfExpanded": { "alias": "showButtonIfExpanded"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; }, never, ["*"], true, never>;
}

export { Expand };
