import * as _angular_core from '@angular/core';
import { AfterViewInit } from '@angular/core';

interface CropSelection {
    shape: 'rectangle' | 'circle';
    pixels: {
        top: number;
        right: number;
        bottom: number;
        left: number;
        width: number;
        height: number;
    };
    percentages: {
        top: number;
        right: number;
        bottom: number;
        left: number;
    };
    containerWidth: number;
    containerHeight: number;
}
interface CropInset {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
type DragHandle = 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'top' | 'right' | 'bottom' | 'left' | 'move';
declare class Crop implements AfterViewInit {
    minWidth: _angular_core.InputSignal<number>;
    minHeight: _angular_core.InputSignal<number>;
    shape: _angular_core.InputSignal<"rectangle" | "circle">;
    selectionApplied: _angular_core.OutputEmitterRef<CropSelection>;
    isCircle: _angular_core.Signal<boolean>;
    selection: _angular_core.WritableSignal<CropInset>;
    private elementRef;
    private activeDragHandle;
    private startDragPosition;
    private startDragSelection;
    constructor();
    ngAfterViewInit(): void;
    private resetSelectionToSquare;
    selectionStyle: _angular_core.Signal<{
        top: string;
        right: string;
        bottom: string;
        left: string;
    }>;
    onDragStart(event: MouseEvent, handle: DragHandle): void;
    onDragEnd(): void;
    private emitSelection;
    onDrag(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Crop, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Crop, "ngs-crop", never, { "minWidth": { "alias": "minWidth"; "required": false; "isSignal": true; }; "minHeight": { "alias": "minHeight"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; }, { "selectionApplied": "selectionApplied"; }, never, ["*"], true, never>;
}

export { Crop };
export type { CropSelection };
