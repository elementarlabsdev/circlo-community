import * as _angular_core from '@angular/core';
import { AfterViewInit, ElementRef } from '@angular/core';
import { ControlValueAccessor, Validator, AbstractControl, ValidationErrors } from '@angular/forms';

/**
 * Represents the different states that require custom transitions between them.
 * @docs-private
 */
declare enum TransitionCheckState {
    /** The initial state of the component before any user interaction. */
    Init = 0,
    /** The state representing the component when it's becoming checked. */
    Checked = 1,
    /** The state representing the component when it's becoming unchecked. */
    Unchecked = 2,
    /** The state representing the component when it's becoming indeterminate. */
    Indeterminate = 3
}
/** Change event object emitted by checkbox. */
declare class CheckboxChange {
    /** The source checkbox of the event. */
    source: Checkbox;
    /** The new `checked` value of the checkbox. */
    checked: boolean;
}
declare class Checkbox implements ControlValueAccessor, Validator, AfterViewInit {
    private _ngZone;
    private _idGenerator;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaLabelledby: _angular_core.InputSignal<string | null>;
    readonly ariaDescribedby: _angular_core.InputSignal<string>;
    readonly ariaExpanded: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly ariaControls: _angular_core.InputSignal<string>;
    readonly ariaOwns: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly labelPosition: _angular_core.InputSignal<"before" | "after">;
    readonly name: _angular_core.InputSignal<string | null>;
    readonly value: _angular_core.InputSignal<string>;
    readonly disableRipple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tabIndex: _angular_core.InputSignalWithTransform<number, any>;
    readonly color: _angular_core.InputSignal<string | undefined>;
    readonly disabledInteractive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly checked: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly indeterminate: _angular_core.ModelSignal<boolean>;
    readonly change: _angular_core.OutputEmitterRef<CheckboxChange>;
    readonly indeterminateChange: _angular_core.OutputEmitterRef<boolean>;
    readonly _inputElement: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    readonly _labelElement: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    private _currentAnimationClass;
    private _currentCheckState;
    private _controlValueAccessorChangeFn;
    private _validatorChangeFn;
    _onTouched: () => void;
    private _animationClasses;
    constructor();
    get inputId(): string;
    ngAfterViewInit(): void;
    focus(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    validate(control: AbstractControl<boolean>): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    toggle(): void;
    _handleInputClick(): void;
    _emitChangeEvent(): void;
    private _createChangeEvent;
    _onInteractionEvent(event: Event): void;
    _onBlur(): void;
    private _transitionCheckState;
    private _getAnimationClassForCheckStateTransition;
    private _syncIndeterminate;
    _onInputClick(): void;
    _onTouchTargetClick(): void;
    _preventBubblingFromLabel(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Checkbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Checkbox, "ngs-checkbox", ["ngsCheckbox"], { "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "ariaExpanded": { "alias": "aria-expanded"; "required": false; "isSignal": true; }; "ariaControls": { "alias": "aria-controls"; "required": false; "isSignal": true; }; "ariaOwns": { "alias": "aria-owns"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disableRipple": { "alias": "disableRipple"; "required": false; "isSignal": true; }; "tabIndex": { "alias": "tabIndex"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "disabledInteractive": { "alias": "disabledInteractive"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "disabled": "disabledChange"; "indeterminate": "indeterminateChange"; "change": "change"; "indeterminateChange": "indeterminateChange"; }, never, ["*", "[ngsCheckboxDecription]"], true, never>;
}

declare class CheckboxDescription {
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxDescription, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CheckboxDescription, "[ngsCheckboxDescription]", never, {}, {}, never, never, true, never>;
}

declare class CheckboxGroup {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CheckboxGroup, "ngs-checkbox-group", never, {}, {}, never, ["*"], true, never>;
}

export { Checkbox, CheckboxChange, CheckboxDescription, CheckboxGroup, TransitionCheckState };
