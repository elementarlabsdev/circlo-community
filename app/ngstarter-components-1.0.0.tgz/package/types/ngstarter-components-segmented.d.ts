import * as _angular_core from '@angular/core';
import { OnInit, OnChanges, AfterContentInit, Signal, ElementRef, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { BooleanInput } from '@angular/cdk/coercion';
import * as i1 from '@ngstarter/components/core';

declare class Segmented implements OnInit, OnChanges, AfterContentInit, ControlValueAccessor {
    private _elementRef;
    private _renderer;
    private _cdr;
    private _destroyRef;
    private _isDestroyed;
    protected _disabled: boolean;
    readonly _buttons: Signal<readonly any[]>;
    readonly _buttonElements: Signal<readonly ElementRef<any>[]>;
    _thumbWidth: number;
    _thumbLeft: number;
    _thumbOpacity: number;
    value: _angular_core.InputSignal<unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    size: _angular_core.InputSignal<string>;
    readonly valueChange: _angular_core.OutputEmitterRef<any>;
    private _selectedValue;
    _onChange: any;
    _onTouched: any;
    get api(): {
        isSelected: (value: any) => boolean;
        select: (value: any) => void;
    };
    constructor();
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    _onResize(): void;
    private _updateThumb;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: BooleanInput): void;
    private _select;
    isSelected(value: any): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Segmented, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Segmented, "ngs-segmented", ["ngsSegmented"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, ["_buttons", "_buttonElements"], ["ngs-segmented-button,[ngs-segmented-button]"], true, never>;
}

declare class SegmentedButton {
    private _segmented;
    value: _angular_core.InputSignal<any>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    iconOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get _isSelected(): boolean;
    get api(): {
        isSelected: () => boolean;
    };
    protected _handleClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SegmentedButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SegmentedButton, "ngs-segmented-button,[ngs-segmented-button]", ["ngsSegmentedButton"], { "value": { "alias": "value"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsSegmentedIcon]", "*"], true, [{ directive: typeof i1.Ripple; inputs: {}; outputs: {}; }]>;
}

declare class SegmentedIconDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SegmentedIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SegmentedIconDirective, "[ngsSegmentedIcon]", ["ngsSegmentedIcon"], {}, {}, never, never, true, never>;
}

export { Segmented, SegmentedButton, SegmentedIconDirective };
