import * as i0 from '@angular/core';

type CookiePopupAcceptType = 'all' | 'necessary';

declare class CookiePopup {
    private _overlay;
    private _viewContainerRef;
    private _injector;
    private _contentRef;
    cookiePolicyUrl: i0.InputSignal<string>;
    visible: i0.InputSignalWithTransform<boolean, unknown>;
    private _overlayRef;
    readonly cookieAccepted: i0.OutputEmitterRef<CookiePopupAcceptType>;
    constructor();
    acceptNecessaryCookiesOnly(): void;
    acceptAllCookies(): void;
    private _show;
    private _hide;
    static ɵfac: i0.ɵɵFactoryDeclaration<CookiePopup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CookiePopup, "ngs-cookie-popup", ["ngsCookiePopup"], { "cookiePolicyUrl": { "alias": "cookiePolicyUrl"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; }, { "cookieAccepted": "cookieAccepted"; }, never, ["[ngsCookiePopupTitle]", "*", "[ngsCookiePopupAcceptNecessaryOnlyButton]", "[ngsCookiePopupAcceptAllButton]"], true, never>;
}

declare class CookiePopupTitleDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CookiePopupTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CookiePopupTitleDirective, "[ngsCookiePopupTitle]", never, {}, {}, never, never, true, never>;
}

declare class CookiePopupAcceptAllButtonDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<CookiePopupAcceptAllButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CookiePopupAcceptAllButtonDirective, "[ngsCookiePopupAcceptAllButton]", never, {}, {}, never, never, true, never>;
}

declare class CookiePopupAcceptNecessaryOnlyButtonDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CookiePopupAcceptNecessaryOnlyButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CookiePopupAcceptNecessaryOnlyButtonDirective, "[ngsCookiePopupAcceptNecessaryOnlyButton]", never, {}, {}, never, never, true, never>;
}

export { CookiePopup, CookiePopupAcceptAllButtonDirective, CookiePopupAcceptNecessaryOnlyButtonDirective, CookiePopupTitleDirective };
export type { CookiePopupAcceptType };
