import * as _angular_core from '@angular/core';
import { InjectionToken, OnInit } from '@angular/core';

interface CarouselApiInterface {
    previous: () => void;
    next: () => void;
    isPreviousDisabled: () => boolean;
    isNextDisabled: () => boolean;
    selectedIndex: () => number;
}
interface CarouselInterface {
    api: CarouselApiInterface;
}
interface CarouselCardInterface {
    element: HTMLElement;
}
declare const CAROUSEL: InjectionToken<unknown>;
declare const CAROUSEL_CARD: InjectionToken<unknown>;

declare class Carousel {
    private _content;
    private _cards;
    fade: _angular_core.InputSignalWithTransform<boolean, unknown>;
    snapToCenter: _angular_core.InputSignal<boolean>;
    snapDebounceTime: _angular_core.InputSignal<number>;
    snapDuration: _angular_core.InputSignal<number>;
    resistanceFactor: _angular_core.InputSignal<number>;
    velocityThreshold: _angular_core.InputSignal<number>;
    visibilityDebounceTime: _angular_core.InputSignal<number>;
    stopPropagation: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly indexChange: _angular_core.OutputEmitterRef<number>;
    protected _index: _angular_core.WritableSignal<number>;
    get api(): CarouselApiInterface;
    protected onIndexChanged(index: number): void;
    private _previous;
    private _next;
    private _scrollToCard;
    private _visibleInParentViewport;
    private get _isPreviousDisabled();
    private get _isNextDisabled();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Carousel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Carousel, "ngs-carousel", ["ngsCarousel"], { "fade": { "alias": "fade"; "required": false; "isSignal": true; }; "snapToCenter": { "alias": "snapToCenter"; "required": false; "isSignal": true; }; "snapDebounceTime": { "alias": "snapDebounceTime"; "required": false; "isSignal": true; }; "snapDuration": { "alias": "snapDuration"; "required": false; "isSignal": true; }; "resistanceFactor": { "alias": "resistanceFactor"; "required": false; "isSignal": true; }; "velocityThreshold": { "alias": "velocityThreshold"; "required": false; "isSignal": true; }; "visibilityDebounceTime": { "alias": "visibilityDebounceTime"; "required": false; "isSignal": true; }; "stopPropagation": { "alias": "stopPropagation"; "required": false; "isSignal": true; }; }, { "indexChange": "indexChange"; }, ["_cards"], ["ngs-carousel-card,[ngs-carousel-card]", "[ngsCarouselControls]"], true, never>;
}

declare class CarouselCard {
    private _elementRef;
    get element(): HTMLElement;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselCard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CarouselCard, "ngs-carousel-card,[ngs-carousel-card]", ["ngsCarouselCard"], {}, {}, never, ["*"], true, never>;
}

declare class CarouselControlsDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselControlsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CarouselControlsDirective, "[ngsCarouselControls]", never, {}, {}, never, never, true, never>;
}

declare class CarouselPreviousDirective implements OnInit {
    protected _carousel: CarouselInterface | null;
    carousel: _angular_core.InputSignal<CarouselInterface | null>;
    ngOnInit(): void;
    _handleClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselPreviousDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CarouselPreviousDirective, "[ngsCarouselPrevious]", ["ngsCarouselPrevious"], { "carousel": { "alias": "carousel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CarouselNextDirective implements OnInit {
    protected _carousel: CarouselInterface | null;
    carousel: _angular_core.InputSignal<CarouselInterface | null>;
    ngOnInit(): void;
    _handleClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselNextDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CarouselNextDirective, "[ngsCarouselNext]", ["ngsCarouselNext"], { "carousel": { "alias": "carousel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { CAROUSEL, CAROUSEL_CARD, Carousel, CarouselCard, CarouselControlsDirective, CarouselNextDirective, CarouselPreviousDirective };
export type { CarouselApiInterface, CarouselCardInterface, CarouselInterface };
