import * as i0 from '@angular/core';

declare class VisualBuilder {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualBuilder, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualBuilder, "ngs-visual-builder", never, {}, {}, never, never, true, never>;
}

export { VisualBuilder };
