import * as _angular_core from '@angular/core';
import { ElementRef, InjectionToken, Signal, WritableSignal, OnDestroy, AfterContentInit, DoCheck } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { CdkConnectedOverlay, CdkOverlayOrigin } from '@angular/cdk/overlay';
import { _OptionParent, _Option, Optgroup } from '@ngstarter/components/option';
export { Optgroup, Option } from '@ngstarter/components/option';
import { FormFieldControl } from '@ngstarter/components/form-field';

declare class SelectTrigger {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SelectTrigger, "ngs-select-trigger", never, {}, {}, never, never, true, never>;
}

declare class SelectBody {
    _elementRef: ElementRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectBody, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectBody, "ngs-select-body", ["ngsSelectBody"], {}, {}, never, ["*"], true, never>;
}

declare abstract class _Select {
    abstract multiple: Signal<boolean>;
    abstract hideCheckIcon: Signal<boolean>;
    abstract _optionsContentChanges: WritableSignal<number>;
    abstract focus(): void;
}
declare const SELECT: InjectionToken<_Select>;

declare class SelectChange {
    source: Select;
    value: any;
    constructor(source: Select, value: any);
}
declare class Select implements ControlValueAccessor, OnDestroy, AfterContentInit, DoCheck, FormFieldControl<any>, _Select, _OptionParent {
    private _elementRef;
    private _cdr;
    private _destroy;
    private _formField;
    readonly ngControl: NgControl | null;
    readonly stateChanges: _angular_core.WritableSignal<void>;
    private _focused;
    protected readonly selectBody: _angular_core.Signal<readonly SelectBody[]>;
    get focused(): boolean;
    _id: _angular_core.InputSignal<string>;
    get id(): string;
    _placeholder: _angular_core.InputSignal<string | undefined>;
    get placeholder(): string | undefined;
    private _disabled;
    _disabledInput: _angular_core.InputSignalWithTransform<boolean, any>;
    _required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    get required(): boolean;
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    hideCheckIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    tabIndex: _angular_core.InputSignalWithTransform<number, any>;
    ariaDescribedby: _angular_core.InputSignal<string | null>;
    isDisabled: _angular_core.Signal<boolean>;
    get disabled(): boolean;
    readonly selectionChange: _angular_core.OutputEmitterRef<any>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    options: _angular_core.Signal<readonly _Option[]>;
    optionGroups: _angular_core.Signal<readonly Optgroup[]>;
    customTrigger: _angular_core.Signal<readonly SelectTrigger[]>;
    overlayDir: _angular_core.Signal<CdkConnectedOverlay | undefined>;
    panel: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    origin: _angular_core.Signal<CdkOverlayOrigin | undefined>;
    get overlayOrigin(): CdkOverlayOrigin | ElementRef;
    get overlayWidth(): string | number;
    panelOpen: _angular_core.WritableSignal<boolean>;
    _panelPosition: _angular_core.WritableSignal<"top" | "bottom">;
    private _selectionModel;
    private _selectionChanges;
    value: _angular_core.ModelSignal<any>;
    private _optionsDestroy;
    private _selectionModelDestroy;
    _optionsContentChanges: _angular_core.WritableSignal<number>;
    private _errorState;
    get errorState(): boolean;
    private _empty;
    get empty(): boolean;
    private _shouldLabelFloat;
    get shouldLabelFloat(): boolean;
    _onChange: (value: any) => void;
    _onTouched: () => void;
    constructor();
    get selected(): _Option | _Option[];
    triggerValue: _angular_core.Signal<string>;
    ngAfterContentInit(): void;
    private _resetOptions;
    ngOnDestroy(): void;
    ngDoCheck(): void;
    private updateErrorState;
    toggle(): void;
    open(): void;
    close(): void;
    _onPositionChange(event: any): void;
    _onFocus(): void;
    _onBlur(): void;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    focus(): void;
    _handleKeydown(event: KeyboardEvent): void;
    _onOptionClick(option: _Option): void;
    private _selectOption;
    private _propagateChanges;
    private _setSelectionByValue;
    private _scrollToSelectedOption;
    private _getOptionIndex;
    private _selectValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Select, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Select, "ngs-select", ["ngsSelect"], { "_id": { "alias": "id"; "required": false; "isSignal": true; }; "_placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "_disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; "_required": { "alias": "required"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "hideCheckIcon": { "alias": "hideCheckIcon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "tabIndex": { "alias": "tabIndex"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; "opened": "opened"; "closed": "closed"; "value": "valueChange"; }, ["selectBody", "options", "optionGroups", "customTrigger"], ["ngs-select-trigger", "ngs-select-header", "ngs-select-body", "ngs-optgroup,ngs-option", "*", "ngs-select-footer"], true, never>;
}

declare class SelectHeader {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectHeader, "ngs-select-header", never, {}, {}, never, ["*"], true, never>;
}

declare class SelectFooter {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectFooter, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectFooter, "ngs-select-footer", never, {}, {}, never, ["*"], true, never>;
}

export { SELECT, Select, SelectBody, SelectChange, SelectFooter, SelectHeader, SelectTrigger, _Select };
