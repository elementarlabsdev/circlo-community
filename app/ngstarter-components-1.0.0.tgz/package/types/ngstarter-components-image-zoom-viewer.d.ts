import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef, TemplateRef } from '@angular/core';

declare class ImageZoomViewer implements OnDestroy {
    private overlay;
    private viewContainerRef;
    private destroyRef;
    readonly contentImageRef: _angular_core.Signal<ElementRef<any>>;
    readonly zoomedTemplate: _angular_core.Signal<TemplateRef<any>>;
    readonly isZoomed: _angular_core.WritableSignal<boolean>;
    readonly imageSrc: _angular_core.WritableSignal<string>;
    readonly imageAlt: _angular_core.WritableSignal<string>;
    readonly imageRect: _angular_core.WritableSignal<DOMRect | undefined>;
    readonly zoomedTransform: _angular_core.WritableSignal<string>;
    private overlayRef;
    private resizeSubscription?;
    constructor();
    ngOnDestroy(): void;
    toggleZoom(): void;
    openZoom(): void;
    closeZoom(): void;
    private calculateZoom;
    private getImageElement;
    private cleanupListeners;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ImageZoomViewer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ImageZoomViewer, "ngs-image-zoom-viewer", ["ngsImageZoomViewer"], {}, {}, ["contentImageRef"], ["*"], true, never>;
}

declare class ImageZoomViewerImage {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ImageZoomViewerImage, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ImageZoomViewerImage, "[ngsImageZoomViewerImage]", never, {}, {}, never, never, true, never>;
}

export { ImageZoomViewer, ImageZoomViewerImage };
