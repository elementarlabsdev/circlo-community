import * as i0 from '@angular/core';

declare class TextDivider {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextDivider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextDivider, "ngs-text-divider", ["ngsTextDivider"], {}, {}, never, ["*"], true, never>;
}

declare class Divider {
    /** Whether the divider is vertically aligned. */
    vertical: i0.InputSignalWithTransform<boolean, unknown>;
    /** Whether the divider is an inset divider. */
    inset: i0.InputSignalWithTransform<boolean, unknown>;
    fixedHeight: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Divider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Divider, "ngs-divider", ["ngsDivider"], { "vertical": { "alias": "vertical"; "required": false; "isSignal": true; }; "inset": { "alias": "inset"; "required": false; "isSignal": true; }; "fixedHeight": { "alias": "fixedHeight"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { Divider, TextDivider };
