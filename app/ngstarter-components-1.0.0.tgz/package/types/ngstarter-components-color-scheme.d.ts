import * as i0 from '@angular/core';
import { OnInit, TemplateRef } from '@angular/core';
import { TemplatePortal } from '@angular/cdk/portal';
import * as _ngrx_signals from '@ngrx/signals';

declare const COLOR_SCHEME_LOCAL_KEY = "ngstarter-color-scheme";
type ColorScheme = 'light' | 'dark';

declare class ColorSchemeSwitcher implements OnInit {
    private store;
    private viewContainerRef;
    private lightRef;
    private darkRef;
    readonly colorScheme: i0.Signal<ColorScheme>;
    readonly colorSchemeChanged: i0.OutputEmitterRef<ColorScheme>;
    protected portal: TemplatePortal<any>;
    ngOnInit(): void;
    protected toggleScheme(): void;
    private setPortal;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorSchemeSwitcher, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ColorSchemeSwitcher, "ngs-color-scheme-switcher", ["ngsColorSchemeSwitcher"], {}, { "colorSchemeChanged": "colorSchemeChanged"; }, ["lightRef", "darkRef"], never, true, never>;
}

declare class ColorSchemeLightDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorSchemeLightDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ColorSchemeLightDirective, "[ngsColorSchemeLight]", never, {}, {}, never, never, true, never>;
}

declare class ColorSchemeDarkDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColorSchemeDarkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ColorSchemeDarkDirective, "[ngsColorSchemeDark]", never, {}, {}, never, never, true, never>;
}

declare const ColorSchemeStore: i0.Type<{
    theme: i0.Signal<ColorScheme>;
    setScheme: (scheme: ColorScheme) => void;
} & _ngrx_signals.StateSource<{
    theme: ColorScheme;
}>>;

export { COLOR_SCHEME_LOCAL_KEY, ColorSchemeDarkDirective, ColorSchemeLightDirective, ColorSchemeStore, ColorSchemeSwitcher };
export type { ColorScheme };
