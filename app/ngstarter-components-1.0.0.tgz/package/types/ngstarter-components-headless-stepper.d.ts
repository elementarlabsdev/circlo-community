import * as _angular_core from '@angular/core';
import { AbstractControl } from '@angular/forms';

declare class HeadlessStep {
    /** Form control associated with this step */
    stepControl: _angular_core.InputSignal<AbstractControl<any, any, any> | undefined>;
    /** Whether the step is optional */
    optional: _angular_core.InputSignal<boolean>;
    /** Whether the user has interacted with this step (writable signal) */
    readonly interacted: _angular_core.WritableSignal<boolean>;
    /** Whether this step is currently active (writable signal, controlled by Stepper) */
    readonly isActive: _angular_core.WritableSignal<boolean>;
    /** Internal writable signal tracking the validity of the stepControl */
    private readonly _isValid;
    private _destroyRef;
    constructor();
    /** Computed signal indicating if the step is completed */
    readonly completed: _angular_core.Signal<boolean>;
    /**
     * Checks if the step is currently valid.
     * Considers the validity of the associated stepControl if provided.
     * @returns boolean True if the step is valid, false otherwise.
     */
    isValid(): boolean;
    /** Resets the step's interacted state */
    reset(): void;
    /** Sets the active state of the step */
    setActive(active: boolean): void;
    /** Sets the interacted state of the step */
    setInteracted(interacted: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HeadlessStep, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HeadlessStep, "ngs-headless-step", ["ngsHeadlessStep"], { "stepControl": { "alias": "stepControl"; "required": false; "isSignal": true; }; "optional": { "alias": "optional"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HeadlessStepper {
    /** Whether the stepper should operate in linear mode. */
    readonly linear: _angular_core.InputSignalWithTransform<boolean, any>;
    /** The index of the active step (two-way bound). */
    readonly selectedIndex: _angular_core.ModelSignal<number>;
    /** Collection of child StepComponent instances. */
    readonly steps: _angular_core.Signal<readonly HeadlessStep[]>;
    /** Computed signal for the total number of steps. */
    readonly stepsCount: _angular_core.Signal<number>;
    /** The currently selected StepComponent instance. */
    readonly selected: _angular_core.Signal<HeadlessStep | undefined>;
    /** Checks if the user can navigate to the next step. */
    readonly canMoveNext: _angular_core.Signal<boolean>;
    /** Computed signal indicating if the current step is the first step. */
    readonly isFirstStep: _angular_core.Signal<boolean>;
    /** Computed signal indicating if the current step is the last step. */
    readonly isLastStep: _angular_core.Signal<boolean>;
    /** Computed signal calculating the progress percentage. */
    readonly progressPercent: _angular_core.Signal<number>;
    constructor();
    /** Navigates to the next step if possible. */
    next(): void;
    /** Navigates to the previous step if possible. */
    previous(): void;
    /** Resets the stepper to the first step. */
    reset(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HeadlessStepper, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HeadlessStepper, "ngs-headless-stepper", ["ngsHeadlessStepper"], { "linear": { "alias": "linear"; "required": false; "isSignal": true; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; "isSignal": true; }; }, { "selectedIndex": "selectedIndexChange"; }, ["steps"], ["ngs-step"], true, never>;
}

export { HeadlessStep, HeadlessStepper };
