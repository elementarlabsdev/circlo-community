import * as i0 from '@angular/core';
import { EventEmitter, TemplateRef } from '@angular/core';

declare class PictureRef {
    readonly closed: EventEmitter<any>;
    close(): void;
}

interface PictureOptions {
    sourceUrl: string;
    title?: string | undefined;
    caption?: string | undefined;
    description?: string | undefined;
    titleTplRef?: TemplateRef<any> | undefined;
    captionTplRef?: TemplateRef<any> | undefined;
    descriptionTplRef?: TemplateRef<any> | undefined;
}

declare class ImageViewerDirective {
    private _overlay;
    private _injector;
    private _destroyRef;
    get api(): {
        open: (options: PictureOptions) => PictureRef;
    };
    private _open;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageViewerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageViewerDirective, "[ngsImageViewer]", ["ngsImageViewer"], {}, {}, never, never, true, never>;
}

declare class ImageViewerPictureDirective {
    private _imageViewer;
    private _titleTplRef;
    private _captionTplRef;
    private _descriptionTplRef;
    sourceUrl: i0.InputSignal<string>;
    caption: i0.InputSignal<string | undefined>;
    title: i0.InputSignal<string | undefined>;
    description: i0.InputSignal<string | undefined>;
    protected onClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageViewerPictureDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageViewerPictureDirective, "[ngsImageViewerPicture]", ["ngsImageViewerPicture"], { "sourceUrl": { "alias": "sourceUrl"; "required": true; "isSignal": true; }; "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, ["_titleTplRef", "_captionTplRef", "_descriptionTplRef"], never, true, never>;
}

declare class ImageViewerPictureCaptionDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageViewerPictureCaptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageViewerPictureCaptionDirective, "[ngsImageViewerPictureCaption]", never, {}, {}, never, never, true, never>;
}

declare class ImageViewerPictureDescriptionDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageViewerPictureDescriptionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageViewerPictureDescriptionDirective, "[ngsImageViewerPictureDescription]", never, {}, {}, never, never, true, never>;
}

declare class ImageViewerPictureTitleDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageViewerPictureTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageViewerPictureTitleDirective, "[ngsImageViewerPictureTitle]", never, {}, {}, never, never, true, never>;
}

export { ImageViewerDirective, ImageViewerPictureCaptionDirective, ImageViewerPictureDescriptionDirective, ImageViewerPictureDirective, ImageViewerPictureTitleDirective };
