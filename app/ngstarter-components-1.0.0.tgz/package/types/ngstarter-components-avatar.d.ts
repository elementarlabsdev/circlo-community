import * as _angular_core from '@angular/core';
import { InjectionToken, OnInit, OnChanges, AfterViewInit, SimpleChanges } from '@angular/core';

declare const AVATAR_ACCESSOR: InjectionToken<unknown>;
type AvatarPresenceIndicator = 'online' | 'offline' | 'away' | null | string;
type AvatarVariant = 'solid' | 'tonal' | 'outlined' | 'plain' | string;

declare class Avatar implements OnInit, OnChanges, AfterViewInit {
    private _elementRef;
    image: _angular_core.InputSignal<string>;
    variant: _angular_core.InputSignal<string>;
    clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    label: _angular_core.InputSignal<string>;
    alt: _angular_core.InputSignal<string>;
    automaticColor: _angular_core.InputSignal<unknown>;
    presenceIndicator: _angular_core.InputSignal<AvatarPresenceIndicator>;
    protected imageLoaded: boolean;
    protected showLabel: boolean;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onImageLoaded(): void;
    private _setAutomaticColor;
    private _newShade;
    isValidHex(color: any): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Avatar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Avatar, "ngs-avatar,[ngs-avatar]", ["ngsAvatar"], { "image": { "alias": "image"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "automaticColor": { "alias": "automaticColor"; "required": false; "isSignal": true; }; "presenceIndicator": { "alias": "presenceIndicator"; "required": false; "isSignal": true; }; }, {}, never, ["mat-icon,ngs-icon"], true, never>;
}

declare class AvatarGroup {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AvatarGroup, "ngs-avatar-group", ["ngsAvatarGroup"], {}, {}, never, ["*"], true, never>;
}

declare class AvatarMore {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarMore, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AvatarMore, "ngs-avatar-more,[ngs-avatar-more]", ["ngsAvatarMore"], {}, {}, never, ["*"], true, never>;
}

declare class AvatarTotal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarTotal, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AvatarTotal, "ngs-avatar-total,[ngs-avatar-total]", ["ngsAvatarTotal"], {}, {}, never, ["*"], true, never>;
}

interface Preset {
    style: any;
    options?: {
        scale?: number;
        backgroundColor?: string[];
        fontWeight?: number;
    };
}
declare class Dicebear implements OnInit {
    image: _angular_core.InputSignal<string>;
    clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    key: _angular_core.InputSignal<any>;
    preset: _angular_core.InputSignal<string>;
    alt: _angular_core.InputSignal<string | undefined>;
    presenceIndicator: _angular_core.InputSignal<AvatarPresenceIndicator>;
    protected imageLoaded: boolean;
    protected svg: string;
    ngOnInit(): void;
    onImageLoaded(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Dicebear, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Dicebear, "ngs-dicebear,[ngs-dicebear]", ["ngsDicebear"], { "image": { "alias": "image"; "required": false; "isSignal": true; }; "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "key": { "alias": "key"; "required": false; "isSignal": true; }; "preset": { "alias": "preset"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "presenceIndicator": { "alias": "presenceIndicator"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { AVATAR_ACCESSOR, Avatar, AvatarGroup, AvatarMore, AvatarTotal, Dicebear };
export type { AvatarPresenceIndicator, AvatarVariant, Preset };
