import * as i0 from '@angular/core';
import { TemplateRef, AfterContentInit } from '@angular/core';

declare class NotificationDefDirective {
    readonly templateRef: TemplateRef<any>;
    ngsNotificationDef: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotificationDefDirective, "[ngsNotificationDef]", never, { "ngsNotificationDef": { "alias": "ngsNotificationDef"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class NotificationControlsDefDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationControlsDefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotificationControlsDefDirective, "[ngsNotificationControlsDef]", never, {}, {}, never, never, true, never>;
}

interface NotificationInterface {
    actor: any;
    type: string;
    createdAt: string;
    isUnread?: boolean;
    [propName: string]: any;
}

declare class NotificationList<T extends NotificationInterface> implements AfterContentInit {
    readonly defs: i0.Signal<readonly NotificationDefDirective[]>;
    readonly controlsDef: i0.Signal<NotificationControlsDefDirective | undefined>;
    notifications: i0.InputSignal<T[]>;
    static: i0.InputSignalWithTransform<boolean, unknown>;
    protected _initialized: boolean;
    protected _defsMap: Map<string, TemplateRef<any>>;
    get controlsTpl(): TemplateRef<any>;
    ngAfterContentInit(): void;
    getNotificationTemplate(type: string): TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationList<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationList<any>, "ngs-notification-list", ["ngsNotificationList"], { "notifications": { "alias": "notifications"; "required": false; "isSignal": true; }; "static": { "alias": "static"; "required": false; "isSignal": true; }; }, {}, ["defs", "controlsDef"], never, true, never>;
}

declare class NotificationSkeleton {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationSkeleton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationSkeleton, "ngs-notification-skeleton", ["ngsNotificationSkeleton"], {}, {}, never, never, true, never>;
}

declare class NotificationTime {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationTime, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationTime, "ngs-notification-time,[ngs-notification-time]", ["ngsNotificationTime"], {}, {}, never, ["*"], true, never>;
}

declare class NotificationActor {
    private elementRef;
    protected get asLink(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationActor, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationActor, "ngs-notification-actor,[ngs-notification-actor]", never, {}, {}, never, ["*"], true, never>;
}

declare class NotificationMessage {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationMessage, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationMessage, "ngs-notification-message", ["ngsNotificationMessage"], {}, {}, never, ["*"], true, never>;
}

declare class Notification {
    isUnread: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Notification, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Notification, "ngs-notification,[ngs-notification]", ["ngsNotification"], { "isUnread": { "alias": "isUnread"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsNotificationAvatar]", "ngs-notification-message,[ngs-notification-message]", "ngs-notification-content,[ngs-notification-content]", "ngs-notification-time,[ngs-notification-time]"], true, never>;
}

declare class NotificationContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationContent, "ngs-notification-content,[ngs-notification-content]", ["ngsNotificationContent"], {}, {}, never, ["*"], true, never>;
}

declare class NotificationPropsDirective {
    isUnread: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationPropsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotificationPropsDirective, "[ngsNotificationProps]", ["ngsNotificationProps"], { "isUnread": { "alias": "isUnread"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class NotificationAvatarDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationAvatarDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NotificationAvatarDirective, "[ngsNotificationAvatar]", ["ngsNotificationAvatar"], {}, {}, never, never, true, never>;
}

export { Notification, NotificationActor, NotificationAvatarDirective, NotificationContent, NotificationControlsDefDirective, NotificationDefDirective, NotificationList, NotificationMessage, NotificationPropsDirective, NotificationSkeleton, NotificationTime };
export type { NotificationInterface };
