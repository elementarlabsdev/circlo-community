import * as i0 from '@angular/core';

declare class EmptyState {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyState, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyState, "ngs-empty-state", ["ngsEmptyState"], {}, {}, never, ["*"], true, never>;
}

declare class EmptyStateImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateImage, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateImage, "ngs-empty-state-image", ["ngsEmptyStateImage"], {}, {}, never, ["*"], true, never>;
}

declare class EmptyStateIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateIcon, "ngs-empty-state-icon", ["ngsEmptyStateIcon"], {}, {}, never, ["*"], true, never>;
}

declare class EmptyStateTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateTitle, "ngs-empty-state-title,[ngs-empty-state-title]", ["ngsEmptyStateTitle"], {}, {}, never, ["*"], true, never>;
}

declare class EmptyStateContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateContent, "ngs-empty-state-content", ["ngsEmptyStateContent"], {}, {}, never, ["*"], true, never>;
}

declare class EmptyStateActions {
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyStateActions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmptyStateActions, "ngs-empty-state-actions", ["ngsEmptyStateActions"], {}, {}, never, ["*"], true, never>;
}

export { EmptyState, EmptyStateActions, EmptyStateContent, EmptyStateIcon, EmptyStateImage, EmptyStateTitle };
