import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';

declare class BlockLoader {
    readonly loading: i0.InputSignalWithTransform<boolean, unknown>;
    readonly spinnerDiameter: i0.InputSignalWithTransform<number, unknown>;
    readonly spinnerStrokeWidth: i0.InputSignalWithTransform<number, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BlockLoader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BlockLoader, "ngs-block-loader", ["ngsBlockLoader"], { "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "spinnerDiameter": { "alias": "spinnerDiameter"; "required": false; "isSignal": true; }; "spinnerStrokeWidth": { "alias": "spinnerStrokeWidth"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class BlockLoaderContainerDirective implements OnInit, OnDestroy {
    private elementRef;
    private renderer;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BlockLoaderContainerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BlockLoaderContainerDirective, "[ngsBlockLoaderContainer]", never, {}, {}, never, never, true, never>;
}

export { BlockLoader, BlockLoaderContainerDirective };
