import * as i0 from '@angular/core';
import { TemplateRef, InjectionToken } from '@angular/core';

declare class AlertIconDirective {
    readonly templateRef: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlertIconDirective, "[ngsAlertIcon]", ["ngsAlertIcon"], {}, {}, never, never, true, never>;
}

declare class Alert {
    private _renderer;
    private _elementRef;
    readonly iconRef: i0.Signal<AlertIconDirective | undefined>;
    autoClose: i0.InputSignalWithTransform<number | null, unknown>;
    bordered: i0.InputSignalWithTransform<boolean, unknown>;
    variant: i0.InputSignal<string>;
    readonly closed: i0.OutputEmitterRef<void>;
    private _autoCloseTimeout;
    constructor();
    get api(): {
        close: () => void;
    };
    protected get iconRefTemplate(): TemplateRef<any>;
    private _close;
    static ɵfac: i0.ɵɵFactoryDeclaration<Alert, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Alert, "ngs-alert", ["ngsAlert"], { "autoClose": { "alias": "autoClose"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, ["iconRef"], ["[ngsAlertIcon]", "ngs-alert-title,[ngsAlertTitle]", "*", "[ngsAlertAction]"], true, never>;
}

declare class AlertTitleDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlertTitleDirective, "ngs-alert-title,[ngsAlertTitle]", ["ngsAlertTitle"], {}, {}, never, never, true, never>;
}

declare class AlertCloseDirective {
    private _alert;
    protected _handleClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertCloseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlertCloseDirective, "[ngsAlertClose]", ["ngsAlertClose"], {}, {}, never, never, true, never>;
}

declare class AlertActionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertActionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlertActionDirective, "[ngsAlertAction]", ["ngsAlertAction"], {}, {}, never, never, true, never>;
}

declare const ALERT: InjectionToken<unknown>;
type AlertVariant = 'default' | 'secondary' | 'positive' | 'informative' | 'negative' | 'notice' | string;

export { ALERT, Alert, AlertActionDirective, AlertCloseDirective, AlertIconDirective, AlertTitleDirective };
export type { AlertVariant };
