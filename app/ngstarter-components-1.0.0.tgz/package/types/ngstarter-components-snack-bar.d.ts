import * as i0 from '@angular/core';
import { InjectionToken, ViewContainerRef, OnDestroy, EventEmitter, Type, TemplateRef } from '@angular/core';
import { AriaLivePoliteness } from '@angular/cdk/a11y';
import { Direction } from '@angular/cdk/bidi';
import { Observable } from 'rxjs';
import { OverlayRef } from '@angular/cdk/overlay';
import { BasePortalOutlet, CdkPortalOutlet, ComponentPortal, TemplatePortal } from '@angular/cdk/portal';

/** Injection token that can be used to access the data that was passed in to a snack bar. */
declare const SNACK_BAR_DATA: InjectionToken<any>;
/** Injection token that can be used to specify default snack bar. */
declare const SNACK_BAR_CONFIG: InjectionToken<SnackBarConfig<any>>;
/** Function to provide the snack bar configuration. */
declare function provideSnackBarConfig(config: SnackBarConfig): {
    provide: InjectionToken<SnackBarConfig<any>>;
    useValue: SnackBarConfig<any>;
};
type SnackBarHorizontalPosition = 'start' | 'center' | 'end' | 'left' | 'right';
type SnackBarVerticalPosition = 'top' | 'bottom';
declare class SnackBarConfig<D = any> {
    /** The politeness level for the MatAriaLiveAnnouncer announcement. */
    politeness?: AriaLivePoliteness;
    /** Message to be announced by the LiveAnnouncer. */
    announcementMessage?: string;
    /** The view container that should be used for the snack bar's origin. */
    viewContainerRef?: ViewContainerRef;
    /** The duration in milliseconds to wait before automatically closing the snack bar. */
    duration?: number;
    /** Extra CSS classes to be added to the snack bar container. */
    panelClass?: string | string[];
    /** Text layout direction for the snack bar. */
    direction?: Direction;
    /** The horizontal position to place the snack bar. */
    horizontalPosition?: SnackBarHorizontalPosition;
    /** The vertical position to place the snack bar. */
    verticalPosition?: SnackBarVerticalPosition;
    /** Data being injected into the child component. */
    data?: D | null;
}

declare class SnackBarRef<T> {
    containerInstance: any;
    private _overlayRef;
    /** The instance of the component making up the content of the snack bar. */
    instance: T;
    /** Subject for notifying the user that the snack bar has been dismissed. */
    private readonly _afterDismissed;
    /** Subject for notifying the user that the snack bar has opened and appeared. */
    private readonly _afterOpened;
    constructor(containerInstance: any, _overlayRef: OverlayRef);
    /** Dismisses the snack bar. */
    dismiss(): void;
    /** Gets an observable that is notified when the snack bar is finished closing. */
    afterDismissed(): Observable<void>;
    /** Gets an observable that is notified when the snack bar has opened and appeared. */
    afterOpened(): Observable<void>;
}

declare class SnackBarContainer extends BasePortalOutlet implements OnDestroy {
    snackBarConfig: SnackBarConfig;
    readonly _portalOutlet: i0.Signal<CdkPortalOutlet>;
    private _cdr;
    private _platformId;
    /** State of the snack bar animation. */
    readonly animationState: i0.WritableSignal<"void" | "visible" | "hidden-top" | "hidden-bottom">;
    readonly leaving: i0.WritableSignal<boolean>;
    /** Event emitted when the snack bar exit animation is finished. */
    readonly _onExit: EventEmitter<void>;
    /** Event emitted when the snack bar enter animation is finished. */
    readonly _onEnter: EventEmitter<void>;
    constructor(snackBarConfig: SnackBarConfig);
    /** Attach a component portal as content to this snack bar container. */
    attachComponentPortal<T>(portal: ComponentPortal<T>): any;
    /** Attach a template portal as content to this snack bar container. */
    attachTemplatePortal<C>(portal: TemplatePortal<C>): any;
    /** Begin animation of snack bar entrance into view. */
    enter(): void;
    /** Begin animation of snack bar exit from view. */
    exit(): void;
    /** Handle end of transition. */
    onTransitionEnd(event: TransitionEvent): void;
    /** Asserts that no content is already attached to the container. */
    private _assertNotAttached;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackBarContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SnackBarContainer, "ngs-snack-bar-container", ["ngsSnackBarContainer"], {}, {}, never, never, true, never>;
}

declare class SimpleSnackBar {
    readonly snackBarRef: SnackBarRef<any>;
    readonly data: any;
    /** Performs the action on the snack bar. */
    action(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleSnackBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleSnackBar, "ngs-simple-snack-bar", ["ngsSimpleSnackBar"], {}, {}, never, never, true, never>;
}

declare class SnackBar {
    private _overlay;
    private _injector;
    private _parentSnackBar;
    private _defaultConfig;
    /** Reference to the currently-opened snack bar. */
    private _openedSnackBarRef;
    /**
     * Opens a snack bar with a message and an optional action.
     */
    open(message: string, action?: string, config?: SnackBarConfig): SnackBarRef<SimpleSnackBar>;
    /**
     * Opens a snack bar with a custom component.
     */
    openFromComponent<T>(component: Type<T>, config?: SnackBarConfig): SnackBarRef<T>;
    /**
     * Opens a snack bar with a custom template.
     */
    openFromTemplate(template: TemplateRef<any>, config?: SnackBarConfig): SnackBarRef<any>;
    /**
     * Dismisses the currently-visible snack bar.
     */
    dismiss(): void;
    /**
     * Attaches the snack bar container and the appropriate content.
     */
    private _attach;
    /**
     * Creates a new overlay and configures it for the snack bar.
     */
    private _createOverlay;
    /**
     * Attaches the snack bar container to the overlay.
     */
    private _attachContainer;
    /**
     * Creates an injector to be used inside of a snack bar component.
     */
    private _createInjector;
    static ɵfac: i0.ɵɵFactoryDeclaration<SnackBar, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SnackBar>;
}

export { SNACK_BAR_CONFIG, SNACK_BAR_DATA, SimpleSnackBar, SnackBar, SnackBarConfig, SnackBarContainer, SnackBarRef, provideSnackBarConfig };
export type { SnackBarHorizontalPosition, SnackBarVerticalPosition };
