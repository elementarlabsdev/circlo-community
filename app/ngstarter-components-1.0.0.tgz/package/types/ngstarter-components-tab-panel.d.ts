import * as i0 from '@angular/core';
import { EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import * as i1 from '@ngstarter/components/core';

declare class TabPanelApiService {
    private _selectionModel;
    readonly itemIdChanged: EventEmitter<any>;
    activate(id: any, emitEvent?: boolean): void;
    isActive(id: any): boolean;
    hasActive(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabPanelApiService>;
}

declare class TabPanel implements OnInit, OnChanges {
    private _destroyRef;
    readonly api: TabPanelApiService;
    hideContentIfTabNotSelected: i0.InputSignalWithTransform<boolean, unknown>;
    activeItemId: i0.InputSignal<any>;
    compact: i0.InputSignalWithTransform<boolean, unknown>;
    readonly itemIdChanged: i0.OutputEmitterRef<void>;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanel, "ngs-tab-panel", ["ngsTabPanel"], { "hideContentIfTabNotSelected": { "alias": "hideContentIfTabNotSelected"; "required": false; "isSignal": true; }; "activeItemId": { "alias": "activeItemId"; "required": false; "isSignal": true; }; "compact": { "alias": "compact"; "required": false; "isSignal": true; }; }, { "itemIdChanged": "itemIdChanged"; }, never, ["ngs-tab-panel-header", "ngs-tab-panel-content", "ngs-tab-panel-footer", "ngs-tab-panel-aside"], true, never>;
}

declare class TabPanelHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelHeader, "ngs-tab-panel-header", ["ngsTabPanelHeader"], {}, {}, never, ["*"], true, never>;
}

declare class TabPanelFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelFooter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelFooter, "ngs-tab-panel-footer", ["ngsTabPanelFooter"], {}, {}, never, ["*"], true, never>;
}

declare class TabPanelItem {
    readonly api: TabPanelApiService;
    private _nav;
    for: i0.InputSignal<any>;
    protected _handleClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelItem, "ngs-tab-panel-item", ["ngsTabPanelItem"], { "for": { "alias": "for"; "required": false; "isSignal": true; }; }, {}, never, ["[ngsTabPanelItemIcon]", "*"], true, [{ directive: typeof i1.Ripple; inputs: {}; outputs: {}; }]>;
}

declare class TabPanelNav {
    nextId: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelNav, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelNav, "ngs-tab-panel-nav", ["ngsTabPanelNav"], {}, {}, never, ["*"], true, never>;
}

declare class TabPanelItemText {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelItemText, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelItemText, "ngs-tab-panel-item-text", ["ngsTabPanelItemText"], {}, {}, never, ["*"], true, never>;
}

declare class TabPanelAside {
    nextId: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelAside, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelAside, "ngs-tab-panel-aside", ["ngsTabPanelAside"], {}, {}, never, ["*"], true, never>;
}

declare class TabPanelContent {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelContent, "ngs-tab-panel-content", ["ngsTabPanelContent"], {}, {}, never, ["*"], true, never>;
}

declare class TabPanelCustomItem {
    readonly api: TabPanelApiService;
    for: i0.InputSignal<any>;
    protected _handleClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelCustomItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelCustomItem, "ngs-tab-panel-custom-item", ["ngsTabPanelCustomItem"], { "for": { "alias": "for"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class TabPanelAsideContentDirective implements OnInit {
    private _aside;
    private _api;
    private _templateRef;
    private _viewContainer;
    private _destroyRef;
    id: i0.InputSignal<any>;
    ngOnInit(): void;
    private _show;
    private _hide;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelAsideContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabPanelAsideContentDirective, "[ngsTabPanelAsideContent]", ["ngsTabPanelAsideContent"], { "id": { "alias": "ngsTabPanelAsideContent"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TabPanelItemIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelItemIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabPanelItemIconDirective, "[ngsTabPanelItemIcon]", ["ngsTabPanelItemIcon"], {}, {}, never, never, true, never>;
}

export { TabPanel, TabPanelAside, TabPanelAsideContentDirective, TabPanelContent, TabPanelCustomItem, TabPanelFooter, TabPanelHeader, TabPanelItem, TabPanelItemIconDirective, TabPanelItemText, TabPanelNav };
