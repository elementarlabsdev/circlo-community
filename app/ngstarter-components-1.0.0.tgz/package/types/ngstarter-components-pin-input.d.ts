import * as _angular_core from '@angular/core';
import { OnInit } from '@angular/core';
import { ControlValueAccessor, FormGroup } from '@angular/forms';

declare class PinInputDirective implements OnInit {
    private _elementRef;
    private _renderer;
    private _placeholder;
    index: _angular_core.InputSignal<number | undefined>;
    acceptOnly: _angular_core.InputSignal<RegExp | undefined>;
    readonly valuePaste: _angular_core.OutputEmitterRef<string>;
    get api(): {
        focus: () => void;
        nativeElement: any;
    };
    ngOnInit(): void;
    protected _handleFocus(): void;
    protected _handleBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PinInputDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PinInputDirective, "[ngsPinInput]", ["ngsPinInput"], { "index": { "alias": "index"; "required": false; "isSignal": true; }; "acceptOnly": { "alias": "acceptOnly"; "required": false; "isSignal": true; }; }, { "valuePaste": "valuePaste"; }, never, never, true, never>;
}

declare class PinInput implements ControlValueAccessor, OnInit {
    private _fb;
    readonly inputs: _angular_core.Signal<readonly PinInputDirective[]>;
    length: _angular_core.InputSignalWithTransform<number, unknown>;
    placeholder: _angular_core.InputSignal<string>;
    acceptOnly: _angular_core.InputSignal<RegExp>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected form: FormGroup;
    private _disabled;
    protected isDisabled: _angular_core.Signal<boolean>;
    onChange: any;
    onTouched: any;
    get controls(): any[];
    ngOnInit(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    protected _valuePaste(event: ClipboardEvent): void;
    protected _handleKeyDown(event: KeyboardEvent): void;
    protected _handleKeyUp(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PinInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PinInput, "ngs-pin-input", ["ngsPinInput"], { "length": { "alias": "length"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "acceptOnly": { "alias": "acceptOnly"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { PinInput };
