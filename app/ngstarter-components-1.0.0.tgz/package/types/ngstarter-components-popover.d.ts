import * as _angular_core from '@angular/core';
import { TemplateRef, InjectionToken, OnInit, OnDestroy } from '@angular/core';
import * as _ngstarter_components_popover from '@ngstarter/components/popover';
import * as _ngstarter_components_overlay from '@ngstarter/components/overlay';
import { OverlayPosition } from '@ngstarter/components/overlay';
import { FlexibleConnectedPositionStrategyOrigin } from '@angular/cdk/overlay';

declare class PopoverContent {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopoverContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PopoverContent, "[ngsPopoverContent]", never, {}, {}, never, never, true, never>;
}

declare class Popover {
    readonly trigger: _ngstarter_components_popover.PopoverTriggerFor | null;
    readonly templateRef: _angular_core.Signal<TemplateRef<any>>;
    readonly content: _angular_core.Signal<PopoverContent | undefined>;
    readonly _context: _angular_core.WritableSignal<any>;
    readonly _positionClasses: _angular_core.WritableSignal<string[]>;
    _setContext(context: any): void;
    _setPositionClasses(classes: string[]): void;
    open(): void;
    close(): void;
    isOpen(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Popover, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Popover, "ngs-popover", ["ngsPopover"], {}, {}, ["content"], ["*"], true, never>;
}

type PopoverTrigger = 'click' | 'hover';
type PopoverPosition = OverlayPosition;
interface PopoverTriggerFor {
    isOpen(): boolean;
    open(): void;
    close(): void;
}
declare const POPOVER_TRIGGER: InjectionToken<PopoverTriggerFor>;

declare class PopoverTriggerForDirective implements OnInit, OnDestroy, PopoverTriggerFor {
    private _overlay;
    private _elementRef;
    private _directionality;
    private _viewContainerRef;
    private _injector;
    private _popoverPortal;
    private _overlayRef;
    private _destroyRef;
    private _openTimeout;
    private _closeTimeout;
    private _closeDelay;
    popover: _angular_core.InputSignal<TemplateRef<any> | Popover>;
    popoverContext: _angular_core.InputSignal<any>;
    trigger: _angular_core.InputSignal<PopoverTrigger>;
    position: _angular_core.InputSignal<_ngstarter_components_overlay.OverlayPosition>;
    delay: _angular_core.InputSignalWithTransform<number, unknown>;
    origin: _angular_core.InputSignal<FlexibleConnectedPositionStrategyOrigin | undefined>;
    closeOnOriginClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    closeOnOriginMouseLeave: _angular_core.InputSignalWithTransform<boolean, unknown>;
    hasBackdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    private _closed;
    constructor();
    protected _handleClick(): void;
    protected _handleMouseover(): void;
    protected _handleMouseout(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    get api(): PopoverTriggerFor;
    isOpen(): boolean;
    open(): void;
    close(): void;
    private _destroyOverlay;
    private _subscribeToOutsideClicks;
    private _getPopoverContentPortal;
    private _getOverlayConfig;
    private _getOverlayPositionStrategy;
    private _getOverlayPositions;
    private _setType;
    private _subscribeToHostMouseleave;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopoverTriggerForDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PopoverTriggerForDirective, "[ngsPopoverTriggerFor]", ["ngsPopoverTriggerFor"], { "popover": { "alias": "ngsPopoverTriggerFor"; "required": true; "isSignal": true; }; "popoverContext": { "alias": "ngsPopoverContext"; "required": false; "isSignal": true; }; "trigger": { "alias": "trigger"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "delay": { "alias": "delay"; "required": false; "isSignal": true; }; "origin": { "alias": "origin"; "required": false; "isSignal": true; }; "closeOnOriginClick": { "alias": "closeOnOriginClick"; "required": false; "isSignal": true; }; "closeOnOriginMouseLeave": { "alias": "closeOnOriginMouseLeave"; "required": false; "isSignal": true; }; "hasBackdrop": { "alias": "hasBackdrop"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

declare class PopoverOriginDirective {
    private _elementRef;
    get api(): {
        nativeElement: () => any;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopoverOriginDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PopoverOriginDirective, "[ngsPopoverOrigin]", ["ngsPopoverOrigin"], {}, {}, never, never, true, never>;
}

export { POPOVER_TRIGGER, Popover, PopoverContent, PopoverOriginDirective, PopoverTriggerForDirective };
export type { PopoverPosition, PopoverTrigger, PopoverTriggerFor };
