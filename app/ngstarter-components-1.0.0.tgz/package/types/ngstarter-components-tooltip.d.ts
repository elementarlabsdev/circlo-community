import * as _angular_core from '@angular/core';
import { InjectionToken, OnDestroy } from '@angular/core';

type TooltipPosition = 'left' | 'right' | 'above' | 'below' | 'before' | 'after';
interface TooltipDefaultOptions {
    showDelay: number;
    hideDelay: number;
    touchendHideDelay: number;
    position?: TooltipPosition;
    offset?: number;
}
declare const TOOLTIP_DEFAULT_OPTIONS: InjectionToken<TooltipDefaultOptions>;
declare class Tooltip implements OnDestroy {
    private _overlay;
    private _elementRef;
    private _viewContainerRef;
    private _dir;
    private _defaultOptions;
    private _platformId;
    private _overlayRef;
    private _tooltipInstance;
    private _portal;
    private readonly _destroyed;
    private _lastPositionAtOrigin;
    private _isContentHovered;
    private _hideTimeoutId;
    readonly message: _angular_core.InputSignal<string>;
    readonly position: _angular_core.InputSignal<TooltipPosition>;
    readonly tooltipClass: _angular_core.InputSignal<any>;
    readonly showDelay: _angular_core.InputSignalWithTransform<number, any>;
    readonly hideDelay: _angular_core.InputSignalWithTransform<number, any>;
    readonly offset: _angular_core.InputSignal<number>;
    readonly positionAtOrigin: _angular_core.InputSignalWithTransform<boolean, any>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, any>;
    constructor();
    ngOnDestroy(): void;
    show(event?: MouseEvent | TouchEvent | FocusEvent, delay?: number): void;
    hide(delay?: number): void;
    toggle(event?: MouseEvent | TouchEvent): void;
    _handleMousedown(event: MouseEvent): void;
    _handleTouchstart(event: TouchEvent): void;
    private _getOrigin;
    private _createOverlay;
    private _detach;
    private _updatePosition;
    private _getPositions;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tooltip, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Tooltip, "[ngsTooltip]", ["ngsTooltip"], { "message": { "alias": "ngsTooltip"; "required": false; "isSignal": true; }; "position": { "alias": "ngsTooltipPosition"; "required": false; "isSignal": true; }; "tooltipClass": { "alias": "ngsTooltipClass"; "required": false; "isSignal": true; }; "showDelay": { "alias": "ngsTooltipShowDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "ngsTooltipHideDelay"; "required": false; "isSignal": true; }; "offset": { "alias": "ngsTooltipOffset"; "required": false; "isSignal": true; }; "positionAtOrigin": { "alias": "ngsTooltipPositionAtOrigin"; "required": false; "isSignal": true; }; "disabled": { "alias": "ngsTooltipDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { TOOLTIP_DEFAULT_OPTIONS, Tooltip };
export type { TooltipDefaultOptions, TooltipPosition };
