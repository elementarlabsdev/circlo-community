import * as _angular_core from '@angular/core';
import { ElementRef, AfterContentInit, Renderer2 } from '@angular/core';

interface ImageResizedEvent {
    width: number;
    height: number;
    naturalWidth: number;
    naturalHeight: number;
}

declare class ImageResizerImageDirective {
    readonly elementRef: ElementRef<HTMLImageElement>;
    protected _onDragStart(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ImageResizerImageDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ImageResizerImageDirective, "[ngsImageResizerImage]", ["ngsImageResizerImage"], {}, {}, never, never, true, never>;
}

declare class ImageResizer implements AfterContentInit {
    protected _platformId: Object;
    protected _elementRef: ElementRef<any>;
    protected _renderer: Renderer2;
    readonly imageRef: _angular_core.Signal<ImageResizerImageDirective>;
    imageMaxWidth: _angular_core.InputSignalWithTransform<number | null, unknown>;
    imageMinWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly imageResized: _angular_core.OutputEmitterRef<ImageResizedEvent>;
    protected _maxWidth: _angular_core.WritableSignal<number | null>;
    constructor();
    ngAfterContentInit(): void;
    onDimensionsChanged(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ImageResizer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ImageResizer, "ngs-image-resizer", ["ngsImageResizer"], { "imageMaxWidth": { "alias": "imageMaxWidth"; "required": false; "isSignal": true; }; "imageMinWidth": { "alias": "imageMinWidth"; "required": false; "isSignal": true; }; }, { "imageResized": "imageResized"; }, ["imageRef"], ["[ngsImageResizerImage]"], true, never>;
}

export { ImageResizer, ImageResizerImageDirective };
export type { ImageResizedEvent };
