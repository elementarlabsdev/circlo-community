import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef } from '@angular/core';

declare class SignaturePad implements OnDestroy {
    penColor: _angular_core.ModelSignal<string>;
    lineWidth: _angular_core.InputSignal<number>;
    backgroundColor: _angular_core.InputSignal<string>;
    lazyRadius: _angular_core.InputSignal<number>;
    lazyFriction: _angular_core.InputSignal<number>;
    lazyEnabled: _angular_core.InputSignal<boolean>;
    colors: _angular_core.InputSignal<string[]>;
    signatureSaved: _angular_core.OutputEmitterRef<string>;
    signatureCleared: _angular_core.OutputEmitterRef<void>;
    mainCanvasRef: _angular_core.Signal<ElementRef<HTMLCanvasElement>>;
    private canvasWidth;
    private canvasHeight;
    private mainContext;
    private memoryCanvasElement;
    private memoryContext;
    private lazyBrushInstance;
    private isDrawing;
    private currentStrokePoints;
    private resizeObserver;
    private platformId;
    private document;
    private subscriptions;
    private pointerDown$;
    constructor();
    ngOnDestroy(): void;
    private setupPointerEvents;
    private setupResizeObserver;
    private initializeLazyBrush;
    private initializeCanvasesAndContexts;
    private configureContextStyling;
    private handlePointerDownLogic;
    private handlePointerMoveLogic;
    private handlePointerUpLogic;
    private drawSmoothStroke;
    private getCoordinates;
    clear(): void;
    save(): void;
    onColorChange(color: string): void;
    private isCanvasEffectivelyBlank;
    handleEscapeKey(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SignaturePad, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SignaturePad, "ngs-signature-pad", ["ngsSignaturePad"], { "penColor": { "alias": "penColor"; "required": false; "isSignal": true; }; "lineWidth": { "alias": "lineWidth"; "required": false; "isSignal": true; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; "isSignal": true; }; "lazyRadius": { "alias": "lazyRadius"; "required": false; "isSignal": true; }; "lazyFriction": { "alias": "lazyFriction"; "required": false; "isSignal": true; }; "lazyEnabled": { "alias": "lazyEnabled"; "required": false; "isSignal": true; }; "colors": { "alias": "colors"; "required": false; "isSignal": true; }; }, { "penColor": "penColorChange"; "signatureSaved": "signatureSaved"; "signatureCleared": "signatureCleared"; }, never, never, true, never>;
}

export { SignaturePad };
