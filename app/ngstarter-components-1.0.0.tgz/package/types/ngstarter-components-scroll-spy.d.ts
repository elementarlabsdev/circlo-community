import * as i0 from '@angular/core';
import { OnInit, AfterContentInit, InjectionToken } from '@angular/core';

declare class ScrollSpyOn implements OnInit {
    private _parent;
    private _elementRef;
    private _renderer;
    private _document;
    targetId: i0.InputSignal<string>;
    ngOnInit(): void;
    protected get isActive(): boolean;
    protected _handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollSpyOn, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollSpyOn, "ngs-scroll-spy-on,[ngs-scroll-spy-on]", ["ngsScrollSpyOn"], { "targetId": { "alias": "targetId"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ScrollSpyNav implements AfterContentInit {
    private document;
    private cdr;
    private platformId;
    private zone;
    private destroyRef;
    private panelBody;
    private layoutBody;
    readonly _items: i0.Signal<readonly ScrollSpyOn[]>;
    private threshold;
    protected _activeId: string;
    private scrollContainer;
    ngAfterContentInit(): void;
    get activeId(): string;
    scrollTo(targetId: string): void;
    private _findActiveItem;
    private _elementIsVisibleInViewport;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollSpyNav, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollSpyNav, "ngs-scroll-spy-nav,[ngs-scroll-spy-nav]", ["ngsScrollSpyNav"], {}, {}, ["_items"], ["ngs-scroll-spy-title,[ngs-scroll-spy-title]", "*", "ngs-scroll-spy-back-to-top,[ngs-scroll-spy-back-to-top]"], true, never>;
}

declare class ScrollSpyTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollSpyTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollSpyTitle, "ngs-scroll-spy-title,[ngs-scroll-spy-title]", ["ngsScrollSpyTitle"], {}, {}, never, ["*"], true, never>;
}

declare class ScrollSpyContainerDirective {
    private elementRef;
    getScrollContainer(): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollSpyContainerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ScrollSpyContainerDirective, "[ngsScrollSpyContainer]", ["ngsScrollSpyContainer"], {}, {}, never, never, true, never>;
}

declare class ScrollSpyBackToTop {
    private platformId;
    private document;
    private panelBody;
    private layoutBody;
    private scrollContainer;
    scrollToTop(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollSpyBackToTop, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollSpyBackToTop, "ngs-scroll-spy-back-to-top,[ngs-scroll-spy-back-to-top]", ["ngsScrollSpyBackToTop"], {}, {}, never, ["*"], true, never>;
}

declare const SCROLL_SPY_NAV: InjectionToken<unknown>;

export { SCROLL_SPY_NAV, ScrollSpyBackToTop, ScrollSpyContainerDirective, ScrollSpyNav, ScrollSpyOn, ScrollSpyTitle };
