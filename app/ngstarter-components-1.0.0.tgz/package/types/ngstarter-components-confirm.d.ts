import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';

interface ConfirmOptions {
    title: string;
    description: string;
}

declare class ConfirmRef {
    readonly canceled: EventEmitter<any>;
    readonly confirmed: EventEmitter<any>;
    readonly closed: EventEmitter<any>;
    close(): void;
    cancel(): void;
    confirm(): void;
}

declare class ConfirmManager {
    private _dialog;
    private _destroyRef;
    open(options: ConfirmOptions): ConfirmRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmManager, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfirmManager>;
}

declare class Confirm {
    private _data;
    title: i0.WritableSignal<any>;
    description: i0.WritableSignal<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Confirm, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Confirm, "ngs-confirm", ["ngsConfirm"], {}, {}, never, never, true, never>;
}

export { Confirm, ConfirmManager, ConfirmRef };
