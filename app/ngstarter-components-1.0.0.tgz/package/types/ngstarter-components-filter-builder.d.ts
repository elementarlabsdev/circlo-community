import * as _angular_core from '@angular/core';
import { TemplateRef, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';

declare class FilterBuilderOperationNameDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterBuilderOperationNameDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FilterBuilderOperationNameDirective, "[ngsFilterBuilderOperationName]", never, {}, {}, never, never, true, never>;
}

declare class FilterBuilderOperationIconDirective {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterBuilderOperationIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FilterBuilderOperationIconDirective, "[ngsFilterBuilderOperationIcon]", never, {}, {}, never, never, true, never>;
}

declare class FilterBuilderOperationDefDirective {
    id: _angular_core.InputSignal<string>;
    allowedDataTypes: _angular_core.InputSignal<string[]>;
    readonly operationName: _angular_core.Signal<FilterBuilderOperationNameDirective | undefined>;
    readonly operationIcon: _angular_core.Signal<FilterBuilderOperationIconDirective | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterBuilderOperationDefDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FilterBuilderOperationDefDirective, "[ngsFilterBuilderOperationDef]", never, { "id": { "alias": "ngsFilterBuilderOperationDef"; "required": false; "isSignal": true; }; "allowedDataTypes": { "alias": "allowedDataTypes"; "required": false; "isSignal": true; }; }, {}, ["operationName", "operationIcon"], never, true, never>;
}

interface FilterBuilderFieldDataSourceItem {
    id: string;
    name: string;
}
interface FilterBuilderFieldDef {
    name: string;
    dataType: string;
    dataField: string;
    format?: string;
    filterOperations?: string[];
    lookup?: {
        dataSource: FilterBuilderFieldDataSourceItem[];
    };
}
interface FilterBuilderCondition {
    value: [string, string, any];
}
interface FilterBuilderGroup {
    logicalOperator?: string;
    value: FilterBuilderItemType[];
}
type FilterBuilderItemType = FilterBuilderCondition | FilterBuilderGroup;

declare class FilterBuilder implements OnInit, AfterViewInit {
    protected _cdr: ChangeDetectorRef;
    protected _isServer: boolean;
    protected _operationAllowedTypesMap: Map<string, string[]>;
    private _resetMethodMap;
    value: _angular_core.InputSignal<FilterBuilderGroup[]>;
    fieldDefs: _angular_core.InputSignal<FilterBuilderFieldDef[]>;
    categories: _angular_core.InputSignal<never[]>;
    groupOperations: _angular_core.InputSignal<{
        id: string;
        name: string;
    }[]>;
    customOperations: _angular_core.InputSignal<never[]>;
    protected _logicalOperator: string;
    readonly _prebuiltOperationDefs: _angular_core.Signal<readonly FilterBuilderOperationDefDirective[]>;
    readonly _customOperationDefs: _angular_core.Signal<readonly FilterBuilderOperationDefDirective[]>;
    protected _operationDefs: FilterBuilderOperationDefDirective[];
    readonly valueChanged: _angular_core.OutputEmitterRef<FilterBuilderGroup[]>;
    protected _value: FilterBuilderGroup[];
    protected _operations: any[];
    protected editItem: FilterBuilderCondition | undefined;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    addCondition(targetGroup?: FilterBuilderGroup): void;
    addGroup(targetGroup?: FilterBuilderGroup): void;
    getConditionField(dataField: string): FilterBuilderFieldDef | undefined;
    getConditionOperation(id: string): any;
    getSelectedGroupOperationName(targetGroup?: FilterBuilderGroup): string;
    selectConditionField(item: FilterBuilderCondition, field: FilterBuilderFieldDef): void;
    operationChanged(item: FilterBuilderCondition, operation: string): void;
    removeCondition(index: number, items: FilterBuilderItemType[]): void;
    isOperationAllowedForCondition(dataField: string, operationId: string): boolean;
    modifyValue(item: FilterBuilderCondition): void;
    getFieldType(item: FilterBuilderCondition): string;
    isValueNotEmpty(item: FilterBuilderCondition): boolean;
    cancelEdit(delay?: number): void;
    getOptions(item: FilterBuilderCondition): FilterBuilderFieldDataSourceItem[];
    getDataSourceItemNameById(item: FilterBuilderCondition, dataSourceItemId: string): string;
    selectBlur(event: FocusEvent): void;
    selectClosed(): void;
    protected operationIconTemplateRef(operation: FilterBuilderOperationDefDirective): TemplateRef<any>;
    protected operationNameTemplateRef(operation: FilterBuilderOperationDefDirective): TemplateRef<any>;
    protected _isGroup(item: FilterBuilderItemType): item is FilterBuilderGroup;
    protected _isCondition(item: FilterBuilderItemType): item is FilterBuilderCondition;
    protected _emitChangeEvent(): void;
    private _getFieldDef;
    private _resetValue;
    private _resetStringValue;
    private _resetNumberValue;
    private _resetArrayValue;
    private _resetBooleanValue;
    private _capitalizeFirstLetter;
    private _normalizeValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterBuilder, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FilterBuilder, "ngs-filter-builder", ["ngsFilterBuilder"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "fieldDefs": { "alias": "fieldDefs"; "required": false; "isSignal": true; }; "categories": { "alias": "categories"; "required": false; "isSignal": true; }; "groupOperations": { "alias": "groupOperations"; "required": false; "isSignal": true; }; "customOperations": { "alias": "customOperations"; "required": false; "isSignal": true; }; }, { "valueChanged": "valueChanged"; }, ["_customOperationDefs"], ["*"], true, never>;
}

export { FilterBuilder, FilterBuilderOperationDefDirective, FilterBuilderOperationIconDirective, FilterBuilderOperationNameDirective };
export type { FilterBuilderCondition, FilterBuilderFieldDataSourceItem, FilterBuilderFieldDef, FilterBuilderGroup, FilterBuilderItemType };
