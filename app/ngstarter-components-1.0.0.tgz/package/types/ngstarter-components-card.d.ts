import * as i0 from '@angular/core';
import { InjectionToken, EnvironmentProviders } from '@angular/core';

declare class CardFooter {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardFooter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardFooter, "ngs-card-footer, [ngs-card-footer], [ngsCardFooter]", never, {}, {}, never, ["*"], true, never>;
}

type CardAppearance = 'raised' | 'outlined' | 'filled';
interface CardConfig {
    appearance?: CardAppearance;
}
declare const CARD_CONFIG: InjectionToken<CardConfig>;
declare function provideCard(config: CardConfig): EnvironmentProviders;

declare class Card {
    private _config;
    appearance: i0.InputSignal<CardAppearance>;
    readonly _footer: i0.Signal<CardFooter | undefined>;
    get hasFooter(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<Card, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Card, "ngs-card", ["ngsCard"], { "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; }, {}, ["_footer"], ["*", "ngs-card-footer"], true, never>;
}

declare class CardHeader {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardHeader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardHeader, "ngs-card-header", never, {}, {}, never, ["ngs-card-avatar, [ngs-card-avatar], [ngsCardAvatar]", "ngs-card-title, [ngs-card-title], [ngsCardTitle]", "ngs-card-subtitle, [ngs-card-subtitle], [ngsCardSubtitle]", "*", "ngs-card-aside, [ngs-card-aside], [ngsCardAside]"], true, never>;
}

declare class CardTitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardTitle, "ngs-card-title, [ngs-card-title], [ngsCardTitle]", ["ngsCardTitle"], {}, {}, never, ["*"], true, never>;
}

declare class CardSubtitle {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardSubtitle, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardSubtitle, "ngs-card-subtitle, [ngs-card-subtitle], [ngsCardSubtitle]", ["ngsCardSubtitle"], {}, {}, never, ["*"], true, never>;
}

declare class CardContent {
    withoutPadding: i0.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardContent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardContent, "ngs-card-content, [ngs-card-content], [ngsCardContent]", ["ngsCardContent"], { "withoutPadding": { "alias": "withoutPadding"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type CardActionsPosition = 'start' | 'center' | 'end' | 'between';
declare class CardActions {
    align: i0.InputSignal<CardActionsPosition>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardActions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardActions, "ngs-card-actions, [ngs-card-actions], [ngsCardActions]", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class CardAside {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardAside, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardAside, "ngs-card-aside, [ngs-card-aside], ngsCardAside", never, {}, {}, never, ["*"], true, never>;
}

declare class CardImage {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardImage, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardImage, "ngs-card-image, [ngs-card-image], [ngsCardImage]", never, {}, {}, never, ["*"], true, never>;
}
declare class CardImageSmall {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardImageSmall, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardImageSmall, "[ngs-card-sm-image], [ngsCardImageSmall]", never, {}, {}, never, never, true, never>;
}
declare class CardImageMedium {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardImageMedium, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardImageMedium, "[ngs-card-md-image], [ngsCardImageMedium]", never, {}, {}, never, never, true, never>;
}
declare class CardImageLarge {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardImageLarge, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardImageLarge, "[ngs-card-lg-image], [ngsCardImageLarge]", never, {}, {}, never, never, true, never>;
}
declare class CardImageXLarge {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardImageXLarge, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardImageXLarge, "[ngs-card-xl-image], [ngsCardImageXLarge]", never, {}, {}, never, never, true, never>;
}

declare class CardAvatar {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardAvatar, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CardAvatar, "ngs-card-avatar, [ngs-card-avatar], [ngsCardAvatar]", never, {}, {}, never, never, true, never>;
}

export { CARD_CONFIG, Card, CardActions, CardAside, CardAvatar, CardContent, CardFooter, CardHeader, CardImage, CardImageLarge, CardImageMedium, CardImageSmall, CardImageXLarge, CardSubtitle, CardTitle, provideCard };
export type { CardActionsPosition, CardAppearance, CardConfig };
