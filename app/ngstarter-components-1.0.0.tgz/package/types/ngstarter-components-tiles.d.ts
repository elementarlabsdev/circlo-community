import * as _angular_core from '@angular/core';
import { OnDestroy, AfterViewInit, InjectionToken } from '@angular/core';
import * as rxjs from 'rxjs';

declare class Tiles {
    private reorder;
    readonly el: HTMLElement;
    readonly element: _angular_core.WritableSignal<HTMLElement | null>;
    readonly order: _angular_core.WritableSignal<Map<Tile, number>>;
    readonly tiles: _angular_core.Signal<readonly Tile[]>;
    readonly items: _angular_core.InputSignal<any[]>;
    readonly gap: _angular_core.InputSignal<string | number>;
    readonly columns: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly orderChange: _angular_core.OutputEmitterRef<Map<number, number>>;
    readonly orderChanged: _angular_core.OutputEmitterRef<any[]>;
    readonly layoutChanged: _angular_core.OutputEmitterRef<any[]>;
    private rearrangeTimer;
    private lastSourceVisualIndex;
    private lastTargetVisualIndex;
    private lastSwapTime;
    private lastSwapX;
    private lastSwapY;
    private initialItems;
    private isInitialized;
    private isDragging;
    constructor();
    private calculateLayout;
    onDragEnd(tile: Tile): void;
    onDragStart(): void;
    rearrange(element: HTMLElement, event: PointerEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tiles, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tiles, "ngs-tiles", ["ngsTiles"], { "items": { "alias": "items"; "required": false; "isSignal": true; }; "gap": { "alias": "gap"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; }, { "orderChange": "orderChange"; "orderChanged": "orderChanged"; "layoutChanged": "layoutChanged"; }, ["tiles"], ["*"], true, never>;
}

declare class Tile implements OnDestroy, AfterViewInit {
    readonly element: HTMLElement;
    private readonly wrapper;
    private readonly service;
    private readonly breakpointObserver;
    private readonly breakpointState;
    protected readonly tiles: Tiles;
    protected readonly dragged: _angular_core.WritableSignal<boolean>;
    protected readonly initialized: _angular_core.WritableSignal<boolean>;
    protected readonly heightPx: _angular_core.WritableSignal<string | null>;
    readonly width: _angular_core.InputSignal<number>;
    readonly widthSm: _angular_core.InputSignal<number | undefined>;
    readonly widthMd: _angular_core.InputSignal<number | undefined>;
    readonly widthLg: _angular_core.InputSignal<number | undefined>;
    readonly widthXl: _angular_core.InputSignal<number | undefined>;
    readonly height: _angular_core.InputSignal<number>;
    readonly heightSm: _angular_core.InputSignal<number | undefined>;
    readonly heightMd: _angular_core.InputSignal<number | undefined>;
    readonly heightLg: _angular_core.InputSignal<number | undefined>;
    readonly heightXl: _angular_core.InputSignal<number | undefined>;
    readonly gridColumn: _angular_core.Signal<string>;
    readonly gridRow: _angular_core.Signal<string>;
    constructor();
    onPointerMove(event: PointerEvent): void;
    onDrag(offset: readonly [number, number], end?: boolean): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tile, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tile, "ngs-tile", ["ngsTile"], { "width": { "alias": "width"; "required": true; "isSignal": true; }; "widthSm": { "alias": "width.sm"; "required": false; "isSignal": true; }; "widthMd": { "alias": "width.md"; "required": false; "isSignal": true; }; "widthLg": { "alias": "width.lg"; "required": false; "isSignal": true; }; "widthXl": { "alias": "width.xl"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": true; "isSignal": true; }; "heightSm": { "alias": "height.sm"; "required": false; "isSignal": true; }; "heightMd": { "alias": "height.md"; "required": false; "isSignal": true; }; "heightLg": { "alias": "height.lg"; "required": false; "isSignal": true; }; "heightXl": { "alias": "height.xl"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class TileService implements OnDestroy {
    private readonly isBrowser;
    private readonly el;
    private readonly tiles;
    private readonly sub;
    private readonly offset$;
    private readonly resize$;
    private readonly mutations$;
    private lastRect;
    private readonly position$;
    init(element?: HTMLElement): void;
    private animate;
    setOffset(offset: readonly [number, number]): void;
    ngOnDestroy(): void;
    private getRect;
    private setRect;
    private setPosition;
    private cleanup;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TileService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TileService>;
}

declare class TileHandleDirective {
    private readonly doc;
    private readonly tile;
    private x;
    private y;
    private startX;
    private startY;
    private isActuallyDragging;
    protected readonly pointerSub: rxjs.Subscription;
    protected onPointer(x?: number, y?: number, end?: boolean): void;
    protected onStart(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TileHandleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TileHandleDirective, "[ngsTileHandle]", never, {}, {}, never, never, true, never>;
}

type ReorderFunction = (order: Map<any, number>, currentVisualIndex: number, newVisualIndex: number) => Map<any, number>;
declare const tilesSwap: ReorderFunction;
declare const tilesShift: ReorderFunction;
declare const TILES_REORDER: InjectionToken<ReorderFunction>;

export { TILES_REORDER, Tile, TileHandleDirective, TileService, Tiles, tilesShift, tilesSwap };
export type { ReorderFunction };
