import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';

declare class PageLoadingBar implements OnInit {
    private _router;
    private _destroyRef;
    private _cdr;
    fixed: i0.InputSignalWithTransform<boolean, unknown>;
    protected visible: boolean;
    protected value: number;
    private _subscription;
    ngOnInit(): void;
    private _start;
    private _finish;
    private _getRandom;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLoadingBar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageLoadingBar, "ngs-page-loading-bar", ["ngsPageLoadingBar"], { "fixed": { "alias": "fixed"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { PageLoadingBar };
