import * as _angular_core from '@angular/core';
import { OnInit, TemplateRef } from '@angular/core';
import * as _ngstarter_components_overlay from '@ngstarter/components/overlay';

declare class EmojiPicker implements OnInit {
    private _trigger;
    private _localeId;
    language: _angular_core.InputSignal<string>;
    selectEmojiLabel: _angular_core.InputSignal<string>;
    readonly emojiSelected: _angular_core.OutputEmitterRef<string>;
    protected loaded: _angular_core.WritableSignal<boolean>;
    protected groups: _angular_core.WritableSignal<any[]>;
    protected _hoveredEmoji: _angular_core.WritableSignal<any>;
    protected _skeletonEmoji: _angular_core.WritableSignal<any[]>;
    ngOnInit(): Promise<void>;
    select(emoji: any): void;
    hoverEmoji(emoji: any): void;
    onMouseLeave(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmojiPicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EmojiPicker, "ngs-emoji-picker", ["ngsEmojiPicker"], { "language": { "alias": "language"; "required": false; "isSignal": true; }; "selectEmojiLabel": { "alias": "selectEmojiLabel"; "required": false; "isSignal": true; }; }, { "emojiSelected": "emojiSelected"; }, never, never, true, never>;
}

declare class EmojiPickerTriggerForDirective {
    private _overlay;
    private _elementRef;
    private _directionality;
    private _viewContainerRef;
    private _injector;
    private _overlayRef;
    private _destroyRef;
    for: _angular_core.InputSignal<TemplateRef<any>>;
    position: _angular_core.InputSignal<_ngstarter_components_overlay.OverlayPosition>;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    get api(): {
        close: () => void;
    };
    protected _onClick(event: Event): void;
    private _close;
    private _subscribeToOutsideClicks;
    private _getPopoverContentPortal;
    private _getOverlayConfig;
    private _getOverlayPositionStrategy;
    private _getOverlayPositions;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmojiPickerTriggerForDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<EmojiPickerTriggerForDirective, "[ngsEmojiPickerTriggerFor]", ["ngsEmojiPickerTriggerFor"], { "for": { "alias": "ngsEmojiPickerTriggerFor"; "required": true; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; }, { "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

export { EmojiPicker, EmojiPickerTriggerForDirective };
