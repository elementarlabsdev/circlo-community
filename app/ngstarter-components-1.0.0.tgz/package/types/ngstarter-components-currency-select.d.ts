import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, ElementRef } from '@angular/core';
import { ControlValueAccessor, NgControl } from '@angular/forms';
import { FormFieldControl } from '@ngstarter/components/form-field';
import { Select, SelectChange } from '@ngstarter/components/select';
import { Subject } from 'rxjs';

interface Currency {
    countryCode: string;
    code: string;
    name: string;
    flag?: string;
    symbol: string;
}

declare class CurrencySelect implements OnInit, OnDestroy, ControlValueAccessor, FormFieldControl<string | null> {
    private _elementRef;
    private _renderer;
    private _formField;
    static nextId: number;
    id: string;
    readonly stateChanges: Subject<void>;
    controlType: string;
    autofilled?: boolean;
    protected searchTerm: _angular_core.ModelSignal<string>;
    private readonly _valueSignal;
    private readonly _focusedSignal;
    private _touched;
    placeholderInputSignal: _angular_core.InputSignal<string>;
    isRequiredSignal: _angular_core.ModelSignal<boolean>;
    isDisabledSignal: _angular_core.ModelSignal<boolean>;
    showCountryName: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly internalCurrencies: Currency[];
    readonly filteredCurrencies: _angular_core.Signal<Currency[]>;
    readonly selectedCurrencyDisplay: _angular_core.Signal<Currency | undefined>;
    readonly ngsSelect: _angular_core.Signal<Select | undefined>;
    readonly searchInput: _angular_core.Signal<ElementRef<HTMLInputElement> | undefined>;
    private readonly fm;
    private readonly elRef;
    readonly ngControl: NgControl | null;
    private readonly destroyRef;
    readonly opened: _angular_core.OutputEmitterRef<void>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    private onChangeFn;
    private onTouchedFn;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    get value(): string | null;
    set value(val: string | null);
    get focused(): boolean;
    onFocusIn(): void;
    onFocusOut(event: any): void;
    get placeholder(): string;
    set placeholder(plh: string);
    get required(): boolean;
    set required(req: boolean);
    get disabled(): boolean;
    set disabled(dis: boolean);
    get empty(): boolean;
    get shouldLabelFloat(): boolean;
    get errorState(): boolean;
    get touched(): boolean;
    setDescribedByIds(ids: string[]): void;
    onContainerClick(): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onSelectionChange(event: SelectChange): void;
    clearSearch(event: MouseEvent): void;
    onSelectOpened(): void;
    onSelectClosed(): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CurrencySelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CurrencySelect, "ngs-currency-select", ["ngsCurrencySelect"], { "searchTerm": { "alias": "searchTerm"; "required": false; "isSignal": true; }; "placeholderInputSignal": { "alias": "placeholder"; "required": false; "isSignal": true; }; "isRequiredSignal": { "alias": "required"; "required": false; "isSignal": true; }; "isDisabledSignal": { "alias": "disabled"; "required": false; "isSignal": true; }; "showCountryName": { "alias": "showCountryName"; "required": false; "isSignal": true; }; }, { "searchTerm": "searchTermChange"; "isRequiredSignal": "requiredChange"; "isDisabledSignal": "disabledChange"; "opened": "opened"; "closed": "closed"; }, never, never, true, never>;
}

declare const currencies: Currency[];

export { CurrencySelect, currencies };
export type { Currency };
